"""
Asset Management Migration Script
Creates the assets table with all necessary columns and indexes
"""

import sqlite3
import sys
import os
from datetime import datetime

def create_assets_table():
    """Create the assets table with all necessary columns"""
    
    # Connect to the database
    db_path = "app.db"
    if not os.path.exists(db_path):
        print(f"Database file {db_path} not found. Please ensure the database exists.")
        return False
    
    try:
        conn = sqlite3.connect(db_path)
        cursor = conn.cursor()
        
        # Create assets table
        create_table_sql = """
        CREATE TABLE IF NOT EXISTS assets (
            id TEXT PRIMARY KEY,
            asset_id TEXT NOT NULL UNIQUE,
            asset_name TEXT NOT NULL,
            business TEXT NOT NULL,
            block TEXT,
            capability TEXT,
            asset_type TEXT NOT NULL,
            asset_status TEXT NOT NULL DEFAULT 'active',
            size_attributes TEXT, -- JSON field
            description TEXT,
            location TEXT,
            owner TEXT,
            contact_person TEXT,
            contact_email TEXT,
            cost REAL,
            currency TEXT DEFAULT 'USD',
            purchase_date DATETIME,
            installation_date DATETIME,
            warranty_expiry DATETIME,
            end_of_life DATETIME,
            vendor TEXT,
            model TEXT,
            version TEXT,
            specifications TEXT, -- JSON field
            dependencies TEXT, -- JSON field
            tags TEXT, -- JSON field
            compliance_requirements TEXT, -- JSON field
            risk_level TEXT,
            criticality TEXT,
            created_date DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            updated_date DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            created_by TEXT,
            updated_by TEXT,
            custom_fields TEXT -- JSON field
        );
        """
        
        cursor.execute(create_table_sql)
        
        # Create indexes for better query performance
        indexes = [
            "CREATE INDEX IF NOT EXISTS idx_assets_asset_id ON assets(asset_id);",
            "CREATE INDEX IF NOT EXISTS idx_assets_asset_name ON assets(asset_name);",
            "CREATE INDEX IF NOT EXISTS idx_assets_business ON assets(business);",
            "CREATE INDEX IF NOT EXISTS idx_assets_block ON assets(block);",
            "CREATE INDEX IF NOT EXISTS idx_assets_capability ON assets(capability);",
            "CREATE INDEX IF NOT EXISTS idx_assets_asset_type ON assets(asset_type);",
            "CREATE INDEX IF NOT EXISTS idx_assets_asset_status ON assets(asset_status);",
            "CREATE INDEX IF NOT EXISTS idx_assets_location ON assets(location);",
            "CREATE INDEX IF NOT EXISTS idx_assets_owner ON assets(owner);",
            "CREATE INDEX IF NOT EXISTS idx_assets_vendor ON assets(vendor);",
            "CREATE INDEX IF NOT EXISTS idx_assets_risk_level ON assets(risk_level);",
            "CREATE INDEX IF NOT EXISTS idx_assets_criticality ON assets(criticality);",
            "CREATE INDEX IF NOT EXISTS idx_assets_created_by ON assets(created_by);",
            "CREATE INDEX IF NOT EXISTS idx_assets_updated_by ON assets(updated_by);",
            "CREATE INDEX IF NOT EXISTS idx_assets_created_date ON assets(created_date);",
            "CREATE INDEX IF NOT EXISTS idx_assets_updated_date ON assets(updated_date);",
        ]
        
        for index_sql in indexes:
            cursor.execute(index_sql)
        
        # Create a trigger to automatically update the updated_date field
        trigger_sql = """
        CREATE TRIGGER IF NOT EXISTS assets_update_timestamp 
        AFTER UPDATE ON assets
        FOR EACH ROW
        BEGIN
            UPDATE assets SET updated_date = CURRENT_TIMESTAMP WHERE id = NEW.id;
        END;
        """
        
        cursor.execute(trigger_sql)
        
        # Commit the changes
        conn.commit()
        
        print("✅ Assets table created successfully with indexes and triggers")
        print("📊 Table structure:")
        
        # Display table info
        cursor.execute("PRAGMA table_info(assets);")
        columns = cursor.fetchall()
        
        for col in columns:
            print(f"   {col[1]} ({col[2]}) - {'NOT NULL' if col[3] else 'NULL'} - {'PRIMARY KEY' if col[5] else ''}")
        
        # Display indexes
        print("\n📋 Indexes created:")
        cursor.execute("SELECT name FROM sqlite_master WHERE type='index' AND tbl_name='assets';")
        indexes = cursor.fetchall()
        for idx in indexes:
            if not idx[0].startswith('sqlite_'):  # Skip auto-created indexes
                print(f"   {idx[0]}")
        
        return True
        
    except sqlite3.Error as e:
        print(f"❌ Database error: {e}")
        return False
    
    except Exception as e:
        print(f"❌ Unexpected error: {e}")
        return False
    
    finally:
        if conn:
            conn.close()

def create_sample_data():
    """Create some sample asset data for testing"""
    
    try:
        conn = sqlite3.connect("app.db")
        cursor = conn.cursor()
        
        sample_assets = [
            {
                'id': 'asset-001-uuid-sample',
                'asset_id': 'IT-HW-001',
                'asset_name': 'Dell PowerEdge R740 Server',
                'business': 'Information Technology',
                'block': 'Infrastructure',
                'capability': 'Server Hosting',
                'asset_type': 'hardware',
                'asset_status': 'active',
                'size_attributes': '{"cpu_cores": 24, "ram_gb": 128, "storage_tb": 2}',
                'description': 'Primary application server for web applications',
                'location': 'Data Center A - Rack 15',
                'owner': 'IT Operations Team',
                'contact_person': 'John Smith',
                'contact_email': 'john.smith@company.com',
                'cost': 25000.00,
                'vendor': 'Dell Technologies',
                'model': 'PowerEdge R740',
                'specifications': '{"cpu": "Intel Xeon Gold 6248", "ram": "128GB DDR4", "storage": "2TB NVMe SSD"}',
                'tags': '["server", "production", "web-app", "high-availability"]',
                'risk_level': 'medium',
                'criticality': 'high',
                'created_by': 'system',
                'updated_by': 'system'
            },
            {
                'id': 'asset-002-uuid-sample',
                'asset_id': 'SW-DB-001',
                'asset_name': 'Oracle Database Enterprise',
                'business': 'Information Technology',
                'block': 'Database Services',
                'capability': 'Data Management',
                'asset_type': 'software',
                'asset_status': 'active',
                'size_attributes': '{"license_count": 4, "storage_gb": 500}',
                'description': 'Enterprise database for customer management system',
                'location': 'Virtual Environment - Cluster 2',
                'owner': 'Database Team',
                'contact_person': 'Jane Doe',
                'contact_email': 'jane.doe@company.com',
                'cost': 75000.00,
                'vendor': 'Oracle Corporation',
                'version': '19c Enterprise Edition',
                'specifications': '{"edition": "Enterprise", "features": ["Advanced Security", "Partitioning", "Analytics"]}',
                'tags': '["database", "enterprise", "customer-data", "mission-critical"]',
                'compliance_requirements': '["SOX", "GDPR", "PCI-DSS"]',
                'risk_level': 'high',
                'criticality': 'critical',
                'created_by': 'system',
                'updated_by': 'system'
            },
            {
                'id': 'asset-003-uuid-sample',
                'asset_id': 'NET-FW-001',
                'asset_name': 'Cisco ASA 5585-X Firewall',
                'business': 'Information Technology',
                'block': 'Network Security',
                'capability': 'Perimeter Security',
                'asset_type': 'security',
                'asset_status': 'active',
                'size_attributes': '{"throughput_gbps": 10, "concurrent_sessions": 1000000}',
                'description': 'Primary perimeter firewall for network security',
                'location': 'Network DMZ - Cabinet 5',
                'owner': 'Network Security Team',
                'contact_person': 'Mike Johnson',
                'contact_email': 'mike.johnson@company.com',
                'cost': 45000.00,
                'vendor': 'Cisco Systems',
                'model': 'ASA 5585-X',
                'specifications': '{"ports": "8x 10GE", "memory": "32GB", "throughput": "10 Gbps"}',
                'tags': '["firewall", "security", "perimeter", "cisco"]',
                'compliance_requirements': '["ISO 27001", "NIST"]',
                'risk_level': 'high',
                'criticality': 'critical',
                'created_by': 'system',
                'updated_by': 'system'
            }
        ]
        
        for asset in sample_assets:
            # Check if asset already exists
            cursor.execute("SELECT id FROM assets WHERE asset_id = ?", (asset['asset_id'],))
            if cursor.fetchone():
                print(f"⚠️  Asset {asset['asset_id']} already exists, skipping...")
                continue
            
            columns = ', '.join(asset.keys())
            placeholders = ', '.join(['?' for _ in asset])
            values = list(asset.values())
            
            cursor.execute(f"INSERT INTO assets ({columns}) VALUES ({placeholders})", values)
            print(f"✅ Created sample asset: {asset['asset_id']} - {asset['asset_name']}")
        
        conn.commit()
        print(f"\n📊 Sample data creation completed!")
        
    except sqlite3.Error as e:
        print(f"❌ Database error while creating sample data: {e}")
        return False
    
    except Exception as e:
        print(f"❌ Unexpected error while creating sample data: {e}")
        return False
    
    finally:
        if conn:
            conn.close()

def main():
    """Main migration function"""
    print("🚀 Starting Asset Management Migration...")
    print("=" * 50)
    
    # Create the assets table
    if create_assets_table():
        print("\n" + "=" * 50)
        
        # Ask if user wants to create sample data
        create_samples = input("Do you want to create sample asset data for testing? (y/N): ").lower().strip()
        
        if create_samples in ['y', 'yes']:
            print("\n📝 Creating sample data...")
            create_sample_data()
        
        print("\n🎉 Migration completed successfully!")
        print("\nNext steps:")
        print("1. Start your FastAPI server")
        print("2. Visit http://localhost:8000/docs to see the Asset Management API")
        print("3. Configure SharePoint integration via the API if needed")
        
    else:
        print("\n❌ Migration failed!")
        sys.exit(1)

if __name__ == "__main__":
    main()

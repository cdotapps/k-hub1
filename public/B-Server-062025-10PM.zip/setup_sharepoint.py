#!/usr/bin/env python3
"""
SharePoint Environment Configuration Helper
This script helps you set up the SharePoint environment variables
"""

import os
import sys
from pathlib import Path

def create_env_file():
    """Create or update .env file with SharePoint configuration"""
    
    print("🔧 SharePoint Environment Configuration")
    print("=" * 40)
    print()
    
    # Check if .env file exists
    env_file = Path(".env")
    env_template = Path(".env.template")
    
    if env_template.exists():
        print("📋 Found .env.template file")
        
        # Read template
        with open(env_template, 'r') as f:
            template_content = f.read()
            
        print("📝 Please provide your SharePoint configuration:")
        print()
        
        # Get SharePoint configuration from user
        site_url = input("SharePoint Site URL (e.g., https://yourcompany.sharepoint.com/sites/yoursite): ").strip()
        list_name = input("SharePoint List Name [Assets]: ").strip() or "Assets"
        client_id = input("Azure AD App Client ID: ").strip()
        client_secret = input("Azure AD App Client Secret: ").strip()
        tenant_id = input("Azure AD Tenant ID: ").strip()
        
        # Validate inputs
        if not all([site_url, client_id, client_secret, tenant_id]):
            print("❌ All fields except List Name are required!")
            return False
            
        # Update template with user values
        updated_content = template_content.replace(
            "SHAREPOINT_SITE_URL=https://yourcompany.sharepoint.com/sites/yoursite",
            f"SHAREPOINT_SITE_URL={site_url}"
        ).replace(
            "SHAREPOINT_LIST_NAME=Assets", 
            f"SHAREPOINT_LIST_NAME={list_name}"
        ).replace(
            "SHAREPOINT_CLIENT_ID=your-azure-app-client-id",
            f"SHAREPOINT_CLIENT_ID={client_id}"
        ).replace(
            "SHAREPOINT_CLIENT_SECRET=your-azure-app-client-secret",
            f"SHAREPOINT_CLIENT_SECRET={client_secret}"
        ).replace(
            "SHAREPOINT_TENANT_ID=your-tenant-id",
            f"SHAREPOINT_TENANT_ID={tenant_id}"
        )
        
        # Write to .env file
        with open(env_file, 'w') as f:
            f.write(updated_content)
            
        print()
        print("✅ Configuration saved to .env file")
        print()
        print("🚀 Next Steps:")
        print("1. Make sure your SharePoint list is set up (see SHAREPOINT_ASSET_SETUP.md)")
        print("2. Start the server: python main.py")
        print("3. Test the connection: POST /api/v1/assets/test-connection")
        
        return True
    else:
        print("❌ .env.template file not found!")
        return False

def check_current_config():
    """Check current SharePoint configuration"""
    print("🔍 Current SharePoint Configuration")
    print("=" * 35)
    print()
    
    try:
        from app.core.config import sharepoint_settings
        
        if sharepoint_settings:
            print("✅ SharePoint is configured:")
            print(f"   Site URL: {sharepoint_settings.site_url}")
            print(f"   List Name: {sharepoint_settings.list_name}")
            print(f"   Tenant ID: {sharepoint_settings.tenant_id}")
            print(f"   Client ID: {sharepoint_settings.client_id[:8]}...")
            print("   Client Secret: [HIDDEN]")
        else:
            print("❌ SharePoint is not configured")
            print()
            print("Missing environment variables:")
            required_vars = [
                "SHAREPOINT_SITE_URL",
                "SHAREPOINT_LIST_NAME", 
                "SHAREPOINT_CLIENT_ID",
                "SHAREPOINT_CLIENT_SECRET",
                "SHAREPOINT_TENANT_ID"
            ]
            
            for var in required_vars:
                value = os.getenv(var)
                status = "✅" if value else "❌"
                print(f"   {status} {var}")
                
    except ImportError:
        print("❌ Cannot import configuration module")
    except Exception as e:
        print(f"❌ Error checking configuration: {e}")

def main():
    """Main function"""
    if len(sys.argv) > 1 and sys.argv[1] == "check":
        check_current_config()
    else:
        print("SharePoint Environment Configuration Helper")
        print()
        print("Options:")
        print("1. Set up SharePoint configuration")
        print("2. Check current configuration")
        print("3. Exit")
        print()
        
        choice = input("Choose an option (1-3): ").strip()
        
        if choice == "1":
            create_env_file()
        elif choice == "2":
            check_current_config()
        elif choice == "3":
            print("Goodbye!")
        else:
            print("Invalid choice!")

if __name__ == "__main__":
    main()

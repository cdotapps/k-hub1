import asyncio
import os
from dotenv import load_dotenv

from app.db.session import async_session, create_tables
from app import crud
from app.schemas.user import UserCreate
from app.schemas.catalog import CatalogCreate, CatalogSearch
from app.models.user import UserRole

# Import the user loading functionality
from load_users import load_users_from_csv_file

load_dotenv()

# Load configuration from environment variables
APP_NAME = os.getenv('APP_NAME', 'User Auth API').lower().replace(' ', '')
ADMIN_USER_ID = os.getenv('ADMIN_USER_ID', 'admin')
ADMIN_EMAIL = f"admin@{APP_NAME}.com"
ADMIN_PASSWORD = os.getenv('ADMIN_PASSWORD', 'admin123')
ADMIN_FIRST_NAME = "System"
ADMIN_LAST_NAME = "Administrator"

# Sample users configuration
SAMPLE_USERS = [
    {
        "user_id": "demo1",
        "email": f"demoemp@{APP_NAME}.com",
        "password": "demo123",
        "first_name": "Demo",
        "last_name": "Employee",
        "role": UserRole.USER,
        "user_type": "employee",
        "organization_id": "ORG001",
        "costcenter_id": "CC001",
        "portfolio_id": "PF001",
        "is_active": True,
        "email_verified": True,
        "designation": "senior associate"
    },
    {
        "user_id": "demo2",
        "email": f"democont@{APP_NAME}.com",
        "password": "demo123",
        "first_name": "Demo",
        "last_name": "Contractor",
        "role": UserRole.USER,
        "user_type": "contractor",
        "organization_id": "ORG002",
        "costcenter_id": "CC002",
        "portfolio_id": "PF002",
        "is_active": True,
        "email_verified": True,
        "designation": "consultant"
    }
]

SAMPLE_NEWS=[];

async def init_db():
    """Initialize database with default admin user, sample users, and sample catalog items"""
    # First, create the database tables
    print("Creating database tables...")
    await create_tables()
    print("Database tables created successfully!")
    
    # Check if CSV file exists and load users from it
    csv_file_path = "users.csv"
    if os.path.exists(csv_file_path):
        print(f"\n📋 Found CSV file: {csv_file_path}")
        print("Loading users from CSV file...")
        await load_users_from_csv_file(csv_file_path)
    else:
        print(f"\nℹ️  No CSV file found ({csv_file_path}). Skipping CSV user import.")
    
    async with async_session() as db:
        # Create admin user
        admin_user = await crud.user.get_by_user_id(db, user_id=ADMIN_USER_ID)
        
        if not admin_user:
            print(f"\nCreating default admin user: {ADMIN_EMAIL}")
            
            # Create admin user
            admin_user_in = UserCreate(
                user_id=ADMIN_USER_ID,
                email=ADMIN_EMAIL,
                password=ADMIN_PASSWORD,
                first_name=ADMIN_FIRST_NAME,
                last_name=ADMIN_LAST_NAME,
                role=UserRole.ADMIN,
                is_superuser=True,
                is_active=True,
                email_verified=True,
                designation="administrator"
            )
            
            admin_user = await crud.user.create(db, obj_in=admin_user_in)
            print(f"✅ Admin user created with ID: {admin_user.id}")
            print(f"   User ID: {ADMIN_USER_ID}, Password: {ADMIN_PASSWORD}")
        else:
            print(f"ℹ️  Admin user already exists: {ADMIN_USER_ID}")

        # Create sample users (only if no CSV was loaded)
        if not os.path.exists(csv_file_path):
            print("\n📝 Creating sample users...")
            for user_data in SAMPLE_USERS:
                existing_user = await crud.user.get_by_user_id(db, user_id=user_data["user_id"])
                
                if not existing_user:
                    user_in = UserCreate(**user_data)
                    new_user = await crud.user.create(db, obj_in=user_in)
                    
                    user_type_icon = "👔" if user_data["user_type"] == "employee" else "🔧"
                    print(f"✅ {user_type_icon} Created {user_data['user_type']}: {user_data['first_name']} {user_data['last_name']}")
                    print(f"   User ID: {user_data['user_id']}, Password: {user_data['password']}")
                    print(f"   Email: {user_data['email']}")
                    print(f"   Organization: {user_data['organization_id']}, Cost Center: {user_data['costcenter_id']}")
                else:
                    print(f"ℹ️  User already exists: {user_data['user_id']}")
        else:
            print("\n✅ Users loaded from CSV file. Skipping sample user creation.")

        # Create sample catalog news items
        print("\n📰 Creating sample news items...")
        for news_data in SAMPLE_NEWS:
            # Check if news item already exists by title
            search_params = CatalogSearch(query=news_data["title"], limit=1, offset=0)
            existing_items, _ = await crud.catalog.search(db, search_params=search_params)
            
            if not existing_items:
                catalog_in = CatalogCreate(**news_data)
                new_catalog = await crud.catalog.create(db, obj_in=catalog_in)
                print(f"✅ 📰 Created news: {news_data['title'][:50]}...")
                print(f"   Category: {news_data['category']}, Status: {news_data['status']}")
                print(f"   Author: {news_data['author']}")
                print(f"   Stats: {news_data['likes']} likes, {news_data['views']} views")
            else:
                print(f"ℹ️  News item already exists: {news_data['title'][:50]}...")

        print("\n🎉 Database initialization completed!")
        print("\n📋 Summary of created content:")
        print("─" * 60)
        print("👑 ADMIN USER:")
        print(f"   User ID: {ADMIN_USER_ID}")
        print(f"   Password: {ADMIN_PASSWORD}")
        print(f"   Email: {ADMIN_EMAIL}")
        
        if os.path.exists(csv_file_path):
            print(f"\n👥 USERS: Loaded from {csv_file_path}")
        else:
            print("\n👥 SAMPLE USERS:")
            for user in SAMPLE_USERS:
                print(f"   User ID: {user['user_id']}, Password: {user['password']}")
        
        print(f"\n📰 SAMPLE NEWS ITEMS: {len(SAMPLE_NEWS)} news articles created")
        print("   - Company AI Analytics Platform Launch")
        print("   - Q1 2025 Financial Results")
        print("   - Sustainability Initiative Success")
        print("   - Employee Wellness Program Expansion")
        print("   - Strategic Technology Partnership")
        print("   - System Maintenance Notification")
        print("─" * 60)

if __name__ == "__main__":
    print("🚀 Initializing database with sample users and catalog content...")
    asyncio.run(init_db())
    print("✅ Database initialization complete!")
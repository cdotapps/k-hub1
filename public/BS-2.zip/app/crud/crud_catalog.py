from typing import Any, Dict, Optional, Union, List
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, update, delete, or_, and_, func
from datetime import datetime
import uuid

from app.models.catalog import Catalog
from app.schemas.catalog import CatalogCreate, CatalogUpdate, CatalogSearch


class CRUDCatalog:
    def __init__(self, model):
        self.model = model

    async def get(self, db: AsyncSession, id: str) -> Optional[Catalog]:
        """Get catalog by id"""
        stmt = select(self.model).where(self.model.id == id)
        result = await db.execute(stmt)
        return result.scalar_one_or_none()

    async def get_multi(
        self, db: AsyncSession, *, skip: int = 0, limit: int = 100
    ) -> List[Catalog]:
        """Get multiple catalogs"""
        stmt = select(self.model).offset(skip).limit(limit).order_by(self.model.created_date.desc())
        result = await db.execute(stmt)
        return result.scalars().all()

    async def create(self, db: AsyncSession, *, obj_in: CatalogCreate) -> Catalog:
        """Create new catalog"""
        # Convert child_ids from CatalogChildItem objects to dict format for JSON storage
        child_ids_data = None
        if obj_in.child_ids:
            child_ids_data = []
            for child_item in obj_in.child_ids:
                if hasattr(child_item, 'model_dump'):
                    child_ids_data.append(child_item.model_dump())
                else:
                    child_ids_data.append(child_item)
        
        db_obj = Catalog(
            id=str(uuid.uuid4()),
            title=obj_in.title,
            description=obj_in.description,
            summary=obj_in.summary,
            type=obj_in.type,
            content=obj_in.content,
            url=obj_in.url,
            image=obj_in.image,
            imageUrl=obj_in.imageUrl,
            display=obj_in.display,
            tags=obj_in.tags,
            author=obj_in.author,
            author_id=getattr(obj_in, 'author_id', None),
            owner_id=getattr(obj_in, 'owner_id', None),
            created_date=obj_in.created_date,
            updated_date=obj_in.updated_date,
            expire_date=obj_in.expire_date,
            due_date=obj_in.due_date,
            custom=obj_in.custom,
            category=obj_in.category,
            parent_id=obj_in.parent_id,
            child_ids=child_ids_data,
            likes=getattr(obj_in, 'likes', 0),
            usages=getattr(obj_in, 'usages', 0),
            favorites=getattr(obj_in, 'favorites', 0),
            views=getattr(obj_in, 'views', 0),
            shares=getattr(obj_in, 'shares', 0),
            approved_by=obj_in.approved_by,
            reviewed_by=obj_in.reviewed_by,
            source=obj_in.source,
            status=obj_in.status,
        )
        db.add(db_obj)
        await db.commit()
        await db.refresh(db_obj)
        return db_obj

    async def update(
        self,
        db: AsyncSession,
        *,
        db_obj: Catalog,
        obj_in: Union[CatalogUpdate, Dict[str, Any]]
    ) -> Catalog:
        """Update catalog"""
        if isinstance(obj_in, dict):
            update_data = obj_in
        else:
            update_data = obj_in.model_dump(exclude_unset=True)
        
        # Convert child_ids from CatalogChildItem objects to dict format for JSON storage
        if 'child_ids' in update_data and update_data['child_ids'] is not None:
            child_ids_data = []
            for child_item in update_data['child_ids']:
                if hasattr(child_item, 'model_dump'):
                    child_ids_data.append(child_item.model_dump())
                elif isinstance(child_item, dict):
                    child_ids_data.append(child_item)
                else:
                    child_ids_data.append(child_item)
            update_data['child_ids'] = child_ids_data
        
        if update_data:
            stmt = (
                update(self.model)
                .where(self.model.id == db_obj.id)
                .values(**update_data)
                .returning(self.model)
            )
            result = await db.execute(stmt)
            await db.commit()
            return result.scalar_one()
        return db_obj

    async def remove(self, db: AsyncSession, *, id: str) -> Catalog:
        """Delete catalog"""
        stmt = select(self.model).where(self.model.id == id)
        result = await db.execute(stmt)
        obj = result.scalar_one_or_none()
        if obj:
            await db.delete(obj)
            await db.commit()
        return obj

    async def search(
        self, db: AsyncSession, *, search_params: CatalogSearch
    ) -> tuple[List[Catalog], int]:
        """Search catalogs with filters"""
        # Base query
        stmt = select(self.model)
        count_stmt = select(func.count(self.model.id))
        
        # Apply filters
        filters = []
        
        # Text search in searchable fields
        if search_params.query:
            search_filters = []
            search_term = f"%{search_params.query}%"
            search_filters.extend([
                self.model.title.ilike(search_term),
                self.model.description.ilike(search_term),
                self.model.summary.ilike(search_term),
                self.model.content.ilike(search_term),
                self.model.tags.ilike(search_term),
                self.model.author.ilike(search_term),
                self.model.source.ilike(search_term),
                self.model.owner_id.ilike(search_term)  # Ensure owner_id is included in text search
            ])
            filters.append(or_(*search_filters))
        
        # Exact match filters
        if search_params.type:
            filters.append(self.model.type == search_params.type)
        if search_params.category:
            filters.append(self.model.category == search_params.category)
        if search_params.status:
            filters.append(self.model.status == search_params.status)
        if search_params.author:
            filters.append(self.model.author == search_params.author)
        if search_params.approved_by:
            filters.append(self.model.approved_by == search_params.approved_by)
        if search_params.reviewed_by:
            filters.append(self.model.reviewed_by == search_params.reviewed_by)
        if search_params.source:
            filters.append(self.model.source == search_params.source)
        if search_params.owner_id:
            filters.append(self.model.owner_id == search_params.owner_id)
        
        # Apply all filters
        if filters:
            stmt = stmt.where(and_(*filters))
            count_stmt = count_stmt.where(and_(*filters))
        
        # Get total count
        count_result = await db.execute(count_stmt)
        total = count_result.scalar()
        
        # Apply pagination and ordering
        stmt = stmt.order_by(self.model.created_date.desc())
        stmt = stmt.offset(search_params.offset).limit(search_params.limit)
        
        # Execute query
        result = await db.execute(stmt)
        items = result.scalars().all()
        
        return items, total

    async def increment_views(self, db: AsyncSession, *, id: str) -> Optional[Catalog]:
        """Increment view count"""
        stmt = (
            update(self.model)
            .where(self.model.id == id)
            .values(views=self.model.views + 1)
            .returning(self.model)
        )
        result = await db.execute(stmt)
        await db.commit()
        return result.scalar_one_or_none()

    async def increment_likes(self, db: AsyncSession, *, id: str) -> Optional[Catalog]:
        """Increment likes count"""
        stmt = (
            update(self.model)
            .where(self.model.id == id)
            .values(likes=self.model.likes + 1)
            .returning(self.model)
        )
        result = await db.execute(stmt)
        await db.commit()
        return result.scalar_one_or_none()

    async def increment_usages(self, db: AsyncSession, *, id: str) -> Optional[Catalog]:
        """Increment usage count"""
        stmt = (
            update(self.model)
            .where(self.model.id == id)
            .values(usages=self.model.usages + 1)
            .returning(self.model)
        )
        result = await db.execute(stmt)
        await db.commit()
        return result.scalar_one_or_none()

    async def get_by_status(
        self, db: AsyncSession, *, status: str, skip: int = 0, limit: int = 100
    ) -> List[Catalog]:
        """Get catalogs by status"""
        stmt = (
            select(self.model)
            .where(self.model.status == status)
            .offset(skip)
            .limit(limit)
            .order_by(self.model.created_date.desc())
        )
        result = await db.execute(stmt)
        return result.scalars().all()

    async def get_by_type(
        self, db: AsyncSession, *, type: str, skip: int = 0, limit: int = 100
    ) -> List[Catalog]:
        """Get catalogs by type"""
        stmt = (
            select(self.model)
            .where(self.model.type == type)
            .offset(skip)
            .limit(limit)
            .order_by(self.model.created_date.desc())
        )
        result = await db.execute(stmt)
        return result.scalars().all()

    async def get_by_author_id(
        self, db: AsyncSession, *, author_id: str, skip: int = 0, limit: int = 100
    ) -> List[Catalog]:
        """Get catalogs by author_id"""
        stmt = (
            select(self.model)
            .where(self.model.author_id == author_id)
            .offset(skip)
            .limit(limit)
            .order_by(self.model.created_date.desc())
        )
        result = await db.execute(stmt)
        return result.scalars().all()

    async def search_with_user_permissions(
        self, db: AsyncSession, *, search_params: CatalogSearch, current_user_id: str, current_user_name: str = None
    ) -> tuple[List[Catalog], int]:
        """Search catalogs with filters and user permission checks (owner, shares, approved_by)"""
        stmt = select(self.model)
        count_stmt = select(func.count(self.model.id))
        filters = []
        print(current_user_id)
        # Text search in searchable fields
        if search_params.query:
            search_filters = []
            search_term = f"%{search_params.query}%"
            search_filters.extend([
                self.model.title.ilike(search_term),
                self.model.description.ilike(search_term),
                self.model.summary.ilike(search_term),
                self.model.content.ilike(search_term),
                self.model.tags.ilike(search_term),
                self.model.author.ilike(search_term),
                self.model.source.ilike(search_term),
                self.model.owner_id.ilike(search_term)  # Ensure owner_id is included in text search
            ])
            filters.append(or_(*search_filters))
        
        # Exact match filters
        if search_params.type:
            filters.append(self.model.type == search_params.type)
        if search_params.category:
            filters.append(self.model.category == search_params.category)
        if search_params.status:
            filters.append(self.model.status == search_params.status)
        if search_params.author:
            filters.append(self.model.author == search_params.author)
        if search_params.approved_by:
            filters.append(self.model.approved_by == search_params.approved_by)
        if search_params.reviewed_by:
            filters.append(self.model.reviewed_by == search_params.reviewed_by)
        if search_params.source:
            filters.append(self.model.source == search_params.source)
        
        # User permission filters: user can see items if:
        # 1. They are in owner array
        # 2. They are in shares array
        # 3. They are in approved_by array
        user_id_str = str(current_user_id)
        permission_filters = or_(
            self.model.owner_id == user_id_str,
            self.model.shared_with.like(f'%{user_id_str}%'),
            self.model.approved_by == user_id_str,
            self.model.author_id == user_id_str
        )
        filters.append(permission_filters)
        
        # Apply all filters
        if filters:
            stmt = stmt.where(and_(*filters))
            count_stmt = count_stmt.where(and_(*filters))
        
        # Get total count
        count_result = await db.execute(count_stmt)
        total = count_result.scalar()
        
        # Apply pagination and ordering
        stmt = stmt.order_by(self.model.created_date.desc())
        stmt = stmt.offset(search_params.offset).limit(search_params.limit)
        
        # Execute query
        result = await db.execute(stmt)
        items = result.scalars().all()
        
        return items, total


catalog = CRUDCatalog(Catalog)
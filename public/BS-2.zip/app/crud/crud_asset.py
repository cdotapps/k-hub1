from typing import Any, Dict, Optional, Union, List
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, update, delete, or_, and_, func, text
from datetime import datetime, timedelta
import uuid

from app.models.asset import Asset
from app.schemas.asset import AssetCreate, AssetUpdate, AssetSearch


class CRUDAsset:
    def __init__(self, model):
        self.model = model

    async def get(self, db: AsyncSession, id: str) -> Optional[Asset]:
        """Get asset by id"""
        stmt = select(self.model).where(self.model.id == id)
        result = await db.execute(stmt)
        return result.scalar_one_or_none()

    async def get_by_asset_id(self, db: AsyncSession, asset_id: str) -> Optional[Asset]:
        """Get asset by business asset ID"""
        stmt = select(self.model).where(self.model.asset_id == asset_id)
        result = await db.execute(stmt)
        return result.scalar_one_or_none()

    async def get_multi(
        self, db: AsyncSession, *, skip: int = 0, limit: int = 100
    ) -> List[Asset]:
        """Get multiple assets"""
        stmt = select(self.model).offset(skip).limit(limit).order_by(self.model.created_date.desc())
        result = await db.execute(stmt)
        return result.scalars().all()

    async def create(self, db: AsyncSession, *, obj_in: AssetCreate, current_user_id: str = None) -> Asset:
        """Create new asset"""
        db_obj = Asset(
            id=str(uuid.uuid4()),
            asset_id=obj_in.asset_id,
            asset_name=obj_in.asset_name,
            business=obj_in.business,
            block=obj_in.block,
            capability=obj_in.capability,
            asset_type=obj_in.asset_type,
            asset_status=obj_in.asset_status,
            size_attributes=obj_in.size_attributes,
            description=obj_in.description,
            location=obj_in.location,
            owner=obj_in.owner,
            contact_person=obj_in.contact_person,
            contact_email=obj_in.contact_email,
            cost=obj_in.cost,
            currency=obj_in.currency,
            purchase_date=obj_in.purchase_date,
            installation_date=obj_in.installation_date,
            warranty_expiry=obj_in.warranty_expiry,
            end_of_life=obj_in.end_of_life,
            vendor=obj_in.vendor,
            model=obj_in.model,
            version=obj_in.version,
            specifications=obj_in.specifications,
            dependencies=obj_in.dependencies,
            tags=obj_in.tags,
            compliance_requirements=obj_in.compliance_requirements,
            risk_level=obj_in.risk_level,
            criticality=obj_in.criticality,
            created_by=current_user_id,
            updated_by=current_user_id,
            custom_fields=obj_in.custom_fields
        )
        db.add(db_obj)
        await db.commit()
        await db.refresh(db_obj)
        return db_obj

    async def update(
        self,
        db: AsyncSession,
        *,
        db_obj: Asset,
        obj_in: Union[AssetUpdate, Dict[str, Any]],
        current_user_id: str = None
    ) -> Asset:
        """Update asset"""
        if isinstance(obj_in, dict):
            update_data = obj_in
        else:
            update_data = obj_in.dict(exclude_unset=True)
        
        # Set updated_by to current user
        if current_user_id:
            update_data["updated_by"] = current_user_id
        
        for field, value in update_data.items():
            if hasattr(db_obj, field):
                setattr(db_obj, field, value)
        
        await db.commit()
        await db.refresh(db_obj)
        return db_obj

    async def remove(self, db: AsyncSession, *, id: str) -> Asset:
        """Delete asset"""
        obj = await self.get(db, id=id)
        await db.delete(obj)
        await db.commit()
        return obj

    async def search(
        self, 
        db: AsyncSession, 
        *, 
        search_params: AssetSearch, 
        skip: int = 0, 
        limit: int = 100
    ) -> List[Asset]:
        """Search assets with filters"""
        stmt = select(self.model)
        
        # Build filters based on search parameters
        filters = []
        
        if search_params.business:
            filters.append(self.model.business.ilike(f"%{search_params.business}%"))
        
        if search_params.block:
            filters.append(self.model.block.ilike(f"%{search_params.block}%"))
        
        if search_params.capability:
            filters.append(self.model.capability.ilike(f"%{search_params.capability}%"))
        
        if search_params.asset_type:
            filters.append(self.model.asset_type == search_params.asset_type)
        
        if search_params.asset_status:
            filters.append(self.model.asset_status == search_params.asset_status)
        
        if search_params.owner:
            filters.append(self.model.owner.ilike(f"%{search_params.owner}%"))
        
        if search_params.vendor:
            filters.append(self.model.vendor.ilike(f"%{search_params.vendor}%"))
        
        if search_params.risk_level:
            filters.append(self.model.risk_level == search_params.risk_level)
        
        if search_params.criticality:
            filters.append(self.model.criticality == search_params.criticality)
        
        if search_params.location:
            filters.append(self.model.location.ilike(f"%{search_params.location}%"))
        
        # Tag filtering (JSON array contains)
        if search_params.tags:
            for tag in search_params.tags:
                filters.append(func.json_contains(self.model.tags, f'"{tag}"'))
        
        # Date range filters
        if search_params.purchase_date_from:
            filters.append(self.model.purchase_date >= search_params.purchase_date_from)
        
        if search_params.purchase_date_to:
            filters.append(self.model.purchase_date <= search_params.purchase_date_to)
        
        if search_params.warranty_expiry_from:
            filters.append(self.model.warranty_expiry >= search_params.warranty_expiry_from)
        
        if search_params.warranty_expiry_to:
            filters.append(self.model.warranty_expiry <= search_params.warranty_expiry_to)
        
        # Cost range filters
        if search_params.cost_min is not None:
            filters.append(self.model.cost >= search_params.cost_min)
        
        if search_params.cost_max is not None:
            filters.append(self.model.cost <= search_params.cost_max)
        
        # General search term
        if search_params.search_term:
            search_term = f"%{search_params.search_term}%"
            search_filters = [
                self.model.asset_id.ilike(search_term),
                self.model.asset_name.ilike(search_term),
                self.model.description.ilike(search_term),
                self.model.business.ilike(search_term),
                self.model.block.ilike(search_term),
                self.model.capability.ilike(search_term),
                self.model.location.ilike(search_term),
                self.model.owner.ilike(search_term),
                self.model.contact_person.ilike(search_term),
                self.model.vendor.ilike(search_term),
                self.model.model.ilike(search_term)
            ]
            filters.append(or_(*search_filters))
        
        # Apply all filters
        if filters:
            stmt = stmt.where(and_(*filters))
        
        # Order and paginate
        stmt = stmt.order_by(self.model.created_date.desc()).offset(skip).limit(limit)
        
        result = await db.execute(stmt)
        return result.scalars().all()

    async def get_by_business(self, db: AsyncSession, business: str) -> List[Asset]:
        """Get all assets for a specific business unit"""
        stmt = select(self.model).where(self.model.business == business)
        result = await db.execute(stmt)
        return result.scalars().all()

    async def get_expiring_warranties(self, db: AsyncSession, days_ahead: int = 30) -> List[Asset]:
        """Get assets with warranties expiring within specified days"""
        cutoff_date = datetime.now() + timedelta(days=days_ahead)
        stmt = select(self.model).where(
            and_(
                self.model.warranty_expiry.isnot(None),
                self.model.warranty_expiry <= cutoff_date,
                self.model.warranty_expiry >= datetime.now()
            )
        )
        result = await db.execute(stmt)
        return result.scalars().all()

    async def get_by_status(self, db: AsyncSession, status: str) -> List[Asset]:
        """Get assets by status"""
        stmt = select(self.model).where(self.model.asset_status == status)
        result = await db.execute(stmt)
        return result.scalars().all()

    async def bulk_update_status(
        self, 
        db: AsyncSession, 
        asset_ids: List[str], 
        new_status: str, 
        current_user_id: str = None
    ) -> int:
        """Bulk update status for multiple assets"""
        update_data = {
            "asset_status": new_status,
            "updated_date": datetime.now()
        }
        if current_user_id:
            update_data["updated_by"] = current_user_id
        
        stmt = (
            update(self.model)
            .where(self.model.id.in_(asset_ids))
            .values(**update_data)
        )
        result = await db.execute(stmt)
        await db.commit()
        return result.rowcount

    async def get_statistics(self, db: AsyncSession) -> Dict[str, Any]:
        """Get asset statistics"""
        # Total count
        total_stmt = select(func.count(self.model.id))
        total_result = await db.execute(total_stmt)
        total_count = total_result.scalar()
        
        # Count by status
        status_stmt = select(
            self.model.asset_status,
            func.count(self.model.id).label('count')
        ).group_by(self.model.asset_status)
        status_result = await db.execute(status_stmt)
        status_counts = {row.asset_status: row.count for row in status_result}
        
        # Count by type
        type_stmt = select(
            self.model.asset_type,
            func.count(self.model.id).label('count')
        ).group_by(self.model.asset_type)
        type_result = await db.execute(type_stmt)
        type_counts = {row.asset_type: row.count for row in type_result}
        
        # Count by business
        business_stmt = select(
            self.model.business,
            func.count(self.model.id).label('count')
        ).group_by(self.model.business)
        business_result = await db.execute(business_stmt)
        business_counts = {row.business: row.count for row in business_result}
        
        return {
            "total_assets": total_count,
            "by_status": status_counts,
            "by_type": type_counts,
            "by_business": business_counts
        }


# Create instance
crud_asset = CRUDAsset(Asset)

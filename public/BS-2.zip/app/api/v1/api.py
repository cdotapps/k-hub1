from fastapi import APIRouter

from app.api.v1.endpoints import auth, users, catalog, webhooks, assets

api_router = APIRouter()

# Authentication routes
api_router.include_router(auth.router, prefix="/auth", tags=["authentication"])

# User management routes
api_router.include_router(users.router, prefix="/users", tags=["users"])

# Catalog routes
api_router.include_router(catalog.router, prefix="/catalog", tags=["catalog"])

# Webhook routes
api_router.include_router(webhooks.router, prefix="/webhooks", tags=["webhooks"])

# Asset management routes
api_router.include_router(assets.router, prefix="/assets", tags=["assets"])
#!/usr/bin/env python3
"""
Simple script to create assets via API
"""

import requests
import json

# API base URL
BASE_URL = "http://localhost:8000/api/v1"

def create_asset(asset_data):
    """Create an asset via API"""
    try:
        # For this demo, we'll bypass authentication
        # In production, you'd need to get a JWT token first
        
        response = requests.post(
            f"{BASE_URL}/assets/",
            json=asset_data,
            headers={
                "Content-Type": "application/json",
                # Note: Authentication is disabled for this demo
            }
        )
        
        if response.status_code == 201:
            asset = response.json()
            print(f"✅ Asset created successfully!")
            print(f"   ID: {asset['id']}")
            print(f"   Asset ID: {asset['asset_id']}")
            print(f"   Name: {asset['asset_name']}")
            return asset
        else:
            print(f"❌ Error creating asset: {response.status_code}")
            print(f"   Response: {response.text}")
            return None
            
    except requests.exceptions.ConnectionError:
        print("❌ Error: Cannot connect to the server. Make sure it's running on http://localhost:8000")
        return None
    except Exception as e:
        print(f"❌ Error: {str(e)}")
        return None

def list_assets():
    """List all assets"""
    try:
        response = requests.get(f"{BASE_URL}/assets/")
        if response.status_code == 200:
            assets = response.json()
            print(f"\n📋 Found {len(assets)} assets:")
            for asset in assets:
                print(f"   • {asset['asset_id']} - {asset['asset_name']} ({asset['asset_status']})")
        else:
            print(f"❌ Error listing assets: {response.status_code}")
    except Exception as e:
        print(f"❌ Error: {str(e)}")

# Sample asset data
sample_assets = [
    {
        "asset_id": "IT-LAP-001",
        "asset_name": "MacBook Pro 16-inch",
        "business": "Marketing",
        "block": "Creative Services",
        "capability": "Content Creation",
        "asset_type": "hardware",
        "asset_status": "active",
        "size_attributes": {
            "screen_size": "16-inch",
            "ram_gb": 32,
            "storage_gb": 1000
        },
        "description": "Marketing team laptop for content creation",
        "location": "Office Floor 2",
        "owner": "Marketing Department",
        "contact_person": "Jane Smith",
        "contact_email": "jane.smith@company.com",
        "cost": 3500.00,
        "currency": "USD",
        "vendor": "Apple",
        "tags": ["laptop", "marketing", "content-creation"]
    },
    {
        "asset_id": "SW-CRM-001",
        "asset_name": "Salesforce Enterprise",
        "business": "Sales",
        "block": "Customer Relations",
        "capability": "CRM",
        "asset_type": "software",
        "asset_status": "active",
        "size_attributes": {
            "users": 50,
            "storage_gb": 100
        },
        "description": "Customer relationship management system",
        "location": "Cloud - Salesforce",
        "owner": "Sales Department",
        "contact_person": "Bob Johnson",
        "contact_email": "bob.johnson@company.com",
        "cost": 12000.00,
        "currency": "USD",
        "vendor": "Salesforce",
        "tags": ["crm", "sales", "customer-management"]
    },
    {
        "asset_id": "NET-SW-001", 
        "asset_name": "Cisco Catalyst 9300 Switch",
        "business": "Information Technology",
        "block": "Network Infrastructure",
        "capability": "Network Switching",
        "asset_type": "network",
        "asset_status": "active",
        "size_attributes": {
            "ports": 48,
            "speed_gbps": 1
        },
        "description": "Core network switch for office connectivity",
        "location": "Network Closet A",
        "owner": "IT Department",
        "contact_person": "Mike Wilson",
        "contact_email": "mike.wilson@company.com",
        "cost": 8000.00,
        "currency": "USD",
        "vendor": "Cisco Systems",
        "tags": ["network", "switch", "infrastructure"]
    }
]

if __name__ == "__main__":
    print("🚀 Asset Creation Tool")
    print("=" * 30)
    
    print("\n1. Creating sample assets...")
    for asset_data in sample_assets:
        create_asset(asset_data)
        print()
    
    print("\n2. Listing all assets...")
    list_assets()
    
    print("\n✨ Done! You can also:")
    print("   • Visit http://localhost:8000/docs to use the interactive API")
    print("   • Modify this script to add your own assets")
    print("   • Use the search endpoints to find assets")

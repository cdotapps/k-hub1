# SharePoint Asset Management Setup Guide

## 🎯 Overview

This system manages your assets directly in SharePoint lists - no local database needed! All your asset data lives in SharePoint, and you use this API to interact with it.

## 📋 SharePoint List Setup

### 1. Create the Assets List in SharePoint

Create a new SharePoint list called "Assets" with these columns:

| Column Name | Type | Required | Description |
|-------------|------|----------|-------------|
| AssetID | Single line of text | ✅ Yes | Unique business asset identifier |
| AssetName | Single line of text | ✅ Yes | Name of the asset |
| Business | Single line of text | ✅ Yes | Business unit |
| Block | Single line of text | No | Block or department |
| Capability | Single line of text | No | Capability area |
| AssetType | Choice | ✅ Yes | Type: Hardware, Software, Service, etc. |
| AssetStatus | Choice | ✅ Yes | Status: Active, Inactive, Maintenance, etc. |
| SizeAttributes | Multiple lines of text | No | JSON data for size info |
| Description | Multiple lines of text | No | Asset description |
| Location | Single line of text | No | Physical/logical location |
| Owner | Single line of text | No | Asset owner |
| ContactPerson | Single line of text | No | Primary contact |
| ContactEmail | Single line of text | No | Contact email |
| Cost | Number | No | Asset cost |
| Currency | Single line of text | No | Currency (default: USD) |
| Vendor | Single line of text | No | Vendor/manufacturer |
| Model | Single line of text | No | Model number |
| Version | Single line of text | No | Version |
| Tags | Multiple lines of text | No | JSON array of tags |
| RiskLevel | Choice | No | Risk: Low, Medium, High, Critical |
| Criticality | Choice | No | Criticality: Low, Medium, High, Critical |

### 2. Set up Choice Values

**AssetType choices:**
- Hardware
- Software
- Service
- Infrastructure
- Application
- Database
- Network
- Security
- Other

**AssetStatus choices:**
- Active
- Inactive
- Maintenance
- Decommissioned
- Pending
- Retired

**RiskLevel & Criticality choices:**
- Low
- Medium
- High
- Critical

## 🔐 Azure AD App Registration

### 1. Create App Registration
1. Go to Azure Portal → Azure Active Directory → App registrations
2. Click "New registration"
3. Name: "Asset Management API"
4. Account types: "Accounts in this organizational directory only"
5. Click "Register"

### 2. Note Important IDs
- **Application (client) ID**
- **Directory (tenant) ID**

### 3. Create Client Secret
1. Go to "Certificates & secrets"
2. Click "New client secret"
3. Description: "Asset API Secret"
4. Expires: Choose appropriate duration
5. Click "Add"
6. **Copy the secret value immediately** (you won't see it again)

### 4. Grant SharePoint Permissions
1. Go to "API permissions"
2. Click "Add a permission"
3. Select "SharePoint"
4. Choose "Application permissions"
5. Add: `Sites.ReadWrite.All`
6. Click "Grant admin consent"

## 🚀 Using the System

### 1. Configure SharePoint Connection

First, configure the API to connect to your SharePoint site:

```bash
curl -X POST "http://localhost:8000/api/v1/assets/configure" \
-H "Authorization: Bearer YOUR_JWT_TOKEN" \
-H "Content-Type: application/json" \
-d '{
  "site_url": "https://yourcompany.sharepoint.com/sites/yoursite",
  "list_name": "Assets",
  "client_id": "your-app-client-id",
  "client_secret": "your-app-client-secret",
  "tenant_id": "your-tenant-id"
}'
```

### 2. Test the Connection

```bash
curl -X POST "http://localhost:8000/api/v1/assets/test-connection" \
-H "Authorization: Bearer YOUR_JWT_TOKEN"
```

### 3. Create Your First Asset

```bash
curl -X POST "http://localhost:8000/api/v1/assets/" \
-H "Authorization: Bearer YOUR_JWT_TOKEN" \
-H "Content-Type: application/json" \
-d '{
  "AssetID": "IT-LAP-001",
  "AssetName": "MacBook Pro 16-inch",
  "Business": "Marketing",
  "Block": "Creative Services",
  "Capability": "Content Creation",
  "AssetType": "Hardware",
  "AssetStatus": "Active",
  "SizeAttributes": "{\"screen_size\": \"16-inch\", \"ram_gb\": 32, \"storage_gb\": 1000}",
  "Description": "Marketing team laptop for content creation",
  "Location": "Office Floor 2",
  "Owner": "Marketing Department",
  "ContactPerson": "Jane Smith",
  "ContactEmail": "jane.smith@company.com",
  "Cost": 3500.00,
  "Currency": "USD",
  "Vendor": "Apple",
  "Tags": "[\"laptop\", \"marketing\", \"content-creation\"]",
  "RiskLevel": "Low",
  "Criticality": "Medium"
}'
```

## 📖 API Endpoints

### Configuration
- `POST /api/v1/assets/configure` - Configure SharePoint connection
- `POST /api/v1/assets/test-connection` - Test connection

### Asset Management
- `GET /api/v1/assets/` - Get all assets
- `POST /api/v1/assets/` - Create new asset
- `GET /api/v1/assets/asset-id/{asset_id}` - Get asset by business ID
- `GET /api/v1/assets/sp-id/{sp_id}` - Get asset by SharePoint ID
- `PUT /api/v1/assets/sp-id/{sp_id}` - Update asset
- `DELETE /api/v1/assets/sp-id/{sp_id}` - Delete asset

### Search & Analytics
- `GET /api/v1/assets/search` - Search assets
- `GET /api/v1/assets/statistics` - Get statistics

## 🔍 Search Examples

**Search by business:**
```
GET /api/v1/assets/search?business=Marketing
```

**Search by type and status:**
```
GET /api/v1/assets/search?asset_type=Hardware&asset_status=Active
```

**General search:**
```
GET /api/v1/assets/search?search_term=laptop
```

## 📊 Data Format

### Size Attributes (JSON string)
```json
{
  "cpu_cores": 8,
  "ram_gb": 32,
  "storage_gb": 500,
  "screen_size": "15-inch"
}
```

### Tags (JSON string)
```json
["laptop", "marketing", "high-priority", "mobile"]
```

## 🎉 Benefits

1. **No Local Database**: All data lives in SharePoint
2. **SharePoint Features**: Use SharePoint's built-in features (permissions, versioning, workflows)
3. **Familiar Interface**: Users can also manage data directly in SharePoint
4. **Integration**: Easy integration with other Microsoft 365 tools
5. **Backup & Security**: Leverage SharePoint's enterprise-grade backup and security

## 🔧 Troubleshooting

### Common Issues

1. **Authentication Errors**
   - Verify client ID, secret, and tenant ID
   - Check app permissions in Azure AD
   - Ensure admin consent was granted

2. **List Not Found**
   - Verify list name spelling
   - Check site URL format
   - Ensure app has access to the site

3. **Permission Denied**
   - Verify SharePoint API permissions
   - Check if admin consent is granted
   - Ensure app has `Sites.ReadWrite.All` permission

### Testing

Use the API documentation at http://localhost:8000/docs to test all endpoints interactively.

The system is now ready to manage your assets directly in SharePoint! 🚀

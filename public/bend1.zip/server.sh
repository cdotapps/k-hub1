# Verify the API can start
print_status "Performing final API validation..."
python -c "
import sys
sys.path.append('.')
try:
    from main import app
    print('✅ API validation successful')
except Exception as e:
    print(f'❌ API validation failed: {e}')
    sys.exit(1)
" || handle_error "API validation"

# Start the server
print_status "Starting FastAPI server..."
echo ""
print_success "🎉 Installation completed successfully!"
echo ""
echo "📚 API Documentation will be available at:"
echo "  • Interactive docs: http://localhost:8000/docs"
echo "  • Alternative docs: http://localhost:8000/redoc"
echo ""
echo "🔗 API Base URL: http://localhost:8000"
echo "🔑 API Endpoints:"
echo "  • POST /api/v1/auth/register - Register new user"
echo "  • POST /api/v1/auth/login - Login user"
echo "  • GET /api/v1/users/me - Get current user profile"
echo "  • GET /api/v1/users/ - List all users (admin only)"
echo ""
print_status "Starting server in development mode..."
echo "Press Ctrl+C to stop the server"
echo ""

# Start the server
python main.py
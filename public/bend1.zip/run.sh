#!/bin/bash

# User Auth API - Clean Installation Script
# This script performs a complete clean installation of the API

set -e  # Exit on any error

echo "🚀 Starting User Auth API Clean Installation..."
echo "=============================================="

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Function to print colored output
print_status() {
    echo -e "${BLUE}[INFO]${NC} $1"
}

print_success() {
    echo -e "${GREEN}[SUCCESS]${NC} $1"
}

print_warning() {
    echo -e "${YELLOW}[WARNING]${NC} $1"
}

print_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

# Function to handle errors
handle_error() {
    print_error "Installation failed at: $1"
    print_error "Please check the error message above and try again."
    exit 1
}

# Check if Python 3 is installed
print_status "Checking Python installation..."
if command -v python3 &> /dev/null; then
    PYTHON_VERSION=$(python3 --version)
    print_success "Found $PYTHON_VERSION"
else
    print_error "Python 3 is not installed. Please install Python 3.8 or higher."
    exit 1
fi

# Check if pip is available
print_status "Checking pip installation..."
if command -v python3 -m pip &> /dev/null; then
    print_success "pip is available"
else
    print_error "pip is not available. Please install pip."
    exit 1
fi

# Clean up previous installation
print_status "Cleaning up previous installation..."

# Remove Python cache files
if [ -d "__pycache__" ]; then
    print_status "Removing Python cache files..."
    find . -type d -name "__pycache__" -exec rm -rf {} + 2>/dev/null || true
    find . -name "*.pyc" -delete 2>/dev/null || true
    print_success "Python cache cleaned"
fi

# Remove existing database
if [ -f "app.db" ]; then
    print_status "Removing existing database..."
    rm -f app.db
    print_success "Database removed"
fi

# Remove existing virtual environment if it exists
if [ -d "venv" ]; then
    print_status "Removing existing virtual environment..."
    rm -rf venv
    print_success "Virtual environment removed"
fi

# Create virtual environment
print_status "Creating virtual environment..."
python3 -m venv venv || handle_error "virtual environment creation"
print_success "Virtual environment created"

# Activate virtual environment
print_status "Activating virtual environment..."
source venv/bin/activate || handle_error "virtual environment activation"
print_success "Virtual environment activated"

# Upgrade pip
print_status "Upgrading pip..."
python -m pip install --upgrade pip || handle_error "pip upgrade"
print_success "pip upgraded"

# Install dependencies
print_status "Installing dependencies from requirements.txt..."
if [ -f "requirements.txt" ]; then
    pip install -r requirements.txt || handle_error "dependency installation"
    print_success "Dependencies installed successfully"
else
    print_error "requirements.txt not found!"
    exit 1
fi

# Verify critical dependencies
print_status "Verifying critical dependencies..."
python -c "import fastapi, uvicorn, sqlalchemy, pydantic; from pydantic import EmailStr" || handle_error "dependency verification"
print_success "All critical dependencies verified"

# Verify environment file
print_status "Checking environment configuration..."
if [ -f ".env" ]; then
    print_success "Environment file found"
else
    print_warning "No .env file found. Using default configuration."
fi

# Initialize database
print_status "Initializing database..."
python init_db.py || handle_error "database initialization"
print_success "Database initialized with default admin user"

# Display admin credentials
print_status "Default Admin Credentials:"
echo "  📧 Email: admin@userauthapi.com"
echo "  🔐 Password: admin123"
echo ""

# Check if server is already running
print_status "Checking if server is already running on port 8000..."
if lsof -Pi :8000 -sTCP:LISTEN -t >/dev/null 2>&1; then
    print_warning "Port 8000 is already in use. Attempting to stop existing process..."
    # Kill process using port 8000
    lsof -ti:8000 | xargs kill -9 2>/dev/null || true
    sleep 2
fi

# Verify the API can start
print_status "Performing final API validation..."
python -c "
import sys
sys.path.append('.')
try:
    from main import app
    print('✅ API validation successful')
except Exception as e:
    print(f'❌ API validation failed: {e}')
    sys.exit(1)
" || handle_error "API validation"

# Start the server
print_status "Starting FastAPI server..."
echo ""
print_success "🎉 Installation completed successfully!"
echo ""
echo "📚 API Documentation will be available at:"
echo "  • Interactive docs: http://localhost:8000/docs"
echo "  • Alternative docs: http://localhost:8000/redoc"
echo ""
echo "🔗 API Base URL: http://localhost:8000"
echo "🔑 API Endpoints:"
echo "  • POST /api/v1/auth/register - Register new user"
echo "  • POST /api/v1/auth/login - Login user"
echo "  • GET /api/v1/users/me - Get current user profile"
echo "  • GET /api/v1/users/ - List all users (admin only)"
echo ""
print_status "Starting server in development mode..."
echo "Press Ctrl+C to stop the server"
echo ""

# Start the server
python main.py
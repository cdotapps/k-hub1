from typing import Any, List
from fastapi import APIRouter, Body, Depends, HTTPException, status, Query, Path, BackgroundTasks
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import or_

from app import crud, models
from app.schemas import catalog as schemas
from app.api import deps
from app.db.session import get_db
from app.services.webhook_service import webhook_service

router = APIRouter()

@router.post("/", response_model=schemas.Catalog)
async def create_catalog(
    *,
    db: AsyncSession = Depends(get_db),
    catalog_in: schemas.CatalogCreate,
    current_user: models.User = Depends(deps.get_current_user),
    background_tasks: BackgroundTasks,
) -> Any:
    """
    Create new catalog item.
    """
    # Set author and author_id to current user if not specified
    if not catalog_in.author:
        catalog_in.author = f"{current_user.first_name} {current_user.last_name}"
    if not catalog_in.author_id:
        catalog_in.author_id = current_user.id
    
    catalog = await crud.catalog.create(db, obj_in=catalog_in)
    
    # Trigger webhook for catalog.created event
    event_data = {
        "catalog_id": catalog.id,
        "title": catalog.title,
        "type": catalog.type,
        "status": catalog.status,
        "author": catalog.author,
        "author_id": catalog.author_id,
        "created_by": current_user.id,
        "user_name": f"{current_user.first_name} {current_user.last_name}"
    }
    background_tasks.add_task(
        webhook_service.trigger_webhooks, 
        db, 
        "catalog.created", 
        event_data
    )
    
    return catalog

@router.get("/", response_model=schemas.CatalogResponse)
async def get_catalogs(
    db: AsyncSession = Depends(get_db),
    current_user: models.User = Depends(deps.get_current_user),
    type: str = Query(None, description="Filter by catalog type (e.g., news, document, tutorial)"),
    query: str = Query(None, description="Search term to find in title, description, content, tags, etc."),
    search: str = Query(None, description="Search term (alias for query)"),
    q: str = Query(None, description="Search term (alias for query)"), 
    title: str = Query(None, description="Search in title field"),
    category: str = Query(None, description="Filter by category"),
    status: str = Query(None, description="Filter by status"),
    author: str = Query(None, description="Filter by author"),
    page: int = Query(1, ge=1, description="Page number (starts from 1)"),
    page_size: int = Query(50, ge=1, le=100, description="Number of items per page"),
    skip: int = Query(None, ge=0, description="Number of items to skip (legacy parameter)"),
    limit: int = Query(None, ge=1, le=100, description="Number of items to return (legacy parameter)"),
) -> Any:
    """
    Get catalog items with pagination, filtering, and search functionality.
    Returns only items that the current user owns, has been shared with, or has approved.
    """
    # Handle pagination - prioritize new format (page/page_size) over legacy (skip/limit)
    if skip is not None and limit is not None:
        offset = skip
        page_limit = limit
        current_page = (skip // limit) + 1 if limit > 0 else 1
    else:
        offset = (page - 1) * page_size
        page_limit = page_size
        current_page = page

    search_term = query or search or q or title

    # Create search parameters
    search_params = schemas.CatalogSearch(
        query=search_term,
        type=type,
        category=category,
        status=status,
        author=author,
        limit=page_limit,
        offset=offset
    )

    # Use the new permission-aware search method
    current_user_name = f"{current_user.first_name} {current_user.last_name}"
    items, total = await crud.catalog.search_with_user_permissions(
        db, search_params=search_params, current_user_id=current_user.id, current_user_name=current_user_name
    )

    return {
        "items": items,
        "total": total,
        "limit": page_limit,
        "offset": offset,
        "page": current_page,
        "page_size": page_limit,
        "total_pages": (total + page_limit - 1) // page_limit if page_limit > 0 else 0
    }

@router.get("/search", response_model=schemas.CatalogResponse)
async def search_catalogs(
    db: AsyncSession = Depends(get_db),
    query: str = Query(None, description="Search term"),
    type: str = Query(None, description="Filter by type"),
    category: str = Query(None, description="Filter by category"),
    status: str = Query(None, description="Filter by status"),
    author: str = Query(None, description="Filter by author"),
    approved_by: str = Query(None, description="Filter by approved_by"),
    reviewed_by: str = Query(None, description="Filter by reviewed_by"),
    source: str = Query(None, description="Filter by source"),
    tags: str = Query(None, description="Filter by tags"),
    skip: int = Query(0, ge=0),
    limit: int = Query(50, ge=1, le=100),
) -> Any:
    """
    Search catalog items with various filters.
    
    This endpoint is public and does not require authentication.
    """
    search_params = schemas.CatalogSearch(
        query=query,
        type=type,
        category=category,
        status=status,
        author=author,
        approved_by=approved_by,
        reviewed_by=reviewed_by,
        source=source,
        tags=tags,
        limit=limit,
        offset=skip
    )
    
    items, total = await crud.catalog.search(db, search_params=search_params)
    
    return {
        "items": items,
        "total": total,
        "limit": limit,
        "offset": skip
    }

@router.get("/{catalog_id}", response_model=schemas.Catalog)
async def get_catalog(
    catalog_id: str,
    db: AsyncSession = Depends(get_db),
) -> Any:
    """
    Get a specific catalog item by ID.
    
    This endpoint is public and does not require authentication.
    """
    catalog = await crud.catalog.get(db, id=catalog_id)
    if not catalog:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Catalog item not found"
        )
    
    # Increment view count
    await crud.catalog.increment_views(db, id=catalog_id)
    
    return catalog

@router.put("/{catalog_id}", response_model=schemas.Catalog)
async def update_catalog(
    *,
    db: AsyncSession = Depends(get_db),
    catalog_id: str,
    catalog_in: schemas.CatalogUpdate,
    current_user: models.User = Depends(deps.get_current_user),
    background_tasks: BackgroundTasks,
) -> Any:
    """
    Update a catalog item.
    """
    catalog = await crud.catalog.get(db, id=catalog_id)
    if not catalog:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Catalog item not found"
        )
    
    # Check permissions - use author_id for more reliable permission checking
    # Fall back to author name comparison for backward compatibility
    is_author = (catalog.author_id == current_user.id or 
                 catalog.author == f"{current_user.first_name} {current_user.last_name}")
    
    if (not is_author and 
        not crud.user.is_admin(current_user) and 
        not crud.user.is_superuser(current_user)):
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Not enough permissions to update this catalog item"
        )
    
    # Store original data for webhook
    original_data = {
        "catalog_id": catalog.id,
        "title": catalog.title,
        "type": catalog.type,
        "status": catalog.status,
        "author": catalog.author
    }
    
    catalog = await crud.catalog.update(db, db_obj=catalog, obj_in=catalog_in)
    
    # Trigger webhook for catalog.updated event
    event_data = {
        "catalog_id": catalog.id,
        "title": catalog.title,
        "type": catalog.type,
        "status": catalog.status,
        "author": catalog.author,
        "updated_by": current_user.id,
        "user_name": f"{current_user.first_name} {current_user.last_name}",
        "changes": catalog_in.model_dump(exclude_unset=True),
        "original": original_data
    }
    background_tasks.add_task(
        webhook_service.trigger_webhooks, 
        db, 
        "catalog.updated", 
        event_data
    )
    
    return catalog

@router.delete("/{catalog_id}")
async def delete_catalog(
    *,
    db: AsyncSession = Depends(get_db),
    catalog_id: str,
    current_user: models.User = Depends(deps.get_current_user),
    background_tasks: BackgroundTasks,
) -> Any:
    """
    Delete a catalog item.
    """
    catalog = await crud.catalog.get(db, id=catalog_id)
    if not catalog:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Catalog item not found"
        )
    
    # Check permissions - use author_id for more reliable permission checking
    # Fall back to author name comparison for backward compatibility
    is_author = (catalog.author_id == current_user.id or 
                 catalog.author == f"{current_user.first_name} {current_user.last_name}")
    
    if (not is_author and 
        not crud.user.is_admin(current_user) and 
        not crud.user.is_superuser(current_user)):
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Not enough permissions to delete this catalog item"
        )
    
    # Store catalog data for webhook before deletion
    event_data = {
        "catalog_id": catalog.id,
        "title": catalog.title,
        "type": catalog.type,
        "status": catalog.status,
        "author": catalog.author,
        "deleted_by": current_user.id,
        "user_name": f"{current_user.first_name} {current_user.last_name}"
    }
    
    await crud.catalog.remove(db, id=catalog_id)
    
    # Trigger webhook for catalog.deleted event
    background_tasks.add_task(
        webhook_service.trigger_webhooks, 
        db, 
        "catalog.deleted", 
        event_data
    )
    
    return {"status": "success", "msg": "Catalog item deleted successfully"}

# Interaction endpoints
@router.post("/{catalog_id}/like", response_model=schemas.Catalog)
async def like_catalog(
    catalog_id: str,
    db: AsyncSession = Depends(get_db),
    current_user: models.User = Depends(deps.get_current_user),
) -> Any:
    """
    Like a catalog item (increment like count).
    """
    catalog = await crud.catalog.increment_likes(db, id=catalog_id)
    if not catalog:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Catalog item not found"
        )
    return catalog

@router.post("/{catalog_id}/use", response_model=schemas.Catalog)
async def use_catalog(
    catalog_id: str,
    db: AsyncSession = Depends(get_db),
    current_user: models.User = Depends(deps.get_current_user),
) -> Any:
    """
    Mark catalog item as used (increment usage count).
    """
    catalog = await crud.catalog.increment_usages(db, id=catalog_id)
    if not catalog:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Catalog item not found"
        )
    return catalog

# Admin endpoints
@router.patch("/{catalog_id}/approve", response_model=schemas.Catalog)
async def approve_catalog(
    *,
    db: AsyncSession = Depends(get_db),
    catalog_id: str,
    current_user: models.User = Depends(deps.get_current_active_admin),
    background_tasks: BackgroundTasks,
) -> Any:
    """
    Approve a catalog item (admin only).
    """
    catalog = await crud.catalog.get(db, id=catalog_id)
    if not catalog:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Catalog item not found"
        )
    
    catalog_update = schemas.CatalogUpdate(
        status="published",
        approved_by=f"{current_user.first_name} {current_user.last_name}"
    )
    catalog = await crud.catalog.update(db, db_obj=catalog, obj_in=catalog_update)
    
    # Trigger webhook for catalog.approved event
    event_data = {
        "catalog_id": catalog.id,
        "title": catalog.title,
        "type": catalog.type,
        "status": catalog.status,
        "author": catalog.author,
        "approved_by": f"{current_user.first_name} {current_user.last_name}",
        "admin_user_id": current_user.id
    }
    background_tasks.add_task(
        webhook_service.trigger_webhooks, 
        db, 
        "catalog.approved", 
        event_data
    )
    
    return catalog

@router.patch("/{catalog_id}/review", response_model=schemas.Catalog)
async def review_catalog(
    *,
    db: AsyncSession = Depends(get_db),
    catalog_id: str,
    status: str = Body(..., embed=True),
    current_user: models.User = Depends(deps.get_current_active_admin),
    background_tasks: BackgroundTasks,
) -> Any:
    """
    Review a catalog item and set status (admin only).
    """
    catalog = await crud.catalog.get(db, id=catalog_id)
    if not catalog:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Catalog item not found"
        )
    
    valid_statuses = ["draft", "published", "archived", "under_review", "rejected"]
    if status not in valid_statuses:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Invalid status. Must be one of: {', '.join(valid_statuses)}"
        )
    
    catalog_update = schemas.CatalogUpdate(
        status=status,
        reviewed_by=f"{current_user.first_name} {current_user.last_name}"
    )
    catalog = await crud.catalog.update(db, db_obj=catalog, obj_in=catalog_update)
    
    # Trigger appropriate webhook event
    if status == "rejected":
        event_type = "catalog.rejected"
    elif status == "published":
        event_type = "catalog.approved"
    else:
        event_type = "catalog.updated"
    
    event_data = {
        "catalog_id": catalog.id,
        "title": catalog.title,
        "type": catalog.type,
        "status": catalog.status,
        "author": catalog.author,
        "reviewed_by": f"{current_user.first_name} {current_user.last_name}",
        "admin_user_id": current_user.id,
        "review_action": status
    }
    
    background_tasks.add_task(
        webhook_service.trigger_webhooks, 
        db, 
        event_type, 
        event_data
    )
    
    return catalog

@router.patch("/{catalog_id}/request-approval", response_model=schemas.Catalog)
async def request_catalog_approval(
    *,
    db: AsyncSession = Depends(get_db),
    catalog_id: str,
    current_user: models.User = Depends(deps.get_current_user),
    background_tasks: BackgroundTasks,
) -> Any:
    """
    Request approval for a catalog item.
    Sets the approver as the user's manager and changes status to pending_approval.
    """
    catalog = await crud.catalog.get(db, id=catalog_id)
    if not catalog:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Catalog item not found"
        )
    
    # Check if user is the author of the catalog item
    is_author = (catalog.author_id == current_user.id or 
                 catalog.author == f"{current_user.first_name} {current_user.last_name}")
    
    if not is_author:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Only the author can request approval for this catalog item"
        )
    
    # Check if user has a manager
    if not current_user.manager_id:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Cannot request approval: No manager assigned to your account"
        )
    
    # Get manager details
    manager = await crud.user.get(db, id=current_user.manager_id)
    if not manager:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Cannot request approval: Manager not found"
        )
    
    # Update catalog status and set approver
    catalog_update = schemas.CatalogUpdate(
        status="pending_approval",
        approved_by=f"{manager.first_name} {manager.last_name}"
    )
    catalog = await crud.catalog.update(db, db_obj=catalog, obj_in=catalog_update)
    
    # Trigger webhook for approval request event
    event_data = {
        "catalog_id": catalog.id,
        "title": catalog.title,
        "type": catalog.type,
        "status": catalog.status,
        "author": catalog.author,
        "author_id": catalog.author_id,
        "approver": f"{manager.first_name} {manager.last_name}",
        "approver_id": manager.id,
        "requested_by": current_user.id,
        "user_name": f"{current_user.first_name} {current_user.last_name}"
    }
    background_tasks.add_task(
        webhook_service.trigger_webhooks, 
        db, 
        "catalog.approval_requested", 
        event_data
    )
    
    return catalog

# Filter endpoints
@router.get("/by-type/{type}", response_model=List[schemas.Catalog])
async def get_catalogs_by_type(
    type: str,
    db: AsyncSession = Depends(get_db),
    skip: int = Query(0, ge=0),
    limit: int = Query(50, ge=1, le=100),
) -> Any:
    """
    Get catalog items by type.
    
    This endpoint is public and does not require authentication.
    """
    catalogs = await crud.catalog.get_by_type(db, type=type, skip=skip, limit=limit)
    return catalogs

@router.get("/by-status/{status}", response_model=List[schemas.Catalog])
async def get_catalogs_by_status(
    status: str,
    db: AsyncSession = Depends(get_db),
    skip: int = Query(0, ge=0),
    limit: int = Query(50, ge=1, le=100),
) -> Any:
    """
    Get catalog items by status.
    
    This endpoint is public and does not require authentication.
    """
    catalogs = await crud.catalog.get_by_status(db, status=status, skip=skip, limit=limit)
    return catalogs

@router.get("/by-author/{author_id}", response_model=List[schemas.Catalog])
async def get_catalogs_by_author(
    author_id: str,
    db: AsyncSession = Depends(get_db),
    current_user: models.User = Depends(deps.get_current_user),
    skip: int = Query(0, ge=0),
    limit: int = Query(50, ge=1, le=100),
) -> Any:
    """
    Get catalog items by author_id.
    Users can only see their own content unless they are admin.
    """
    # Check permissions - users can only see their own content, admins can see all
    if author_id != current_user.id and not crud.user.is_admin(current_user):
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Not enough permissions to view this user's catalog items"
        )
    
    catalogs = await crud.catalog.get_by_author_id(db, author_id=author_id, skip=skip, limit=limit)
    return catalogs

@router.get("/my-content", response_model=List[schemas.Catalog])
async def get_my_catalog_content(
    db: AsyncSession = Depends(get_db),
    current_user: models.User = Depends(deps.get_current_user),
    skip: int = Query(0, ge=0),
    limit: int = Query(50, ge=1, le=100),
) -> Any:
    """
    Get all catalog items created by the current user.
    """
    catalogs = await crud.catalog.get_by_author_id(db, author_id=current_user.id, skip=skip, limit=limit)
    return catalogs

@router.get("/{catalog_id}/conversations", response_model=List[dict])
async def get_catalog_conversations(
    catalog_id: str = Path(..., description="Catalog item ID"),
    db: AsyncSession = Depends(get_db),
) -> Any:
    """
    Get all conversations for a catalog item.
    """
    catalog = await crud.catalog.get(db, id=catalog_id)
    if not catalog:
        raise HTTPException(status_code=404, detail="Catalog item not found")
    return catalog.conversations or []

@router.post("/{catalog_id}/conversations", response_model=List[dict])
async def add_catalog_conversation(
    catalog_id: str = Path(..., description="Catalog item ID"),
    conversation: dict = Body(..., description="Conversation/comment to add"),
    db: AsyncSession = Depends(get_db),
    current_user: models.User = Depends(deps.get_current_user),
) -> Any:
    """
    Add a new conversation/comment to a catalog item.
    """
    catalog = await crud.catalog.get(db, id=catalog_id)
    if not catalog:
        raise HTTPException(status_code=404, detail="Catalog item not found")
    conversations = catalog.conversations or []
    # Optionally, enrich with user info and timestamp
    import datetime
    conversation.setdefault("user_id", current_user.user_id)
    conversation.setdefault("timestamp", datetime.datetime.utcnow().isoformat() + "Z")
    conversations.append(conversation)
    await crud.catalog.update(db, db_obj=catalog, obj_in={"conversations": conversations})
    return conversations
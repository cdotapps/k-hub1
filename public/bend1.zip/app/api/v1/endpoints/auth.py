from typing import Any
from fastapi import APIRouter, Depends, HTTPException, status
from fastapi.security import HTTPAuthorizationCredentials
from sqlalchemy.ext.asyncio import AsyncSession

from app import crud
from app.schemas import user as schemas
from app.api import deps
from app.db.session import get_db
from app.models.user import UserRole

router = APIRouter()

@router.post("/register", response_model=schemas.User)
async def register(
    *,
    db: AsyncSession = Depends(get_db),
    user_in: schemas.UserCreate,
) -> Any:
    """
    Create new user account.
    """
    # Check if user_id already exists
    user = await crud.user.get_by_user_id(db, user_id=user_in.user_id)
    if user:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="The user with this user_id already exists in the system"
        )
    
    # Check if email already exists (if email is provided)
    if user_in.email:
        existing_user = await crud.user.get_by_email(db, email=user_in.email)
        if existing_user:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="The user with this email already exists in the system"
            )
    
    # Create new user
    user = await crud.user.create(db, obj_in=user_in)
    return user

@router.post("/register-admin", response_model=schemas.User)
async def register_admin(
    *,
    db: AsyncSession = Depends(get_db),
    user_in: schemas.UserCreate,
    current_user: schemas.User = Depends(deps.get_current_active_admin),
) -> Any:
    """
    Create new admin user account (admin only).
    """
    # Check if user_id already exists
    user = await crud.user.get_by_user_id(db, user_id=user_in.user_id)
    if user:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="The user with this user_id already exists in the system"
        )
    
    # Check if email already exists (if email is provided)
    if user_in.email:
        existing_user = await crud.user.get_by_email(db, email=user_in.email)
        if existing_user:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="The user with this email already exists in the system"
            )
    
    # Set role to admin
    user_in.role = UserRole.ADMIN
    
    # Create new admin user
    user = await crud.user.create(db, obj_in=user_in)
    return user

@router.post("/login", response_model=schemas.Token)
async def login(
    *,
    db: AsyncSession = Depends(get_db),
    user_credentials: schemas.LoginRequest,
) -> Any:
    """
    OAuth2 compatible token login, get an access token for future requests.
    """
    user = await crud.user.authenticate(
        db, user_id=user_credentials.user_id, password=user_credentials.password
    )
    if not user:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Incorrect user_id or password"
        )
    elif not crud.user.is_active(user):
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Inactive user"
        )
    
    # Update last login
    await crud.user.update_last_login(db, user=user)
    
    # Create tokens
    access_token = deps.create_access_token(user.id)
    refresh_token = deps.create_refresh_token(user.id)
    
    return {
        "access_token": access_token,
        "refresh_token": refresh_token,
        "token_type": "bearer",
        "user": schemas.TokenUser(
            id=user.id,
            user_id=user.user_id,
            email=user.email,
            first_name=user.first_name,
            last_name=user.last_name,
            role=user.role,
            designation=user.designation
        )
    }

@router.post("/refresh", response_model=schemas.Token)
async def refresh_token(
    *,
    db: AsyncSession = Depends(get_db),
    credentials: HTTPAuthorizationCredentials = Depends(deps.security),
) -> Any:
    """
    Refresh access token using refresh token.
    """
    # Verify refresh token
    user_id = deps.verify_token(credentials.credentials, token_type="refresh")
    if user_id is None:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid refresh token"
        )
    
    # Get user
    user = await crud.user.get(db, id=user_id)
    if not user:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="User not found"
        )
    elif not crud.user.is_active(user):
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Inactive user"
        )
    
    # Create new tokens
    access_token = deps.create_access_token(user.id)
    refresh_token = deps.create_refresh_token(user.id)
    
    return {
        "access_token": access_token,
        "refresh_token": refresh_token,
        "token_type": "bearer",
        "user": schemas.TokenUser(
            id=user.id,
            user_id=user.user_id,
            email=user.email,
            first_name=user.first_name,
            last_name=user.last_name,
            role=user.role,
            designation=user.designation
        )
    }

@router.post("/logout", response_model=schemas.Msg)
async def logout(
    current_user: schemas.User = Depends(deps.get_current_active_user),
) -> Any:
    """
    Logout user (client should delete tokens).
    """
    return {"msg": "Successfully logged out"}
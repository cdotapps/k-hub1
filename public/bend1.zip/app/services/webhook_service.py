import asyncio
import json
import hmac
import hashlib
from typing import Dict, Any, List
from datetime import datetime
import aiohttp
import logging
from sqlalchemy.ext.asyncio import AsyncSession

from app import crud
from app.schemas.webhook import WebhookEventPayload, WebhookDeliveryCreate
from app.models.webhook import WebhookEventType

logger = logging.getLogger(__name__)

class WebhookService:
    """Service for managing and delivering webhooks"""
    
    def __init__(self):
        self.timeout = 30  # 30 seconds timeout for webhook delivery
        self.max_retries = 3
        self.user_agent = "Backend-Server-Webhook/1.0"

    def _create_signature(self, payload: str, secret: str) -> str:
        """Create HMAC signature for webhook payload"""
        return hmac.new(
            secret.encode('utf-8'),
            payload.encode('utf-8'),
            hashlib.sha256
        ).hexdigest()

    def _create_webhook_payload(
        self, 
        event_type: str, 
        data: Dict[str, Any], 
        webhook_id: str
    ) -> WebhookEventPayload:
        """Create standardized webhook payload"""
        return WebhookEventPayload(
            event=event_type,
            timestamp=datetime.utcnow(),
            data=data,
            webhook={
                "id": webhook_id,
                "version": "1.0"
            }
        )

    async def _deliver_webhook(
        self, 
        webhook_url: str, 
        payload: Dict[str, Any], 
        headers: Dict[str, str] = None,
        secret: str = None
    ) -> tuple[bool, str, str, str]:
        """
        Deliver webhook to a single endpoint
        Returns: (success, status_code, response_body, error_message)
        """
        try:
            # Prepare payload
            payload_json = json.dumps(payload, default=str)
            
            # Prepare headers
            request_headers = {
                "Content-Type": "application/json",
                "User-Agent": self.user_agent,
                "X-Webhook-Timestamp": str(int(datetime.utcnow().timestamp())),
            }
            
            # Add custom headers
            if headers:
                request_headers.update(headers)
            
            # Add signature if secret is provided
            if secret:
                signature = f"sha256={self._create_signature(payload_json, secret)}"
                request_headers["X-Webhook-Signature"] = signature
            
            # Deliver webhook
            timeout = aiohttp.ClientTimeout(total=self.timeout)
            async with aiohttp.ClientSession(timeout=timeout) as session:
                async with session.post(
                    webhook_url, 
                    data=payload_json, 
                    headers=request_headers
                ) as response:
                    response_body = await response.text()
                    
                    # Truncate response body if too long
                    if len(response_body) > 1000:
                        response_body = response_body[:1000] + "... [truncated]"
                    
                    success = 200 <= response.status < 300
                    return success, str(response.status), response_body, ""
                    
        except asyncio.TimeoutError:
            error_msg = f"Webhook delivery timed out after {self.timeout} seconds"
            logger.warning(f"Webhook timeout: {webhook_url}")
            return False, "timeout", "", error_msg
            
        except aiohttp.ClientError as e:
            error_msg = f"HTTP client error: {str(e)}"
            logger.warning(f"Webhook client error: {webhook_url} - {error_msg}")
            return False, "client_error", "", error_msg
            
        except Exception as e:
            error_msg = f"Unexpected error: {str(e)}"
            logger.error(f"Webhook delivery error: {webhook_url} - {error_msg}")
            return False, "error", "", error_msg

    async def _should_trigger_webhook(self, webhook, event_data: Dict[str, Any]) -> bool:
        """Check if webhook should be triggered based on filters"""
        if not webhook.filters:
            return True
            
        try:
            # Simple filter evaluation - can be extended
            for key, expected_value in webhook.filters.items():
                if key in event_data:
                    actual_value = event_data[key]
                    if actual_value != expected_value:
                        return False
            return True
        except Exception as e:
            logger.warning(f"Error evaluating webhook filters: {e}")
            return True  # Default to triggering on filter error

    async def trigger_webhooks(
        self, 
        db: AsyncSession, 
        event_type: str, 
        event_data: Dict[str, Any]
    ):
        """Trigger all webhooks subscribed to an event type"""
        try:
            # Get all active webhooks for this event type
            webhooks = await crud.webhook.get_active_by_event(db, event_type)
            
            if not webhooks:
                logger.debug(f"No active webhooks found for event: {event_type}")
                return

            logger.info(f"Triggering {len(webhooks)} webhooks for event: {event_type}")

            # Process webhooks concurrently
            tasks = []
            for webhook in webhooks:
                task = self._process_webhook(db, webhook, event_type, event_data)
                tasks.append(task)
            
            if tasks:
                await asyncio.gather(*tasks, return_exceptions=True)
                
        except Exception as e:
            logger.error(f"Error triggering webhooks for event {event_type}: {e}")

    async def _process_webhook(
        self, 
        db: AsyncSession, 
        webhook, 
        event_type: str, 
        event_data: Dict[str, Any]
    ):
        """Process a single webhook delivery"""
        try:
            # Check if webhook should be triggered
            if not await self._should_trigger_webhook(webhook, event_data):
                logger.debug(f"Webhook {webhook.id} skipped due to filters")
                return

            # Create webhook payload
            payload = self._create_webhook_payload(event_type, event_data, webhook.id)
            payload_dict = payload.model_dump()

            # Deliver webhook
            success, status, response_body, error_msg = await self._deliver_webhook(
                webhook.url,
                payload_dict,
                webhook.headers,
                webhook.secret
            )

            # Record delivery
            delivery = WebhookDeliveryCreate(
                webhook_id=webhook.id,
                event_type=event_type,
                payload=payload_dict,
                response_status=status,
                response_body=response_body,
                error_message=error_msg,
                success=success
            )
            
            await crud.webhook_delivery.create(db, obj_in=delivery)
            
            # Update webhook stats
            await crud.webhook.update_stats(db, webhook_id=webhook.id, success=success)
            
            if success:
                logger.info(f"Webhook {webhook.id} delivered successfully to {webhook.url}")
            else:
                logger.warning(f"Webhook {webhook.id} delivery failed: {error_msg}")
                
        except Exception as e:
            logger.error(f"Error processing webhook {webhook.id}: {e}")

    async def test_webhook(self, db: AsyncSession, webhook_id: str) -> Dict[str, Any]:
        """Send a test payload to a webhook"""
        try:
            webhook = await crud.webhook.get(db, id=webhook_id)
            if not webhook:
                return {"success": False, "error": "Webhook not found"}

            # Create test payload
            test_payload = {
                "test": True,
                "message": "This is a test webhook delivery",
                "webhook_id": webhook_id,
                "timestamp": datetime.utcnow().isoformat() + "Z"
            }

            # Deliver test webhook
            success, status, response_body, error_msg = await self._deliver_webhook(
                webhook.url,
                test_payload,
                webhook.headers,
                webhook.secret
            )

            # Record test delivery
            delivery = WebhookDeliveryCreate(
                webhook_id=webhook.id,
                event_type="webhook.test",
                payload=test_payload,
                response_status=status,
                response_body=response_body,
                error_message=error_msg,
                success=success
            )
            
            await crud.webhook_delivery.create(db, obj_in=delivery)

            return {
                "success": success,
                "status": status,
                "response": response_body,
                "error": error_msg if not success else None
            }

        except Exception as e:
            logger.error(f"Error testing webhook {webhook_id}: {e}")
            return {"success": False, "error": str(e)}


# Global webhook service instance
webhook_service = WebhookService()
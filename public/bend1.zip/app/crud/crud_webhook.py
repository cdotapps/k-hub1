from typing import Any, Dict, Optional, Union, List
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, update, delete, and_, func
from datetime import datetime
import uuid

from app.models.webhook import Webhook, WebhookDelivery
from app.schemas.webhook import WebhookCreate, WebhookUpdate, WebhookDeliveryCreate


class CRUDWebhook:
    def __init__(self, model):
        self.model = model

    async def get(self, db: AsyncSession, id: str) -> Optional[Webhook]:
        """Get webhook by id"""
        stmt = select(self.model).where(self.model.id == id)
        result = await db.execute(stmt)
        return result.scalar_one_or_none()

    async def get_multi(
        self, db: AsyncSession, *, skip: int = 0, limit: int = 100, created_by: str = None
    ) -> List[Webhook]:
        """Get multiple webhooks, optionally filtered by creator"""
        stmt = select(self.model).offset(skip).limit(limit).order_by(self.model.created_date.desc())
        
        if created_by:
            stmt = stmt.where(self.model.created_by == created_by)
            
        result = await db.execute(stmt)
        return result.scalars().all()

    async def create(self, db: AsyncSession, *, obj_in: WebhookCreate, created_by: str) -> Webhook:
        """Create new webhook"""
        db_obj = Webhook(
            id=str(uuid.uuid4()),
            name=obj_in.name,
            url=str(obj_in.url),
            events=obj_in.events,
            secret=obj_in.secret,
            headers=obj_in.headers,
            active=obj_in.active,
            filters=obj_in.filters,
            created_by=created_by,
            status="active"
        )
        db.add(db_obj)
        await db.commit()
        await db.refresh(db_obj)
        return db_obj

    async def update(
        self,
        db: AsyncSession,
        *,
        db_obj: Webhook,
        obj_in: Union[WebhookUpdate, Dict[str, Any]]
    ) -> Webhook:
        """Update webhook"""
        if isinstance(obj_in, dict):
            update_data = obj_in
        else:
            update_data = obj_in.model_dump(exclude_unset=True)
        
        # Convert URL to string if present
        if 'url' in update_data and update_data['url']:
            update_data['url'] = str(update_data['url'])
        
        update_data["updated_date"] = datetime.utcnow()
        
        if update_data:
            stmt = (
                update(self.model)
                .where(self.model.id == db_obj.id)
                .values(**update_data)
                .returning(self.model)
            )
            result = await db.execute(stmt)
            await db.commit()
            return result.scalar_one()
        return db_obj

    async def remove(self, db: AsyncSession, *, id: str) -> Webhook:
        """Delete webhook"""
        stmt = select(self.model).where(self.model.id == id)
        result = await db.execute(stmt)
        obj = result.scalar_one_or_none()
        if obj:
            await db.delete(obj)
            await db.commit()
        return obj

    async def get_active_by_event(self, db: AsyncSession, event_type: str) -> List[Webhook]:
        """Get all active webhooks that subscribe to a specific event type"""
        stmt = select(self.model).where(
            and_(
                self.model.active == True,
                self.model.status == "active",
                self.model.events.contains([event_type])
            )
        )
        result = await db.execute(stmt)
        return result.scalars().all()

    async def update_stats(
        self, db: AsyncSession, *, webhook_id: str, success: bool, last_triggered: datetime = None
    ) -> Optional[Webhook]:
        """Update webhook delivery statistics"""
        if last_triggered is None:
            last_triggered = datetime.utcnow()
            
        if success:
            stmt = (
                update(self.model)
                .where(self.model.id == webhook_id)
                .values(
                    success_count=func.cast(self.model.success_count, int) + 1,
                    last_triggered=last_triggered,
                    status="active"
                )
                .returning(self.model)
            )
        else:
            stmt = (
                update(self.model)
                .where(self.model.id == webhook_id)
                .values(
                    failure_count=func.cast(self.model.failure_count, int) + 1,
                    last_triggered=last_triggered
                )
                .returning(self.model)
            )
        
        result = await db.execute(stmt)
        await db.commit()
        return result.scalar_one_or_none()


class CRUDWebhookDelivery:
    def __init__(self, model):
        self.model = model

    async def create(self, db: AsyncSession, *, obj_in: WebhookDeliveryCreate) -> WebhookDelivery:
        """Create new webhook delivery record"""
        db_obj = WebhookDelivery(
            id=str(uuid.uuid4()),
            webhook_id=obj_in.webhook_id,
            event_type=obj_in.event_type,
            payload=obj_in.payload,
            response_status=obj_in.response_status,
            response_body=obj_in.response_body,
            error_message=obj_in.error_message,
            attempts=obj_in.attempts,
            success=obj_in.success
        )
        db.add(db_obj)
        await db.commit()
        await db.refresh(db_obj)
        return db_obj

    async def get_by_webhook(
        self, db: AsyncSession, *, webhook_id: str, skip: int = 0, limit: int = 100
    ) -> List[WebhookDelivery]:
        """Get delivery history for a specific webhook"""
        stmt = (
            select(self.model)
            .where(self.model.webhook_id == webhook_id)
            .offset(skip)
            .limit(limit)
            .order_by(self.model.delivered_at.desc())
        )
        result = await db.execute(stmt)
        return result.scalars().all()


webhook = CRUDWebhook(Webhook)
webhook_delivery = CRUDWebhookDelivery(WebhookDelivery)
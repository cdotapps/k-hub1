# Environment-Based SharePoint Configuration

## 🎯 Overview

The SharePoint Asset Management system now uses **environment-based configuration** instead of runtime API configuration. This means you set up your SharePoint connection once using environment variables, and the system automatically connects at startup.

## ⚙️ Environment Configuration

### Required Environment Variables

Add these variables to your `.env` file:

```bash
# SharePoint Configuration
SHAREPOINT_SITE_URL=https://yourcompany.sharepoint.com/sites/yoursite
SHAREPOINT_LIST_NAME=Assets
SHAREPOINT_CLIENT_ID=your-azure-app-client-id
SHAREPOINT_CLIENT_SECRET=your-azure-app-client-secret
SHAREPOINT_TENANT_ID=your-tenant-id
```

### Configuration Details

| Variable | Description | Example |
|----------|-------------|---------|
| `SHAREPOINT_SITE_URL` | Your SharePoint site URL | `https://contoso.sharepoint.com/sites/assets` |
| `SHAREPOINT_LIST_NAME` | Name of your SharePoint list | `Assets` (default) |
| `SHAREPOINT_CLIENT_ID` | Azure AD App Registration Client ID | `12345678-abcd-1234-abcd-123456789012` |
| `SHAREPOINT_CLIENT_SECRET` | Azure AD App Registration Client Secret | `your-client-secret` |
| `SHAREPOINT_TENANT_ID` | Your Azure AD Tenant ID | `87654321-dcba-4321-dcba-210987654321` |

## 🚀 Quick Setup

### Option 1: Use the Setup Helper

```bash
python setup_sharepoint.py
```

The setup script will:
1. Guide you through entering your SharePoint configuration
2. Create/update your `.env` file with the correct values
3. Validate your configuration

### Option 2: Manual Setup

1. Copy the template:
   ```bash
   cp .env.template .env
   ```

2. Edit `.env` file and replace the placeholder values:
   ```bash
   # Replace these with your actual values
   SHAREPOINT_SITE_URL=https://yourcompany.sharepoint.com/sites/yoursite
   SHAREPOINT_CLIENT_ID=your-azure-app-client-id
   SHAREPOINT_CLIENT_SECRET=your-azure-app-client-secret
   SHAREPOINT_TENANT_ID=your-tenant-id
   ```

3. Start the server:
   ```bash
   python main.py
   ```

## 📊 Configuration Status

### Check Configuration via API

```bash
# Get configuration status (requires authentication)
GET /api/v1/assets/config-info
```

Response when configured:
```json
{
  "configured": true,
  "site_url": "https://yourcompany.sharepoint.com/sites/yoursite",
  "list_name": "Assets",
  "tenant_id": "87654321-dcba-4321-dcba-210987654321",
  "message": "SharePoint is properly configured"
}
```

Response when not configured:
```json
{
  "configured": false,
  "message": "SharePoint is not configured. Please set environment variables.",
  "required_variables": [
    "SHAREPOINT_SITE_URL",
    "SHAREPOINT_LIST_NAME",
    "SHAREPOINT_CLIENT_ID",
    "SHAREPOINT_CLIENT_SECRET",
    "SHAREPOINT_TENANT_ID"
  ]
}
```

### Check Configuration via Script

```bash
# Check current configuration
python setup_sharepoint.py check
```

### Startup Logs

When the server starts, you'll see configuration status:

```
✅ SharePoint configuration loaded successfully
   Site URL: https://yourcompany.sharepoint.com/sites/yoursite
   List Name: Assets
   Tenant ID: 87654321-dcba-4321-dcba-210987654321
✅ SharePoint Asset Service is ready
```

If not configured:
```
⚠️  SharePoint configuration not found
   Set these environment variables for SharePoint integration:
   - SHAREPOINT_SITE_URL
   - SHAREPOINT_LIST_NAME
   - SHAREPOINT_CLIENT_ID
   - SHAREPOINT_CLIENT_SECRET
   - SHAREPOINT_TENANT_ID
```

## 🔧 How It Works

### Auto-Configuration Process

1. **Environment Loading**: On startup, the system loads environment variables from `.env`
2. **Configuration Validation**: Checks if all required SharePoint variables are present
3. **Service Initialization**: If configured, the SharePoint service automatically connects
4. **API Protection**: All asset endpoints check for proper configuration before executing

### Configuration Classes

```python
# Main application settings
class Settings(BaseSettings):
    # ... other settings ...
    sharepoint_site_url: Optional[str] = None
    sharepoint_list_name: str = "Assets"
    sharepoint_client_id: Optional[str] = None
    sharepoint_client_secret: Optional[str] = None
    sharepoint_tenant_id: Optional[str] = None

# SharePoint-specific settings
class SharePointSettings(BaseSettings):
    site_url: str
    list_name: str = "Assets"
    client_id: str
    client_secret: str
    tenant_id: str
    
    class Config:
        env_prefix = "SHAREPOINT_"
```

## 🛡️ Security Considerations

### Environment Variables Security

1. **Never commit `.env` files** to version control
2. **Use `.env.template`** for sharing configuration structure
3. **Set proper file permissions** on `.env` files: `chmod 600 .env`
4. **Use Azure Key Vault** or similar for production secrets

### Production Deployment

For production, consider:

1. **Azure Key Vault**: Store secrets in Azure Key Vault
2. **Environment Variables**: Set via your deployment platform
3. **Container Secrets**: Use Docker secrets or Kubernetes secrets
4. **CI/CD Variables**: Set via your CI/CD pipeline

Example production setup:
```bash
# Azure App Service - set these as Application Settings
SHAREPOINT_SITE_URL=https://contoso.sharepoint.com/sites/production
SHAREPOINT_CLIENT_ID=prod-client-id
SHAREPOINT_CLIENT_SECRET=@Microsoft.KeyVault(SecretUri=https://vault.vault.azure.net/secrets/sharepoint-secret/)
SHAREPOINT_TENANT_ID=tenant-id
```

## 🧪 Testing Your Configuration

### Test Connection

```bash
# Start server
python main.py

# Test connection (requires authentication)
curl -X POST "http://localhost:8000/api/v1/assets/test-connection" \
  -H "Authorization: Bearer YOUR_TOKEN"
```

### Test Asset Operations

```bash
# Get all assets (requires authentication)
curl -X GET "http://localhost:8000/api/v1/assets/" \
  -H "Authorization: Bearer YOUR_TOKEN"
```

## 🔄 Migration from API Configuration

If you were previously using the API configuration endpoint:

1. **Remove the configuration endpoint**: No longer needed
2. **Set environment variables**: Use the values you were passing to the API
3. **Restart the server**: Configuration is now loaded at startup
4. **Update your client code**: Remove calls to `/configure` endpoint

## 🆘 Troubleshooting

### Common Issues

1. **"SharePoint is not configured"**
   - Check that all required environment variables are set
   - Verify `.env` file exists and has correct values
   - Run `python setup_sharepoint.py check` to diagnose

2. **"Service Unavailable" errors**
   - The API endpoints return 503 if SharePoint isn't configured
   - Check configuration status via `/config-info` endpoint

3. **Authentication failures**
   - Verify Azure AD app registration settings
   - Check client ID, client secret, and tenant ID are correct
   - Ensure app has proper SharePoint permissions

4. **Environment variables not loading**
   - Ensure `.env` file is in the root directory
   - Check file permissions (readable by the application)
   - Verify no syntax errors in `.env` file

### Debug Steps

1. **Check environment loading**:
   ```python
   import os
   print("Site URL:", os.getenv("SHAREPOINT_SITE_URL"))
   ```

2. **Check configuration status**:
   ```python
   from app.core.config import sharepoint_settings
   print("Configured:", sharepoint_settings is not None)
   ```

3. **Check service status**:
   ```python
   from app.services.sharepoint_asset_service import sharepoint_asset_service
   print("Service ready:", sharepoint_asset_service.is_configured())
   ```

## 📚 Next Steps

1. **Complete SharePoint Setup**: Follow `SHAREPOINT_ASSET_SETUP.md` for SharePoint list and Azure AD setup
2. **Configure Environment**: Use `setup_sharepoint.py` or manually edit `.env`
3. **Test Connection**: Use the test connection endpoint
4. **Start Managing Assets**: Use the API endpoints to manage your assets

Your SharePoint Asset Management system is now ready for production use with secure, environment-based configuration!

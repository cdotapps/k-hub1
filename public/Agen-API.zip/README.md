# Finance AI Agent API

A FastAPI-based API that creates an AI agent for finance business teams. The agent can upload documents to AWS S3, create embeddings using Titan, store FAISS files, and answer questions using RAG (Retrieval-Augmented Generation) and Postgres database queries via Claude model.

## Features

- Upload CSV, JSON, TXT, PDF, and Word documents to S3 (data or metadata folders), with intelligent CSV processing that converts large files to JSONL chunks for accurate analytical queries
- Upload structured data dictionaries (CSV format) with detailed table schemas, column descriptions, data types, constraints, and relationships
- Upload sample query patterns (CSV format) with SQL templates, parameter definitions, performance characteristics, and business context
- Process documents to create embeddings with AWS Titan and store FAISS indices in S3 (data_embeddings, metadata_embeddings, data_dictionary_embeddings, or query_patterns_embeddings folders), using optimized chunking for accurate retrieval
- Query the system using a LangChain agent with Data RAG, Metadata RAG, Data Dictionary RAG, Query Patterns RAG, Enhanced Schema, Database Explorer, and DB tools, all guided by comprehensive RETROS-structured prompts stored in editable .prompt files
- **Fallback Database Intelligence**: Even without uploaded CSV files, the agent can understand database structure through direct database introspection, including relationships, constraints, indexes, sample data, and business context inferred from naming patterns

## Setup

1. Install dependencies:
   ```bash
   pip install -r requirements.txt
   ```

2. Configure environment variables. Copy `.env.example` to `.env` and fill in your values. The example includes all configurable parameters with defaults.
   - `S3_BUCKET`: Your AWS S3 bucket name
   - `BEDROCK_REGION`: AWS region for Bedrock (default: us-east-1)
   - `DB_HOST`: Postgres database host
   - `DB_NAME`: Postgres database name
   - `DB_MAX_ROWS`: Maximum rows to return from database queries (0 = no limit, default: 50000)

3. Ensure AWS credentials are configured (e.g., via AWS CLI or environment variables).

## Usage

1. Start the server:
   ```bash
   uvicorn main:app --reload
   ```

2. Upload a document (data or metadata):
   ```bash
   curl -X POST "http://localhost:8000/upload/data" -F "file=@datafile.pdf"
   curl -X POST "http://localhost:8000/upload/metadata" -F "file=@datadict.pdf"
   ```

3. Upload a structured data dictionary:
   ```bash
   curl -X POST "http://localhost:8000/upload/data_dictionary" -F "file=@sample_data_dictionary.csv"
   ```

4. Upload sample query patterns:
   ```bash
   curl -X POST "http://localhost:8000/upload/query_patterns" -F "file=@sample_query_patterns.csv"
   ```

5. Process the documents to create embeddings:
   ```bash
   curl -X POST "http://localhost:8000/process/data/datafile.pdf"
   curl -X POST "http://localhost:8000/process/metadata/datadict.pdf"
   curl -X POST "http://localhost:8000/process/data_dictionary/sample_data_dictionary.csv"
   curl -X POST "http://localhost:8000/process/query_patterns/sample_query_patterns.csv"
   ```

6. Query the agent (basic endpoint):
   ```bash
   curl -X POST "http://localhost:8000/query/datafile.pdf/datadict.pdf" -H "Content-Type: application/json" -d '{"question": "What is the total revenue?"}'
   ```

7. Query the agent (enhanced endpoint with data dictionary and query patterns):
   ```bash
   curl -X POST "http://localhost:8000/query/enhanced" \
     -H "Content-Type: application/json" \
     -d '{
       "data_filename": "datafile.pdf",
       "metadata_filename": "datadict.pdf",
       "data_dictionary_filename": "sample_data_dictionary.csv",
       "query_patterns_filename": "sample_query_patterns.csv",
       "question": "Show me budget variances by department and suggest optimization queries",
       "user_id": "user123",
       "user_role": "manager"
     }'
   ```

## API Endpoints

- `GET /`: Health check
- `POST /upload/{doc_type}`: Upload a document (doc_type: data, metadata, data_dictionary, query_patterns)
- `POST /process/{doc_type}/{filename}`: Process document and create embeddings (doc_type: data, metadata, data_dictionary, query_patterns)
- `POST /query/{data_filename}/{metadata_filename}`: Basic query endpoint with data and metadata RAG tools
- `POST /query/enhanced`: Enhanced query endpoint supporting optional data dictionary and query patterns RAG tools

## Document Types

- **data**: Business documents (CSV, PDF, Word, etc.) containing financial data
- **metadata**: General metadata and documentation about the data
- **data_dictionary**: CSV files with detailed table schemas, column descriptions, data types, constraints, and relationships
- **query_patterns**: CSV files with sample SQL queries, parameter definitions, performance characteristics, and business context

## Intelligent Database Understanding

The system provides multiple layers of database intelligence:

### Primary Intelligence (CSV Uploads)
- **Data Dictionary CSV**: Rich business context with detailed column descriptions, relationships, and constraints
- **Query Patterns CSV**: Common SQL patterns with usage examples and performance characteristics

### Fallback Intelligence (Direct Database Introspection)
Even without uploaded CSV files, the agent uses several tools to understand your database:

#### Enhanced Schema Tool (`Enhanced_Schema`)
- Comprehensive column information with data types, constraints, and relationships
- Foreign key relationships and primary key identification
- Index information and table constraints
- Sample data preview (first 3 rows)
- Business context inferred from naming patterns and data types

#### Database Explorer Tool (`Database_Explorer`)
- Complete overview of all tables in the database
- Foreign key relationships across the entire schema
- **Intelligent table suggestions**: Dynamically analyzes table and column names to recommend relevant tables based on query content
- Relationship mapping for complex queries

#### Intelligent Column Inference
The system uses heuristics to understand column purposes:
- **Amount/Money fields**: `amount`, `price`, `cost` columns identified for financial calculations
- **Date/Time fields**: Columns with date/time data types or names for temporal analysis
- **Reference fields**: Foreign key columns identified by `_id` suffix patterns
- **Text fields**: Description and name fields for qualitative analysis

### Example Fallback Intelligence
For a question like *"Show me expense trends by department"*:

1. **Database Explorer** dynamically analyzes all tables and columns:
   - Finds tables with "expense" in name (score +4)
   - Identifies columns containing "amount", "price", "cost" (score +3 for financial analysis)
   - Finds temporal columns like "date", "created_at" (score +2 for trend analysis)
   - Detects relationship columns ending in "_id" (score +2 for grouping)
   - Returns ranked recommendations: `expenses` (⭐⭐⭐), `departments` (⭐⭐⭐), etc.

2. **Enhanced Schema** provides detailed column info for recommended tables:
   - Shows `expenses.amount` (DECIMAL, monetary), `expenses.date` (DATE, temporal)
   - Identifies `departments.name` (VARCHAR, identifier) and foreign key relationships
   - Displays sample data and business context inferences

3. **Business context inference** identifies patterns:
   - `amount` columns as "Monetary value - suitable for SUM, AVG aggregations"
   - `date` columns as "Date/timestamp field - useful for time-based analysis"
   - `_id` columns as "References other tables - enables JOINs"

4. Agent constructs informed queries using relationship knowledge and column understanding

#### Data Dictionary CSV Format
The data dictionary CSV should include these key columns:
- `table_name`: Name of the database table
- `column_name`: Name of the column (leave blank for table-level info)
- `data_type`: SQL data type (e.g., VARCHAR(100), DECIMAL(10,2))
- `description`: Business description of the column/table
- `nullable`: true/false indicating if column allows NULL values
- `primary_key`: true/false indicating if column is part of primary key
- `foreign_key_table`: Referenced table name (if foreign key)
- `foreign_key_column`: Referenced column name (if foreign key)
- `relationship_type`: Type of relationship (many-to-one, one-to-one, etc.)
- `constraints`: Additional constraints (unique, auto_increment, etc.)
- `business_rules`: Business validation rules (pipe-separated)
- `sample_values`: Example values (pipe-separated)
- `indexes`: Index definitions
- `usage_patterns`: How the table/column is used (pipe-separated)

#### Query Patterns CSV Format
The query patterns CSV should include these key columns:
- `pattern_id`: Unique identifier for the query pattern
- `name`: Human-readable name
- `description`: Detailed description of what the query does
- `category`: Category (reporting, analysis, operational)
- `complexity`: Complexity level (simple, intermediate, advanced)
- `sql_query`: The actual SQL query with parameter placeholders
- `parameters`: Parameter definitions (name:type:description:required;...)
- `tables_used`: Comma-separated list of tables used
- `joins_required`: Join definitions (table:join_type:condition;...)
- `output_columns`: Output column definitions (name:description:type:nullable,...)
- `business_context`: Use case, frequency, stakeholders (use_case:frequency:stakeholder1|stakeholder2)
- `performance_characteristics`: Runtime and result size expectations
- `tags`: Search tags (pipe-separated)
- `related_patterns`: Related pattern IDs (pipe-separated)

- Python 3.8+
- AWS account with Bedrock access
- S3 bucket
- Postgres database

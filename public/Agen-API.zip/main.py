"""
Finance AI Agent API - Main Application

This FastAPI application provides an AI-powered financial analysis system that:
- Uploads and processes documents (CSV, PDF, Word, etc.) to AWS S3
- Creates embeddings using AWS Titan and stores FAISS indices
- Uses LangChain agents with RAG and database tools for intelligent querying
- Leverages AWS Bedrock Claude model for natural language responses

Architecture:
- Document Processing: Extract text from various file formats
- Vector Storage: FAISS indices stored in S3 for efficient retrieval
- Agent System: LangChain agents coordinating multiple tools
- Database Integration: Secure Postgres queries with validation
- Security: Query validation, read-only access, and input sanitization
"""

from typing import Union, List
from fastapi import FastAPI, UploadFile, File, HTTPException
from fastapi.responses import JSONResponse
from pydantic import BaseModel
import boto3
import os
from dotenv import load_dotenv
import psycopg2
from langchain.vectorstores import FAISS
from langchain.embeddings import BedrockEmbeddings
from langchain.llms import Bedrock
from langchain.agents import initialize_agent, Tool
from langchain.chains import RetrievalQA
from langchain.text_splitter import RecursiveCharacterTextSplitter
import faiss
import pickle
import pandas as pd
import numpy as np
from PyPDF2 import PdfReader
from docx import Document
import logging
import config

# Configure logging
logging.basicConfig(level=getattr(logging, config.LOG_LEVEL.upper(), logging.INFO))
logger = logging.getLogger(__name__)

# === PROMPT MANAGEMENT ===
# Load RETROS-structured prompts from external files for easy customization

def load_prompt(filename: str) -> str:
    """Load prompt content from text file"""
    try:
        with open(filename, 'r', encoding='utf-8') as f:
            return f.read().strip()
    except FileNotFoundError:
        return f"Error: Prompt file {filename} not found"

# Load prompts
SYSTEM_MESSAGE = load_prompt('prompts/system.prompt')
RAG_TOOL_DESCRIPTION_TEMPLATE = load_prompt('prompts/rag.prompt')
SCHEMA_TOOL_DESCRIPTION_TEMPLATE = load_prompt('prompts/schema.prompt')
DB_TOOL_DESCRIPTION = load_prompt('prompts/db.prompt')

# === CONFIGURATION ===
load_dotenv()

app = FastAPI(title="Finance AI Agent API", description="API for uploading documents, creating embeddings, and querying with RAG and DB tools using AWS Bedrock")

class QueryRequest(BaseModel):
    question: str
    user_id: str = ""
    user_role: str = "employee"
    user_profile: str = ""
    user_settings: str = ""
    security_level: str = "standard"
    user_department: str = ""

# === AWS SERVICES INITIALIZATION ===
s3_client = boto3.client('s3', region_name=config.BEDROCK_REGION)
bedrock_client = boto3.client('bedrock-runtime', region_name=config.BEDROCK_REGION)

# Initialize embeddings and LLM
embeddings = BedrockEmbeddings(client=bedrock_client, model_id=config.EMBEDDINGS_MODEL_ID)
llm = Bedrock(client=bedrock_client, model_id=config.LLM_MODEL_ID)

# === DATABASE CONNECTION ===
def get_db_connection():
    """Create and return a database connection to Postgres"""
    return psycopg2.connect(
        host=config.DB_HOST,
        database=config.DB_NAME,
        user=config.DB_USER,
        password=config.DB_PASSWORD
    )

# === DOCUMENT PROCESSING ===
# Extract text content from various file formats for embedding and analysis

def extract_text_from_file(file_path: str, file_type: str) -> Union[str, List[str]]:
    """
    Extract text content from different file types.
    Returns string for small files, list of strings for large CSVs (converted to JSONL chunks).
    Enhanced to handle structured data dictionary and query patterns JSON files.
    """
    if file_type == "pdf":
        reader = PdfReader(file_path)
        text = ""
        for page in reader.pages:
            text += page.extract_text()
        return text
    elif file_type == "docx":
        doc = Document(file_path)
        text = ""
        for para in doc.paragraphs:
            text += para.text + "\n"
        return text
    elif file_type == "txt":
        with open(file_path, 'r', encoding='utf-8') as f:
            return f.read()
    elif file_type == "csv":
        df = pd.read_csv(file_path)
        
        # Check if this is a data dictionary CSV
        data_dict_columns = {'table_name', 'column_name', 'data_type', 'description'}
        if data_dict_columns.issubset(set(df.columns)):
            return format_data_dictionary_csv(df)
        
        # Check if this is a query patterns CSV
        query_pattern_columns = {'pattern_id', 'name', 'sql_query', 'description'}
        if query_pattern_columns.issubset(set(df.columns)):
            return format_query_patterns_csv(df)
        
        # Otherwise, process as regular CSV
        if len(df) > config.CSV_LARGE_THRESHOLD:
            # Convert to JSONL chunks
            records = df.to_dict('records')
            jsonl_lines = [json.dumps(record) for record in records]
            
            # Chunk the lines
            chunks = []
            for i in range(0, len(jsonl_lines), config.CSV_CHUNK_LINES):
                chunk_lines = jsonl_lines[i:i + config.CSV_CHUNK_LINES]
                chunk_text = '\n'.join(chunk_lines)
                chunks.append(chunk_text)
            return chunks
        else:
            # Use summary approach for small CSVs
            text = f"""
Dataset Overview:

Columns: {', '.join(df.columns)}

Data Types:
{df.dtypes.to_string()}

Shape: {df.shape[0]} rows, {df.shape[1]} columns

"""
            if not df.empty:
                # Summary stats for numeric columns
                numeric_cols = df.select_dtypes(include=[np.number]).columns
                if len(numeric_cols) > 0:
                    text += f"\nSummary Statistics (numeric columns):\n{df[numeric_cols].describe().to_string()}\n"
                
                # Value counts for categorical columns (top 5)
                categorical_cols = df.select_dtypes(include=['object', 'category']).columns
                for col in categorical_cols[:config.CSV_MAX_CATEGORICAL]:  # Limit to first 3 categorical columns
                    if df[col].nunique() <= config.CSV_MAX_UNIQUE:  # Only if not too many unique values
                        text += f"\nValue counts for {col}:\n{df[col].value_counts().head().to_string()}\n"
                
                # Sample data
                sample_size = min(config.CSV_SAMPLE_SIZE, len(df))
                text += f"\nSample Data (first {sample_size} rows):\n{df.head(sample_size).to_string()}\n"
            
            if len(df) > 10000:
                text += f"\n\nNote: Large dataset with {len(df)} rows. Analysis based on summary and sample."
            
            return text
    elif file_type == "json":
        with open(file_path, 'r', encoding='utf-8') as f:
            data = json.load(f)
            
            # Check if this is a structured data dictionary
            if isinstance(data, dict) and "tables" in data:
                return format_data_dictionary(data)
            # Check if this is a structured query patterns file
            elif isinstance(data, dict) and "query_patterns" in data:
                return format_query_patterns(data)
            # Otherwise treat as regular JSON
            else:
                return json.dumps(data, indent=2)
    else:
        raise ValueError(f"Unsupported file type: {file_type}")

def format_data_dictionary(data: dict) -> str:
    """
    Format a structured data dictionary JSON into readable text for embedding.
    """
    text_parts = []
    
    # Header information
    if "database_name" in data:
        text_parts.append(f"Database: {data['database_name']}")
    if "version" in data:
        text_parts.append(f"Version: {data['version']}")
    if "description" in data:
        text_parts.append(f"Description: {data.get('description', 'No description available')}")
    
    text_parts.append("\n" + "="*80 + "\n")
    
    # Process each table
    for table in data.get("tables", []):
        table_name = table.get("table_name", "Unknown Table")
        text_parts.append(f"TABLE: {table_name}")
        text_parts.append("-" * (len(table_name) + 7))
        
        if "description" in table:
            text_parts.append(f"Description: {table['description']}")
        if "category" in table:
            text_parts.append(f"Category: {table['category']}")
        if "owner" in table:
            text_parts.append(f"Owner: {table['owner']}")
        
        text_parts.append("\nCOLUMNS:")
        
        # Process columns
        for col in table.get("columns", []):
            col_name = col.get("column_name", "Unknown")
            data_type = col.get("data_type", "Unknown")
            nullable = "NULL" if col.get("nullable", True) else "NOT NULL"
            
            text_parts.append(f"  - {col_name} ({data_type}) {nullable}")
            
            if "description" in col:
                text_parts.append(f"    Description: {col['description']}")
            
            if col.get("primary_key"):
                text_parts.append("    Primary Key: Yes")
            
            if "foreign_key" in col:
                fk = col["foreign_key"]
                text_parts.append(f"    Foreign Key -> {fk.get('referenced_table', 'Unknown')}.{fk.get('referenced_column', 'Unknown')}")
                text_parts.append(f"    Relationship: {fk.get('relationship_type', 'Unknown')}")
            
            if "business_rules" in col and col["business_rules"]:
                text_parts.append(f"    Business Rules: {', '.join(col['business_rules'])}")
            
            if "sample_values" in col and col["sample_values"]:
                samples = [str(v) for v in col["sample_values"][:3]]  # Limit to 3 samples
                text_parts.append(f"    Sample Values: {', '.join(samples)}")
            
            text_parts.append("")  # Empty line between columns
        
        # Process relationships
        if "relationships" in table and table["relationships"]:
            text_parts.append("RELATIONSHIPS:")
            for rel in table["relationships"]:
                text_parts.append(f"  - {rel.get('type', 'Unknown')} relationship with {rel.get('related_table', 'Unknown')}: {rel.get('description', '')}")
            text_parts.append("")
        
        # Process indexes
        if "indexes" in table and table["indexes"]:
            text_parts.append("INDEXES:")
            for idx in table["indexes"]:
                cols = ", ".join(idx.get("columns", []))
                unique = "UNIQUE" if idx.get("unique") else ""
                text_parts.append(f"  - {idx.get('index_name', 'Unknown')}: ({cols}) {unique}")
            text_parts.append("")
        
        # Process usage patterns
        if "usage_patterns" in table and table["usage_patterns"]:
            text_parts.append("USAGE PATTERNS:")
            for pattern in table["usage_patterns"]:
                text_parts.append(f"  - {pattern}")
            text_parts.append("")
        
        text_parts.append("\n" + "="*80 + "\n")
    
    # Process relationships overview
    if "relationships_overview" in data and data["relationships_overview"]:
        text_parts.append("KEY RELATIONSHIPS OVERVIEW:")
        text_parts.append("="*50)
        for rel in data["relationships_overview"]:
            text_parts.append(f"Relationship: {rel.get('name', 'Unknown')}")
            text_parts.append(f"Description: {rel.get('description', '')}")
            text_parts.append(f"Tables Involved: {', '.join(rel.get('tables_involved', []))}")
            text_parts.append("")
    
    return "\n".join(text_parts)

def format_data_dictionary_csv(df: pd.DataFrame) -> str:
    """
    Format a CSV data dictionary into readable text for embedding.
    Expects columns: table_name, column_name, data_type, description, nullable, primary_key, etc.
    """
    text_parts = []
    
    # Group by table
    tables = df.groupby('table_name')
    
    for table_name, table_df in tables:
        text_parts.append(f"TABLE: {table_name}")
        text_parts.append("-" * (len(table_name) + 7))
        
        # Table-level info (take first row for table-level columns)
        first_row = table_df.iloc[0]
        if pd.notna(first_row.get('description')) and first_row['description']:
            text_parts.append(f"Description: {first_row['description']}")
        if pd.notna(first_row.get('category')) and first_row['category']:
            text_parts.append(f"Category: {first_row['category']}")
        if pd.notna(first_row.get('owner')) and first_row['owner']:
            text_parts.append(f"Owner: {first_row['owner']}")
        
        text_parts.append("\nCOLUMNS:")
        
        # Process each column
        for _, row in table_df.iterrows():
            col_name = row.get('column_name', 'Unknown')
            data_type = row.get('data_type', 'Unknown')
            nullable = "NULL" if row.get('nullable', True) else "NOT NULL"
            
            text_parts.append(f"  - {col_name} ({data_type}) {nullable}")
            
            if pd.notna(row.get('description')) and row['description']:
                text_parts.append(f"    Description: {row['description']}")
            
            if row.get('primary_key'):
                text_parts.append("    Primary Key: Yes")
            
            if pd.notna(row.get('foreign_key_table')) and row['foreign_key_table']:
                fk_table = row['foreign_key_table']
                fk_column = row.get('foreign_key_column', 'Unknown')
                rel_type = row.get('relationship_type', 'Unknown')
                text_parts.append(f"    Foreign Key -> {fk_table}.{fk_column}")
                text_parts.append(f"    Relationship: {rel_type}")
            
            if pd.notna(row.get('business_rules')) and row['business_rules']:
                rules = str(row['business_rules']).split('|')
                text_parts.append(f"    Business Rules: {'; '.join(rules)}")
            
            if pd.notna(row.get('sample_values')) and row['sample_values']:
                samples = str(row['sample_values']).split('|')
                samples = [s.strip() for s in samples[:3]]  # Limit to 3 samples
                text_parts.append(f"    Sample Values: {', '.join(samples)}")
            
            if pd.notna(row.get('constraints')) and row['constraints']:
                text_parts.append(f"    Constraints: {row['constraints']}")
            
            text_parts.append("")  # Empty line between columns
        
        # Process indexes (group by table and collect indexes)
        index_rows = table_df[pd.notna(table_df.get('indexes')) & (table_df['indexes'] != '')]
        if not index_rows.empty:
            text_parts.append("INDEXES:")
            for _, row in index_rows.iterrows():
                text_parts.append(f"  - {row['indexes']}")
            text_parts.append("")
        
        # Process usage patterns
        usage_rows = table_df[pd.notna(table_df.get('usage_patterns')) & (table_df['usage_patterns'] != '')]
        if not usage_rows.empty:
            text_parts.append("USAGE PATTERNS:")
            for _, row in usage_rows.iterrows():
                patterns = str(row['usage_patterns']).split('|')
                for pattern in patterns:
                    text_parts.append(f"  - {pattern.strip()}")
            text_parts.append("")
        
        text_parts.append("\n" + "="*80 + "\n")
    
    return "\n".join(text_parts)

def format_query_patterns_csv(df: pd.DataFrame) -> str:
    """
    Format a CSV query patterns file into readable text for embedding.
    Expects columns: pattern_id, name, description, sql_query, parameters, etc.
    """
    text_parts = []
    
    for _, row in df.iterrows():
        pattern_id = row.get('pattern_id', 'Unknown')
        name = row.get('name', 'Unknown Pattern')
        
        text_parts.append(f"QUERY PATTERN: {name} (ID: {pattern_id})")
        text_parts.append("-" * (len(name) + len(pattern_id) + 18))
        
        if pd.notna(row.get('description')) and row['description']:
            text_parts.append(f"Description: {row['description']}")
        if pd.notna(row.get('category')) and row['category']:
            text_parts.append(f"Category: {row['category']}")
        if pd.notna(row.get('complexity')) and row['complexity']:
            text_parts.append(f"Complexity: {row['complexity']}")
        
        text_parts.append("\nSQL QUERY:")
        if pd.notna(row.get('sql_query')) and row['sql_query']:
            text_parts.append(row['sql_query'])
        else:
            text_parts.append("No SQL provided")
        
        # Process parameters
        if pd.notna(row.get('parameters')) and row['parameters']:
            text_parts.append("\nPARAMETERS:")
            params = str(row['parameters']).split(';')
            for param in params:
                if ':' in param:
                    parts = param.split(':')
                    if len(parts) >= 4:
                        param_name = parts[0].strip()
                        param_type = parts[1].strip()
                        param_desc = parts[2].strip()
                        required = "Required" if parts[3].strip().lower() == 'true' else "Optional"
                        text_parts.append(f"  - {param_name}: {param_type} - {param_desc} ({required})")
        
        # Process tables used
        if pd.notna(row.get('tables_used')) and row['tables_used']:
            tables = str(row['tables_used']).split(',')
            text_parts.append(f"\nTABLES USED: {', '.join(t.strip() for t in tables)}")
        
        # Process joins
        if pd.notna(row.get('joins_required')) and row['joins_required']:
            text_parts.append("\nJOINS REQUIRED:")
            joins = str(row['joins_required']).split(';')
            for join in joins:
                if ':' in join:
                    parts = join.split(':')
                    if len(parts) >= 3:
                        left_table = parts[0].strip()
                        join_type = parts[1].strip()
                        condition = parts[2].strip()
                        text_parts.append(f"  - {left_table} {join_type} JOIN {condition}")
        
        # Process output columns
        if pd.notna(row.get('output_columns')) and row['output_columns']:
            text_parts.append("\nOUTPUT COLUMNS:")
            columns = str(row['output_columns']).split(',')
            for col in columns:
                if ':' in col:
                    parts = col.split(':')
                    if len(parts) >= 4:
                        col_name = parts[0].strip()
                        col_desc = parts[1].strip()
                        data_type = parts[2].strip()
                        nullable = "NULL" if parts[3].strip().lower() == 'true' else "NOT NULL"
                        text_parts.append(f"  - {col_name}: {col_desc} ({data_type}) {nullable}")
        
        # Process business context
        if pd.notna(row.get('business_context')) and row['business_context']:
            context_parts = str(row['business_context']).split(':')
            if len(context_parts) >= 3:
                use_case = context_parts[0].strip()
                frequency = context_parts[1].strip()
                stakeholders = context_parts[2].strip().split('|')
                text_parts.append(f"\nBUSINESS CONTEXT:")
                text_parts.append(f"  Use Case: {use_case}")
                text_parts.append(f"  Frequency: {frequency}")
                text_parts.append(f"  Stakeholders: {', '.join(s.strip() for s in stakeholders)}")
        
        # Process performance characteristics
        if pd.notna(row.get('performance_characteristics')) and row['performance_characteristics']:
            perf_parts = str(row['performance_characteristics']).split(':')
            if len(perf_parts) >= 2:
                runtime = perf_parts[0].strip()
                result_size = perf_parts[1].strip()
                text_parts.append(f"\nPERFORMANCE:")
                text_parts.append(f"  Expected Runtime: {runtime}")
                text_parts.append(f"  Result Size: {result_size}")
        
        # Process tags
        if pd.notna(row.get('tags')) and row['tags']:
            tags = str(row['tags']).split('|')
            text_parts.append(f"\nTAGS: {', '.join(t.strip() for t in tags)}")
        
        # Process related patterns
        if pd.notna(row.get('related_patterns')) and row['related_patterns']:
            related = str(row['related_patterns']).split('|')
            text_parts.append(f"\nRELATED PATTERNS: {', '.join(r.strip() for r in related)}")
        
        text_parts.append("\n" + "="*80 + "\n")
    
    return "\n".join(text_parts)

# === API ENDPOINTS ===
# FastAPI routes for document upload, processing, and querying

@app.post("/upload/{doc_type}")
async def upload_file(doc_type: str, file: UploadFile = File(...)):
    """
    Upload document to S3 storage.
    Args:
        doc_type: "data" for business documents, "metadata" for schema/data dictionary,
                 "data_dictionary" for structured data dictionaries, "query_patterns" for SQL query patterns
        file: Uploaded file (CSV, PDF, Word, JSON, etc.)
    Returns:
        Upload confirmation with S3 key
    """
    if doc_type not in ["data", "metadata", "data_dictionary", "query_patterns"]:
        raise HTTPException(status_code=400, detail="Invalid type. Must be 'data', 'metadata', 'data_dictionary', or 'query_patterns'")
    if file.filename.split('.')[-1].lower() not in ["csv", "json", "txt", "pdf", "docx"]:
        raise HTTPException(status_code=400, detail="Unsupported file type")

    try:
        if doc_type == "data":
            folder = config.DATA_FOLDER
        elif doc_type == "metadata":
            folder = config.METADATA_FOLDER
        elif doc_type == "data_dictionary":
            folder = config.DATA_DICTIONARY_FOLDER
        elif doc_type == "query_patterns":
            folder = config.QUERY_PATTERNS_FOLDER
        
        # Upload to S3
        s3_key = folder + file.filename
        s3_client.upload_fileobj(file.file, config.S3_BUCKET, s3_key)
        return {"message": f"File {file.filename} uploaded successfully to S3 {doc_type} folder", "s3_key": s3_key}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/process/{doc_type}/{filename}")
async def process_file(doc_type: str, filename: str):
    """
    Process uploaded document to create embeddings and FAISS index.
    Downloads from S3, extracts text, creates vector embeddings, stores FAISS index back to S3.
    Args:
        doc_type: "data", "metadata", "data_dictionary", or "query_patterns"
        filename: Name of uploaded file
    Returns:
        Processing completion status
    """
    if doc_type not in ["data", "metadata", "data_dictionary", "query_patterns"]:
        raise HTTPException(status_code=400, detail="Invalid type. Must be 'data', 'metadata', 'data_dictionary', or 'query_patterns'")
    
    if doc_type == "data":
        folder = config.DATA_FOLDER
        embeddings_folder = config.DATA_EMBEDDINGS_FOLDER
    elif doc_type == "metadata":
        folder = config.METADATA_FOLDER
        embeddings_folder = config.METADATA_EMBEDDINGS_FOLDER
    elif doc_type == "data_dictionary":
        folder = config.DATA_DICTIONARY_FOLDER
        embeddings_folder = config.DATA_DICTIONARY_EMBEDDINGS_FOLDER
    elif doc_type == "query_patterns":
        folder = config.QUERY_PATTERNS_FOLDER
        embeddings_folder = config.QUERY_PATTERNS_EMBEDDINGS_FOLDER
    
    s3_key = folder + filename
    file_type = filename.split('.')[-1].lower()

    try:
        # Download file from S3
        local_path = f"/tmp/{filename}"
        s3_client.download_file(config.S3_BUCKET, s3_key, local_path)

        # Extract text
        text_or_texts = extract_text_from_file(local_path, file_type)

        if isinstance(text_or_texts, list):
            chunks = text_or_texts
        else:
            # Split text into chunks
            text_splitter = RecursiveCharacterTextSplitter(
                chunk_size=config.CHUNK_SIZE,
                chunk_overlap=config.CHUNK_OVERLAP,
                separators=config.SEPARATORS,
                length_function=len
            )
            chunks = text_splitter.split_text(text_or_texts)

        # Create FAISS index
        vectorstore = FAISS.from_texts(chunks, embeddings)

        # Save FAISS index locally
        faiss_path = f"/tmp/{filename}_faiss"
        vectorstore.save_local(faiss_path)

        # Upload FAISS files to S3
        for file in os.listdir(faiss_path):
            s3_client.upload_file(f"{faiss_path}/{file}", config.S3_BUCKET, embeddings_folder + f"{filename}_{file}")

        # Clean up
        os.remove(local_path)
        import shutil
        shutil.rmtree(faiss_path)

        return {"message": f"Embeddings created and FAISS stored for {filename} in {doc_type} embeddings"}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

# === AI AGENT TOOLS ===
# LangChain tools that provide different capabilities to the AI agent

def create_rag_tool(doc_type: str, filename: str):
    """
    Create a RAG (Retrieval-Augmented Generation) tool for document querying.
    Loads FAISS index from S3 and creates a retrieval QA chain.
    Args:
        doc_type: "data", "metadata", "data_dictionary", or "query_patterns"
        filename: Base filename of the processed document
    Returns:
        LangChain Tool for document retrieval
    """
    if doc_type not in ["data", "metadata", "data_dictionary", "query_patterns"]:
        raise ValueError("Invalid doc_type")
    
    if doc_type == "data":
        embeddings_folder = config.DATA_EMBEDDINGS_FOLDER
        tool_name = "Data_RAG"
    elif doc_type == "metadata":
        embeddings_folder = config.METADATA_EMBEDDINGS_FOLDER
        tool_name = "Metadata_RAG"
    elif doc_type == "data_dictionary":
        embeddings_folder = config.DATA_DICTIONARY_EMBEDDINGS_FOLDER
        tool_name = "DataDictionary_RAG"
    elif doc_type == "query_patterns":
        embeddings_folder = config.QUERY_PATTERNS_EMBEDDINGS_FOLDER
        tool_name = "QueryPatterns_RAG"
    
    # Download FAISS files from S3
    faiss_path = f"/tmp/{filename}_faiss"
    os.makedirs(faiss_path, exist_ok=True)

    logger.info(f"Downloading FAISS index for {doc_type} document '{filename}' from S3...")
    # Assuming FAISS saves index.faiss and index.pkl
    s3_client.download_file(config.S3_BUCKET, embeddings_folder + f"{filename}_index.faiss", f"{faiss_path}/index.faiss")
    s3_client.download_file(config.S3_BUCKET, embeddings_folder + f"{filename}_index.pkl", f"{faiss_path}/index.pkl")

    # Load FAISS
    logger.info(f"Loading FAISS vectorstore for {doc_type} document '{filename}'...")
    vectorstore = FAISS.load_local(faiss_path, embeddings)

    # Create retrieval QA
    logger.info(f"Creating retrieval QA chain for {doc_type} document '{filename}'...")
    qa_chain = RetrievalQA.from_chain_type(llm=llm, chain_type="stuff", retriever=vectorstore.as_retriever(search_type="mmr", search_kwargs={"k": config.MMR_K, "lambda_mult": config.MMR_LAMBDA_MULT}))

    def rag_query(query: str) -> str:
        logger.info(f"Running RAG query for {doc_type} document: {query}")
        result = qa_chain.run(query)
        logger.info(f"RAG query result for {doc_type}: {result[:200]}...")  # Log first 200 chars
        return result

    description = RAG_TOOL_DESCRIPTION_TEMPLATE.format(doc_type=doc_type)

    return Tool(
        name=tool_name,
        description=description,
        func=rag_query
    )

def create_database_explorer_tool():
    """
    Create a database exploration tool that provides an overview of the entire database schema.
    Useful for understanding the overall data model and finding relevant tables for queries.
    """
    def explore_database(query_input: str) -> str:
        """
        Provide database overview, table relationships, and suggest relevant tables for queries.
        """
        try:
            conn = get_db_connection()
            cur = conn.cursor()

            output_parts = ["DATABASE EXPLORATION REPORT"]
            output_parts.append("=" * 50)

            # Get all tables
            cur.execute("""
                SELECT table_name, table_type
                FROM information_schema.tables
                WHERE table_schema = 'public' AND table_type = 'BASE TABLE'
                ORDER BY table_name
            """)

            tables = cur.fetchall()
            output_parts.append(f"\nTOTAL TABLES: {len(tables)}")

            if tables:
                output_parts.append("\nALL TABLES:")
                for table_name, table_type in tables:
                    output_parts.append(f"  • {table_name} ({table_type})")

            # Get table relationships (foreign keys)
            cur.execute("""
                SELECT
                    tc.table_name as source_table,
                    ku.column_name as source_column,
                    c2.table_name as target_table,
                    ku2.column_name as target_column
                FROM information_schema.table_constraints tc
                JOIN information_schema.key_column_usage ku ON tc.constraint_name = ku.constraint_name
                JOIN information_schema.referential_constraints rc ON tc.constraint_name = rc.constraint_name
                JOIN information_schema.key_column_usage ku2 ON rc.unique_constraint_name = ku2.constraint_name
                JOIN information_schema.columns c2 ON ku2.table_name = c2.table_name AND ku2.column_name = c2.column_name
                WHERE tc.constraint_type = 'FOREIGN KEY' AND tc.table_schema = 'public'
                ORDER BY tc.table_name, ku.column_name
            """)

            relationships = cur.fetchall()
            if relationships:
                output_parts.append(f"\nTABLE RELATIONSHIPS ({len(relationships)} foreign keys):")
                for source_table, source_col, target_table, target_col in relationships:
                    output_parts.append(f"  {source_table}.{source_col} → {target_table}.{target_col}")

            # Analyze query input to suggest relevant tables
            if query_input and query_input.strip():
                query_lower = query_input.lower()
                relevant_tables = []

                # Dynamically analyze tables and columns to suggest relevance
                for table_name, table_type in tables:
                    table_score = 0
                    matching_columns = []

                    # Get columns for this table to analyze relevance
                    try:
                        cur.execute("""
                            SELECT column_name, data_type
                            FROM information_schema.columns
                            WHERE table_name = %s AND table_schema = 'public'
                        """, (table_name,))
                        columns = cur.fetchall()

                        for col_name, data_type in columns:
                            col_lower = col_name.lower()

                            # Score based on column name matches
                            if any(keyword in col_lower for keyword in ['amount', 'price', 'cost', 'value', 'total']) and any(kw in query_lower for kw in ['expense', 'cost', 'money', 'amount', 'spend', 'budget']):
                                table_score += 3
                                matching_columns.append(f"{col_name} (financial)")

                            if any(keyword in col_lower for keyword in ['date', 'time', 'created', 'updated']) and any(kw in query_lower for kw in ['when', 'date', 'time', 'trend', 'period', 'month', 'year']):
                                table_score += 2
                                matching_columns.append(f"{col_name} (temporal)")

                            if any(keyword in col_lower for keyword in ['name', 'description', 'title']) and any(kw in query_lower for kw in ['what', 'describe', 'name', 'detail']):
                                table_score += 2
                                matching_columns.append(f"{col_name} (descriptive)")

                            if col_name.endswith('_id') and any(kw in query_lower for kw in ['by', 'group', 'categorize', 'department', 'category', 'vendor']):
                                table_score += 2
                                matching_columns.append(f"{col_name} (relationship)")

                        # Score based on table name matches
                        table_lower = table_name.lower()
                        if 'expense' in table_lower and any(kw in query_lower for kw in ['expense', 'cost', 'spend', 'money']):
                            table_score += 4
                        if 'department' in table_lower and any(kw in query_lower for kw in ['department', 'team', 'group', 'organizational']):
                            table_score += 4
                        if 'vendor' in table_lower and any(kw in query_lower for kw in ['vendor', 'supplier', 'provider', 'purchase']):
                            table_score += 4
                        if 'category' in table_lower and any(kw in query_lower for kw in ['category', 'type', 'classification', 'group']):
                            table_score += 4
                        if 'budget' in table_lower and any(kw in query_lower for kw in ['budget', 'allocation', 'planned']):
                            table_score += 4

                        # General business intelligence keywords
                        if any(kw in query_lower for kw in ['analysis', 'report', 'summary', 'overview', 'performance']):
                            table_score += 1  # Slight boost for analysis queries

                        # Store table with its score and matching info
                        if table_score > 0:
                            relevant_tables.append((table_name, table_score, matching_columns[:3]))  # Limit to top 3 matching columns

                    except Exception:
                        continue  # Skip tables we can't analyze

                # Sort by relevance score and format output
                relevant_tables.sort(key=lambda x: x[1], reverse=True)

                if relevant_tables:
                    output_parts.append(f"\nRECOMMENDED TABLES FOR QUERY (ranked by relevance):")
                    for table_name, score, matching_cols in relevant_tables[:5]:  # Top 5 most relevant
                        relevance_indicator = "⭐⭐⭐" if score >= 4 else "⭐⭐" if score >= 2 else "⭐"
                        output_parts.append(f"  {relevance_indicator} {table_name} (score: {score})")
                        if matching_cols:
                            output_parts.append(f"    Matching columns: {', '.join(matching_cols)}")
                    output_parts.append("\nThese tables may contain relevant data for your question.")
                else:
                    output_parts.append("\nRECOMMENDED TABLES: Could not determine specific table recommendations.")
                    output_parts.append("Try using the Enhanced_Schema tool on specific table names.")

            cur.close()
            conn.close()

            return "\n".join(output_parts)

        except Exception as e:
            return f"Error exploring database: {str(e)}"

    return Tool(
        name="Database_Explorer",
        description="Provides an overview of the entire database schema, table relationships, and suggests relevant tables for specific queries.",
        func=explore_database
    )

def create_enhanced_schema_tool(table_name: str = config.SCHEMA_TABLE_NAME):
    """
    Enhanced schema information tool that provides comprehensive database understanding.
    Queries multiple information_schema tables and uses heuristics to provide business context.
    Args:
        table_name: Name of the database table (default: from config)
    Returns:
        LangChain Tool for comprehensive schema and business context retrieval
    """
    def get_enhanced_schema_info(query_input: str) -> str:
        # Parse table name from query, or use default
        table_name_to_query = query_input.strip() if query_input.strip() else table_name

        try:
            conn = get_db_connection()
            cur = conn.cursor()

            # Get comprehensive table information
            output_parts = []

            # 1. Basic table information
            cur.execute("""
                SELECT table_name, table_type
                FROM information_schema.tables
                WHERE table_name = %s AND table_schema = 'public'
            """, (table_name_to_query,))
            table_result = cur.fetchone()

            if not table_result:
                return f"No table found with name '{table_name_to_query}'."

            table_name_result, table_type = table_result
            output_parts.append(f"TABLE: {table_name_result} ({table_type})")
            output_parts.append("=" * 60)

            # 2. Column information with relationships
            cur.execute("""
                SELECT
                    c.column_name,
                    c.data_type,
                    c.is_nullable,
                    c.column_default,
                    c.ordinal_position,
                    CASE WHEN pk.column_name IS NOT NULL THEN 'PRIMARY KEY' ELSE '' END as pk_flag,
                    fk.referenced_table_name,
                    fk.referenced_column_name
                FROM information_schema.columns c
                LEFT JOIN (
                    SELECT ku.column_name, ku.table_name
                    FROM information_schema.table_constraints tc
                    JOIN information_schema.key_column_usage ku ON tc.constraint_name = ku.constraint_name
                    WHERE tc.constraint_type = 'PRIMARY KEY' AND tc.table_name = %s
                ) pk ON c.column_name = pk.column_name AND c.table_name = pk.table_name
                LEFT JOIN (
                    SELECT
                        ku.column_name,
                        c2.table_name as referenced_table_name,
                        ku2.column_name as referenced_column_name
                    FROM information_schema.table_constraints tc
                    JOIN information_schema.key_column_usage ku ON tc.constraint_name = ku.constraint_name
                    JOIN information_schema.referential_constraints rc ON tc.constraint_name = rc.constraint_name
                    JOIN information_schema.key_column_usage ku2 ON rc.unique_constraint_name = ku2.constraint_name
                    JOIN information_schema.columns c2 ON ku2.table_name = c2.table_name AND ku2.column_name = c2.column_name
                    WHERE tc.constraint_type = 'FOREIGN KEY' AND tc.table_name = %s
                ) fk ON c.column_name = fk.column_name
                WHERE c.table_name = %s AND c.table_schema = 'public'
                ORDER BY c.ordinal_position
            """, (table_name_to_query, table_name_to_query, table_name_to_query))

            columns = cur.fetchall()

            if columns:
                output_parts.append("\nCOLUMNS:")
                for col in columns:
                    col_name, data_type, nullable, default, ordinal, pk_flag, ref_table, ref_col = col
                    col_info = f"  {ordinal}. {col_name} ({data_type})"

                    flags = []
                    if pk_flag:
                        flags.append("PRIMARY KEY")
                    if nullable == 'NO':
                        flags.append("NOT NULL")

                    if flags:
                        col_info += f" [{' | '.join(flags)}]"

                    output_parts.append(col_info)

                    # Add relationship info
                    if ref_table:
                        output_parts.append(f"     → References {ref_table}.{ref_col}")

                    # Add default value if present
                    if default:
                        output_parts.append(f"     → Default: {default}")

                    # Add business context based on naming patterns
                    business_context = infer_column_business_context(col_name, data_type, table_name_to_query)
                    if business_context:
                        output_parts.append(f"     → Business context: {business_context}")

            # 3. Table constraints
            cur.execute("""
                SELECT tc.constraint_type, tc.constraint_name, ku.column_name
                FROM information_schema.table_constraints tc
                JOIN information_schema.key_column_usage ku ON tc.constraint_name = ku.constraint_name
                WHERE tc.table_name = %s AND tc.table_schema = 'public'
                ORDER BY tc.constraint_type, tc.constraint_name
            """, (table_name_to_query,))

            constraints = cur.fetchall()
            if constraints:
                output_parts.append("\nCONSTRAINTS:")
                for constraint_type, constraint_name, column_name in constraints:
                    output_parts.append(f"  {constraint_type}: {constraint_name} on {column_name}")

            # 4. Indexes
            cur.execute("""
                SELECT indexname, indexdef
                FROM pg_indexes
                WHERE tablename = %s AND schemaname = 'public'
            """, (table_name_to_query,))

            indexes = cur.fetchall()
            if indexes:
                output_parts.append("\nINDEXES:")
                for index_name, index_def in indexes:
                    output_parts.append(f"  {index_name}: {index_def}")

            # 5. Sample data (limited)
            try:
                cur.execute(f"SELECT * FROM {table_name_to_query} LIMIT 3")
                sample_rows = cur.fetchall()
                column_names = [desc[0] for desc in cur.description]

                if sample_rows:
                    output_parts.append(f"\nSAMPLE DATA (first 3 rows):")
                    output_parts.append(" | ".join(column_names))
                    output_parts.append("-" * (len(" | ".join(column_names))))

                    for row in sample_rows:
                        # Truncate long values for display
                        display_values = []
                        for val in row:
                            val_str = str(val) if val is not None else "NULL"
                            display_values.append(val_str[:50] + "..." if len(val_str) > 50 else val_str)
                        output_parts.append(" | ".join(display_values))
            except Exception as e:
                output_parts.append(f"\nSAMPLE DATA: Unable to retrieve ({str(e)})")

            # 6. Business insights
            business_insights = infer_table_business_context(table_name_to_query, columns)
            if business_insights:
                output_parts.append("\nBUSINESS INSIGHTS:")
                for insight in business_insights:
                    output_parts.append(f"  • {insight}")

            cur.close()
            conn.close()

            return "\n".join(output_parts)

        except Exception as e:
            return f"Error getting enhanced schema: {str(e)}"

    return Tool(
        name="Enhanced_Schema",
        description="Provides comprehensive database schema information including columns, relationships, constraints, indexes, sample data, and business context inferred from database structure.",
        func=get_enhanced_schema_info
    )

def infer_column_business_context(column_name: str, data_type: str, table_name: str) -> str:
    """
    Use naming conventions and data types to infer business context for columns.
    """
    insights = []

    # Common patterns
    if column_name.endswith('_id') and column_name != f"{table_name}_id":
        referenced_table = column_name[:-3]  # Remove '_id'
        insights.append(f"References {referenced_table} table")

    if 'amount' in column_name.lower() or 'price' in column_name.lower():
        insights.append("Monetary value - likely represents costs, revenues, or prices")

    if 'date' in column_name.lower() or data_type.upper().startswith('DATE'):
        insights.append("Date/timestamp field - useful for time-based analysis and filtering")

    if 'description' in column_name.lower() or 'name' in column_name.lower():
        insights.append("Textual identifier or description field")

    if 'status' in column_name.lower():
        insights.append("Status indicator - may contain categorical values like 'active', 'inactive', etc.")

    if 'count' in column_name.lower() or 'quantity' in column_name.lower():
        insights.append("Numeric count or quantity field")

    # Data type based insights
    if 'DECIMAL' in data_type.upper() or 'NUMERIC' in data_type.upper():
        insights.append("Decimal number - suitable for financial calculations and aggregations")

    if 'VARCHAR' in data_type.upper() and any(x in data_type for x in ['255', '500', '1000']):
        insights.append("Long text field - may contain detailed descriptions or notes")

    return "; ".join(insights) if insights else ""

def infer_table_business_context(table_name: str, columns: list) -> list:
    """
    Infer business context for tables based on structure and naming.
    """
    insights = []

    # Check for common table patterns
    if 'expense' in table_name.lower():
        insights.append("Transaction table for expense tracking")
        insights.append("Likely contains financial transaction data with amounts and dates")

    if 'department' in table_name.lower():
        insights.append("Organizational structure table")
        insights.append("Contains department information for grouping and reporting")

    if 'category' in table_name.lower():
        insights.append("Classification/dimension table")
        insights.append("Used for grouping and categorizing other data")

    if 'vendor' in table_name.lower() or 'supplier' in table_name.lower():
        insights.append("External party information")
        insights.append("Contains information about vendors or suppliers")

    # Analyze column patterns
    has_amount = any('amount' in str(col[0]).lower() for col in columns)
    has_date = any('date' in str(col[0]).lower() or 'DATE' in str(col[1]) for col in columns)
    has_description = any('description' in str(col[0]).lower() for col in columns)
    has_id_refs = any(str(col[0]).endswith('_id') and str(col[0]) != f"{table_name}_id" for col in columns)

    if has_amount and has_date:
        insights.append("Contains transactional data with monetary amounts and timestamps")

    if has_id_refs:
        insights.append("Contains foreign key relationships - connects to other tables")

    if has_description:
        insights.append("Includes descriptive text fields for additional context")

    # Suggest common query patterns
    if has_amount:
        insights.append("Suitable for SUM, AVG, and other aggregation queries")
    if has_date:
        insights.append("Can be filtered by date ranges and used for time-series analysis")

    return insights

def validate_query(query: str) -> bool:
    """
    Validate SQL query for safety and correctness.
    Checks for SELECT-only, proper syntax, and blocked dangerous operations.
    Args:
        query: SQL query string
    Returns:
        True if query is safe and valid
    """
    query_upper = query.upper().strip()
    
    # Must start with SELECT
    if not query_upper.startswith("SELECT"):
        return False
    
    # Block dangerous operations
    dangerous_keywords = ["DROP", "DELETE", "INSERT", "UPDATE", "CREATE", "ALTER", "TRUNCATE", "EXEC", "EXECUTE"]
    for keyword in dangerous_keywords:
        if keyword in query_upper:
            return False
    
    # Basic syntax check - ensure balanced parentheses
    if query.count("(") != query.count(")"):
        return False
    
    return True

def create_db_tool(user_id: str = "", user_role: str = "employee", user_department: str = ""):
    """
    Create a database query tool with security validation and user-specific filtering.
    Executes SELECT queries with result formatting, automatic limits, and security filters.
    Args:
        user_id: Current user's ID for row-level security
        user_role: User's role (admin, manager, employee) for access control
        user_department: User's department ID for department-level filtering
    Returns:
        LangChain Tool for safe database querying with security filters
    """
    def db_query(query: str) -> str:
        # Apply security filters based on user role
        security_filter = ""
        if user_role == "employee" and user_id:
            # Employees only see their own data
            security_filter = f" AND user_id = '{user_id}'"
        elif user_role == "manager" and user_department:
            # Managers see their department's data
            security_filter = f" AND department_id = '{user_department}'"
        # Admin users have no additional filters

        # Modify query to include security filter if it's a SELECT from expenses
        if "FROM expenses" in query.upper() and security_filter:
            # Insert filter after WHERE if exists, or add WHERE
            if "WHERE" in query.upper():
                query = query.replace(" WHERE ", f" WHERE 1=1{security_filter} AND ", 1)
            else:
                query = query.replace(" FROM expenses", f" FROM expenses WHERE 1=1{security_filter}", 1)

        # Validate query
        if not validate_query(query):
            return "Error: Invalid or unsafe query. Only SELECT queries are allowed."
        
        try:
            conn = get_db_connection()
            cur = conn.cursor()
            cur.execute(query)
            results = cur.fetchall()
            column_names = [desc[0] for desc in cur.description] if cur.description else []
            
            # Limit results for large datasets
            total_rows = len(results)
            if config.DB_MAX_ROWS > 0 and total_rows > config.DB_MAX_ROWS:
                results = results[:config.DB_MAX_ROWS]
                note = f"\n\nNote: Results limited to first {config.DB_MAX_ROWS} rows out of {total_rows} total."
            else:
                note = ""
            
            # Format as readable text
            if results:
                # Create table-like format
                output = " | ".join(column_names) + "\n"
                output += "-" * len(output) + "\n"
                for row in results:
                    output += " | ".join(str(cell) for cell in row) + "\n"
                output += note
            else:
                output = "No results found."
            
            cur.close()
            conn.close()
            return output
        except Exception as e:
            return f"Error executing query: {str(e)}"

    return Tool(
        name="Database",
        description=DB_TOOL_DESCRIPTION,
        func=db_query
    )

@app.post("/query/{data_filename}/{metadata_filename}")
async def query_agent(data_filename: str, metadata_filename: str, request: QueryRequest):
    """
    Main query endpoint that orchestrates AI agent analysis.
    Initializes LangChain agent with RAG, Schema, and DB tools to answer financial questions.
    Uses RETROS-structured prompts and AWS Bedrock Claude model.

    Args:
        data_filename: Name of processed data document
        metadata_filename: Name of processed metadata/schema document
        request: Query request with question

    Returns:
        AI-generated answer based on document and database analysis
    """
    try:
        logger.info("Initializing RAG tools...")
        data_rag_tool = create_rag_tool("data", data_filename)
        metadata_rag_tool = create_rag_tool("metadata", metadata_filename)
        db_tool = create_db_tool(user_id=request.user_id, user_role=request.user_role, user_department=request.user_department)
        enhanced_schema_tool = create_enhanced_schema_tool()
        db_explorer_tool = create_database_explorer_tool()

        # Format system message with user context
        user_context = {
            'user_id': request.user_id,
            'user_role': request.user_role,
            'user_profile': request.user_profile,
            'user_settings': request.user_settings,
            'security_level': request.security_level
        }
        system_message = SYSTEM_MESSAGE.format(**user_context)

        logger.info(f"Initializing LangChain agent for user {request.user_id} (role: {request.user_role}, dept: {request.user_department})...")
        agent = initialize_agent([data_rag_tool, metadata_rag_tool, enhanced_schema_tool, db_explorer_tool, db_tool], llm, agent="zero-shot-react-description", verbose=True, system_message=system_message)

        logger.info(f"Running agent with question: {request.question}")
        response = agent.run(request.question)
        logger.info(f"Agent response: {response}")
        return {"answer": response}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/query/enhanced")
async def query_agent_enhanced(request: QueryRequest, data_filename: str, metadata_filename: str, data_dictionary_filename: str = None, query_patterns_filename: str = None):
    """
    Enhanced query endpoint with optional data dictionary and query patterns support.
    Use query parameters to specify document filenames.

    Args:
        request: Query request with question
        data_filename: Name of processed data document
        metadata_filename: Name of processed metadata/schema document
        data_dictionary_filename: Optional name of processed data dictionary document
        query_patterns_filename: Optional name of processed query patterns document

    Returns:
        AI-generated answer based on document and database analysis
    """
    try:
        logger.info("Initializing RAG tools...")
        tools = []
        
        # Always include data and metadata RAG tools
        data_rag_tool = create_rag_tool("data", data_filename)
        metadata_rag_tool = create_rag_tool("metadata", metadata_filename)
        tools.extend([data_rag_tool, metadata_rag_tool])
        
        # Optionally include data dictionary RAG tool
        if data_dictionary_filename:
            data_dict_rag_tool = create_rag_tool("data_dictionary", data_dictionary_filename)
            tools.append(data_dict_rag_tool)
            logger.info(f"Including data dictionary RAG tool: {data_dictionary_filename}")
        
        # Optionally include query patterns RAG tool
        if query_patterns_filename:
            query_patterns_rag_tool = create_rag_tool("query_patterns", query_patterns_filename)
            tools.append(query_patterns_rag_tool)
            logger.info(f"Including query patterns RAG tool: {query_patterns_filename}")
        
        # Always include enhanced database tools
        db_tool = create_db_tool(user_id=request.user_id, user_role=request.user_role, user_department=request.user_department)
        enhanced_schema_tool = create_enhanced_schema_tool()
        db_explorer_tool = create_database_explorer_tool()
        tools.extend([enhanced_schema_tool, db_explorer_tool, db_tool])

        # Format system message with user context
        user_context = {
            'user_id': request.user_id,
            'user_role': request.user_role,
            'user_profile': request.user_profile,
            'user_settings': request.user_settings,
            'security_level': request.security_level
        }
        system_message = SYSTEM_MESSAGE.format(**user_context)

        logger.info(f"Initializing LangChain agent for user {request.user_id} (role: {request.user_role}, dept: {request.user_department})...")
        agent = initialize_agent(tools, llm, agent="zero-shot-react-description", verbose=True, system_message=system_message)

        logger.info(f"Running agent with question: {request.question}")
        response = agent.run(request.question)
        logger.info(f"Agent response: {response}")
        return {"answer": response}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

# TODO: Implement endpoints

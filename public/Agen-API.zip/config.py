import os

# AWS S3 configurations
S3_BUCKET = os.getenv("S3_BUCKET")
DATA_FOLDER = os.getenv("DATA_FOLDER", "data/")
METADATA_FOLDER = os.getenv("METADATA_FOLDER", "metadata/")
DATA_DICTIONARY_FOLDER = os.getenv("DATA_DICTIONARY_FOLDER", "data_dictionary/")
QUERY_PATTERNS_FOLDER = os.getenv("QUERY_PATTERNS_FOLDER", "query_patterns/")
DATA_EMBEDDINGS_FOLDER = os.getenv("DATA_EMBEDDINGS_FOLDER", "data_embeddings/")
METADATA_EMBEDDINGS_FOLDER = os.getenv("METADATA_EMBEDDINGS_FOLDER", "metadata_embeddings/")
DATA_DICTIONARY_EMBEDDINGS_FOLDER = os.getenv("DATA_DICTIONARY_EMBEDDINGS_FOLDER", "data_dictionary_embeddings/")
QUERY_PATTERNS_EMBEDDINGS_FOLDER = os.getenv("QUERY_PATTERNS_EMBEDDINGS_FOLDER", "query_patterns_embeddings/")

# AWS Bedrock configurations
BEDROCK_REGION = os.getenv("BEDROCK_REGION", "us-east-1")
EMBEDDINGS_MODEL_ID = os.getenv("EMBEDDINGS_MODEL_ID", "amazon.titan-embed-text-v1")
LLM_MODEL_ID = os.getenv("LLM_MODEL_ID", "anthropic.claude-v2")

# Database configurations
DB_HOST = os.getenv("DB_HOST")
DB_NAME = os.getenv("DB_NAME")
DB_USER = os.getenv("DB_USER")
DB_PASSWORD = os.getenv("DB_PASSWORD")

# Chunking configurations
CHUNK_SIZE = int(os.getenv("CHUNK_SIZE", "500"))
CHUNK_OVERLAP = int(os.getenv("CHUNK_OVERLAP", "100"))
SEPARATORS = os.getenv("SEPARATORS", "\n\n,\n,. , ,").split(",")

# Retrieval configurations
MMR_K = int(os.getenv("MMR_K", "5"))
MMR_LAMBDA_MULT = float(os.getenv("MMR_LAMBDA_MULT", "0.7"))

# CSV processing configurations
CSV_SAMPLE_SIZE = int(os.getenv("CSV_SAMPLE_SIZE", "10"))
CSV_MAX_CATEGORICAL = int(os.getenv("CSV_MAX_CATEGORICAL", "3"))
CSV_MAX_UNIQUE = int(os.getenv("CSV_MAX_UNIQUE", "20"))
CSV_LARGE_THRESHOLD = int(os.getenv("CSV_LARGE_THRESHOLD", "1000"))
CSV_CHUNK_LINES = int(os.getenv("CSV_CHUNK_LINES", "50"))
SCHEMA_TABLE_NAME = os.getenv("SCHEMA_TABLE_NAME", "expenses")
DB_MAX_ROWS = int(os.getenv("DB_MAX_ROWS", "50000"))

import asyncio
import json
from sqlalchemy.ext.asyncio import AsyncSession
from app.db.session import async_session
from app.crud.crud_catalog import catalog
from app.models.catalog import Catalog

async def get_catalog_by_id(catalog_id: str):
    """Query and display catalog data by ID"""
    async with async_session() as db:
        try:
            # Get the catalog item
            catalog_item = await catalog.get(db, id=catalog_id)
            
            if catalog_item:
                print(f"Found catalog item with ID: {catalog_id}")
                print("=" * 50)
                
                # Display all fields
                print(f"ID: {catalog_item.id}")
                print(f"Title: {catalog_item.title}")
                print(f"Description: {catalog_item.description}")
                print(f"Summary: {catalog_item.summary}")
                print(f"Type: {catalog_item.type}")
                print(f"Content: {catalog_item.content}")
                print(f"URL: {catalog_item.url}")
                print(f"Image: {catalog_item.image}")
                print(f"Image URL: {catalog_item.imageUrl}")
                print(f"Display: {catalog_item.display}")
                print(f"Tags: {catalog_item.tags}")
                print(f"Author: {catalog_item.author}")
                print(f"Author ID: {catalog_item.author_id}")
                print(f"Created Date: {catalog_item.created_date}")
                print(f"Updated Date: {catalog_item.updated_date}")
                print(f"Expire Date: {catalog_item.expire_date}")
                print(f"Due Date: {catalog_item.due_date}")
                print(f"Category: {catalog_item.category}")
                print(f"Parent ID: {catalog_item.parent_id}")
                print(f"Child IDs: {catalog_item.child_ids}")
                print(f"Priority: {catalog_item.priority}")
                print(f"Severity: {catalog_item.severity}")
                print(f"Urgent: {catalog_item.urgent}")
                print(f"Important: {catalog_item.important}")
                print(f"Likes: {catalog_item.likes}")
                print(f"Usages: {catalog_item.usages}")
                print(f"Favorites: {catalog_item.favorites}")
                print(f"Views: {catalog_item.views}")
                print(f"Shares: {catalog_item.shares}")
                print(f"Approved By: {catalog_item.approved_by}")
                print(f"Reviewed By: {catalog_item.reviewed_by}")
                print(f"Source: {catalog_item.source}")
                print(f"Status: {catalog_item.status}")
                print(f"Private: {catalog_item.private}")
                print(f"Shared With: {catalog_item.shared_with}")
                print(f"Conversations: {catalog_item.conversations}")
                
                # Display custom fields in a formatted way
                if catalog_item.custom:
                    print("\nCustom Fields:")
                    print("-" * 20)
                    for group_name, group_data in catalog_item.custom.items():
                        print(f"  Group: {group_name}")
                        for item in group_data:
                            column = item.get('column', 'N/A')
                            value = item.get('value', 'N/A')
                            print(f"    {column}: {value}")
                        print()
                
                print("=" * 50)
                
                # Also display as JSON for easy copying
                print("\nJSON representation:")
                catalog_dict = {
                    "id": catalog_item.id,
                    "title": catalog_item.title,
                    "description": catalog_item.description,
                    "summary": catalog_item.summary,
                    "type": catalog_item.type,
                    "content": catalog_item.content,
                    "url": catalog_item.url,
                    "image": catalog_item.image,
                    "imageUrl": catalog_item.imageUrl,
                    "display": catalog_item.display,
                    "tags": catalog_item.tags,
                    "author": catalog_item.author,
                    "author_id": catalog_item.author_id,
                    "created_date": catalog_item.created_date.isoformat() if catalog_item.created_date else None,
                    "updated_date": catalog_item.updated_date.isoformat() if catalog_item.updated_date else None,
                    "expire_date": catalog_item.expire_date,
                    "due_date": catalog_item.due_date,
                    "custom": catalog_item.custom,
                    "category": catalog_item.category,
                    "parent_id": catalog_item.parent_id,
                    "child_ids": catalog_item.child_ids,
                    "priority": catalog_item.priority,
                    "severity": catalog_item.severity,
                    "urgent": catalog_item.urgent,
                    "important": catalog_item.important,
                    "likes": catalog_item.likes,
                    "usages": catalog_item.usages,
                    "favorites": catalog_item.favorites,
                    "views": catalog_item.views,
                    "shares": catalog_item.shares,
                    "approved_by": catalog_item.approved_by,
                    "reviewed_by": catalog_item.reviewed_by,
                    "source": catalog_item.source,
                    "status": catalog_item.status,
                    "private": catalog_item.private,
                    "shared_with": catalog_item.shared_with,
                    "conversations": catalog_item.conversations
                }
                print(json.dumps(catalog_dict, indent=2, default=str))
                
            else:
                print(f"No catalog item found with ID: {catalog_id}")
                
        except Exception as e:
            print(f"Error querying catalog: {str(e)}")

if __name__ == "__main__":
    catalog_id = "db1d1828-34a3-4ad6-b5c8-e0bc468379ae"
    asyncio.run(get_catalog_by_id(catalog_id))
# Asset Management System

A simple and clean asset management system built with FastAPI and SQLAlchemy. Manage your organizational assets including hardware, software, services, and infrastructure with full CRUD operations and advanced search capabilities.

## Features

### 🏢 Asset Management
- **Complete CRUD Operations**: Create, Read, Update, Delete assets
- **Asset Types**: Hardware, Software, Service, Infrastructure, Application, Database, Network, Security
- **Status Tracking**: Active, Inactive, Maintenance, Decommissioned, Pending, Retired
- **Business Organization**: Organize assets by Business, Block, and Capability
- **Rich Metadata**: Size attributes, specifications, dependencies, tags, and custom fields

### 🔍 Advanced Search & Filtering
- **Multi-criteria Search**: Search by business, type, status, owner, vendor, location
- **Date Range Filtering**: Filter by purchase dates, warranty expiry
- **Cost Range Filtering**: Filter assets by cost ranges
- **Tag-based Filtering**: Organize and filter using tags
- **General Text Search**: Search across multiple fields simultaneously

### 📊 Analytics & Reporting
- **Asset Statistics**: Get counts by status, type, and business unit
- **Warranty Tracking**: Monitor assets with expiring warranties
- **Risk Assessment**: Track risk levels and business criticality
- **Compliance Monitoring**: Track compliance requirements per asset

### �️ Security & Audit
- **User Authentication**: JWT-based authentication system
- **Audit Trail**: Track who created/updated assets and when
- **Compliance Tracking**: Built-in compliance requirements tracking
- **Risk Assessment**: Risk level and criticality tracking

## Quick Start

### 1. Installation

```bash
# Navigate to your project directory
cd backend-server

# Install dependencies (already done if you have the existing project)
pip install -r requirements.txt
```

### 2. Database Setup

Run the asset management migration to set up the database:

```bash
python migrate_assets.py
```

This will:
- Create the assets table with proper indexes
- Set up database triggers for automatic timestamp updates
- Optionally create sample data for testing

### 3. Start the Server

```bash
# Using the provided script
./server.sh

# Or directly with uvicorn
uvicorn main:app --host 0.0.0.0 --port 8000 --reload
```

### 4. Access the API

- **API Documentation**: http://localhost:8000/docs
- **Alternative Documentation**: http://localhost:8000/redoc

## API Endpoints

### Asset Management

| Method | Endpoint | Description |
|--------|----------|-------------|
| `POST` | `/api/v1/assets/` | Create a new asset |
| `GET` | `/api/v1/assets/` | Get all assets (paginated) |
| `GET` | `/api/v1/assets/{id}` | Get asset by internal ID |
| `GET` | `/api/v1/assets/asset-id/{asset_id}` | Get asset by business asset ID |
| `PUT` | `/api/v1/assets/{id}` | Update an asset |
| `DELETE` | `/api/v1/assets/{id}` | Delete an asset |

### Search & Analytics

| Method | Endpoint | Description |
|--------|----------|-------------|
| `GET` | `/api/v1/assets/search` | Advanced asset search |
| `GET` | `/api/v1/assets/statistics` | Get asset statistics |
| `GET` | `/api/v1/assets/by-business/{business}` | Get assets by business unit |
| `GET` | `/api/v1/assets/by-status/{status}` | Get assets by status |
| `GET` | `/api/v1/assets/expiring-warranties` | Get assets with expiring warranties |

### Bulk Operations

| Method | Endpoint | Description |
|--------|----------|-------------|
| `POST` | `/api/v1/assets/bulk-update-status` | Bulk update asset status |

## Asset Data Model

### Core Fields
```json
{
  "id": "system-generated-uuid",
  "asset_id": "IT-HW-001",
  "asset_name": "Dell PowerEdge R740 Server",
  "business": "Information Technology",
  "block": "Infrastructure",
  "capability": "Server Hosting",
  "asset_type": "hardware",
  "asset_status": "active"
}
```

### Extended Metadata
```json
{
  "size_attributes": {
    "cpu_cores": 24,
    "ram_gb": 128,
    "storage_tb": 2
  },
  "description": "Primary application server",
  "location": "Data Center A - Rack 15",
  "owner": "IT Operations Team",
  "contact_person": "John Smith",
  "contact_email": "john.smith@company.com"
}
```

### Financial & Lifecycle
```json
{
  "cost": 25000.00,
  "currency": "USD",
  "purchase_date": "2023-01-15T00:00:00Z",
  "installation_date": "2023-02-01T00:00:00Z",
  "warranty_expiry": "2026-01-15T00:00:00Z",
  "end_of_life": "2028-01-15T00:00:00Z"
}
```

### Technical Specifications
```json
{
  "vendor": "Dell Technologies",
  "model": "PowerEdge R740",
  "version": "1.0",
  "specifications": {
    "cpu": "Intel Xeon Gold 6248",
    "ram": "128GB DDR4",
    "storage": "2TB NVMe SSD"
  }
}
```

### Relationships & Compliance
```json
{
  "dependencies": ["asset-id-001", "asset-id-002"],
  "tags": ["server", "production", "web-app"],
  "compliance_requirements": ["SOX", "GDPR", "PCI-DSS"],
  "risk_level": "medium",
  "criticality": "high"
}
```

## Usage Examples

### Create an Asset

```python
import requests

asset_data = {
    "asset_id": "IT-HW-001",
    "asset_name": "Dell PowerEdge R740 Server",
    "business": "Information Technology",
    "asset_type": "hardware",
    "asset_status": "active",
    "size_attributes": {
        "cpu_cores": 24,
        "ram_gb": 128,
        "storage_tb": 2
    },
    "cost": 25000.00,
    "vendor": "Dell Technologies",
    "tags": ["server", "production"]
}

response = requests.post(
    "http://localhost:8000/api/v1/assets/",
    json=asset_data,
    headers={"Authorization": f"Bearer {jwt_token}"}
)
```

### Search Assets

```python
search_params = {
    "business": "Information Technology",
    "asset_type": "hardware",
    "asset_status": "active",
    "cost_min": 10000,
    "cost_max": 50000,
    "search_term": "server"
}

response = requests.get(
    "http://localhost:8000/api/v1/assets/search",
    params=search_params,
    headers={"Authorization": f"Bearer {jwt_token}"}
)
```

### Bulk Update Status

```python
bulk_operation = {
    "asset_ids": ["asset-1-id", "asset-2-id"],
    "operation": "update_status",
    "parameters": {"status": "maintenance"}
}

response = requests.post(
    "http://localhost:8000/api/v1/assets/bulk-update-status",
    json=bulk_operation,
    headers={"Authorization": f"Bearer {jwt_token}"}
)
```

### Get Asset Statistics

```python
response = requests.get(
    "http://localhost:8000/api/v1/assets/statistics",
    headers={"Authorization": f"Bearer {jwt_token}"}
)

# Response includes counts by status, type, and business
stats = response.json()
print(f"Total assets: {stats['total_assets']}")
print(f"By status: {stats['by_status']}")
```

## Environment Variables

You can configure these environment variables if needed:

```bash
# Database Configuration
DATABASE_URL=sqlite:///./app.db

# API Configuration
API_HOST=localhost
API_PORT=8000

# Security Configuration
SECRET_KEY=your-secret-key-here
ACCESS_TOKEN_EXPIRE_MINUTES=30

# Logging Configuration
LOG_LEVEL=INFO
```

## Asset Types and Statuses

### Asset Types
- `hardware` - Physical equipment (servers, laptops, etc.)
- `software` - Software applications and licenses
- `service` - External services and subscriptions
- `infrastructure` - Infrastructure components
- `application` - Internal applications
- `database` - Database systems
- `network` - Network equipment and components
- `security` - Security tools and systems
- `other` - Other asset types

### Asset Statuses
- `active` - Currently in use
- `inactive` - Not currently in use but available
- `maintenance` - Under maintenance
- `decommissioned` - Retired from service
- `pending` - Pending deployment or approval
- `retired` - Permanently retired

## Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Add tests if applicable
5. Submit a pull request

## License

This project is licensed under the MIT License - see the LICENSE file for details.

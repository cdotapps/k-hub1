from typing import Any, List, Dict, Optional
from fastapi import APIRouter, Body, Depends, HTTPException, status, Query, Path, BackgroundTasks
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import or_
from pydantic import BaseModel, ValidationError
import logging

from app import crud, models
from app.schemas import catalog as schemas
from app.api import deps
from app.db.session import get_db
from app.services.webhook_service import webhook_service
from app.models.user import User

# Set up logger
logger = logging.getLogger(__name__)

router = APIRouter()

class CustomAttribute(BaseModel):
    column: str
    value: str

class CustomAttributesRequest(BaseModel):
    attributes: Dict[str, List[CustomAttribute]]

class CustomAttributesResponse(BaseModel):
    attributes: Dict[str, List[CustomAttribute]]

@router.post("/", response_model=schemas.Catalog)
async def create_catalog(
    *,
    db: AsyncSession = Depends(get_db),
    catalog_in: schemas.CatalogCreate,
    current_user: models.User = Depends(deps.get_current_user),
    background_tasks: BackgroundTasks,
) -> Any:
    """
    Create new catalog item.
    """
    # Debug logging for catalog creation
    logger.info(f"🔍 [DEBUG] Catalog creation request from user: {current_user.id}")
    logger.info(f"🔍 [DEBUG] Raw catalog data type: {type(catalog_in)}")
    logger.info(f"🔍 [DEBUG] Catalog data dict: {catalog_in.model_dump()}")
    
    # Check specific fields that might cause string validation errors
    logger.info(f"🔍 [DEBUG] Title: '{catalog_in.title}' (type: {type(catalog_in.title)})")
    logger.info(f"🔍 [DEBUG] Type: '{catalog_in.type}' (type: {type(catalog_in.type)})")
    logger.info(f"🔍 [DEBUG] Status: '{catalog_in.status}' (type: {type(catalog_in.status)})")
    logger.info(f"🔍 [DEBUG] Description: '{catalog_in.description}' (type: {type(catalog_in.description)})")
    logger.info(f"🔍 [DEBUG] Summary: '{catalog_in.summary}' (type: {type(catalog_in.summary)})")
    logger.info(f"🔍 [DEBUG] Content length: {len(catalog_in.content) if catalog_in.content else 0}")
    logger.info(f"🔍 [DEBUG] URL: '{catalog_in.url}' (type: {type(catalog_in.url)})")
    logger.info(f"🔍 [DEBUG] Image: '{catalog_in.image}' (type: {type(catalog_in.image)})")
    logger.info(f"🔍 [DEBUG] Category: '{catalog_in.category}' (type: {type(catalog_in.category)})")
    logger.info(f"🔍 [DEBUG] Tags: {catalog_in.tags} (type: {type(catalog_in.tags)})")
    logger.info(f"🔍 [DEBUG] Child IDs: {catalog_in.child_ids} (type: {type(catalog_in.child_ids)})")
    logger.info(f"🔍 [DEBUG] Author: '{catalog_in.author}' (type: {type(catalog_in.author)})")
    logger.info(f"🔍 [DEBUG] Author ID: '{catalog_in.author_id}' (type: {type(catalog_in.author_id)})")
    logger.info(f"🔍 [DEBUG] Priority: '{catalog_in.priority}' (type: {type(catalog_in.priority)})")
    logger.info(f"🔍 [DEBUG] Severity: '{catalog_in.severity}' (type: {type(catalog_in.severity)})")
    logger.info(f"🔍 [DEBUG] Urgent: {catalog_in.urgent} (type: {type(catalog_in.urgent)})")
    logger.info(f"🔍 [DEBUG] Important: {catalog_in.important} (type: {type(catalog_in.important)})")
    logger.info(f"🔍 [DEBUG] Private: {catalog_in.private} (type: {type(catalog_in.private)})")
    logger.info(f"🔍 [DEBUG] Expire date: '{catalog_in.expire_date}' (type: {type(catalog_in.expire_date)})")
    logger.info(f"🔍 [DEBUG] Due date: '{catalog_in.due_date}' (type: {type(catalog_in.due_date)})")
    logger.info(f"🔍 [DEBUG] Custom: {catalog_in.custom} (type: {type(catalog_in.custom)})")
    logger.info(f"🔍 [DEBUG] Shared with: {catalog_in.shared_with} (type: {type(catalog_in.shared_with)})")
    
    # Set author and author_id to current user if not specified
    if not catalog_in.author:
        catalog_in.author = f"{current_user.first_name} {current_user.last_name}"
        logger.info(f"🔍 [DEBUG] Set author to: {catalog_in.author}")
    if not catalog_in.author_id:
        catalog_in.author_id = current_user.id
        logger.info(f"🔍 [DEBUG] Set author_id to: {catalog_in.author_id}")
    
    try:
        catalog = await crud.catalog.create(db, obj_in=catalog_in)
        logger.info(f"🔍 [DEBUG] Catalog created successfully with ID: {catalog.id}")
    except Exception as e:
        logger.error(f"🔍 [DEBUG] Error creating catalog: {str(e)}")
        logger.error(f"🔍 [DEBUG] Error type: {type(e)}")
        raise
    
    # Trigger webhook for catalog.created event
    event_data = {
        "catalog_id": catalog.id,
        "title": catalog.title,
        "type": catalog.type,
        "status": catalog.status,
        "author": catalog.author,
        "author_id": catalog.author_id,
        "created_by": current_user.id,
        "user_name": f"{current_user.first_name} {current_user.last_name}"
    }
    background_tasks.add_task(
        webhook_service.trigger_webhooks, 
        db, 
        "catalog.created", 
        event_data
    )
    
    return catalog

@router.get("/", response_model=schemas.CatalogResponse)
async def get_catalogs(
    db: AsyncSession = Depends(get_db),
    current_user: models.User = Depends(deps.get_current_user),
    type: str = Query(None, description="Filter by catalog type (e.g., news, document, tutorial)"),
    query: str = Query(None, description="Search term to find in title, description, content, tags, etc."),
    search: str = Query(None, description="Search term (alias for query)"),
    q: str = Query(None, description="Search term (alias for query)"), 
    title: str = Query(None, description="Search in title field"),
    category: str = Query(None, description="Filter by category"),
    status: str = Query(None, description="Filter by status"),
    author: str = Query(None, description="Filter by author"),
    page: int = Query(1, ge=1, description="Page number (starts from 1)"),
    page_size: int = Query(50, ge=1, le=100, description="Number of items per page"),
    skip: int = Query(None, ge=0, description="Number of items to skip (legacy parameter)"),
    limit: int = Query(None, ge=1, le=100, description="Number of items to return (legacy parameter)"),
) -> Any:
    """
    Get catalog items with pagination, filtering, and search functionality.
    Returns only items that the current user owns, has been shared with, or has approved.
    """
    # Handle pagination - prioritize new format (page/page_size) over legacy (skip/limit)
    if skip is not None and limit is not None:
        offset = skip
        page_limit = limit
        current_page = (skip // limit) + 1 if limit > 0 else 1
    else:
        offset = (page - 1) * page_size
        page_limit = page_size
        current_page = page

    search_term = query or search or q or title

    # Create search parameters
    search_params = schemas.CatalogSearch(
        query=search_term,
        type=type,
        category=category,
        status=status,
        author=author,
        limit=page_limit,
        offset=offset
    )

    # Use the new permission-aware search method
    current_user_name = f"{current_user.first_name} {current_user.last_name}"
    items, total = await crud.catalog.search_with_user_permissions(
        db, search_params=search_params, current_user_id=current_user.id, current_user_name=current_user_name
    )

    return {
        "items": items,
        "total": total,
        "limit": page_limit,
        "offset": offset,
        "page": current_page,
        "page_size": page_limit,
        "total_pages": (total + page_limit - 1) // page_limit if page_limit > 0 else 0
    }

@router.get("/search", response_model=schemas.CatalogResponse)
async def search_catalogs(
    db: AsyncSession = Depends(get_db),
    query: str = Query(None, description="Search term"),
    type: str = Query(None, description="Filter by type"),
    category: str = Query(None, description="Filter by category"),
    status: str = Query(None, description="Filter by status"),
    author: str = Query(None, description="Filter by author"),
    approved_by: str = Query(None, description="Filter by approved_by"),
    reviewed_by: str = Query(None, description="Filter by reviewed_by"),
    source: str = Query(None, description="Filter by source"),
    tags: str = Query(None, description="Filter by tags"),
    skip: int = Query(0, ge=0),
    limit: int = Query(50, ge=1, le=100),
) -> Any:
    """
    Search catalog items with various filters.
    
    This endpoint is public and does not require authentication.
    """
    search_params = schemas.CatalogSearch(
        query=query,
        type=type,
        category=category,
        status=status,
        author=author,
        approved_by=approved_by,
        reviewed_by=reviewed_by,
        source=source,
        tags=tags,
        limit=limit,
        offset=skip
    )
    
    items, total = await crud.catalog.search(db, search_params=search_params)
    
    return {
        "items": items,
        "total": total,
        "limit": limit,
        "offset": skip
    }

@router.get("/{catalog_id}", response_model=schemas.Catalog)
async def get_catalog(
    catalog_id: str,
    db: AsyncSession = Depends(get_db),
) -> Any:
    """
    Get a specific catalog item by ID.
    
    This endpoint is public and does not require authentication.
    """
    catalog = await crud.catalog.get(db, id=catalog_id)
    if not catalog:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Catalog item not found"
        )
    
    # Increment view count
    await crud.catalog.increment_views(db, id=catalog_id)
    
    return catalog

@router.put("/{catalog_id}", response_model=schemas.Catalog)
async def update_catalog(
    *,
    db: AsyncSession = Depends(get_db),
    catalog_id: str,
    catalog_in: schemas.CatalogUpdate,
    current_user: models.User = Depends(deps.get_current_user),
    background_tasks: BackgroundTasks,
) -> Any:
    """
    Update a catalog item.
    """
    catalog = await crud.catalog.get(db, id=catalog_id)
    if not catalog:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Catalog item not found"
        )
    
    # Check permissions - use author_id for more reliable permission checking
    # Fall back to author name comparison for backward compatibility
    is_author = (catalog.author_id == current_user.id or 
                 catalog.author == f"{current_user.first_name} {current_user.last_name}")
    
    if (not is_author and 
        not crud.user.is_admin(current_user) and 
        not crud.user.is_superuser(current_user)):
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Not enough permissions to update this catalog item"
        )
    
    # Store original data for webhook
    original_data = {
        "catalog_id": catalog.id,
        "title": catalog.title,
        "type": catalog.type,
        "status": catalog.status,
        "author": catalog.author
    }
    
    catalog = await crud.catalog.update(db, db_obj=catalog, obj_in=catalog_in)
    
    # Trigger webhook for catalog.updated event
    event_data = {
        "catalog_id": catalog.id,
        "title": catalog.title,
        "type": catalog.type,
        "status": catalog.status,
        "author": catalog.author,
        "updated_by": current_user.id,
        "user_name": f"{current_user.first_name} {current_user.last_name}",
        "changes": catalog_in.model_dump(exclude_unset=True),
        "original": original_data
    }
    background_tasks.add_task(
        webhook_service.trigger_webhooks, 
        db, 
        "catalog.updated", 
        event_data
    )
    
    return catalog

@router.delete("/{catalog_id}")
async def delete_catalog(
    *,
    db: AsyncSession = Depends(get_db),
    catalog_id: str,
    current_user: models.User = Depends(deps.get_current_user),
    background_tasks: BackgroundTasks,
) -> Any:
    """
    Delete a catalog item.
    """
    catalog = await crud.catalog.get(db, id=catalog_id)
    if not catalog:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Catalog item not found"
        )
    
    # Check permissions - use author_id for more reliable permission checking
    # Fall back to author name comparison for backward compatibility
    is_author = (catalog.author_id == current_user.id or 
                 catalog.author == f"{current_user.first_name} {current_user.last_name}")
    
    if (not is_author and 
        not crud.user.is_admin(current_user) and 
        not crud.user.is_superuser(current_user)):
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Not enough permissions to delete this catalog item"
        )
    
    # Store catalog data for webhook before deletion
    event_data = {
        "catalog_id": catalog.id,
        "title": catalog.title,
        "type": catalog.type,
        "status": catalog.status,
        "author": catalog.author,
        "deleted_by": current_user.id,
        "user_name": f"{current_user.first_name} {current_user.last_name}"
    }
    
    await crud.catalog.remove(db, id=catalog_id)
    
    # Trigger webhook for catalog.deleted event
    background_tasks.add_task(
        webhook_service.trigger_webhooks, 
        db, 
        "catalog.deleted", 
        event_data
    )
    
    return {"status": "success", "msg": "Catalog item deleted successfully"}

# Interaction endpoints
@router.post("/{catalog_id}/like", response_model=schemas.Catalog)
async def like_catalog(
    catalog_id: str,
    db: AsyncSession = Depends(get_db),
    current_user: models.User = Depends(deps.get_current_user),
) -> Any:
    """
    Like a catalog item (increment like count).
    """
    catalog = await crud.catalog.increment_likes(db, id=catalog_id)
    if not catalog:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Catalog item not found"
        )
    return catalog

@router.post("/{catalog_id}/use", response_model=schemas.Catalog)
async def use_catalog(
    catalog_id: str,
    db: AsyncSession = Depends(get_db),
    current_user: models.User = Depends(deps.get_current_user),
) -> Any:
    """
    Mark catalog item as used (increment usage count).
    """
    catalog = await crud.catalog.increment_usages(db, id=catalog_id)
    if not catalog:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Catalog item not found"
        )
    return catalog

# Admin endpoints
@router.patch("/{catalog_id}/approve", response_model=schemas.Catalog)
async def approve_catalog(
    *,
    db: AsyncSession = Depends(get_db),
    catalog_id: str,
    current_user: models.User = Depends(deps.get_current_active_admin),
    background_tasks: BackgroundTasks,
) -> Any:
    """
    Approve a catalog item (admin only).
    """
    catalog = await crud.catalog.get(db, id=catalog_id)
    if not catalog:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Catalog item not found"
        )
    
    catalog_update = schemas.CatalogUpdate(
        status="published",
        approved_by=f"{current_user.first_name} {current_user.last_name}"
    )
    catalog = await crud.catalog.update(db, db_obj=catalog, obj_in=catalog_update)
    
    # Trigger webhook for catalog.approved event
    event_data = {
        "catalog_id": catalog.id,
        "title": catalog.title,
        "type": catalog.type,
        "status": catalog.status,
        "author": catalog.author,
        "approved_by": f"{current_user.first_name} {current_user.last_name}",
        "admin_user_id": current_user.id
    }
    background_tasks.add_task(
        webhook_service.trigger_webhooks, 
        db, 
        "catalog.approved", 
        event_data
    )
    
    return catalog

@router.patch("/{catalog_id}/review", response_model=schemas.Catalog)
async def review_catalog(
    *,
    db: AsyncSession = Depends(get_db),
    catalog_id: str,
    status: str = Body(..., embed=True),
    current_user: models.User = Depends(deps.get_current_active_admin),
    background_tasks: BackgroundTasks,
) -> Any:
    """
    Review a catalog item and set status (admin only).
    """
    catalog = await crud.catalog.get(db, id=catalog_id)
    if not catalog:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Catalog item not found"
        )
    
    valid_statuses = ["draft", "published", "archived", "under_review", "rejected"]
    if status not in valid_statuses:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Invalid status. Must be one of: {', '.join(valid_statuses)}"
        )
    
    catalog_update = schemas.CatalogUpdate(
        status=status,
        reviewed_by=f"{current_user.first_name} {current_user.last_name}"
    )
    catalog = await crud.catalog.update(db, db_obj=catalog, obj_in=catalog_update)
    
    # Trigger appropriate webhook event
    if status == "rejected":
        event_type = "catalog.rejected"
    elif status == "published":
        event_type = "catalog.approved"
    else:
        event_type = "catalog.updated"
    
    event_data = {
        "catalog_id": catalog.id,
        "title": catalog.title,
        "type": catalog.type,
        "status": catalog.status,
        "author": catalog.author,
        "reviewed_by": f"{current_user.first_name} {current_user.last_name}",
        "admin_user_id": current_user.id,
        "review_action": status
    }
    
    background_tasks.add_task(
        webhook_service.trigger_webhooks, 
        db, 
        event_type, 
        event_data
    )
    
    return catalog

@router.patch("/{catalog_id}/request-approval", response_model=schemas.Catalog)
async def request_catalog_approval(
    *,
    db: AsyncSession = Depends(get_db),
    catalog_id: str,
    current_user: models.User = Depends(deps.get_current_user),
    background_tasks: BackgroundTasks,
) -> Any:
    """
    Request approval for a catalog item.
    Sets the approver as the user's manager and changes status to pending_approval.
    """
    catalog = await crud.catalog.get(db, id=catalog_id)
    if not catalog:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Catalog item not found"
        )
    
    # Check if user is the author of the catalog item
    is_author = (catalog.author_id == current_user.id or 
                 catalog.author == f"{current_user.first_name} {current_user.last_name}")
    
    if not is_author:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Only the author can request approval for this catalog item"
        )
    
    # Check if user has a manager
    if not current_user.manager_id:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Cannot request approval: No manager assigned to your account"
        )
    
    # Get manager details
    manager = await crud.user.get(db, id=current_user.manager_id)
    if not manager:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Cannot request approval: Manager not found"
        )
    
    # Update catalog status and set approver
    catalog_update = schemas.CatalogUpdate(
        status="pending_approval",
        approved_by=f"{manager.first_name} {manager.last_name}"
    )
    catalog = await crud.catalog.update(db, db_obj=catalog, obj_in=catalog_update)
    
    # Trigger webhook for approval request event
    event_data = {
        "catalog_id": catalog.id,
        "title": catalog.title,
        "type": catalog.type,
        "status": catalog.status,
        "author": catalog.author,
        "author_id": catalog.author_id,
        "approver": f"{manager.first_name} {manager.last_name}",
        "approver_id": manager.id,
        "requested_by": current_user.id,
        "user_name": f"{current_user.first_name} {current_user.last_name}"
    }
    background_tasks.add_task(
        webhook_service.trigger_webhooks, 
        db, 
        "catalog.approval_requested", 
        event_data
    )
    
    return catalog

# Filter endpoints
@router.get("/by-type/{type}", response_model=List[schemas.Catalog])
async def get_catalogs_by_type(
    type: str,
    db: AsyncSession = Depends(get_db),
    skip: int = Query(0, ge=0),
    limit: int = Query(50, ge=1, le=100),
) -> Any:
    """
    Get catalog items by type.
    
    This endpoint is public and does not require authentication.
    """
    catalogs = await crud.catalog.get_by_type(db, type=type, skip=skip, limit=limit)
    return catalogs

@router.get("/by-status/{status}", response_model=List[schemas.Catalog])
async def get_catalogs_by_status(
    status: str,
    db: AsyncSession = Depends(get_db),
    skip: int = Query(0, ge=0),
    limit: int = Query(50, ge=1, le=100),
) -> Any:
    """
    Get catalog items by status.
    
    This endpoint is public and does not require authentication.
    """
    catalogs = await crud.catalog.get_by_status(db, status=status, skip=skip, limit=limit)
    return catalogs

@router.get("/by-author/{author_id}", response_model=List[schemas.Catalog])
async def get_catalogs_by_author(
    author_id: str,
    db: AsyncSession = Depends(get_db),
    current_user: models.User = Depends(deps.get_current_user),
    skip: int = Query(0, ge=0),
    limit: int = Query(50, ge=1, le=100),
) -> Any:
    """
    Get catalog items by author_id.
    Users can only see their own content unless they are admin.
    """
    # Check permissions - users can only see their own content, admins can see all
    if author_id != current_user.id and not crud.user.is_admin(current_user):
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Not enough permissions to view this user's catalog items"
        )
    
    catalogs = await crud.catalog.get_by_author_id(db, author_id=author_id, skip=skip, limit=limit)
    return catalogs

@router.get("/my-content", response_model=List[schemas.Catalog])
async def get_my_catalog_content(
    db: AsyncSession = Depends(get_db),
    current_user: models.User = Depends(deps.get_current_user),
    skip: int = Query(0, ge=0),
    limit: int = Query(50, ge=1, le=100),
) -> Any:
    """
    Get all catalog items created by the current user.
    """
    catalogs = await crud.catalog.get_by_author_id(db, author_id=current_user.id, skip=skip, limit=limit)
    return catalogs

@router.get("/{catalog_id}/conversations", response_model=List[dict])
async def get_catalog_conversations(
    catalog_id: str = Path(..., description="Catalog item ID"),
    db: AsyncSession = Depends(get_db),
) -> Any:
    """
    Get all conversations for a catalog item.
    """
    catalog = await crud.catalog.get(db, id=catalog_id)
    if not catalog:
        raise HTTPException(status_code=404, detail="Catalog item not found")
    return catalog.conversations or []

@router.post("/{catalog_id}/conversations", response_model=List[dict])
async def add_catalog_conversation(
    catalog_id: str = Path(..., description="Catalog item ID"),
    conversation: dict = Body(..., description="Conversation/comment to add"),
    db: AsyncSession = Depends(get_db),
    current_user: models.User = Depends(deps.get_current_user),
) -> Any:
    """
    Add a new conversation/comment to a catalog item.
    """
    catalog = await crud.catalog.get(db, id=catalog_id)
    if not catalog:
        raise HTTPException(status_code=404, detail="Catalog item not found")
    conversations = catalog.conversations or []
    # Optionally, enrich with user info and timestamp
    import datetime
    conversation.setdefault("user_id", current_user.user_id)
    conversation.setdefault("timestamp", datetime.datetime.utcnow().isoformat() + "Z")
    conversations.append(conversation)
    await crud.catalog.update(db, db_obj=catalog, obj_in={"conversations": conversations})
    return conversations

@router.get("/{id}/custom", response_model=CustomAttributesResponse)
async def get_custom_attributes(
    *,
    db: AsyncSession = Depends(deps.get_db),
    id: str,
    current_user: User = Depends(deps.get_current_active_user),
) -> Any:
    """
    Get custom attributes for a catalog item.
    """
    catalog_item = await crud.catalog.get(db=db, id=id)
    if not catalog_item:
        raise HTTPException(status_code=404, detail="Catalog not found")
    
    # Check permissions (user must own it, have it shared, or be an approver)
    if not (catalog_item.author_id == current_user.id or 
            (catalog_item.shared_with and current_user.id in catalog_item.shared_with) or
            catalog_item.approved_by == current_user.name):
        raise HTTPException(status_code=403, detail="Not enough permissions")
    
    # Convert custom JSON to nested attributes format
    attributes = {}
    if catalog_item.custom:
        for list_name, list_data in catalog_item.custom.items():
            if isinstance(list_data, list):
                # If it's already in the expected format
                attributes[list_name] = [CustomAttribute(**item) for item in list_data if isinstance(item, dict) and 'column' in item and 'value' in item]
            elif isinstance(list_data, dict):
                # Convert dict to list of attributes
                attributes[list_name] = [CustomAttribute(column=key, value=str(value)) for key, value in list_data.items()]
            else:
                # Handle single values as a default list
                attributes[list_name] = [CustomAttribute(column="value", value=str(list_data))]
    
    return CustomAttributesResponse(attributes=attributes)

@router.post("/{id}/custom", response_model=CustomAttributesResponse)
async def update_custom_attributes(
    *,
    db: AsyncSession = Depends(deps.get_db),
    id: str,
    attributes_in: CustomAttributesRequest,
    current_user: User = Depends(deps.get_current_active_user),
) -> Any:
    """
    Update custom attributes for a catalog item.
    """
    catalog_item = await crud.catalog.get(db=db, id=id)
    if not catalog_item:
        raise HTTPException(status_code=404, detail="Catalog not found")
    
    # Check permissions (user must own it or be an approver)
    if not (catalog_item.author_id == current_user.id or 
            catalog_item.approved_by == current_user.name):
        raise HTTPException(status_code=403, detail="Not enough permissions")
    
    # Convert nested attributes format to custom JSON
    custom_data = {}
    for list_name, attr_list in attributes_in.attributes.items():
        custom_data[list_name] = [{"column": attr.column, "value": attr.value} for attr in attr_list]
    
    # Update the catalog item
    updated_catalog = await crud.catalog.update(
        db=db,
        db_obj=catalog_item,
        obj_in={"custom": custom_data}
    )
    
    # Convert back to response format
    attributes = {}
    if updated_catalog.custom:
        for list_name, list_data in updated_catalog.custom.items():
            if isinstance(list_data, list):
                attributes[list_name] = [CustomAttribute(**item) for item in list_data if isinstance(item, dict) and 'column' in item and 'value' in item]
            elif isinstance(list_data, dict):
                attributes[list_name] = [CustomAttribute(column=key, value=str(value)) for key, value in list_data.items()]
            else:
                attributes[list_name] = [CustomAttribute(column="value", value=str(list_data))]
    
    return CustomAttributesResponse(attributes=attributes)
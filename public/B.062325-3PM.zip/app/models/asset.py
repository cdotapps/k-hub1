from sqlalchemy import Column, String, Boolean, DateTime, Enum, Integer, Text, JSON, Float
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.sql import func
import enum
import uuid

Base = declarative_base()

class AssetStatus(str, enum.Enum):
    ACTIVE = "active"
    INACTIVE = "inactive"
    MAINTENANCE = "maintenance"
    DECOMMISSIONED = "decommissioned"
    PENDING = "pending"
    RETIRED = "retired"

class AssetType(str, enum.Enum):
    HARDWARE = "hardware"
    SOFTWARE = "software"
    SERVICE = "service"
    INFRASTRUCTURE = "infrastructure"
    APPLICATION = "application"
    DATABASE = "database"
    NETWORK = "network"
    SECURITY = "security"
    OTHER = "other"

class Asset(Base):
    __tablename__ = "assets"

    id = Column(String, primary_key=True, index=True, default=lambda: str(uuid.uuid4()))
    asset_id = Column(String, nullable=False, unique=True, index=True)  # Business Asset ID
    asset_name = Column(String, nullable=False, index=True)  # Asset Name
    business = Column(String, nullable=False, index=True)  # Business unit
    block = Column(String, nullable=True, index=True)  # Block or department
    capability = Column(String, nullable=True, index=True)  # Capability area
    asset_type = Column(String, nullable=False, index=True)  # Asset Type
    asset_status = Column(String, nullable=False, default="active", index=True)  # Asset Status
    
    # Size attributes - flexible to accommodate different types of size measurements
    size_attributes = Column(JSON, nullable=True)  # JSON field for various size metrics
    
    # Additional metadata
    description = Column(Text, nullable=True)  # Detailed description
    location = Column(String, nullable=True, index=True)  # Physical or logical location
    owner = Column(String, nullable=True, index=True)  # Asset owner
    contact_person = Column(String, nullable=True)  # Primary contact
    contact_email = Column(String, nullable=True)  # Contact email
    
    # Financial information
    cost = Column(Float, nullable=True)  # Asset cost
    currency = Column(String, nullable=True, default="USD")  # Currency
    
    # Lifecycle information
    purchase_date = Column(DateTime, nullable=True)  # Purchase/acquisition date
    installation_date = Column(DateTime, nullable=True)  # Installation date
    warranty_expiry = Column(DateTime, nullable=True)  # Warranty expiry date
    end_of_life = Column(DateTime, nullable=True)  # End of life date
    
    # Technical specifications
    vendor = Column(String, nullable=True, index=True)  # Vendor/manufacturer
    model = Column(String, nullable=True)  # Model number
    version = Column(String, nullable=True)  # Version
    specifications = Column(JSON, nullable=True)  # Technical specifications
    
    # Dependencies and relationships
    dependencies = Column(JSON, nullable=True)  # Asset dependencies
    tags = Column(JSON, nullable=True)  # Tags for categorization
    
    # Compliance and governance
    compliance_requirements = Column(JSON, nullable=True)  # Compliance requirements
    risk_level = Column(String, nullable=True, index=True)  # Risk assessment level
    criticality = Column(String, nullable=True, index=True)  # Business criticality
    
    # Audit fields
    created_date = Column(DateTime, nullable=False, default=func.now())
    updated_date = Column(DateTime, nullable=False, default=func.now(), onupdate=func.now())
    created_by = Column(String, nullable=True, index=True)  # User who created the record
    updated_by = Column(String, nullable=True, index=True)  # User who last updated the record
    
    # Additional custom fields
    custom_fields = Column(JSON, nullable=True)  # Custom fields for organization-specific data

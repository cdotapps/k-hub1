import { Injectable } from '@angular/core';
import { Observable, of, throwError, BehaviorSubject } from 'rxjs';
import { delay } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class AuthService {
  private isAuthenticated = false;
  private currentUser: any = null;
  
  // Add reactive state management
  private authStateSubject = new BehaviorSubject<boolean>(false);
  private currentUserSubject = new BehaviorSubject<any>(null);
  
  // Public observables
  public authState$ = this.authStateSubject.asObservable();
  public currentUser$ = this.currentUserSubject.asObservable();

  constructor() {
    // Check if user is already logged in from localStorage
    const savedUser = localStorage.getItem('currentUser');
    if (savedUser) {
      this.currentUser = JSON.parse(savedUser);
      this.isAuthenticated = true;
      // Emit initial state
      this.authStateSubject.next(true);
      this.currentUserSubject.next(this.currentUser);
    }
  }

  login(email: string, password: string): Observable<any> {
    // Simulate API call with demo credentials
    if (email === 'admin@askdata.com' && password === 'password123') {
      const user = {
        id: 1,
        name: 'Admin User',
        email: email,
        role: 'admin'
      };
      
      this.currentUser = user;
      this.isAuthenticated = true;
      localStorage.setItem('currentUser', JSON.stringify(user));
      
      // Emit new state
      this.authStateSubject.next(true);
      this.currentUserSubject.next(user);
      
      return of({ success: true, user }).pipe(delay(1000));
    } else {
      return throwError(() => new Error('Invalid credentials')).pipe(delay(1000));
    }
  }

  logout(): void {
    this.isAuthenticated = false;
    this.currentUser = null;
    localStorage.removeItem('currentUser');
    
    // Emit new state
    this.authStateSubject.next(false);
    this.currentUserSubject.next(null);
  }

  getCurrentUser(): any {
    return this.currentUser;
  }

  isLoggedIn(): boolean {
    return this.isAuthenticated;
  }
}
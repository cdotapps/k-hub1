import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { RouterModule, Routes } from '@angular/router';
import { CommonModule } from '@angular/common';

import { AppComponent } from './app.component';
import { LoginComponent } from './pages/login/login.component';
import { HomeComponent } from './pages/home/home.component';
import { QueriesComponent } from './pages/queries/queries.component';
import { FeaturesComponent } from './pages/features/features.component';
import { DesignComponent } from './pages/design/design.component';
import { DataSourcesComponent } from './pages/data-sources/data-sources.component';
import { ApiComponent } from './pages/api/api.component';
import { SupportComponent } from './pages/support/support.component';
import { UsecaseComponent } from './pages/usecase/usecase.component';
import { DashboardComponent } from './pages/dashboard/dashboard.component';
import { AuthService } from './services/auth.service';

// Shared Components
import { HeaderComponent } from './components/shared/header/header.component';
import { FooterComponent } from './components/shared/footer/footer.component';
import { CardComponent } from './components/shared/card/card.component';
import { ButtonComponent } from './components/shared/button/button.component';

const routes: Routes = [
  { path: '', redirectTo: '/login', pathMatch: 'full' },
  { path: 'login', component: LoginComponent },
  { path: 'queries', component: QueriesComponent },
  { path: 'dashboard', component: DashboardComponent },
  { path: 'home', component: HomeComponent },
  { path: 'features', component: FeaturesComponent },
  { path: 'design', component: DesignComponent },
  { path: 'usecase', component: UsecaseComponent },
  { path: 'data-sources', component: DataSourcesComponent },
  { path: 'api', component: ApiComponent },
  { path: 'support', component: SupportComponent },
  { path: '**', redirectTo: '/login' }
];

@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    HomeComponent,
    QueriesComponent,
    FeaturesComponent,
    DesignComponent,
    DataSourcesComponent,
    ApiComponent,
    SupportComponent,
    UsecaseComponent,
    DashboardComponent,
    // Shared Components
    HeaderComponent,
    FooterComponent,
    CardComponent,
    ButtonComponent
  ],
  imports: [
    BrowserModule,
    CommonModule,
    ReactiveFormsModule,
    FormsModule,
    RouterModule.forRoot(routes)
  ],
  providers: [AuthService],
  bootstrap: [AppComponent]
})
export class AppModule { }

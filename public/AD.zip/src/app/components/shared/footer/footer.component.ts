import { Component, Input } from '@angular/core';

@Component({
  selector: 'app-footer',
  templateUrl: './footer.component.html',
  styleUrls: ['./footer.component.css']
})
export class FooterComponent {
  @Input() partners: string[] = ['OpenAI', 'AWS', 'Snowflake', 'Tableau', 'Power BI'];
  @Input() showPartners: boolean = true;

  constructor() {}
}
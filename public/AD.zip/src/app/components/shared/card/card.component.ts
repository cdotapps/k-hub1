import { Component, Input } from '@angular/core';

@Component({
  selector: 'app-card',
  templateUrl: './card.component.html',
  styleUrls: ['./card.component.css']
})
export class CardComponent {
  @Input() variant: 'default' | 'stat' | 'glass' = 'default';
  @Input() padding: 'sm' | 'md' | 'lg' = 'md';
  @Input() hover: boolean = true;

  constructor() {}

  get cardClasses() {
    return {
      'card': true,
      [`card-${this.variant}`]: true,
      [`card-padding-${this.padding}`]: true,
      'card-hover': this.hover
    };
  }
}
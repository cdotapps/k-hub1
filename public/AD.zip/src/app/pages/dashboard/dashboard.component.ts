import { Component, OnInit, OnDestroy } from '@angular/core';
import { Router } from '@angular/router';

interface Query {
  id: string;
  text: string;
  timestamp: Date;
  status: 'completed' | 'processing' | 'failed';
}

interface Prompt {
  id: string;
  title: string;
  text: string;
  category: string;
  usageCount: number;
  createdAt: Date;
}

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit, OnDestroy {
  queryText: string = '';
  isProcessing: boolean = false;
  showResults: boolean = false;
  processingTime: number = 0;
  timer: any;

  // Mock data for the results
  chainOfThoughts: string[] = [];
  widgets: any[] = [];
  showProcessingDetails: boolean = false;
  summarizedAnswer: string = '';

  // Feedback properties
  summaryFeedback: 'like' | 'dislike' | null = null;
  showFeedbackContext: boolean = false;

  // Statistics
  totalQueries: number = 47;
  totalInsights: number = 12;

  // Recent Queries
  recentQueries: Query[] = [
    {
      id: '1',
      text: 'Show me revenue trends for Q3 2025',
      timestamp: new Date(Date.now() - 2 * 60 * 60 * 1000), // 2 hours ago
      status: 'completed'
    },
    {
      id: '2', 
      text: 'Which marketing channels have the best ROI?',
      timestamp: new Date(Date.now() - 24 * 60 * 60 * 1000), // 1 day ago
      status: 'completed'
    },
    {
      id: '3',
      text: 'Compare product performance by region',
      timestamp: new Date(Date.now() - 3 * 24 * 60 * 60 * 1000), // 3 days ago
      status: 'completed'
    },
    {
      id: '4',
      text: 'Customer acquisition cost analysis',
      timestamp: new Date(Date.now() - 5 * 24 * 60 * 60 * 1000), // 5 days ago
      status: 'completed'
    }
  ];

  // Saved Prompts
  savedPrompts: Prompt[] = [
    {
      id: '1',
      title: 'Monthly Revenue Report',
      text: 'Generate a comprehensive monthly revenue report showing trends, breakdown by product lines, and year-over-year comparison',
      category: 'revenue',
      usageCount: 15,
      createdAt: new Date(Date.now() - 7 * 24 * 60 * 60 * 1000)
    },
    {
      id: '2',
      title: 'Customer Churn Analysis',
      text: 'Analyze customer churn rates, identify patterns, and suggest retention strategies',
      category: 'customers',
      usageCount: 8,
      createdAt: new Date(Date.now() - 14 * 24 * 60 * 60 * 1000)
    },
    {
      id: '3',
      title: 'Marketing Performance Dashboard',
      text: 'Show marketing campaign performance across all channels with ROI calculations',
      category: 'performance',
      usageCount: 12,
      createdAt: new Date(Date.now() - 21 * 24 * 60 * 60 * 1000)
    }
  ];

  // Modal state
  showSavePromptModal: boolean = false;
  newPrompt: Partial<Prompt> = {
    title: '',
    text: '',
    category: 'general'
  };
  selectedQuery: Query | null = null;

  constructor(private router: Router) {}

  ngOnInit() {
    // Initialize dashboard
  }

  ngOnDestroy() {
    if (this.timer) {
      clearInterval(this.timer);
    }
  }

  onSubmitQuery() {
    console.log('Submit query called with text:', this.queryText);
    
    if (this.queryText.trim()) {
      console.log('Starting processing...');
      // Reset states
      this.showResults = false;
      this.chainOfThoughts = [];
      this.widgets = [];
      
      // Start processing
      this.isProcessing = true;
      this.processingTime = 0;
      
      // Start timer
      this.timer = setInterval(() => {
        this.processingTime += 0.1;
      }, 100);
      
      // Simulate processing with chain of thoughts
      this.simulateProcessing();
    } else {
      console.log('No query text provided');
    }
  }

  onKeyDown(event: KeyboardEvent) {
    if (event.key === 'Enter' && !event.shiftKey) {
      event.preventDefault();
      this.onSubmitQuery();
    }
  }

  onFollowUpKeyDown(event: KeyboardEvent, value: string) {
    if (event.key === 'Enter' && !event.shiftKey) {
      event.preventDefault();
      if (value.trim()) {
        this.onNewQuery(value);
        // Clear the input
        const target = event.target as HTMLTextAreaElement;
        target.value = '';
      }
    }
  }

  onFollowUpInput(event: Event) {
    // Optional: Handle input changes if needed
    const target = event.target as HTMLTextAreaElement;
    // You can add any logic here for handling input changes
  }

  private simulateProcessing() {
    const thoughts = [
      'Analyzing your query...',
      'Connecting to data sources...',
      'Processing data patterns...',
      'Generating insights...',
      'Creating visualizations...',
      'Finalizing results...'
    ];
    
    this.chainOfThoughts = [];
    
    thoughts.forEach((thought, index) => {
      setTimeout(() => {
        this.chainOfThoughts.push(thought);
        
        // Complete processing after all thoughts
        if (index === thoughts.length - 1) {
          setTimeout(() => {
            this.completeProcessing();
          }, 800);
        }
      }, (index + 1) * 800);
    });
  }

  private completeProcessing() {
    clearInterval(this.timer);
    this.isProcessing = false;
    this.showResults = true;
    
    // Generate summarized answer based on query
    this.generateSummarizedAnswer();
    
    // Mock widgets data
    this.widgets = [
      {
        type: 'chart',
        title: 'Revenue Trends',
        data: { value: '$2.4M', change: '+12%' }
      },
      {
        type: 'metric',
        title: 'Customer Growth',
        data: { value: '1,234', change: '+8%' }
      },
      {
        type: 'table',
        title: 'Top Products',
        data: { rows: 5, columns: 3 }
      }
    ];
  }

  private generateSummarizedAnswer() {
    // Generate a contextual answer based on the query
    const query = this.queryText.toLowerCase();
    
    if (query.includes('revenue') || query.includes('sales')) {
      this.summarizedAnswer = `Based on the latest data analysis, your revenue has shown a positive growth trend of 12% compared to the previous quarter. The total revenue reached $2.4M, with Product A being the top performer contributing 35% of the total sales. Key growth drivers include improved marketing efficiency and customer retention strategies.`;
    } else if (query.includes('customer') || query.includes('user')) {
      this.summarizedAnswer = `Customer analysis reveals a healthy growth pattern with 1,234 new customers acquired this period, representing an 8% increase. Customer satisfaction scores have improved by 15%, and retention rates are at an all-time high of 92%. The main acquisition channels are organic search (40%) and referrals (30%).`;
    } else if (query.includes('product') || query.includes('performance')) {
      this.summarizedAnswer = `Product performance analysis shows strong market positioning across all categories. Product A leads with $120K in sales and 15% growth, followed by Product B with $95K and 8% growth. Market share has increased by 5% overall, with particularly strong performance in the enterprise segment.`;
    } else {
      this.summarizedAnswer = `Analysis complete. The data shows positive trends across key metrics with notable improvements in performance indicators. Detailed insights and visualizations are available below to help you make informed decisions. Key recommendations include focusing on high-performing segments and optimizing underperforming areas.`;
    }
  }

  toggleProcessingDetails() {
    this.showProcessingDetails = !this.showProcessingDetails;
  }

  onNewQuery(query?: string) {
    if (query) {
      this.router.navigate(['/queries'], { queryParams: { q: query } });
    } else {
      this.router.navigate(['/queries']);
    }
  }

  onBackToInput() {
    this.showResults = false;
    this.isProcessing = false;
    this.chainOfThoughts = [];
    this.widgets = [];
    this.processingTime = 0;
    this.queryText = '';
    // Reset feedback when going back
    this.summaryFeedback = null;
    this.showFeedbackContext = false;
  }

  // Method to format summary text with bold numbers/percentages/amounts
  getFormattedSummary(): string {
    return this.formatNumbersInText(this.summarizedAnswer);
  }

  private formatNumbersInText(text: string): string {
    // Regular expression to match:
    // - Currency amounts (e.g., $2.4M, $120K, €1,234.56)
    // - Percentages (e.g., 12%, +8%, -5.2%)
    // - Numbers with commas (e.g., 1,234, 10,000)
    // - Decimal numbers (e.g., 15.5, 92.3)
    // - Numbers with K/M/B suffixes (e.g., 2.4M, 120K)
    const numberPattern = /(\$[0-9,]+\.?[0-9]*[KMB]?|€[0-9,]+\.?[0-9]*[KMB]?|£[0-9,]+\.?[0-9]*[KMB]?|[+\-]?[0-9,]+\.?[0-9]*%|[0-9,]+\.?[0-9]*[KMB]?(?!\w)|[0-9,]+\.?[0-9]*(?=\s|$|[^\w]))/g;
    
    return text.replace(numberPattern, '<strong>$1</strong>');
  }

  onSummaryFeedback(feedbackType: 'like' | 'dislike') {
    if (this.summaryFeedback === feedbackType) {
      // If clicking the same button, remove feedback
      this.summaryFeedback = null;
      this.showFeedbackContext = false;
    } else {
      // Set new feedback
      this.summaryFeedback = feedbackType;
      this.showFeedbackContext = true;
      
      // Auto-hide feedback context after 5 seconds
      setTimeout(() => {
        this.showFeedbackContext = false;
      }, 5000);
      
      // Log feedback for analytics (in real app, send to backend)
      console.log(`Summary feedback: ${feedbackType}`, {
        query: this.queryText,
        summary: this.summarizedAnswer,
        timestamp: new Date().toISOString()
      });
    }
  }

  closeFeedbackContext() {
    this.showFeedbackContext = false;
  }

  // Navigation methods
  onNewQueryNavigation() {
    this.router.navigate(['/queries']);
  }

  onViewAllQueries() {
    this.router.navigate(['/queries'], { queryParams: { view: 'all' } });
  }

  // Query actions
  onRerunQuery(query: Query, event?: Event) {
    if (event) {
      event.stopPropagation();
    }
    this.router.navigate(['/queries'], { queryParams: { q: query.text } });
  }

  onSavePrompt(query: Query, event?: Event) {
    if (event) {
      event.stopPropagation();
    }
    this.selectedQuery = query;
    this.newPrompt = {
      title: '',
      text: query.text,
      category: 'general'
    };
    this.showSavePromptModal = true;
  }

  // Prompt Library methods
  onUsePrompt(prompt: Prompt) {
    // Increment usage count
    prompt.usageCount++;
    
    // Navigate to queries with the prompt text
    this.router.navigate(['/queries'], { queryParams: { q: prompt.text } });
  }

  onCreatePrompt() {
    this.selectedQuery = null;
    this.newPrompt = {
      title: '',
      text: '',
      category: 'general'
    };
    this.showSavePromptModal = true;
  }

  onEditPrompt(prompt: Prompt, event?: Event) {
    if (event) {
      event.stopPropagation();
    }
    this.newPrompt = { ...prompt };
    this.showSavePromptModal = true;
  }

  onDeletePrompt(prompt: Prompt, event?: Event) {
    if (event) {
      event.stopPropagation();
    }
    
    if (confirm(`Are you sure you want to delete "${prompt.title}"?`)) {
      this.savedPrompts = this.savedPrompts.filter(p => p.id !== prompt.id);
    }
  }

  onManagePrompts() {
    // Future: Navigate to a dedicated prompt management page
    console.log('Manage prompts - feature coming soon');
  }

  // Modal methods
  onCloseSavePromptModal() {
    this.showSavePromptModal = false;
    this.newPrompt = {
      title: '',
      text: '',
      category: 'general'
    };
    this.selectedQuery = null;
  }

  onSaveNewPrompt() {
    if (!this.newPrompt.title?.trim() || !this.newPrompt.text?.trim()) {
      return;
    }

    const prompt: Prompt = {
      id: this.newPrompt.id || Date.now().toString(),
      title: this.newPrompt.title!,
      text: this.newPrompt.text!,
      category: this.newPrompt.category || 'general',
      usageCount: this.newPrompt.usageCount || 0,
      createdAt: this.newPrompt.createdAt || new Date()
    };

    if (this.newPrompt.id) {
      // Update existing prompt
      const index = this.savedPrompts.findIndex(p => p.id === this.newPrompt.id);
      if (index !== -1) {
        this.savedPrompts[index] = prompt;
      }
    } else {
      // Add new prompt
      this.savedPrompts.unshift(prompt);
    }

    this.onCloseSavePromptModal();
  }

  // Quick Actions
  onQuickAction(action: string) {
    const prompts = {
      revenue: 'Generate a comprehensive revenue analysis for the current quarter',
      customers: 'Analyze customer behavior patterns and segment performance',
      performance: 'Show key performance metrics and trending indicators',
      trends: 'Identify emerging trends and market patterns in our data'
    };

    const queryText = prompts[action as keyof typeof prompts] || 'Analyze the data';
    this.router.navigate(['/queries'], { queryParams: { q: queryText } });
  }
}
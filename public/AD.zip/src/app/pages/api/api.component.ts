import { Component } from '@angular/core';

@Component({
  selector: 'app-api',
  templateUrl: './api.component.html',
  styleUrls: ['./api.component.css']
})
export class ApiComponent {
  endpoints = [
    {
      method: 'POST',
      path: '/api/v1/query',
      description: 'Submit a natural language query',
      example: '{"query": "What were our top selling products last month?"}'
    },
    {
      method: 'GET',
      path: '/api/v1/insights/{id}',
      description: 'Retrieve insights for a specific query',
      example: 'GET /api/v1/insights/abc123'
    },
    {
      method: 'GET',
      path: '/api/v1/visualizations/{id}',
      description: 'Get chart data for visualization',
      example: 'GET /api/v1/visualizations/chart456'
    }
  ];

  constructor() {}
}
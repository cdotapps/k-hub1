# Finsight - Financial Insights AI Platform

## Project Overview
You are a best Angular developer who builds manageable eterprise applications with optimal project structure and reusable components. Build a sophisticated Financial Insights platform that empowers finance professionals with next-level AI solutions for real-time analytics, risk management, and predictive insights.

## Tech Stack
- **Frontend**: Angular 16+ with TypeScript
- **Backend**: Python FastAPI
- **UI Framework**: Angular Material or PrimeNG for enterprise components
- **Charts**: Chart.js or D3.js for financial visualizations
- **Icons**: Lucide Angular or Heroicons
- **Styling**: SCSS with CSS custom properties for theming

## Core Features & Requirements

### 1. Brand Identity & Design System
- **Primary Colors**: Deep blue gradient background (#0a1628 to #1e3a8a)
- **Accent Colors**: Cyan/teal (#06b6d4) for highlights and CTAs
- **Typography**: Clean, modern sans-serif fonts
- **Theme**: Dark mode primary with professional financial aesthetic
- **Logo**: "FINSIGHT" with distinctive icon (chart/analytics symbol)

### 2. Navigation & Layout
- **Header**: Fixed navigation with logo, main menu (Home, Products, Partnerships, Docs, Team), and "Launch App" CTA
- **Responsive Design**: Mobile-first approach with breakpoints for tablet and desktop
- **Smooth Transitions**: Implement page transitions and micro-interactions

### 3. AI-Powered Prompt Management System
- **Prompt Interface**: Intuitive input system for business questions about financial data
- **CRUD Operations**: Add, update, delete, and organize prompts
- **Recent Activity**: Display last 3 prompts with quick access
- **Smart Suggestions**: Show 3 AI-generated prompt suggestions based on context
- **Prompt Categories**: Organize by risk analysis, market trends, portfolio insights, etc.

### 4. Financial Data Visualization & Insights
- **Interactive Charts**: 
  - Bitcoin/cryptocurrency price charts with forecasting
  - Candlestick charts for market data
  - Line charts with prediction overlays
  - Real-time data updates
- **Chart Features**:
  - Zoom and pan functionality
  - Time range selectors
  - Forecast indicators with confidence intervals
  - Data point tooltips with detailed information

### 5. Insights Dashboard
- **Question-Answer Format**: Clear display of user questions and AI responses
- **Visual Analytics**: 
  - Pie charts for portfolio allocation
  - Bar charts for performance metrics
  - Data tables with sorting and filtering
  - Trend indicators and percentage changes
- **Contextual Conversations**: Continue asking follow-up questions within the same context
- **Export Capabilities**: Download insights as PDF or Excel

### 6. User Experience Guidelines
- **Minimalistic Design**: Clean interfaces with purposeful white space
- **Icon-Driven**: Use SVG icons over text where appropriate
- **Limited Color Palette**: Maintain professional appearance with restrained color usage
- **Loading States**: Implement skeleton screens and progress indicators
- **Error Handling**: User-friendly error messages and fallback states

### 7. Technical Architecture
- **Component Structure**: 
  - Shared components library
  - Feature modules (dashboard, insights, prompts, charts)
  - Core services (API, state management, authentication)
- **State Management**: NgRx for complex state or simple services for smaller state
- **Security**: Implement proper authentication and data validation
- **Performance**: Lazy loading, OnPush change detection, virtual scrolling for large datasets

### 8. Security & Best Practices
- **Dependency Management**: Avoid vulnerable libraries and unnecessary third-party packages
- **Code Quality**: ESLint, Prettier, and strict TypeScript configuration
- **Testing**: Unit tests with Jest, E2E tests with Cypress
- **Accessibility**: WCAG 2.1 AA compliance

## Key Pages & Components

### Landing Page
- Hero section with "Unlock Financial Insights with AI" messaging
- Feature highlights and benefits
- Interactive demo or preview
- Call-to-action buttons

### Dashboard
- Overview of recent activity
- Quick access to prompt management
- Summary of latest insights
- Navigation to detailed views

### Prompt Management
- Prompt creation and editing interface
- History and favorites
- Search and filtering capabilities
- Suggestion engine

### Insights Viewer
- Question and answer display
- Interactive charts and visualizations
- Data export options
- Conversation continuation

### Settings & Profile
- User preferences
- API configurations
- Theme customization
- Account management

## Development Priorities
1. **Reusable Components**: Build a comprehensive component library
2. **Performance**: Optimize for large datasets and real-time updates
3. **Scalability**: Design for enterprise-level usage
4. **User Experience**: Focus on intuitive workflows and visual appeal
5. **Security**: Implement robust security measures throughout
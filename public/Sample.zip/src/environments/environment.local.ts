export const environment = {
  production: false,
  apiUrl: 'http://localhost:8000', // Local development API URL
  apiVersion: 'v1',
  appName: 'Finsights Local',
  appVersion: '1.0.0-local',
  features: {
    enableLogging: true,
    enableAnalytics: false,
    enableDebugMode: true
  },
  auth: {
    tokenKey: 'finsights_local_access_token',
    refreshTokenKey: 'finsights_local_refresh_token',
    tokenExpiryKey: 'finsights_local_token_expiry'
  },
  api: {
    timeout: 10000, // 10 seconds for local development
    retryAttempts: 1,
    retryDelay: 500 // 0.5 seconds
  }
};

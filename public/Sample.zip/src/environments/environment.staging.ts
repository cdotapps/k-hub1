export const environment = {
  production: false,
  apiUrl: 'https://staging-api.finsights.com', // Staging API URL
  apiVersion: 'v1',
  appName: 'Finsights Staging',
  appVersion: '1.0.0-staging',
  features: {
    enableLogging: true,
    enableAnalytics: true,
    enableDebugMode: true
  },
  auth: {
    tokenKey: 'finsights_staging_access_token',
    refreshTokenKey: 'finsights_staging_refresh_token',
    tokenExpiryKey: 'finsights_staging_token_expiry'
  },
  api: {
    timeout: 30000, // 30 seconds
    retryAttempts: 3,
    retryDelay: 1000 // 1 second
  }
};

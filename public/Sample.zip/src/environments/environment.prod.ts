export const environment = {
  production: true,
  apiUrl: 'https://api.finsights.com', // Production API URL
  apiVersion: 'v1',
  appName: 'Finsights',
  appVersion: '1.0.0',
  features: {
    enableLogging: false,
    enableAnalytics: true,
    enableDebugMode: false
  },
  auth: {
    tokenKey: 'finsights_access_token',
    refreshTokenKey: 'finsights_refresh_token',
    tokenExpiryKey: 'finsights_token_expiry'
  },
  api: {
    timeout: 30000, // 30 seconds
    retryAttempts: 3,
    retryDelay: 1000 // 1 second
  }
};

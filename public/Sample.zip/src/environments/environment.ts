// This file can be replaced during build by using the `fileReplacements` array.
// `ng build` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.

export const environment = {
  production: false,
  apiUrl: 'http://localhost:8000',
  apiVersion: 'v1',
  appName: 'Finsights',
  appVersion: '1.0.0',
  features: {
    enableLogging: true,
    enableAnalytics: false,
    enableDebugMode: true
  },
  auth: {
    tokenKey: 'finsights_access_token',
    refreshTokenKey: 'finsights_refresh_token',
    tokenExpiryKey: 'finsights_token_expiry'
  },
  api: {
    timeout: 30000, // 30 seconds
    retryAttempts: 3,
    retryDelay: 1000 // 1 second
  }
};

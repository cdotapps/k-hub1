import { Component } from '@angular/core';

@Component({
  selector: 'app-agent-log',
  templateUrl: './agent-log.component.html',
  styleUrls: ['./agent-log.component.css']
})
export class AgentLogComponent {

}

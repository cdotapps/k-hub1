import { Component, Input, Output, EventEmitter } from '@angular/core';
import { Router } from '@angular/router';

interface InsightData {
  portfolioReturn?: number;
  marketReturn?: number;
  topPerformers?: string[];
  portfolioBeta?: number;
  volatility?: number;
  sharpeRatio?: number;
  confidence?: number;
  dataPoints?: number;
}

export interface Insight {
  id: number;
  question: string;
  answer: string;
  timestamp: Date;
  charts: Array<{type: string, title: string}>;
  data: InsightData;
  key?: string;
  rawJson?: any;
}

@Component({
  selector: 'app-insights-card',
  templateUrl: './insights-card.component.html',
  styleUrls: ['./insights-card.component.css']
})
export class InsightsCardComponent {
  @Input() insight!: Insight;
  @Output() keyClicked = new EventEmitter<void>();
  @Output() exportClicked = new EventEmitter<void>();
  @Output() followUpClicked = new EventEmitter<string>();

  expanded: boolean = false;

  constructor(private router: Router) {}

  getMetrics(data: InsightData): Array<{label: string, value: string, class?: string}> {
    const metrics: Array<{label: string, value: string, class?: string}> = [];
    if (data.portfolioReturn !== undefined) {
      metrics.push({
        label: 'Portfolio Return',
        value: `${data.portfolioReturn}%`,
        class: data.portfolioReturn > 0 ? 'positive' : 'negative'
      });
    }
    if (data.marketReturn !== undefined) {
      metrics.push({
        label: 'Market Return',
        value: `${data.marketReturn}%`,
        class: data.marketReturn > 0 ? 'positive' : 'negative'
      });
    }
    if (data.portfolioBeta !== undefined) {
      metrics.push({ label: 'Portfolio Beta', value: data.portfolioBeta.toString() });
    }
    if (data.volatility !== undefined) {
      metrics.push({ label: 'Volatility', value: `${data.volatility}%` });
    }
    if (data.sharpeRatio !== undefined) {
      metrics.push({ label: 'Sharpe Ratio', value: data.sharpeRatio.toString() });
    }
    if (data.confidence !== undefined) {
      metrics.push({ label: 'Confidence', value: `${data.confidence}%` });
    }
    return metrics;
  }

  toggleExpanded() {
    this.expanded = !this.expanded;
  }

  keyClickedHandler() {
    if (this.insight.key) {
      this.router.navigate(['/insights-details', this.insight.key]);
    }
  }

  exportClickedHandler() {
    this.exportClicked.emit();
  }

  followUpClickedHandler(value: string) {
    this.followUpClicked.emit(value);
  }
}

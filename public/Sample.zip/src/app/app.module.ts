import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { RouterModule } from '@angular/router';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';

import { AppComponent } from './app.component';
import { HeaderComponent } from './shared/components/header/header.component';
import { FooterComponent } from './shared/components/footer/footer.component';
import { HomeComponent } from './features/home/home.component';
import { DashboardComponent } from './features/dashboard/dashboard.component';
import { InsightsComponent } from './features/insights/insights.component';
import { CoreModule } from './core/core.module';
import { PromptsComponent } from './features/prompts/prompts.component';
import { InsightsCardComponent } from './components/insights-card/insights-card.component';
import { InsightsDetailsComponent } from './features/insights-details/insights-details.component';
import { AgentLogComponent } from './components/agent-log/agent-log.component';

const routes = [
  { path: '', component: HomeComponent },
  { path: 'dashboard', component: DashboardComponent },
  { path: 'insights', component: InsightsComponent },
  { path: 'insights-details/:key', component: InsightsDetailsComponent },
  { path: 'prompts', component: PromptsComponent },
  { path: '**', redirectTo: '' }
];

@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    FooterComponent,
    HomeComponent,
    DashboardComponent,
    InsightsComponent,
    PromptsComponent,
    InsightsCardComponent,
    InsightsDetailsComponent,
    AgentLogComponent
  ],
  imports: [
    BrowserModule,
    CommonModule,
    FormsModule,
    RouterModule.forRoot(routes),
    CoreModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }

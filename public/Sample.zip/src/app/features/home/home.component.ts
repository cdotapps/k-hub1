import { Component, OnInit, OnDestroy } from '@angular/core';
import { Router } from '@angular/router';
import { ApiService } from '../../core/services/api.service';
import { environment } from '../../../environments/environment';

export interface UserProfile {
  username: string;
  password: string;
  displayName: string;
  role: string;
  iconType: string;
  description: string;
  color: string;
  avatar: string;
}

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.scss']
})
export class HomeComponent implements OnInit, OnDestroy {
  
  chartData = {
    currentExpense: 45230,
    forecastExpense: 44280
  };

  currentSlide = 0;
  heroSlides = [
    { title: 'Voice & Text Input' },
    { title: 'AI Data Analysis' },
    { title: 'Interactive Charts' }
  ];

  // Interactive demo properties
  isRecordingDemo = false;
  typedText = '';
  fullText = 'How are my asset expenses this month?';
  dataPackets: any[] = [];
  docPackets: any[] = [];
  
  private typingInterval: any;
  private recordingInterval: any;
  private dataFlowInterval: any;

  currentDemoStep = 0;
  demoSteps = [
    {
      title: 'User Agent & Role-Based Security',
      description: 'Our FP&A AI agent maintains user context, prompts, and settings while ensuring role-based access control for secure, tailored responses.',
      demoText: 'Show me Block A maintenance costs vs budget variance',
      visualClass: 'user-agent-visual',
      features: [
        'User prompt memory & settings storage',
        'Role-based access control (FP&A Manager, Analyst, etc.)',
        'Personalized response tailoring',
        'Secure authentication & authorization'
      ]
    },
    {
      title: 'Multi-Source Data Integration',
      description: 'Three specialized agents work together: User Agent (context), DB Agent (admin expense data), and Knowledge Base (business documents & reports).',
      visualClass: 'integration-visual',
      features: [
        'User Agent: Maintains context & preferences',
        'DB Agent: Real-time admin expense table queries',
        'Knowledge Base: Business documents & reports',
        'AI Consolidation: Unified response generation'
      ]
    },
    {
      title: 'Real-time Insights & Gen AI Summary',
      description: 'All data sources are consolidated to provide real-time expense insights with Gen AI-powered summaries and actionable recommendations.',
      visualClass: 'insights-visual',
      features: [
        'Real-time admin expense visualization',
        'Gen AI-powered insight summaries',
        'Automated trend analysis & forecasting',
        'Actionable FP&A recommendations'
      ]
    }
  ];


  userProfiles: UserProfile[] = [
    {
      username: 'admin',
      password: 'admin123',
      displayName: 'Admin User',
      role: 'Administrator',
      iconType: 'admin',
      description: 'Full system access',
      color: '#06b6d4',
      avatar: '👨‍💼'
    },
    {
      username: 'analyst',
      password: 'analyst123',
      displayName: 'Financial Analyst',
      role: 'Analyst',
      iconType: 'analyst',
      description: 'Data analysis',
      color: '#8b5cf6',
      avatar: '📊'
    },
    {
      username: 'officer',
      password: 'officer123',
      displayName: 'Finance Officer',
      role: 'Officer',
      iconType: 'officer',
      description: 'Financial operations',
      color: '#22c55e',
      avatar: '💰'
    }
  ];

  isLoggingIn = false;
  selectedUser: UserProfile | null = null;

  constructor(
    private router: Router,
    private apiService: ApiService
  ) { }

  ngOnInit(): void {
    this.startSlideAutoAdvance();
    this.initializeInteractiveElements();
  }

  ngOnDestroy(): void {
    if (this.slideInterval) clearInterval(this.slideInterval);
    if (this.typingInterval) clearInterval(this.typingInterval);
    if (this.recordingInterval) clearInterval(this.recordingInterval);
    if (this.dataFlowInterval) clearInterval(this.dataFlowInterval);
  }

  initializeInteractiveElements(): void {
    // Initialize data packets for processing animation
    this.dataPackets = Array.from({ length: 4 }, (_, i) => ({
      id: i,
      position: 0,
      delay: i * 0.6
    }));
    
    // Initialize document packets with different timing
    this.docPackets = Array.from({ length: 3 }, (_, i) => ({
      id: i + 10,
      position: 0,
      delay: i * 0.8 + 0.3
    }));
    
    this.startInteractiveAnimations();
  }

  slideInterval: any;

  startSlideAutoAdvance(): void {
    this.slideInterval = setInterval(() => {
      this.nextSlide();
    }, 4000); // Change slide every 4 seconds
  }

  setSlide(index: number): void {
    this.currentSlide = index;
    // Reset auto-advance timer when user manually changes slide
    if (this.slideInterval) {
      clearInterval(this.slideInterval);
      this.startSlideAutoAdvance();
    }
    this.startInteractiveAnimations();
  }

  setDemoStep(step: number): void {
    this.currentDemoStep = step;
    // Reset auto-advance timer when user manually changes slide
    if (this.slideInterval) {
      clearInterval(this.slideInterval);
      this.startSlideAutoAdvance();
    }
    this.startInteractiveAnimations();
  }

  nextStep(): void {
    if (this.currentDemoStep < this.demoSteps.length - 1) {
      this.currentDemoStep++;
      this.startInteractiveAnimations();
    }
  }

  previousStep(): void {
    if (this.currentDemoStep > 0) {
      this.currentDemoStep--;
      this.startInteractiveAnimations();
    }
  }

  nextSlide(): void {
    this.currentSlide = (this.currentSlide + 1) % this.heroSlides.length;
    this.startInteractiveAnimations();
  }


  startInteractiveAnimations(): void {
    // Clear existing intervals
    if (this.typingInterval) clearInterval(this.typingInterval);
    if (this.recordingInterval) clearInterval(this.recordingInterval);
    if (this.dataFlowInterval) clearInterval(this.dataFlowInterval);

    // Start animations based on current slide
    setTimeout(() => {
      switch (this.currentSlide) {
        case 0:
          this.startTypingAnimation();
          this.startRecordingAnimation();
          break;
        case 1:
          this.startDataFlowAnimation();
          break;
        case 2:
          // Chart animations are handled by CSS/SVG
          break;
      }
    }, 300); // Small delay for slide transition
  }

  startTypingAnimation(): void {
    this.typedText = '';
    let currentIndex = 0;
    
    this.typingInterval = setInterval(() => {
      if (currentIndex < this.fullText.length) {
        this.typedText += this.fullText[currentIndex];
        currentIndex++;
      } else {
        clearInterval(this.typingInterval);
        // Restart after a pause
        setTimeout(() => {
          if (this.currentSlide === 0) {
            this.startTypingAnimation();
          }
        }, 2000);
      }
    }, 100);
  }

  startRecordingAnimation(): void {
    this.recordingInterval = setInterval(() => {
      this.isRecordingDemo = !this.isRecordingDemo;
    }, 3000);
  }

  startDataFlowAnimation(): void {
    this.dataFlowInterval = setInterval(() => {
      this.dataPackets.forEach((packet, index) => {
        packet.position = (packet.position + 2) % 100;
      });
      this.docPackets.forEach((packet, index) => {
        packet.position = (packet.position + 1.8) % 100;
      });
    }, 100);
  }

  trackPacket(index: number, packet: any): number {
    return packet.id;
  }

  loginAsUser(user: UserProfile): void {
    this.isLoggingIn = true;
    this.selectedUser = user;

    // Real API authentication for all environments
    const loginRequest = {
      username: user.username,
      password: user.password,
      grant_type: 'password'
    };

    this.apiService.login(loginRequest).subscribe({
      next: (response) => {
        // Store user profile in localStorage
        localStorage.setItem('user_profile', JSON.stringify({
          username: user.username,
          displayName: user.displayName,
          role: user.role,
          iconType: user.iconType,
          avatar: user.avatar
        }));

        // Store the token from API response
        if (response && response.access_token) {
          localStorage.setItem('finsights_access_token', response.access_token);
        }

        this.isLoggingIn = false;
        this.router.navigate(['/dashboard']);
      },
      error: (error) => {
        this.isLoggingIn = false;
        this.selectedUser = null;
        console.error('Login failed:', error);
        alert('Login failed: Unable to connect to the server. Please check your connection or try again later.');
      }
    });
  }

  onViewDemo(): void {
    this.router.navigate(['/dashboard']);
  }

}

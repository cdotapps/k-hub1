import { Component, OnInit, OnDestroy } from '@angular/core';
import { ApiService } from '../../core/services/api.service';
import { interval, Subscription } from 'rxjs';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.scss']
})
export class DashboardComponent implements OnInit, OnDestroy {
  
  recentPrompts = [
    {
      id: 1,
      question: "How are my asset expenses this month?",
      timestamp: new Date(Date.now() - 2 * 60 * 60 * 1000), // 2 hours ago
      status: 'completed'
    },
    {
      id: 2,
      question: "Show me the trend of expenses for last 6 months",
      timestamp: new Date(Date.now() - 5 * 60 * 60 * 1000), // 5 hours ago
      status: 'completed'
    },
    {
      id: 3,
      question: "How many blocks do we have and show expense report?",
      timestamp: new Date(Date.now() - 24 * 60 * 60 * 1000), // 1 day ago
      status: 'completed'
    }
  ];

  suggestions = [
    "What are the highest expense categories this month?",
    "Show me cost breakdown by block and department",
    "Which assets have the highest maintenance costs?"
  ];

  quickStats = {
    totalQueries: 47,
    insightsGenerated: 23,
    totalExpenses: 125430.50,
    monthlyChange: -8.45
  };

  adminExpenseSummary = {
    recordCount: 1287,
    s3: {
      data: 8,
      metadata: 4,
      embeddings: 2
    }
  };

  agentStatus: string = 'Unknown';
  currentUser: string = '';
  currentRole: string = '';
  private healthSub?: Subscription;

  constructor(private apiService: ApiService) { }

  ngOnInit(): void {
    const user = this.getCurrentUser();
    this.currentUser = user.username;
    this.currentRole = user.role;
    this.pollAgentStatus();
  }

  ngOnDestroy(): void {
    if (this.healthSub) this.healthSub.unsubscribe();
  }

  pollAgentStatus(): void {
    this.healthSub = interval(10000).subscribe(() => {
      this.apiService.getHealth().subscribe({
        next: (res) => {
          this.agentStatus = res.status || 'Online';
        },
        error: () => {
          this.agentStatus = 'Offline';
        }
      });
    });
    // Initial poll
    this.apiService.getHealth().subscribe({
      next: (res) => {
        this.agentStatus = res.status || 'Online';
      },
      error: () => {
        this.agentStatus = 'Offline';
      }
    });
  }

  getCurrentUser(): { username: string, role: string } {
    const userProfile = localStorage.getItem('user_profile');
    if (userProfile) {
      try {
        const user = JSON.parse(userProfile);
        return {
          username: user.username || 'user',
          role: user.role || 'user'
        };
      } catch {
        return { username: 'user', role: 'user' };
      }
    }
    return { username: 'user', role: 'user' };
  }

  onSyncKnowledgeBase(): void {
    // TODO: Implement sync logic here
    console.log('Sync Knowledge Base triggered by admin');
  }

  onFileUpload(event: Event): void {
    const input = event.target as HTMLInputElement;
    if (input.files && input.files.length > 0) {
      const file = input.files[0];
      // TODO: Implement file upload logic here
      console.log('Uploading file to S3 data folder:', file.name);
    }
  }

  onAskQuestion(question: string): void {
    console.log('Asking question:', question);
    // Navigate to insights page with the question
  }

  onViewInsight(promptId: number): void {
    console.log('Viewing insight for prompt:', promptId);
    // Navigate to specific insight
  }
}

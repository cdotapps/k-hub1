import { Component, OnInit, OnDestroy, ChangeDetectorRef, NgZone } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { CatalogService } from '../../core/services/catalog.service';
import { CatalogItem } from '../../core/models/api.models';
import { Subscription } from 'rxjs';

interface InsightData {
  portfolioReturn?: number;
  marketReturn?: number;
  topPerformers?: string[];
  portfolioBeta?: number;
  volatility?: number;
  sharpeRatio?: number;
  confidence?: number;
  dataPoints?: number;
}

interface Insight {
  id: number;
  question: string;
  answer: string;
  timestamp: Date;
  charts: Array<{type: string, title: string}>;
  data: InsightData;
  key?: string;
  rawJson?: CatalogItem;
}

@Component({
  selector: 'app-insights-details',
  templateUrl: './insights-details.component.html',
  styleUrls: ['./insights-details.component.scss']
})
export class InsightsDetailsComponent implements OnInit, OnDestroy {
  
  currentQuestion = '';
  isLoading = false;
  isRecording = false;
  recognition: any;
  speechSupported = false;
  interimTranscript = '';
  finalTranscript = '';
  agentLogs: { timestamp: string; message: string; key?: string }[] = [];
  currentQuestionKey: string | null = null;
  agentLogPopupVisible: boolean = false;
  agentLogPopupLogs: CatalogItem[] = [];
  agentLogPopupKey: string | null = null;
  catalogItems: CatalogItem[] = [];
  userRequest: Insight | null = null;
  agentSteps: Insight[] = [];
  routeSub: Subscription | null = null;
  showAgentLogs = true;
  
  insights: Insight[] = [
    
  ];

  constructor(
    private cdr: ChangeDetectorRef,
    private ngZone: NgZone,
    private route: ActivatedRoute,
    private catalogService: CatalogService
  ) { }

  ngOnInit(): void {
    this.checkSpeechSupport();
    if (this.speechSupported) {
      this.initializeSpeechRecognition();
    }
    // Listen for route param 'key' and load catalog items
    this.routeSub = this.route.params.subscribe(params => {
      const key = params['key'];
      if (key) {
        this.loadCatalogItemsByKey(key);
      }
    });
    // Check for query parameter from prompts
    this.route.queryParams.subscribe(params => {
      if (params['query']) {
        this.currentQuestion = params['query'];
        // Optionally auto-submit the query
        // this.submitQuestion();
      }
    });
  }

  ngOnDestroy(): void {
    // Clean up speech recognition
    if (this.recognition && this.isRecording) {
      this.recognition.stop();
    }
    if (this.routeSub) this.routeSub.unsubscribe();
  }

  checkSpeechSupport(): void {
    this.speechSupported = 'webkitSpeechRecognition' in window || 'SpeechRecognition' in window;
    console.log('Speech recognition supported:', this.speechSupported);
  }

  initializeSpeechRecognition(): void {
    if ('webkitSpeechRecognition' in window || 'SpeechRecognition' in window) {
      this.speechSupported = true;
      const SpeechRecognition = (window as any).webkitSpeechRecognition || (window as any).SpeechRecognition;
      this.recognition = new SpeechRecognition();
      
      this.recognition.continuous = true;
      this.recognition.interimResults = true;
      this.recognition.lang = 'en-US';
      this.recognition.maxAlternatives = 1;
      
      this.recognition.onstart = () => {
        this.ngZone.run(() => {
          this.isRecording = true;
          this.interimTranscript = '';
          this.finalTranscript = '';
          console.log('Speech recognition started');
        });
      };
      
      this.recognition.onresult = (event: any) => {
        this.ngZone.run(() => {
          let interimTranscript = '';
          let finalTranscript = this.finalTranscript;
          
          // Process all results from the current event
          for (let i = event.resultIndex; i < event.results.length; i++) {
            const transcript = event.results[i][0].transcript;
            
            if (event.results[i].isFinal) {
              finalTranscript += transcript + ' ';
            } else {
              interimTranscript += transcript;
            }
          }
          
          // Update transcripts
          this.finalTranscript = finalTranscript;
          this.interimTranscript = interimTranscript;
          
          // Combine final and interim for display
          this.currentQuestion = (finalTranscript + interimTranscript).trim();
          
          // Trigger change detection
          this.cdr.detectChanges();
        });
      };
      
      this.recognition.onerror = (event: any) => {
        this.ngZone.run(() => {
          console.error('Speech recognition error:', event.error);
          this.isRecording = false;
          this.cdr.detectChanges();
        });
      };
      
      this.recognition.onend = () => {
        this.ngZone.run(() => {
          this.isRecording = false;
          // Keep the final transcript
          this.currentQuestion = this.finalTranscript.trim();
          console.log('Speech recognition ended');
          this.cdr.detectChanges();
        });
      };
    }
  }

  toggleVoiceRecording(): void {
    if (!this.speechSupported) {
      alert('Speech recognition is not supported in your browser');
      return;
    }

    try {
      if (this.isRecording) {
        console.log('Stopping speech recognition');
        this.recognition.stop();
      } else {
        console.log('Starting speech recognition');
        // Reset transcripts before starting
        this.finalTranscript = '';
        this.interimTranscript = '';
        this.recognition.start();
      }
    } catch (error) {
      console.error('Error toggling speech recognition:', error);
      this.isRecording = false;
    }
  }

  onKeyDown(event: KeyboardEvent): void {
    if (event.ctrlKey && event.key === 'Enter') {
      this.onAskQuestion();
    }
  }

  async onAskQuestion(): Promise<void> {
    if (!this.currentQuestion.trim()) return;
    this.isLoading = true;
    // Clear agent log for new question
    this.agentLogs = [];
    // Add entry to catalog
    const catalogItem: CatalogItem = {
      name: this.currentQuestion,
      content: this.currentQuestion,
      type: 'question',
      category: 'question',
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString(),
      created_by: 'user',
      private: false
    };
    this.agentLogs.unshift({
      timestamp: new Date().toISOString(),
      message: 'Key generation started for question',
    });
    this.catalogService.createItem(catalogItem).subscribe({
      next: (created) => {
        this.currentQuestionKey = created.key ?? null;
        this.agentLogs.unshift({
          timestamp: new Date().toISOString(),
          message: 'Key generated: ' + created.key,
          key: created.key
        });
        this.agentLogs.unshift({
          timestamp: new Date().toISOString(),
          message: 'Calling model for analysis...',
          key: created.key
        });
        // Call agentic chat streaming API with the generated key
        const token: string = (localStorage.getItem('finsights_access_token') ?? '') as string;
        this.catalogService.streamAgenticChat(created.key ?? '', this.currentQuestion, token).subscribe({
          next: (response: string) => {
            this.agentLogs.unshift({
              timestamp: new Date().toISOString(),
              message: 'Model response received for key: ' + created.key,
              key: created.key
            });
            const newInsight: Insight = {
              id: this.insights.length + 1,
              key: created.key ?? undefined,
              question: this.currentQuestion,
              answer: response,
              timestamp: new Date(),
              charts: [ { type: 'line', title: 'Trend Analysis' } ],
              data: { confidence: 85, dataPoints: 150 }
            };
            this.insights.unshift(newInsight);
            this.currentQuestion = '';
            this.isLoading = false;
          },
          error: (err: any) => {
            this.agentLogs.unshift({
              timestamp: new Date().toISOString(),
              message: 'Error from model: ' + (err.message || 'Unknown error'),
              key: created.key
            });
            this.isLoading = false;
          }
        });
      },
      error: (err: any) => {
        this.agentLogs.unshift({
          timestamp: new Date().toISOString(),
          message: 'Error generating key: ' + (err.message || 'Unknown error'),
        });
        this.isLoading = false;
      }
    });
  }

  onContinueConversation(insightId: number, followUpQuestion: string): void {
    console.log('Continue conversation for insight:', insightId, 'with question:', followUpQuestion);
    // Add follow-up logic here
  }

  onExportInsight(insightId: number): void {
    console.log('Export insight:', insightId);
    // Add export logic here
  }

  onInputFocus(): void {
    // Add focus handling if needed
  }

  onInputBlur(): void {
    // Add blur handling if needed
  }

  clearQuestion(): void {
    // Stop recording if active
    if (this.isRecording && this.recognition) {
      this.recognition.stop();
    }
    
    // Clear all text
    this.currentQuestion = '';
    this.finalTranscript = '';
    this.interimTranscript = '';
  }

  setQuestion(question: string): void {
    this.currentQuestion = question;
  }

  trackByInsightId(index: number, insight: any): number {
    return insight.id;
  }

  getMetrics(data: any): Array<{label: string, value: string, class?: string}> {
    const metrics: Array<{label: string, value: string, class?: string}> = [];
    
    if (data.portfolioReturn !== undefined) {
      metrics.push({
        label: 'Portfolio Return',
        value: `${data.portfolioReturn}%`,
        class: data.portfolioReturn > 0 ? 'positive' : 'negative'
      });
    }
    
    if (data.marketReturn !== undefined) {
      metrics.push({
        label: 'Market Return',
        value: `${data.marketReturn}%`,
        class: data.marketReturn > 0 ? 'positive' : 'negative'
      });
    }
    
    if (data.portfolioBeta !== undefined) {
      metrics.push({
        label: 'Portfolio Beta',
        value: data.portfolioBeta.toString()
      });
    }
    
    if (data.volatility !== undefined) {
      metrics.push({
        label: 'Volatility',
        value: `${data.volatility}%`
      });
    }
    
    if (data.sharpeRatio !== undefined) {
      metrics.push({
        label: 'Sharpe Ratio',
        value: data.sharpeRatio.toString()
      });
    }
    
    if (data.confidence !== undefined) {
      metrics.push({
        label: 'Confidence',
        value: `${data.confidence}%`
      });
    }
    
    return metrics;
  }

  showAgentLogPopup(insight: Insight): void {
    const key = this.currentQuestionKey;
    if (!key) return;
    this.agentLogPopupKey = key;
    this.agentLogPopupVisible = true;
    // Fetch agent logs from catalog by type and key
    this.catalogService.getItemsByKey(key).subscribe({
      next: (logs) => {
        this.agentLogPopupLogs = logs;
      },
      error: () => {
        this.agentLogPopupLogs = [];
      }
    });
  }

  closeAgentLogPopup(): void {
    this.agentLogPopupVisible = false;
    this.agentLogPopupLogs = [];
    this.agentLogPopupKey = null;
  }

  loadCatalogItemsByKey(key: string): void {
    this.isLoading = true;
    this.catalogService.getItemsByKey(key).subscribe({
      next: (items: CatalogItem[]) => {
        this.catalogItems = items;
        const userItem = items.find(i => i.created_by === 'user') || null;
        this.userRequest = userItem ? this.catalogItemToInsight(userItem) : null;
        this.agentSteps = items.filter(i => i.created_by !== 'user').map(i => this.catalogItemToInsight(i));
        this.isLoading = false;
      },
      error: () => {
        this.catalogItems = [];
        this.userRequest = null;
        this.agentSteps = [];
        this.isLoading = false;
      }
    });
  }

  catalogItemToInsight(item: CatalogItem): Insight {
    return {
      id: item.id ? Number(item.id) : 0,
      key: item.key,
      question: item.name || item.content || '',
      answer: item.ai_content || item.content || '',
      timestamp: item.created_at ? new Date(item.created_at) : new Date(),
      charts: [],
      data: {},
      rawJson: item // Pass the full CatalogItem as rawJson
    };
  }
}

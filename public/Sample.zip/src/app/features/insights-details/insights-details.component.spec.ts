import { ComponentFixture, TestBed } from '@angular/core/testing';

import { InsightsDetailsComponent } from './insights-details.component';

describe('InsightsDetailsComponent', () => {
  let component: InsightsDetailsComponent;
  let fixture: ComponentFixture<InsightsDetailsComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [InsightsDetailsComponent]
    });
    fixture = TestBed.createComponent(InsightsDetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

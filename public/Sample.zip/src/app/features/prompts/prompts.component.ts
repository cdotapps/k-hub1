import { Component, OnInit, OnDestroy } from '@angular/core';
import { Router } from '@angular/router';
import { Subject, takeUntil, of } from 'rxjs';
import { CatalogService } from '../../core/services/catalog.service';
import { CatalogItem } from '../../core/models/api.models';
import { environment } from '../../../environments/environment';

@Component({
  selector: 'app-prompts',
  templateUrl: './prompts.component.html',
  styleUrls: ['./prompts.component.scss']
})
export class PromptsComponent implements OnInit, OnDestroy {
  private destroy$ = new Subject<void>();
  
  prompts: CatalogItem[] = [];
  filteredPrompts: CatalogItem[] = [];
  loading = false;
  searchTerm = '';
  errorMessage: string | null = null;
  
  // Modal states
  showAddModal = false;
  showEditModal = false;
  showDeleteModal = false;
  selectedPrompt: CatalogItem | null = null;

  CATALOG_TYPE = 'prompt';
  
  // Form data
  promptForm = {
    name: '',
    description: '',
    content: '',
    category: 'general',
    priority: 1
  };

  // Pagination and category filter state
  visibleCount = 4;
  selectedCategory: string | null = null;
  uniqueCategories: string[] = [];

  constructor(
    private catalogService: CatalogService,
    private router: Router
  ) {}

  ngOnInit(): void {
    this.loadPrompts();
  }

  ngOnDestroy(): void {
    this.destroy$.next();
    this.destroy$.complete();
  }

  loadPrompts(): void {
    this.loading = true;
    
    // Check authentication status
    const token = localStorage.getItem('finsights_access_token');
    console.log('🔧 Loading prompts from API...');
    console.log('🔑 Token present:', !!token);
    if (token) {
      console.log('🔑 Token preview:', token.substring(0, 20) + '...');
    }
    
    // Real API call
    this.catalogService.getItemsByType(this.CATALOG_TYPE)
      .pipe(takeUntil(this.destroy$))
      .subscribe({
        next: (prompts) => {
          console.log('✅ API prompts loaded:', prompts.length, 'items');
          this.prompts = prompts;
          this.filteredPrompts = prompts;
          this.uniqueCategories = Array.from(new Set(prompts.map(p => p.category).filter((cat): cat is string => typeof cat === 'string')));
          this.loading = false;
        },
        error: (error) => {
          console.error('Error loading prompts:', error);
          console.error('Error details:', error.status, error.statusText);
          this.prompts = [];
          this.filteredPrompts = [];
          this.uniqueCategories = [];
          this.loading = false;
        }
      });
  }

  get visiblePrompts(): CatalogItem[] {
    return this.filteredPrompts.slice(0, this.visibleCount);
  }

  loadMore(): void {
    this.visibleCount += 4;
  }

  filterByCategory(category: string): void {
    this.selectedCategory = category;
    this.searchTerm = '';
    this.filteredPrompts = this.prompts.filter(p => p.category === category);
    this.visibleCount = 4;
  }

  clearCategoryFilter(): void {
    this.selectedCategory = null;
    this.filteredPrompts = this.prompts;
    this.visibleCount = 4;
  }

  searchPrompts(): void {
    if (!this.searchTerm.trim()) {
      this.filteredPrompts = this.selectedCategory
        ? this.prompts.filter(p => p.category === this.selectedCategory)
        : this.prompts;
      this.visibleCount = 4;
      return;
    }

    this.filteredPrompts = (this.selectedCategory
      ? this.prompts.filter(p => p.category === this.selectedCategory)
      : this.prompts
    ).filter(prompt =>
      prompt.name.toLowerCase().includes(this.searchTerm.toLowerCase()) ||
      prompt.description?.toLowerCase().includes(this.searchTerm.toLowerCase()) ||
      prompt.content?.toLowerCase().includes(this.searchTerm.toLowerCase())
    );
    this.visibleCount = 4;
  }

  openAddModal(): void {
    this.resetForm();
    this.showAddModal = true;
  }

  openEditModal(prompt: CatalogItem): void {
    this.selectedPrompt = prompt;
    this.promptForm = {
      name: prompt.name,
      description: prompt.description || '',
      content: prompt.content || '',
      category: prompt.category || 'general',
      priority: prompt.priority || 1
    };
    this.showEditModal = true;
  }

  openDeleteModal(prompt: CatalogItem): void {
    this.selectedPrompt = prompt;
    this.showDeleteModal = true;
  }

  closeModals(): void {
    this.showAddModal = false;
    this.showEditModal = false;
    this.showDeleteModal = false;
    this.selectedPrompt = null;
    this.resetForm();
  }

  resetForm(): void {
    this.promptForm = {
      name: '',
      description: '',
      content: '',
      category: 'general',
      priority: 1
    };
  }

  savePrompt(): void {
    if (!this.promptForm.name.trim() || !this.promptForm.content.trim()) {
      return;
    }
    this.errorMessage = null;

    const promptData: CatalogItem = {
      name: this.promptForm.name,
      description: this.promptForm.description,
      content: this.promptForm.content,
      type: this.CATALOG_TYPE,
      category: this.promptForm.category,
      priority: 1, // Always default to Low
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString(),
      created_by: this.getCurrentUser(),
      private: false
    };

    this.loading = true;

    console.log('🔧 Creating prompt via API...');
    console.log('Prompt payload:', promptData);
    
    // Real API call
    this.catalogService.createItem(promptData)
      .pipe(takeUntil(this.destroy$))
      .subscribe({
        next: (createdPrompt) => {
          console.log('✅ API prompt created:', createdPrompt.name);
          this.loadPrompts();
          this.closeModals();
        },
        error: (error) => {
          this.errorMessage = error.message || 'Failed to create prompt.';
          this.loading = false;
          this.closeModals();
        }
      });
  }

  updatePrompt(): void {
    if (!this.selectedPrompt || !this.selectedPrompt.id || !this.promptForm.name.trim() || !this.promptForm.content.trim()) {
      return;
    }
    this.errorMessage = null;

    const updatedPrompt: CatalogItem = {
      ...this.selectedPrompt,
      name: this.promptForm.name,
      description: this.promptForm.description,
      content: this.promptForm.content,
      category: this.promptForm.category,
      priority: this.promptForm.priority,
      updated_at: new Date().toISOString()
    };

    this.loading = true;

    console.log('🔧 Updating prompt via API...');
    
    // Real API call
    this.catalogService.updateItem(this.selectedPrompt.id, updatedPrompt)
      .pipe(takeUntil(this.destroy$))
      .subscribe({
        next: (updated) => {
          console.log('✅ API prompt updated:', updated.name);
          this.loadPrompts();
          this.closeModals();
        },
        error: (error) => {
          this.errorMessage = error.message || 'Failed to update prompt.';
          this.loading = false;
          this.closeModals();
        }
      });
  }

  deletePrompt(): void {
    if (!this.selectedPrompt || !this.selectedPrompt.id) return;

    this.loading = true;

    console.log('🔧 Deleting prompt via API...');
    
    // Real API call
    this.catalogService.deleteItem(this.selectedPrompt.id)
      .pipe(takeUntil(this.destroy$))
      .subscribe({
        next: () => {
          console.log('✅ API prompt deleted');
          this.loadPrompts();
          this.closeModals();
        },
        error: (error) => {
          console.error('Error deleting prompt:', error);
          this.loading = false;
          this.closeModals();
        }
      });
  }

  usePrompt(prompt: CatalogItem): void {
    // Navigate to insights page with the prompt content as query
    this.router.navigate(['/insights'], { 
      queryParams: { query: prompt.content } 
    });
  }

  private getCurrentUser(): string {
    const userProfile = localStorage.getItem('user_profile');
    if (userProfile) {
      try {
        const user = JSON.parse(userProfile);
        return user.username || 'unknown';
      } catch {
        return 'unknown';
      }
    }
    return 'unknown';
  }

  formatDate(dateString: string): string {
    return new Date(dateString).toLocaleDateString();
  }

  getPriorityLabel(priority: number): string {
    switch (priority) {
      case 3: return 'High';
      case 2: return 'Medium';
      case 1: return 'Low';
      default: return 'Low';
    }
  }

  getPriorityClass(priority: number): string {
    switch (priority) {
      case 3: return 'priority-high';
      case 2: return 'priority-medium';
      case 1: return 'priority-low';
      default: return 'priority-low';
    }
  }
}

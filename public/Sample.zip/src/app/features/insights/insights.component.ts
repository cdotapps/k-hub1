import { Component, OnInit, OnDestroy, ChangeDetectorRef, NgZone } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { CatalogService } from '../../core/services/catalog.service';
import { CatalogItem } from '../../core/models/api.models';

interface InsightData {
  portfolioReturn?: number;
  marketReturn?: number;
  topPerformers?: string[];
  portfolioBeta?: number;
  volatility?: number;
  sharpeRatio?: number;
  confidence?: number;
  dataPoints?: number;
}

interface Insight {
  id: number;
  question: string;
  answer: string;
  timestamp: Date;
  charts: Array<{type: string, title: string}>;
  data: InsightData;
  key?: string;
}

@Component({
  selector: 'app-insights',
  templateUrl: './insights.component.html',
  styleUrls: ['./insights.component.scss']
})
export class InsightsComponent implements OnInit, OnDestroy {
  
  currentQuestion = '';
  isLoading = false;
  isRecording = false;
  recognition: any;
  speechSupported = false;
  interimTranscript = '';
  finalTranscript = '';
  agentLogs: { timestamp: string; message: string; key?: string }[] = [];
  currentQuestionKey: string | null = null;
  agentLogPopupVisible: boolean = false;
  agentLogPopupLogs: CatalogItem[] = [];
  agentLogPopupKey: string | null = null;
  
  insights: Insight[] = [
    {
      id: 1,
      key: 'SF-RDJ8-56SF',
      question: "How are my asset expenses this month?",
      answer: "Your asset expenses this month total $45,230, which is 8% higher than last month. Block A had the highest expenses at $18,500, mainly due to maintenance costs. IT infrastructure (25% allocation) and facility management (30% allocation) are the top expense categories.",
      timestamp: new Date(Date.now() - 2 * 60 * 60 * 1000),
      charts: [
        { type: 'line', title: 'Monthly Expense Trends' },
        { type: 'pie', title: 'Expense Breakdown by Category' }
      ],
      data: {
        portfolioReturn: 8.0,
        marketReturn: 6.2,
        topPerformers: ['Block A', 'Block B', 'Block C']
      }
    },
    {
      id: 2,
      key: 'ST-GDF-56SF',
      question: "Show me the trend of expenses for last 6 months",
      answer: "Your expense trend shows seasonal patterns with 15% increase during Q2 due to facility upgrades. Block-wise analysis reveals Block A consistently has higher costs due to newer equipment maintenance. Consider cost optimization strategies for infrastructure expenses.",
      timestamp: new Date(Date.now() - 5 * 60 * 60 * 1000),
      charts: [
        { type: 'bar', title: 'Expense Trends by Block' },
        { type: 'line', title: '6-Month Cost Analysis' }
      ],
      data: {
        portfolioBeta: 1.2,
        volatility: 18.5,
        sharpeRatio: 1.45
      }
    }
  ];

  constructor(
    private cdr: ChangeDetectorRef,
    private ngZone: NgZone,
    private route: ActivatedRoute,
    private catalogService: CatalogService
  ) { }

  ngOnInit(): void {
    this.checkSpeechSupport();
    if (this.speechSupported) {
      this.initializeSpeechRecognition();
    }
    
    // Check for query parameter from prompts
    this.route.queryParams.subscribe(params => {
      if (params['query']) {
        this.currentQuestion = params['query'];
        // Optionally auto-submit the query
        // this.submitQuestion();
      }
    });
  }

  ngOnDestroy(): void {
    // Clean up speech recognition
    if (this.recognition && this.isRecording) {
      this.recognition.stop();
    }
  }

  checkSpeechSupport(): void {
    this.speechSupported = 'webkitSpeechRecognition' in window || 'SpeechRecognition' in window;
    console.log('Speech recognition supported:', this.speechSupported);
  }

  initializeSpeechRecognition(): void {
    if ('webkitSpeechRecognition' in window || 'SpeechRecognition' in window) {
      this.speechSupported = true;
      const SpeechRecognition = (window as any).webkitSpeechRecognition || (window as any).SpeechRecognition;
      this.recognition = new SpeechRecognition();
      
      this.recognition.continuous = true;
      this.recognition.interimResults = true;
      this.recognition.lang = 'en-US';
      this.recognition.maxAlternatives = 1;
      
      this.recognition.onstart = () => {
        this.ngZone.run(() => {
          this.isRecording = true;
          this.interimTranscript = '';
          this.finalTranscript = '';
          console.log('Speech recognition started');
        });
      };
      
      this.recognition.onresult = (event: any) => {
        this.ngZone.run(() => {
          let interimTranscript = '';
          let finalTranscript = this.finalTranscript;
          
          // Process all results from the current event
          for (let i = event.resultIndex; i < event.results.length; i++) {
            const transcript = event.results[i][0].transcript;
            
            if (event.results[i].isFinal) {
              finalTranscript += transcript + ' ';
            } else {
              interimTranscript += transcript;
            }
          }
          
          // Update transcripts
          this.finalTranscript = finalTranscript;
          this.interimTranscript = interimTranscript;
          
          // Combine final and interim for display
          this.currentQuestion = (finalTranscript + interimTranscript).trim();
          
          // Trigger change detection
          this.cdr.detectChanges();
        });
      };
      
      this.recognition.onerror = (event: any) => {
        this.ngZone.run(() => {
          console.error('Speech recognition error:', event.error);
          this.isRecording = false;
          this.cdr.detectChanges();
        });
      };
      
      this.recognition.onend = () => {
        this.ngZone.run(() => {
          this.isRecording = false;
          // Keep the final transcript
          this.currentQuestion = this.finalTranscript.trim();
          console.log('Speech recognition ended');
          this.cdr.detectChanges();
        });
      };
    }
  }

  toggleVoiceRecording(): void {
    if (!this.speechSupported) {
      alert('Speech recognition is not supported in your browser');
      return;
    }

    try {
      if (this.isRecording) {
        console.log('Stopping speech recognition');
        this.recognition.stop();
      } else {
        console.log('Starting speech recognition');
        // Reset transcripts before starting
        this.finalTranscript = '';
        this.interimTranscript = '';
        this.recognition.start();
      }
    } catch (error) {
      console.error('Error toggling speech recognition:', error);
      this.isRecording = false;
    }
  }

  onKeyDown(event: KeyboardEvent): void {
    if (event.ctrlKey && event.key === 'Enter') {
      this.onAskQuestion();
    }
  }

  async onAskQuestion(): Promise<void> {
    if (!this.currentQuestion.trim()) return;
    this.isLoading = true;
    // Clear agent log for new question
    this.agentLogs = [];
    // Add entry to catalog
    const catalogItem: CatalogItem = {
      name: this.currentQuestion,
      content: this.currentQuestion,
      type: 'question',
      category: 'question',
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString(),
      created_by: 'user',
      private: false
    };
    this.agentLogs.unshift({
      timestamp: new Date().toISOString(),
      message: 'Key generation started for question',
    });
    this.catalogService.createItem(catalogItem).subscribe({
      next: (created) => {
        this.currentQuestionKey = created.key ?? null;
        this.agentLogs.unshift({
          timestamp: new Date().toISOString(),
          message: 'Key generated: ' + created.key,
          key: created.key
        });
        this.agentLogs.unshift({
          timestamp: new Date().toISOString(),
          message: 'Calling model for analysis...',
          key: created.key
        });
        // Call agentic chat streaming API with the generated key
        const token: string = (localStorage.getItem('finsights_access_token') ?? '') as string;
        this.catalogService.streamAgenticChat(created.key ?? '', this.currentQuestion, token).subscribe({
          next: (response: string) => {
            this.agentLogs.unshift({
              timestamp: new Date().toISOString(),
              message: 'Model response received for key: ' + created.key,
              key: created.key
            });
            const newInsight: Insight = {
              id: this.insights.length + 1,
              key: created.key ?? undefined,
              question: this.currentQuestion,
              answer: response,
              timestamp: new Date(),
              charts: [ { type: 'line', title: 'Trend Analysis' } ],
              data: { confidence: 85, dataPoints: 150 }
            };
            this.insights.unshift(newInsight);
            this.currentQuestion = '';
            this.isLoading = false;
          },
          error: (err: any) => {
            this.agentLogs.unshift({
              timestamp: new Date().toISOString(),
              message: 'Error from model: ' + (err.message || 'Unknown error'),
              key: created.key
            });
            this.isLoading = false;
          }
        });
      },
      error: (err: any) => {
        this.agentLogs.unshift({
          timestamp: new Date().toISOString(),
          message: 'Error generating key: ' + (err.message || 'Unknown error'),
        });
        this.isLoading = false;
      }
    });
  }

  onContinueConversation(insightId: number, followUpQuestion: string): void {
    console.log('Continue conversation for insight:', insightId, 'with question:', followUpQuestion);
    // Add follow-up logic here
  }

  onExportInsight(insightId: number): void {
    console.log('Export insight:', insightId);
    // Add export logic here
  }

  onInputFocus(): void {
    // Add focus handling if needed
  }

  onInputBlur(): void {
    // Add blur handling if needed
  }

  clearQuestion(): void {
    // Stop recording if active
    if (this.isRecording && this.recognition) {
      this.recognition.stop();
    }
    
    // Clear all text
    this.currentQuestion = '';
    this.finalTranscript = '';
    this.interimTranscript = '';
  }

  setQuestion(question: string): void {
    this.currentQuestion = question;
  }

  trackByInsightId(index: number, insight: any): number {
    return insight.id;
  }

  getMetrics(data: any): Array<{label: string, value: string, class?: string}> {
    const metrics: Array<{label: string, value: string, class?: string}> = [];
    
    if (data.portfolioReturn !== undefined) {
      metrics.push({
        label: 'Portfolio Return',
        value: `${data.portfolioReturn}%`,
        class: data.portfolioReturn > 0 ? 'positive' : 'negative'
      });
    }
    
    if (data.marketReturn !== undefined) {
      metrics.push({
        label: 'Market Return',
        value: `${data.marketReturn}%`,
        class: data.marketReturn > 0 ? 'positive' : 'negative'
      });
    }
    
    if (data.portfolioBeta !== undefined) {
      metrics.push({
        label: 'Portfolio Beta',
        value: data.portfolioBeta.toString()
      });
    }
    
    if (data.volatility !== undefined) {
      metrics.push({
        label: 'Volatility',
        value: `${data.volatility}%`
      });
    }
    
    if (data.sharpeRatio !== undefined) {
      metrics.push({
        label: 'Sharpe Ratio',
        value: data.sharpeRatio.toString()
      });
    }
    
    if (data.confidence !== undefined) {
      metrics.push({
        label: 'Confidence',
        value: `${data.confidence}%`
      });
    }
    
    return metrics;
  }

  showAgentLogPopup(insight: Insight): void {
    const key = this.currentQuestionKey;
    if (!key) return;
    this.agentLogPopupKey = key;
    this.agentLogPopupVisible = true;
    // Fetch agent logs from catalog by type and key
    this.catalogService.getItemsByKey(key).subscribe({
      next: (logs) => {
        this.agentLogPopupLogs = logs;
      },
      error: () => {
        this.agentLogPopupLogs = [];
      }
    });
  }

  closeAgentLogPopup(): void {
    this.agentLogPopupVisible = false;
    this.agentLogPopupLogs = [];
    this.agentLogPopupKey = null;
  }
}

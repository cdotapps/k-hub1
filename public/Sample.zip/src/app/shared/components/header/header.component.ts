import { Component, OnInit } from '@angular/core';
import { ApiService } from '../../../core/services/api.service';
import { Router } from '@angular/router';

interface UserProfile {
  username: string;
  displayName: string;
  role: string;
  avatar: string;
}

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.scss']
})
export class HeaderComponent implements OnInit {

  menuItems = [
    { label: 'Home', route: '/' },
    { label: 'Dashboard', route: '/dashboard' },
    { label: 'Insights', route: '/insights' },
    { label: 'Prompts', route: '/prompts' }
  ];

  currentUser: UserProfile | null = null;
  isAuthenticated = false;

  constructor(
    private apiService: ApiService,
    private router: Router
  ) { }

  ngOnInit(): void {
    // Subscribe to authentication status
    this.apiService.isAuthenticated$.subscribe((isAuth: boolean) => {
      this.isAuthenticated = isAuth;
      if (isAuth) {
        this.loadUserProfile();
      } else {
        this.currentUser = null;
      }
    });
  }

  loadUserProfile(): void {
    const userProfileStr = localStorage.getItem('user_profile');
    if (userProfileStr) {
      try {
        this.currentUser = JSON.parse(userProfileStr);
      } catch (error) {
        console.error('Error parsing user profile:', error);
        this.currentUser = null;
      }
    }
  }

  logout(): void {
    this.apiService.logout();
    localStorage.removeItem('user_profile');
    this.currentUser = null;
    this.router.navigate(['/']);
  }

}

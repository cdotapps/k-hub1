import { Injectable } from '@angular/core';
import { HttpInterceptor, HttpRequest, HttpHandler, HttpEvent, HttpErrorResponse } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { catchError } from 'rxjs/operators';
import { Router } from '@angular/router';

@Injectable()
export class AuthInterceptor implements HttpInterceptor {

  constructor(private router: Router) {}

  intercept(request: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
    // Get token directly from localStorage
    const token = localStorage.getItem('finsights_access_token');
    
    // Clone the request and add authorization header if token exists
    if (token && !request.headers.has('Authorization')) {
      request = request.clone({
        setHeaders: {
          Authorization: `Bearer ${token}`
        }
      });
    }

    // Handle the request and catch any authentication errors
    return next.handle(request).pipe(
      catchError((error: HttpErrorResponse) => {
        if (error.status === 401) {
          // Token is invalid or expired - clear all auth data
          localStorage.removeItem('finsights_access_token');
          localStorage.removeItem('finsights_refresh_token');
          localStorage.removeItem('finsights_token_expiry');
          this.router.navigate(['/login']);
        }
        return throwError(() => error);
      })
    );
  }
}

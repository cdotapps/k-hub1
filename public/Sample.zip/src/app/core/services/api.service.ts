import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders, HttpParams, HttpErrorResponse } from '@angular/common/http';
import { Observable, throwError, BehaviorSubject } from 'rxjs';
import { catchError, map, tap } from 'rxjs/operators';
import { environment } from '../../../environments/environment';
import { 
  CatalogItem, 
  LoginRequest, 
  LoginResponse, 
  CatalogSearchParams, 
  CatalogListParams,
  HealthResponse,
  RootResponse,
  ApiResponse,
  HTTPValidationError
} from '../models/api.models';

@Injectable({
  providedIn: 'root'
})
export class ApiService {
  private readonly baseUrl = environment.apiUrl;
  private readonly apiVersion = environment.apiVersion;
  
  private tokenSubject = new BehaviorSubject<string | null>(null);
  public token$ = this.tokenSubject.asObservable();
  
  private isAuthenticatedSubject = new BehaviorSubject<boolean>(false);
  public isAuthenticated$ = this.isAuthenticatedSubject.asObservable();

  constructor(private http: HttpClient) {
    // Check for existing token on service initialization
    const token = localStorage.getItem(environment.auth.tokenKey);
    if (token) {
      this.tokenSubject.next(token);
      this.isAuthenticatedSubject.next(true);
    }
  }

  // ==================== UTILITY METHODS ====================

  private getApiUrl(endpoint: string): string {
    if (endpoint.startsWith('/v1/')) {
      return `${this.baseUrl}${endpoint}`;
    }
    if (endpoint.startsWith('/')) {
      return `${this.baseUrl}${endpoint}`;
    }
    return `${this.baseUrl}/${this.apiVersion}/${endpoint}`;
  }

  private getHeaders(): HttpHeaders {
    let headers = new HttpHeaders({
      'Content-Type': 'application/json'
    });

    const token = this.tokenSubject.value;
    if (token) {
      headers = headers.set('Authorization', `Bearer ${token}`);
    }

    return headers;
  }

  private getFormHeaders(): HttpHeaders {
    let headers = new HttpHeaders({
      'Content-Type': 'application/x-www-form-urlencoded'
    });

    const token = this.tokenSubject.value;
    if (token) {
      headers = headers.set('Authorization', `Bearer ${token}`);
    }

    return headers;
  }

  private handleError(error: HttpErrorResponse): Observable<never> {
    let errorMessage = 'An unknown error occurred';
    
    if (error.error instanceof ErrorEvent) {
      // Client-side error
      errorMessage = `Error: ${error.error.message}`;
    } else {
      // Server-side error
      if (error.status === 401) {
        this.logout();
        errorMessage = 'Unauthorized access. Please login again.';
      } else if (error.status === 422) {
        // Validation error
        const validationError = error.error as HTTPValidationError;
        errorMessage = validationError.detail.map(err => err.msg).join(', ');
      } else {
        errorMessage = `Error Code: ${error.status}\nMessage: ${error.message}`;
      }
    }

    console.error('API Error:', error);
    return throwError(() => new Error(errorMessage));
  }

  // ==================== AUTHENTICATION METHODS ====================

  login(credentials: LoginRequest): Observable<LoginResponse> {
    const body = new URLSearchParams();
    body.set('username', credentials.username);
    body.set('password', credentials.password);
    if (credentials.grant_type) body.set('grant_type', credentials.grant_type);
    if (credentials.scope) body.set('scope', credentials.scope);
    if (credentials.client_id) body.set('client_id', credentials.client_id);
    if (credentials.client_secret) body.set('client_secret', credentials.client_secret);

    return this.http.post<LoginResponse>(
      this.getApiUrl('/v1/login'),
      body.toString(),
      { headers: this.getFormHeaders() }
    ).pipe(
      tap(response => {
        if (response.access_token) {
          localStorage.setItem(environment.auth.tokenKey, response.access_token);
          this.tokenSubject.next(response.access_token);
          this.isAuthenticatedSubject.next(true);
          
          // Store token expiry if provided
          if (response.expires_in) {
            const expiryTime = new Date().getTime() + (response.expires_in * 1000);
            localStorage.setItem(environment.auth.tokenExpiryKey, expiryTime.toString());
          }
          
          // Store refresh token if provided
          if (response.refresh_token) {
            localStorage.setItem(environment.auth.refreshTokenKey, response.refresh_token);
          }
        }
      }),
      catchError(this.handleError.bind(this))
    );
  }

  logout(): void {
    localStorage.removeItem(environment.auth.tokenKey);
    localStorage.removeItem(environment.auth.refreshTokenKey);
    localStorage.removeItem(environment.auth.tokenExpiryKey);
    this.tokenSubject.next(null);
    this.isAuthenticatedSubject.next(false);
  }

  // Method for mock authentication in development
  setMockAuthentication(token: string): void {
    this.tokenSubject.next(token);
    this.isAuthenticatedSubject.next(true);
  }

  // ==================== HEALTH & ROOT METHODS ====================

  getRoot(): Observable<RootResponse> {
    return this.http.get<RootResponse>(this.getApiUrl('/'))
      .pipe(catchError(this.handleError.bind(this)));
  }

  getHealth(): Observable<HealthResponse> {
    return this.http.get<HealthResponse>(this.getApiUrl('/health'))
      .pipe(catchError(this.handleError.bind(this)));
  }

  // ==================== CATALOG METHODS ====================

  // List catalog items with optional type filter
  getCatalogItems(params?: CatalogListParams): Observable<CatalogItem[]> {
    let httpParams = new HttpParams();
    if (params?.type) {
      httpParams = httpParams.set('type', params.type);
    }

    return this.http.get<CatalogItem[]>(
      this.getApiUrl('/v1/catalog'),
      { 
        headers: this.getHeaders(),
        params: httpParams 
      }
    ).pipe(catchError(this.handleError.bind(this)));
  }

  // Create a new catalog item
  createCatalogItem(item: CatalogItem): Observable<CatalogItem> {
    return this.http.post<CatalogItem>(
      this.getApiUrl('/v1/catalog'),
      item,
      { headers: this.getHeaders() }
    ).pipe(catchError(this.handleError.bind(this)));
  }

  // Get a specific catalog item by ID
  getCatalogItem(itemId: string): Observable<CatalogItem> {
    return this.http.get<CatalogItem>(
      this.getApiUrl(`/v1/catalog/${itemId}`),
      { headers: this.getHeaders() }
    ).pipe(catchError(this.handleError.bind(this)));
  }

  // Update a catalog item
  updateCatalogItem(itemId: string, item: CatalogItem): Observable<CatalogItem> {
    return this.http.put<CatalogItem>(
      this.getApiUrl(`/v1/catalog/${itemId}`),
      item,
      { headers: this.getHeaders() }
    ).pipe(catchError(this.handleError.bind(this)));
  }

  // Delete a catalog item
  deleteCatalogItem(itemId: string): Observable<any> {
    return this.http.delete(
      this.getApiUrl(`/v1/catalog/${itemId}`),
      { headers: this.getHeaders() }
    ).pipe(catchError(this.handleError.bind(this)));
  }

  // Search catalog items with multiple filters
  searchCatalogItems(searchParams: CatalogSearchParams): Observable<CatalogItem[]> {
    let httpParams = new HttpParams();
    
    Object.keys(searchParams).forEach(key => {
      const value = searchParams[key as keyof CatalogSearchParams];
      if (value !== undefined && value !== null && value !== '') {
        httpParams = httpParams.set(key, value.toString());
      }
    });

    return this.http.get<CatalogItem[]>(
      this.getApiUrl('/v1/catalog/search'),
      { 
        headers: this.getHeaders(),
        params: httpParams 
      }
    ).pipe(catchError(this.handleError.bind(this)));
  }

  // Search catalog items by key (new API)
  searchCatalogItemsByKey(key: string): Observable<CatalogItem[]> {
    return this.http.get<CatalogItem[]>(
      this.getApiUrl('/v1/catalog/search/by-key'),
      {
        headers: this.getHeaders(),
        params: new HttpParams().set('key', key)
      }
    ).pipe(catchError(this.handleError.bind(this)));
  }

  // Stream agentic chat response with token and plain text response
  streamAgenticChat(key: string, question: string, token: string): Observable<string> {
    let headers = this.getHeaders();
    if (token) {
      headers = headers.set('Authorization', `Bearer ${token}`);
    }
    return this.http.post(
      this.getApiUrl('/v1/agentic-chat/stream'),
      { key, question },
      { headers, responseType: 'text' }
    ).pipe(catchError(this.handleError.bind(this)));
  }

  // ==================== CONVENIENCE METHODS ====================

  // Check if user is currently authenticated
  isAuthenticated(): boolean {
    return this.isAuthenticatedSubject.value;
  }

  // Get current token
  getToken(): string | null {
    return this.tokenSubject.value;
  }

  // Search catalog items by name (convenience method)
  searchByName(name: string): Observable<CatalogItem[]> {
    return this.searchCatalogItems({ name });
  }

  // Search catalog items by type (convenience method)
  searchByType(type: string): Observable<CatalogItem[]> {
    return this.searchCatalogItems({ type });
  }

  // Search catalog items by category (convenience method)
  searchByCategory(category: string): Observable<CatalogItem[]> {
    return this.searchCatalogItems({ category });
  }

  // Get catalog items by status (convenience method)
  getItemsByStatus(status: string): Observable<CatalogItem[]> {
    return this.searchCatalogItems({ status });
  }

  // Get catalog items by priority (convenience method)
  getItemsByPriority(priority: number): Observable<CatalogItem[]> {
    return this.searchCatalogItems({ priority });
  }

  // Get catalog items created by specific user (convenience method)
  getItemsByCreator(createdBy: string): Observable<CatalogItem[]> {
    return this.searchCatalogItems({ created_by: createdBy });
  }

  // ==================== TOKEN MANAGEMENT METHODS ====================

  // Check if token is expired
  isTokenExpired(): boolean {
    const expiryTime = localStorage.getItem(environment.auth.tokenExpiryKey);
    if (!expiryTime) return false;
    
    const expiry = parseInt(expiryTime, 10);
    return new Date().getTime() > expiry;
  }

  // Get token expiry time
  getTokenExpiry(): Date | null {
    const expiryTime = localStorage.getItem(environment.auth.tokenExpiryKey);
    if (!expiryTime) return null;
    
    return new Date(parseInt(expiryTime, 10));
  }

  // Get refresh token
  getRefreshToken(): string | null {
    return localStorage.getItem(environment.auth.refreshTokenKey);
  }

  // Get environment info
  getEnvironmentInfo(): any {
    return {
      production: environment.production,
      apiUrl: environment.apiUrl,
      apiVersion: environment.apiVersion,
      appName: environment.appName,
      appVersion: environment.appVersion,
      features: environment.features
    };
  }

  // Log environment info (for debugging)
  logEnvironmentInfo(): void {
    if (environment.features.enableLogging) {
      console.log('Environment Info:', this.getEnvironmentInfo());
    }
  }
}

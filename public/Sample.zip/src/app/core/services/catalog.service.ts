import { Injectable } from '@angular/core';
import { Observable, BehaviorSubject } from 'rxjs';
import { tap, map } from 'rxjs/operators';
import { ApiService } from './api.service';
import { CatalogItem, CatalogSearchParams } from '../models/api.models';

@Injectable({
  providedIn: 'root'
})
export class CatalogService {
  private catalogItemsSubject = new BehaviorSubject<CatalogItem[]>([]);
  public catalogItems$ = this.catalogItemsSubject.asObservable();

  private selectedItemSubject = new BehaviorSubject<CatalogItem | null>(null);
  public selectedItem$ = this.selectedItemSubject.asObservable();

  private loadingSubject = new BehaviorSubject<boolean>(false);
  public loading$ = this.loadingSubject.asObservable();

  constructor(private apiService: ApiService) {}

  // ==================== CATALOG OPERATIONS ====================

  // Load all catalog items
  loadCatalogItems(type?: string): Observable<CatalogItem[]> {
    this.loadingSubject.next(true);
    
    return this.apiService.getCatalogItems(type ? { type } : undefined).pipe(
      tap(items => {
        this.catalogItemsSubject.next(items);
        this.loadingSubject.next(false);
      })
    );
  }

  // Create a new catalog item
  createItem(item: CatalogItem): Observable<CatalogItem> {
    this.loadingSubject.next(true);
    
    return this.apiService.createCatalogItem(item).pipe(
      tap(newItem => {
        const currentItems = this.catalogItemsSubject.value;
        this.catalogItemsSubject.next([...currentItems, newItem]);
        this.loadingSubject.next(false);
      })
    );
  }

  // Get a specific catalog item
  getItem(itemId: string): Observable<CatalogItem> {
    this.loadingSubject.next(true);
    
    return this.apiService.getCatalogItem(itemId).pipe(
      tap(item => {
        this.selectedItemSubject.next(item);
        this.loadingSubject.next(false);
      })
    );
  }

  // Update an existing catalog item
  updateItem(itemId: string, item: CatalogItem): Observable<CatalogItem> {
    this.loadingSubject.next(true);
    
    return this.apiService.updateCatalogItem(itemId, item).pipe(
      tap(updatedItem => {
        const currentItems = this.catalogItemsSubject.value;
        const index = currentItems.findIndex(i => i.id === itemId);
        if (index !== -1) {
          currentItems[index] = updatedItem;
          this.catalogItemsSubject.next([...currentItems]);
        }
        this.selectedItemSubject.next(updatedItem);
        this.loadingSubject.next(false);
      })
    );
  }

  // Delete a catalog item
  deleteItem(itemId: string): Observable<any> {
    this.loadingSubject.next(true);
    
    return this.apiService.deleteCatalogItem(itemId).pipe(
      tap(() => {
        const currentItems = this.catalogItemsSubject.value;
        const filteredItems = currentItems.filter(item => item.id !== itemId);
        this.catalogItemsSubject.next(filteredItems);
        
        // Clear selected item if it was deleted
        if (this.selectedItemSubject.value?.id === itemId) {
          this.selectedItemSubject.next(null);
        }
        
        this.loadingSubject.next(false);
      })
    );
  }

  // Search catalog items
  searchItems(searchParams: CatalogSearchParams): Observable<CatalogItem[]> {
    this.loadingSubject.next(true);
    
    return this.apiService.searchCatalogItems(searchParams).pipe(
      tap(items => {
        this.catalogItemsSubject.next(items);
        this.loadingSubject.next(false);
      })
    );
  }

  // Get catalog items by key (new API)
  getItemsByKey(key: string): Observable<CatalogItem[]> {
    this.loadingSubject.next(true);
    return this.apiService.searchCatalogItemsByKey(key).pipe(
      tap(items => {
        this.catalogItemsSubject.next(items);
        this.loadingSubject.next(false);
      })
    );
  }

  // Proxy to ApiService for agentic chat streaming
  streamAgenticChat(key: string, question: string, token: string): Observable<any> {
    return this.apiService.streamAgenticChat(key, question, token);
  }

  // ==================== CONVENIENCE METHODS ====================

  // Get items by type
  getItemsByType(type: string): Observable<CatalogItem[]> {
    return this.searchItems({ type });
  }

  // Get items by category
  getItemsByCategory(category: string): Observable<CatalogItem[]> {
    return this.searchItems({ category });
  }

  // Get items by status
  getItemsByStatus(status: string): Observable<CatalogItem[]> {
    return this.searchItems({ status });
  }

  // Get items by priority
  getItemsByPriority(priority: number): Observable<CatalogItem[]> {
    return this.searchItems({ priority });
  }

  // Search items by name
  searchByName(name: string): Observable<CatalogItem[]> {
    return this.searchItems({ name });
  }

  // Get items created by specific user
  getItemsByCreator(createdBy: string): Observable<CatalogItem[]> {
    return this.searchItems({ created_by: createdBy });
  }

  // ==================== STATE MANAGEMENT ====================

  // Set selected item
  setSelectedItem(item: CatalogItem | null): void {
    this.selectedItemSubject.next(item);
  }

  // Get current catalog items
  getCurrentItems(): CatalogItem[] {
    return this.catalogItemsSubject.value;
  }

  // Get selected item
  getSelectedItem(): CatalogItem | null {
    return this.selectedItemSubject.value;
  }

  // Clear all data
  clearData(): void {
    this.catalogItemsSubject.next([]);
    this.selectedItemSubject.next(null);
    this.loadingSubject.next(false);
  }

  // ==================== FILTERING & SORTING ====================

  // Filter items by multiple criteria
  filterItems(filters: Partial<CatalogItem>): Observable<CatalogItem[]> {
    return this.catalogItems$.pipe(
      map(items => items.filter(item => {
        return Object.keys(filters).every(key => {
          const filterValue = filters[key as keyof CatalogItem];
          const itemValue = item[key as keyof CatalogItem];
          
          if (filterValue === undefined || filterValue === null || filterValue === '') {
            return true;
          }
          
          if (typeof filterValue === 'string' && typeof itemValue === 'string') {
            return itemValue.toLowerCase().includes(filterValue.toLowerCase());
          }
          
          return itemValue === filterValue;
        });
      }))
    );
  }

  // Sort items by field
  sortItems(field: keyof CatalogItem, direction: 'asc' | 'desc' = 'asc'): Observable<CatalogItem[]> {
    return this.catalogItems$.pipe(
      map(items => [...items].sort((a, b) => {
        const aValue = a[field];
        const bValue = b[field];
        
        if (aValue === undefined || aValue === null) return 1;
        if (bValue === undefined || bValue === null) return -1;
        
        if (typeof aValue === 'string' && typeof bValue === 'string') {
          return direction === 'asc' 
            ? aValue.localeCompare(bValue)
            : bValue.localeCompare(aValue);
        }
        
        if (typeof aValue === 'number' && typeof bValue === 'number') {
          return direction === 'asc' ? aValue - bValue : bValue - aValue;
        }
        
        return 0;
      }))
    );
  }

  // Get items with AI content
  getItemsWithAI(): Observable<CatalogItem[]> {
    return this.catalogItems$.pipe(
      map(items => items.filter(item => 
        item.ai_content || item.ai_summary
      ))
    );
  }

  // Get public items
  getPublicItems(): Observable<CatalogItem[]> {
    return this.catalogItems$.pipe(
      map(items => items.filter(item => !item.private))
    );
  }

  // Get private items
  getPrivateItems(): Observable<CatalogItem[]> {
    return this.catalogItems$.pipe(
      map(items => items.filter(item => item.private))
    );
  }
}

import { Injectable } from '@angular/core';
import { environment } from '../../../environments/environment';

@Injectable({
  providedIn: 'root'
})
export class ConfigService {

  constructor() {
    this.logEnvironmentInfo();
  }

  // ==================== ENVIRONMENT GETTERS ====================

  get isProduction(): boolean {
    return environment.production;
  }

  get isDevelopment(): boolean {
    return !environment.production;
  }

  get apiUrl(): string {
    return environment.apiUrl;
  }

  get apiVersion(): string {
    return environment.apiVersion;
  }

  get appName(): string {
    return environment.appName;
  }

  get appVersion(): string {
    return environment.appVersion;
  }

  get fullApiUrl(): string {
    return `${environment.apiUrl}/${environment.apiVersion}`;
  }

  // ==================== FEATURE FLAGS ====================

  get isLoggingEnabled(): boolean {
    return environment.features.enableLogging;
  }

  get isAnalyticsEnabled(): boolean {
    return environment.features.enableAnalytics;
  }

  get isDebugModeEnabled(): boolean {
    return environment.features.enableDebugMode;
  }

  // ==================== AUTH CONFIGURATION ====================

  get tokenKey(): string {
    return environment.auth.tokenKey;
  }

  get refreshTokenKey(): string {
    return environment.auth.refreshTokenKey;
  }

  get tokenExpiryKey(): string {
    return environment.auth.tokenExpiryKey;
  }

  // ==================== API CONFIGURATION ====================

  get apiTimeout(): number {
    return environment.api.timeout;
  }

  get apiRetryAttempts(): number {
    return environment.api.retryAttempts;
  }

  get apiRetryDelay(): number {
    return environment.api.retryDelay;
  }

  // ==================== UTILITY METHODS ====================

  // Get complete environment configuration
  getEnvironmentConfig(): any {
    return {
      production: environment.production,
      apiUrl: environment.apiUrl,
      apiVersion: environment.apiVersion,
      appName: environment.appName,
      appVersion: environment.appVersion,
      features: environment.features,
      auth: environment.auth,
      api: environment.api
    };
  }

  // Log environment information
  logEnvironmentInfo(): void {
    if (this.isLoggingEnabled) {
      console.group(`🚀 ${this.appName} v${this.appVersion}`);
      console.log('Environment:', this.isProduction ? 'Production' : 'Development');
      console.log('API URL:', this.apiUrl);
      console.log('API Version:', this.apiVersion);
      console.log('Features:', environment.features);
      console.groupEnd();
    }
  }

  // Check if feature is enabled
  isFeatureEnabled(featureName: keyof typeof environment.features): boolean {
    return environment.features[featureName] || false;
  }

  // Get API endpoint URL
  getApiEndpoint(endpoint: string): string {
    // Remove leading slash if present
    const cleanEndpoint = endpoint.startsWith('/') ? endpoint.slice(1) : endpoint;
    
    // If endpoint already includes version, use base URL
    if (cleanEndpoint.startsWith('v1/') || cleanEndpoint.startsWith(`${this.apiVersion}/`)) {
      return `${this.apiUrl}/${cleanEndpoint}`;
    }
    
    // Otherwise, add version prefix
    return `${this.apiUrl}/${this.apiVersion}/${cleanEndpoint}`;
  }

  // Get health check URL
  getHealthCheckUrl(): string {
    return `${this.apiUrl}/health`;
  }

  // Get login URL
  getLoginUrl(): string {
    return `${this.apiUrl}/${this.apiVersion}/login`;
  }

  // Get catalog base URL
  getCatalogBaseUrl(): string {
    return `${this.apiUrl}/${this.apiVersion}/catalog`;
  }

  // Validate environment configuration
  validateEnvironment(): { isValid: boolean; errors: string[] } {
    const errors: string[] = [];

    if (!environment.apiUrl) {
      errors.push('API URL is not configured');
    }

    if (!environment.apiVersion) {
      errors.push('API version is not configured');
    }

    if (!environment.appName) {
      errors.push('App name is not configured');
    }

    if (!environment.auth.tokenKey) {
      errors.push('Token key is not configured');
    }

    // Validate API URL format
    try {
      new URL(environment.apiUrl);
    } catch {
      errors.push('API URL is not a valid URL');
    }

    return {
      isValid: errors.length === 0,
      errors
    };
  }

  // Get environment-specific storage keys
  getStorageKey(key: string): string {
    const prefix = this.isProduction ? 'finsights' : `finsights_${this.isProduction ? 'prod' : 'dev'}`;
    return `${prefix}_${key}`;
  }
}

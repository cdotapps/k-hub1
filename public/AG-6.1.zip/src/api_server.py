#!/usr/bin/env python3
"""
News Agent API - FastAPI-based REST API for web content scraping and catalog creation
Provides endpoints to scrape URLs and create catalog entries with authentication
"""

import sys
import os
import logging
from datetime import datetime
from typing import Optional, Dict, Any
from urllib.parse import urlparse

# Add the src directory to Python path
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

# Set up logging
logging.basicConfig(level=logging.DEBUG, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

from fastapi import FastAPI, HTTPException, Depends, status, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from pydantic import BaseModel, HttpUrl
import uvicorn

from scraper.web_scraper import WebScraper
from ai_agent.content_analyzer import ContentAnalyzer
from ai_agent.summarizer import Summarizer
from models.catalog import Catalog, CatalogData
from utils.json_handler import save_to_json
from config.settings import OUTPUT_DIR
from services.catalog_service import post_catalog_item, validate_catalog_service_connection, prepare_catalog_data_for_api

# FastAPI app instance
app = FastAPI(
    title="News Agent API",
    description="API for web content scraping and catalog creation",
    version="1.0.0"
)

# Add CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # Allows all origins
    allow_credentials=True,
    allow_methods=["*"],  # Allows all methods including OPTIONS
    allow_headers=["*"],  # Allows all headers
)

# Security scheme
security = HTTPBearer(auto_error=False)

# Configuration
API_KEY = "news-agent-api-key-2025"  # You can change this to your preferred key
HOST = "0.0.0.0"
PORT = 8001

# Request/Response models
class ScrapeRequest(BaseModel):
    url: HttpUrl
    
class ScrapeResponse(BaseModel):
    success: bool
    message: str
    catalog_id: Optional[str] = None
    local_file: Optional[str] = None
    title: Optional[str] = None
    author: Optional[str] = None
    category: Optional[str] = None
    summary: Optional[str] = None
    content: Optional[str] = None  # Add full content
    url: Optional[str] = None      # Add source URL
    image: Optional[str] = None    # Add image URL
    tags: Optional[list] = None    # Add tags
    source: Optional[str] = None   # Add source
    key: Optional[str] = None      # Add catalog key
    created_date: Optional[str] = None  # Add creation date
    error: Optional[str] = None

class HealthResponse(BaseModel):
    status: str
    timestamp: str
    version: str

# Dependency for API key authentication
def verify_api_key(request: Request, credentials: HTTPAuthorizationCredentials = Depends(security)):
    logger.debug(f"=== AUTH DEBUG ===")
    logger.debug(f"Request headers: {dict(request.headers)}")
    logger.debug(f"Credentials object: {credentials}")
    logger.debug(f"Expected API key: {API_KEY}")
    
    if credentials is None:
        logger.error("No authorization header provided")
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Authorization header missing",
            headers={"WWW-Authenticate": "Bearer"},
        )
    
    logger.debug(f"Received credentials: {credentials.credentials}")
    
    # Check if it's the simple API key
    if credentials.credentials == API_KEY:
        logger.debug("Authentication successful with API key")
        return credentials.credentials
    
    # Accept any JWT token (starts with 'eyJ') without validation
    if credentials.credentials.startswith('eyJ'):
        logger.debug("JWT token received - accepting without validation")
        return credentials.credentials
    
    # Accept any other Bearer token for pass-through authentication
    logger.debug("Bearer token received - accepting for pass-through")
    return credentials.credentials

# News Agent Service Class
class NewsAgentService:
    def __init__(self):
        self.scraper = WebScraper()
        self.analyzer = ContentAnalyzer()
        self.summarizer = Summarizer()
        self.access_token = None

    def validate_url(self, url: str) -> bool:
        """Validate if the provided URL is valid"""
        try:
            result = urlparse(str(url))
            return all([result.scheme, result.netloc])
        except:
            return False

    def process_url(self, url: str, auth_token: str = None) -> Dict[str, Any]:
        """Process a single URL and return the result"""
        try:
            logger.info(f"Processing URL: {url}")
            
            # Validate URL
            if not self.validate_url(url):
                raise ValueError(f"Invalid URL: {url}")

            # Scrape content
            logger.debug("Starting web scraping...")
            scraped_data = self.scraper.scrape(str(url))
            logger.debug(f"Scraped data keys: {list(scraped_data.keys()) if scraped_data else 'None'}")
            
            # Analyze content
            logger.debug("Starting content analysis...")
            analyzed_data = self.analyzer.analyze(scraped_data)
            logger.debug(f"Analyzed data keys: {list(analyzed_data.keys()) if analyzed_data else 'None'}")
            
            # Generate summary
            logger.debug("Starting summarization...")
            summary = self.summarizer.summarize(analyzed_data['content'])
            analyzed_data['summary'] = summary
            logger.debug(f"Summary length: {len(summary) if summary else 0}")
            
            # Create catalog entry
            logger.debug("Creating catalog entry...")
            catalog_data = CatalogData(**analyzed_data)
            catalog_entry = Catalog(
                key=analyzed_data['key'],
                obj_in=catalog_data,
                child_ids_data=[]
            )
            
            # Save locally (always do this regardless of catalog service status)
            logger.debug("Saving locally...")
            timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
            filename = os.path.join(OUTPUT_DIR, f"catalog_output_{timestamp}.json")
            save_to_json(catalog_entry, filename)
            logger.debug(f"Saved to: {filename}")
            
            # Try to post to catalog service (but don't fail if it doesn't work)
            logger.debug("Attempting to post to catalog service...")
            catalog_id = self.post_to_catalog_service(catalog_entry, auth_token)
            
            if catalog_id:
                logger.info(f"Successfully posted to catalog service with ID: {catalog_id}")
            else:
                logger.warning("Failed to post to catalog service, but processing completed successfully")
            
            return {
                "success": True,
                "catalog_entry": catalog_entry,
                "local_file": filename,
                "catalog_id": catalog_id,
                "warning": "Catalog service posting failed - check authentication" if not catalog_id else None
            }
            
        except Exception as e:
            logger.error(f"Error processing URL: {str(e)}", exc_info=True)
            return {
                "success": False,
                "error": str(e)
            }

    def post_to_catalog_service(self, catalog_entry: Catalog, auth_token: str = None) -> Optional[str]:
        """Post catalog entry to the catalog service API"""
        try:
            logger.debug("=== CATALOG SERVICE DEBUG ===")
            logger.debug(f"Received auth token: {auth_token}")
            
            # Check if catalog service is available
            logger.debug("Checking catalog service connection...")
            if not validate_catalog_service_connection():
                error_msg = "Catalog service not available at http://localhost:8000"
                logger.error(error_msg)
                raise Exception(error_msg)
            
            logger.debug("Catalog service is available")
            
            # Prepare and post data with the provided token
            logger.debug("Preparing catalog data...")
            catalog_data = catalog_entry.to_dict()
            api_data = prepare_catalog_data_for_api(catalog_data)
            logger.debug(f"API data keys: {list(api_data.keys()) if api_data else 'None'}")
            
            # Post with the provided token (JWT or API key)
            logger.debug("Posting to catalog service...")
            response = post_catalog_item(api_data, token=auth_token)
            logger.debug(f"Catalog service response: {response}")
            
            if response and "error" not in response:
                if isinstance(response, dict) and "id" in response:
                    logger.debug(f"Success: Got catalog ID {response['id']}")
                    return response["id"]
                logger.debug("Success: No specific ID returned")
                return "success"
            else:
                error_msg = f"Catalog service authentication failed. Check if the JWT token from your frontend is valid."
                logger.error(error_msg)
                logger.error(f"Response details: {response}")
                # Don't raise exception - just log the error and continue
                return None
                
        except Exception as e:
            logger.error(f"Error posting to catalog service: {str(e)}", exc_info=True)
            # Don't raise exception - just log and continue
            return None

# Initialize service
news_service = NewsAgentService()

# API Endpoints
@app.get("/", response_model=HealthResponse)
async def root():
    """Root endpoint - health check"""
    return HealthResponse(
        status="healthy",
        timestamp=datetime.now().isoformat(),
        version="1.0.0"
    )

@app.get("/health", response_model=HealthResponse)
async def health_check():
    """Health check endpoint"""
    return HealthResponse(
        status="healthy",
        timestamp=datetime.now().isoformat(),
        version="1.0.0"
    )

@app.post("/scrape", response_model=ScrapeResponse)
async def scrape_url(request: ScrapeRequest, auth_token: str = Depends(verify_api_key)):
    """
    Scrape a URL and create a catalog entry
    
    Requires:
    - Authorization: Bearer {API_KEY}
    - Request body with URL to scrape
    
    Returns:
    - Success/failure status
    - Catalog information if successful
    - Error details if failed
    """
    try:
        logger.info(f"=== SCRAPE REQUEST ===")
        logger.info(f"URL: {request.url}")
        logger.info(f"Using auth token: {auth_token[:20]}..." if auth_token else "No token")
        
        result = news_service.process_url(str(request.url), auth_token)
        
        if result["success"]:
            catalog_entry = result["catalog_entry"]
            response = ScrapeResponse(
                success=True,
                message="URL processed successfully" + (f" - {result.get('warning', '')}" if result.get('warning') else ""),
                catalog_id=result.get("catalog_id"),
                local_file=result.get("local_file"),
                title=catalog_entry.title,
                author=catalog_entry.author,
                category=catalog_entry.category,
                summary=catalog_entry.summary[:200] + "..." if len(catalog_entry.summary) > 200 else catalog_entry.summary,
                content=catalog_entry.content,
                url=catalog_entry.url,
                image=catalog_entry.image,
                tags=catalog_entry.tags,
                source=catalog_entry.source,
                key=catalog_entry.key,
                created_date=catalog_entry.created_date
            )
            logger.info("Scrape request completed successfully")
            return response
        else:
            response = ScrapeResponse(
                success=False,
                message="Failed to process URL",
                error=result.get("error")
            )
            logger.error(f"Scrape request failed: {result.get('error')}")
            return response
            
    except Exception as e:
        logger.error(f"Scrape endpoint error: {str(e)}", exc_info=True)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Internal server error: {str(e)}"
        )

@app.get("/status")
async def get_status(api_key: str = Depends(verify_api_key)):
    """
    Get service status and configuration
    
    Requires:
    - Authorization: Bearer {API_KEY}
    """
    return {
        "status": "running",
        "timestamp": datetime.now().isoformat(),
        "catalog_service_available": validate_catalog_service_connection(),
        "output_directory": OUTPUT_DIR,
        "version": "1.0.0"
    }

if __name__ == "__main__":
    print("=== News Agent API Server ===")
    print(f"Starting server on {HOST}:{PORT}")
    print(f"API Key: {API_KEY}")
    print(f"Docs available at: http://{HOST}:{PORT}/docs")
    print("=" * 50)
    
    uvicorn.run(
        "api_server:app",
        host=HOST,
        port=PORT,
        reload=True,
        log_level="debug"
    )
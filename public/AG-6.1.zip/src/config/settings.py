# Configuration settings for the News Agent

import os

# API Configuration
API_KEY = "your_api_key_here"
TIMEOUT = 10  # seconds
BASE_URL = "https://example.com/api"
MAX_RETRIES = 3

# User Agent for web scraping
USER_AGENT = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36"

# Output Configuration
OUTPUT_DIR = "output"
OUTPUT_FILE = os.path.join(OUTPUT_DIR, "catalog_output.json")

# Content Analysis Settings
MAX_SUMMARY_SENTENCES = 3
MAX_KEYWORDS = 10
MAX_TAGS = 10

# Scraping Settings
REQUEST_TIMEOUT = 10
MAX_CONTENT_LENGTH = 1000000  # 1MB limit

# Default Catalog Values
DEFAULT_STATUS = "active"
DEFAULT_PRIVATE = True
DEFAULT_DISPLAY = True
import re
from typing import List, Dict
from bs4 import BeautifulSoup

class Summarizer:
    def __init__(self):
        pass

    def summarize(self, content: str, max_sentences: int = 3) -> str:
        """Generate a summary of the content using extractive summarization with key points"""
        if not content or len(content.strip()) < 50:
            return "Content too short to summarize."
        
        # Extract plain text from HTML content
        plain_text = self._extract_text_from_html(content)
        
        if len(plain_text.strip()) < 50:
            return "Content too short to summarize."
        
        # Clean and preprocess the content
        cleaned_content = self._clean_content(plain_text)
        
        # Split into sentences
        sentences = self._split_into_sentences(cleaned_content)
        
        if len(sentences) <= max_sentences:
            return self._create_summary_from_sentences(sentences)
        
        # Score sentences based on various factors
        sentence_scores = self._score_sentences(sentences)
        
        # Select top sentences for summary
        top_sentences = self._select_top_sentences(sentences, sentence_scores, max_sentences)
        
        # Create a coherent summary with key points
        summary = self._create_summary_from_sentences(top_sentences)
        
        return summary

    def _extract_text_from_html(self, html_content: str) -> str:
        """Extract plain text from HTML content while preserving structure"""
        soup = BeautifulSoup(html_content, 'html.parser')
        
        # Remove any remaining unwanted elements
        for element in soup(['script', 'style', 'nav', 'header', 'footer', 'aside']):
            element.decompose()
        
        # Get text with some structure preservation
        text_parts = []
        
        for element in soup.find_all(['p', 'h1', 'h2', 'h3', 'h4', 'h5', 'h6', 'blockquote', 'li']):
            text = element.get_text().strip()
            if text and len(text) > 15:  # Filter out very short fragments
                text_parts.append(text)
        
        # If no structured content found, get all text
        if not text_parts:
            text_parts = [soup.get_text()]
        
        return ' '.join(text_parts)

    def _clean_content(self, content: str) -> str:
        """Clean and preprocess the content"""
        # Remove extra whitespace and normalize
        content = re.sub(r'\s+', ' ', content)
        
        # Remove Wikipedia-specific noise patterns
        content = re.sub(r'Archived from the original on.*?(?=\.|$)', '', content, flags=re.IGNORECASE)
        content = re.sub(r'Retrieved .*?(?=\.|$)', '', content, flags=re.IGNORECASE)
        content = re.sub(r'Original archived.*?(?=\.|$)', '', content, flags=re.IGNORECASE)
        content = re.sub(r'Wayback Machine.*?(?=\.|$)', '', content, flags=re.IGNORECASE)
        content = re.sub(r'CS1 maint:.*?(?=\.|$)', '', content, flags=re.IGNORECASE)
        content = re.sub(r'ISSN \d+-\d+.*?(?=\.|$)', '', content, flags=re.IGNORECASE)
        content = re.sub(r'doi:.*?(?=\s|$)', '', content, flags=re.IGNORECASE)
        content = re.sub(r'PMID.*?(?=\s|$)', '', content, flags=re.IGNORECASE)
        content = re.sub(r'S2CID.*?(?=\s|$)', '', content, flags=re.IGNORECASE)
        content = re.sub(r'Bibcode:.*?(?=\s|$)', '', content, flags=re.IGNORECASE)
        
        # Remove common noise patterns
        content = re.sub(r'Video Ad Feedback.*?(?=\.|$)', '', content, flags=re.IGNORECASE)
        content = re.sub(r'Now playing.*?(?=\.|$)', '', content, flags=re.IGNORECASE)
        content = re.sub(r'Click here.*?(?=\.|$)', '', content, flags=re.IGNORECASE)
        content = re.sub(r'Read more.*?(?=\.|$)', '', content, flags=re.IGNORECASE)
        content = re.sub(r'Jump to navigation.*?(?=\.|$)', '', content, flags=re.IGNORECASE)
        content = re.sub(r'Jump to search.*?(?=\.|$)', '', content, flags=re.IGNORECASE)
        
        # Remove citation markers like [1], [2], etc.
        content = re.sub(r'\[\d+\]', '', content)
        content = re.sub(r'\[citation needed\]', '', content, flags=re.IGNORECASE)
        content = re.sub(r'\[edit\]', '', content, flags=re.IGNORECASE)
        
        # Remove special characters that might interfere with sentence splitting
        content = re.sub(r'[^\w\s.,!?;:()"-]', '', content)
        
        return content.strip()

    def _split_into_sentences(self, content: str) -> List[str]:
        """Split content into sentences with better sentence boundary detection"""
        # More sophisticated sentence splitting
        sentences = re.split(r'(?<=[.!?])\s+(?=[A-Z])', content)
        
        # Clean up sentences and filter
        cleaned_sentences = []
        for sentence in sentences:
            sentence = sentence.strip()
            if (sentence and 
                len(sentence) > 20 and  # Minimum length
                len(sentence) < 500 and  # Maximum length
                sentence[0].isupper() and  # Starts with capital
                sentence[-1] in '.!?'):  # Ends with punctuation
                cleaned_sentences.append(sentence)
        
        return cleaned_sentences

    def _score_sentences(self, sentences: List[str]) -> Dict[int, float]:
        """Score sentences based on various factors for news articles"""
        scores = {}
        
        # Calculate word frequency
        word_freq = self._calculate_word_frequency(sentences)
        
        # Key phrases that indicate importance in news articles
        important_phrases = [
            'according to', 'officials said', 'sources told', 'reported', 
            'confirmed', 'announced', 'revealed', 'investigation', 'breaking',
            'first time', 'unprecedented', 'significant', 'major', 'critical'
        ]
        
        # Action/event indicators
        action_words = [
            'killed', 'injured', 'arrested', 'charged', 'sentenced', 'died',
            'elected', 'appointed', 'resigned', 'fired', 'hired', 'launched',
            'announced', 'decided', 'voted', 'approved', 'rejected', 'banned'
        ]
        
        for i, sentence in enumerate(sentences):
            score = 0.0
            words = sentence.lower().split()
            
            # Base score from word frequency
            for word in words:
                if word in word_freq:
                    score += word_freq[word]
            
            # Normalize by sentence length
            if len(words) > 0:
                score = score / len(words)
            
            # Boost for important phrases
            sentence_lower = sentence.lower()
            for phrase in important_phrases:
                if phrase in sentence_lower:
                    score *= 1.5
            
            # Boost for action words
            for action in action_words:
                if action in sentence_lower:
                    score *= 1.3
            
            # Boost for numbers and statistics
            if re.search(r'\d+', sentence):
                score *= 1.2
            
            # Boost for proper nouns (names, places, organizations)
            proper_nouns = [w for w in words if w[0].isupper()]
            if proper_nouns:
                score *= (1 + len(proper_nouns) * 0.1)
            
            # Boost for quotes
            if '"' in sentence or "'" in sentence:
                score *= 1.2
            
            # Penalize very short or very long sentences
            sentence_length = len(words)
            if sentence_length < 8:
                score *= 0.5
            elif sentence_length > 40:
                score *= 0.7
            
            # Boost sentences near the beginning (lead paragraphs are important)
            if i < len(sentences) * 0.2:
                score *= 1.5
            elif i < len(sentences) * 0.4:
                score *= 1.2
            
            scores[i] = score
        
        return scores

    def _calculate_word_frequency(self, sentences: List[str]) -> Dict[str, float]:
        """Calculate word frequency with better filtering for news content"""
        word_count = {}
        total_words = 0
        
        # Enhanced stop words list
        stop_words = {
            'the', 'a', 'an', 'and', 'or', 'but', 'in', 'on', 'at', 'to', 'for', 
            'of', 'with', 'by', 'is', 'are', 'was', 'were', 'be', 'been', 'have', 
            'has', 'had', 'do', 'does', 'did', 'will', 'would', 'could', 'should',
            'this', 'that', 'these', 'those', 'i', 'you', 'he', 'she', 'it', 'we', 
            'they', 'me', 'him', 'her', 'us', 'them', 'my', 'your', 'his', 'her',
            'its', 'our', 'their', 'can', 'may', 'might', 'must', 'shall', 'up',
            'down', 'out', 'off', 'over', 'under', 'again', 'further', 'then',
            'once', 'here', 'there', 'when', 'where', 'why', 'how', 'all', 'any',
            'both', 'each', 'few', 'more', 'most', 'other', 'some', 'such', 'no',
            'nor', 'not', 'only', 'own', 'same', 'so', 'than', 'too', 'very', 's',
            't', 'just', 'now', 'said', 'get', 'go', 'like', 'also', 'back', 'know'
        }
        
        for sentence in sentences:
            words = sentence.lower().split()
            for word in words:
                # Remove punctuation and clean
                word = re.sub(r'[^\w]', '', word)
                if (word and 
                    word not in stop_words and 
                    len(word) > 2 and 
                    not word.isdigit()):
                    word_count[word] = word_count.get(word, 0) + 1
                    total_words += 1
        
        # Calculate frequency
        word_freq = {}
        for word, count in word_count.items():
            word_freq[word] = count / total_words if total_words > 0 else 0
        
        return word_freq

    def _select_top_sentences(self, sentences: List[str], scores: Dict[int, float], max_sentences: int) -> List[str]:
        """Select top sentences while maintaining chronological order and ensuring diversity"""
        # Sort by score
        sorted_indices = sorted(scores.keys(), key=lambda x: scores[x], reverse=True)
        
        # Select diverse sentences (avoid too much similarity)
        selected_indices = []
        selected_sentences = []
        
        for idx in sorted_indices:
            if len(selected_indices) >= max_sentences:
                break
            
            sentence = sentences[idx]
            
            # Check for diversity (avoid very similar sentences)
            if not selected_sentences or not self._is_too_similar(sentence, selected_sentences):
                selected_indices.append(idx)
                selected_sentences.append(sentence)
        
        # Sort selected indices to maintain original order
        selected_indices.sort()
        
        return [sentences[i] for i in selected_indices]

    def _is_too_similar(self, sentence: str, existing_sentences: List[str]) -> bool:
        """Check if a sentence is too similar to existing selected sentences"""
        sentence_words = set(sentence.lower().split())
        
        for existing in existing_sentences:
            existing_words = set(existing.lower().split())
            
            # Calculate Jaccard similarity
            intersection = sentence_words.intersection(existing_words)
            union = sentence_words.union(existing_words)
            
            if len(union) > 0:
                similarity = len(intersection) / len(union)
                if similarity > 0.5:  # Too similar
                    return True
        
        return False

    def _create_summary_from_sentences(self, sentences: List[str]) -> str:
        """Create a coherent summary from selected sentences"""
        if not sentences:
            return "No key points could be extracted from the content."
        
        # Join sentences with proper spacing
        summary = ' '.join(sentences)
        
        # Clean up the summary
        summary = re.sub(r'\s+', ' ', summary)
        summary = summary.strip()
        
        return summary

    def extract_key_points(self, content: str, max_points: int = 5) -> List[str]:
        """Extract key bullet points from the content"""
        plain_text = self._extract_text_from_html(content)
        sentences = self._split_into_sentences(self._clean_content(plain_text))
        
        if not sentences:
            return []
        
        sentence_scores = self._score_sentences(sentences)
        top_sentences = self._select_top_sentences(sentences, sentence_scores, max_points)
        
        # Format as bullet points
        key_points = []
        for sentence in top_sentences:
            # Shorten long sentences for bullet points
            if len(sentence) > 100:
                sentence = sentence[:97] + "..."
            key_points.append(sentence)
        
        return key_points
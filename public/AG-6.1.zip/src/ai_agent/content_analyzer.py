import re
from typing import Dict, List, Any
from datetime import datetime

class ContentAnalyzer:
    def __init__(self):
        pass

    def analyze(self, scraped_data: Dict) -> Dict[str, Any]:
        """Analyze scraped content and return structured data for catalog creation"""
        analyzed_data = {
            'key': self._generate_key(scraped_data.get('title', '')),
            'title': scraped_data.get('title', ''),
            'description': scraped_data.get('description', ''),
            'content': scraped_data.get('content', ''),
            'url': scraped_data.get('url', ''),
            'image': scraped_data.get('image', ''),
            'imageUrl': scraped_data.get('image', ''),  # Same as image for now
            'display': True,
            'tags': scraped_data.get('tags', []),
            'author': scraped_data.get('author', ''),
            'author_id': None,
            'owner_id': None,
            'created_date': datetime.now().isoformat(),
            'updated_date': datetime.now().isoformat(),
            'expire_date': None,
            'due_date': None,
            'custom': {},
            'category': scraped_data.get('category', 'General'),
            'parent_id': None,
            'child_ids': [],
            'priority': self._determine_priority(scraped_data),
            'severity': None,
            'urgent': self._is_urgent(scraped_data),
            'important': self._is_important(scraped_data),
            'likes': 0,
            'usages': 0,
            'favorites': 0,
            'views': 0,
            'shares': 0,
            'approved_by': '',
            'reviewed_by': '',
            'source': scraped_data.get('source', ''),
            'status': 'active',
            'private': True,
            'shared_with': None,
            'conversations': None,
            'type': scraped_data.get('type', 'article')
        }
        
        return analyzed_data

    def _generate_key(self, title: str) -> str:
        """Generate a unique key based on title"""
        # Convert to lowercase, remove special characters, replace spaces with underscores
        key = re.sub(r'[^a-zA-Z0-9\s]', '', title.lower())
        key = re.sub(r'\s+', '_', key.strip())
        # Add timestamp to ensure uniqueness
        timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
        return f"{key}_{timestamp}" if key else f"content_{timestamp}"

    def _determine_priority(self, data: Dict) -> str:
        """Determine content priority based on various factors"""
        content = data.get('content', '').lower()
        title = data.get('title', '').lower()
        
        # High priority indicators
        high_priority_keywords = ['breaking', 'urgent', 'important', 'critical', 'emergency']
        if any(keyword in title or keyword in content for keyword in high_priority_keywords):
            return 'high'
        
        # Medium priority for news content
        if data.get('type') == 'news':
            return 'medium'
        
        return 'low'

    def _is_urgent(self, data: Dict) -> bool:
        """Determine if content is urgent"""
        urgent_keywords = ['breaking', 'urgent', 'emergency', 'immediate', 'alert']
        content_text = f"{data.get('title', '')} {data.get('content', '')}".lower()
        return any(keyword in content_text for keyword in urgent_keywords)

    def _is_important(self, data: Dict) -> bool:
        """Determine if content is important"""
        important_keywords = ['important', 'significant', 'major', 'critical', 'key']
        content_text = f"{data.get('title', '')} {data.get('content', '')}".lower()
        return any(keyword in content_text for keyword in important_keywords)

    def extract_entities(self, content: str) -> List[str]:
        """Extract named entities from content (simplified version)"""
        # This is a simple implementation. In production, you might use NLP libraries like spaCy
        entities = []
        
        # Simple regex patterns for common entities
        patterns = {
            'email': r'\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b',
            'phone': r'\b\d{3}[-.]?\d{3}[-.]?\d{4}\b',
            'date': r'\b\d{1,2}[/-]\d{1,2}[/-]\d{2,4}\b',
            'url': r'http[s]?://(?:[a-zA-Z]|[0-9]|[$-_@.&+]|[!*\\(\\),]|(?:%[0-9a-fA-F][0-9a-fA-F]))+'
        }
        
        for entity_type, pattern in patterns.items():
            matches = re.findall(pattern, content)
            for match in matches:
                entities.append(f"{entity_type}:{match}")
        
        return entities

    def analyze_sentiment(self, content: str) -> str:
        """Simple sentiment analysis (can be enhanced with ML libraries)"""
        positive_words = ['good', 'great', 'excellent', 'amazing', 'wonderful', 'fantastic', 'positive', 'success']
        negative_words = ['bad', 'terrible', 'awful', 'horrible', 'negative', 'failure', 'disaster', 'crisis']
        
        content_lower = content.lower()
        positive_count = sum(1 for word in positive_words if word in content_lower)
        negative_count = sum(1 for word in negative_words if word in content_lower)
        
        if positive_count > negative_count:
            return 'positive'
        elif negative_count > positive_count:
            return 'negative'
        else:
            return 'neutral'
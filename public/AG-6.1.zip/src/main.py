#!/usr/bin/env python3
"""
News Agent - Web Content Scraper and Analyzer
Scrapes web content and creates structured catalog entries with AI analysis
"""

import sys
import os
from urllib.parse import urlparse
from datetime import datetime

# Add the src directory to Python path
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from scraper.web_scraper import WebScraper
from ai_agent.content_analyzer import ContentAnalyzer
from ai_agent.summarizer import Summarizer
from models.catalog import Catalog, CatalogData
from utils.json_handler import save_to_json
from config.settings import OUTPUT_FILE, OUTPUT_DIR
from services.catalog_service import post_catalog_item, validate_catalog_service_connection, prepare_catalog_data_for_api

def validate_url(url: str) -> bool:
    """Validate if the provided URL is valid"""
    try:
        result = urlparse(url)
        return all([result.scheme, result.netloc])
    except:
        return False

def create_timestamped_filename(base_filename: str) -> str:
    """Create a timestamped filename"""
    timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
    name, ext = os.path.splitext(base_filename)
    return f"{name}_{timestamp}{ext}"

def post_to_catalog_service(catalog_entry: Catalog) -> bool:
    """Post catalog entry to the catalog service API"""
    try:
        # First check if the catalog service is available
        if not validate_catalog_service_connection():
            print("❌ Catalog service is not available at http://localhost:8000")
            print("💡 To post content to the catalog service:")
            print("   1. Start your catalog service on localhost:8000")
            print("   2. Ensure it has the required API endpoints (/api/v1/catalog/)")
            print("   3. Re-run the News Agent")
            return False
        
        print("📡 Posting to catalog service...")
        
        # Prepare catalog data for API using the proper data preparation function
        catalog_data = catalog_entry.to_dict()
        api_data = prepare_catalog_data_for_api(catalog_data)
        
        # Post directly with token (no authentication step needed)
        response = post_catalog_item(api_data)
        
        if response and "error" not in response:
            print("✅ Successfully posted to catalog service")
            if isinstance(response, dict) and "id" in response:
                print(f"📋 Catalog ID: {response['id']}")
            return True
        else:
            print(f"⚠️ Catalog service response: {response}")
            return False
            
    except Exception as e:
        print(f"❌ Failed to post to catalog service: {str(e)}")
        return False

def main():
    """Main function to orchestrate the web scraping and content analysis process"""
    print("=== News Agent - Web Content Scraper & Catalog Publisher ===")
    print("This tool will scrape web content, create a structured catalog entry, and post it to the catalog service.\n")
    
    # Get URL from user
    url = input("Enter the URL to scrape: ").strip()
    
    if not validate_url(url):
        print("Error: Invalid URL provided. Please enter a valid URL starting with http:// or https://")
        return
    
    try:
        print(f"\n🔍 Scraping content from: {url}")
        
        # Initialize the web scraper and scrape content
        scraper = WebScraper()
        scraped_data = scraper.scrape(url)
        print("✅ Content scraped successfully")
        
        # Analyze the scraped content
        print("🧠 Analyzing content...")
        analyzer = ContentAnalyzer()
        analyzed_data = analyzer.analyze(scraped_data)
        print("✅ Content analysis completed")
        
        # Generate summary
        print("📝 Generating summary...")
        summarizer = Summarizer()
        summary = summarizer.summarize(analyzed_data['content'])
        analyzed_data['summary'] = summary
        print("✅ Summary generated")
        
        # Create catalog data object
        catalog_data = CatalogData(**analyzed_data)
        
        # Create catalog entry
        print("📋 Creating catalog entry...")
        catalog_entry = Catalog(
            key=analyzed_data['key'],
            obj_in=catalog_data,
            child_ids_data=[]
        )
        print("✅ Catalog entry created")
        
        # Create timestamped output filename
        timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
        timestamped_filename = os.path.join(OUTPUT_DIR, f"catalog_output_{timestamp}.json")
        
        # Save to timestamped JSON file
        print(f"💾 Saving to: {timestamped_filename}")
        save_to_json(catalog_entry, timestamped_filename)
        
        # Also save to the default output file (for backward compatibility)
        save_to_json(catalog_entry, OUTPUT_FILE)
        print("✅ Local files saved successfully!")
        
        # Post to catalog service
        print("\n🚀 Publishing to catalog service...")
        success = post_to_catalog_service(catalog_entry)
        
        if success:
            print("✅ Catalog entry published successfully!")
        else:
            print("⚠️ Failed to publish to catalog service, but local files were saved")
        
        # Display summary information
        print("\n=== Summary ===")
        print(f"Title: {catalog_entry.title}")
        print(f"Author: {catalog_entry.author}")
        print(f"Category: {catalog_entry.category}")
        print(f"Type: {catalog_entry.type}")
        print(f"Priority: {catalog_entry.priority}")
        print(f"Urgent: {catalog_entry.urgent}")
        print(f"Important: {catalog_entry.important}")
        print(f"Tags: {', '.join(catalog_entry.tags) if catalog_entry.tags else 'None'}")
        print(f"Summary: {catalog_entry.summary[:200]}{'...' if len(catalog_entry.summary) > 200 else ''}")
        print(f"\nLocal files saved:")
        print(f"- Current: {OUTPUT_FILE}")
        print(f"- Timestamped: {timestamped_filename}")
        
        if success:
            print(f"✅ Published to catalog service successfully!")
        
    except Exception as e:
        print(f"❌ Error occurred: {str(e)}")
        print("Please check the URL and try again.")
        return 1
    
    return 0

if __name__ == "__main__":
    exit_code = main()
    sys.exit(exit_code)
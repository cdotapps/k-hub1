import requests
from bs4 import BeautifulSoup
from urllib.parse import urljoin, urlparse
import re
from typing import Dict, List, Optional

class WebScraper:
    def __init__(self):
        self.session = requests.Session()
        self.session.headers.update({
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'
        })

    def scrape(self, url: str) -> Dict:
        """Scrape content from the given URL and return structured data"""
        try:
            response = self.session.get(url, timeout=10)
            response.raise_for_status()
            
            soup = BeautifulSoup(response.text, 'html.parser')
            return self.extract_data(soup, url)
            
        except requests.RequestException as e:
            raise Exception(f"Failed to retrieve content from {url}: {str(e)}")

    def extract_data(self, soup: BeautifulSoup, url: str) -> Dict:
        """Extract structured data from BeautifulSoup object"""
        data = {
            'url': url,
            'title': self._extract_title(soup),
            'content': self._extract_content_with_html(soup),
            'description': self._extract_description(soup),
            'author': self._extract_author(soup),
            'image': self._extract_main_image(soup, url),
            'tags': self._extract_tags(soup),
            'category': self._extract_category(soup),
            'type': self._determine_content_type(soup),
            'source': self._extract_source(soup, url)
        }
        return data

    def _extract_title(self, soup: BeautifulSoup) -> str:
        """Extract the title from the page"""
        # Try different title sources in order of preference
        selectors = [
            'h1.headline__text',  # CNN specific
            'h1[data-module="ArticleHeadline"]',  # News sites
            'h1.entry-title',
            'h1.post-title',
            'h1.article-title',
            'h1',
            '[property="og:title"]',
            '[name="twitter:title"]',
            'title',
            '.title',
            '.headline'
        ]
        
        for selector in selectors:
            element = soup.select_one(selector)
            if element:
                title = element.get('content') if element.get('content') else element.get_text()
                if title and title.strip():
                    return title.strip()
        
        return 'No Title Found'

    def _extract_content_with_html(self, soup: BeautifulSoup) -> str:
        """Extract main content preserving HTML formatting where appropriate"""
        # Remove unwanted elements but preserve content structure
        for element in soup(['script', 'style', 'nav', 'header', 'footer', 'aside', 'iframe', 'noscript']):
            element.decompose()
        
        # Try to find main content areas with priority order
        content_selectors = [
            'div.article__content',  # CNN specific
            'div[data-module="ArticleBody"]',
            'article .zn-body__paragraph',  # CNN paragraphs
            'div.l-container',
            'article',
            '.content',
            '.post-content',
            '.entry-content',
            'main',
            '.main-content',
            '.article-body',
            '.story-body'
        ]
        
        content_html = ""
        content_found = False
        
        for selector in content_selectors:
            content_area = soup.select_one(selector)
            if content_area:
                # Extract content with basic HTML formatting preserved
                content_html = self._process_content_html(content_area)
                if len(content_html.strip()) > 200:  # Ensure substantial content
                    content_found = True
                    break
        
        if not content_found:
            # Fallback: get all paragraphs with basic HTML
            paragraphs = soup.find_all('p')
            if paragraphs:
                content_parts = []
                for p in paragraphs:
                    p_content = self._clean_paragraph_html(p)
                    if p_content.strip() and len(p_content.strip()) > 20:
                        content_parts.append(f"<p>{p_content}</p>")
                content_html = '\n'.join(content_parts)
        
        return content_html if content_html else 'No content found'

    def _process_content_html(self, content_area: BeautifulSoup) -> str:
        """Process content area to preserve meaningful HTML structure"""
        # Remove ads, social media, and other noise
        for unwanted in content_area.find_all(['div'], class_=re.compile(r'ad|social|share|related|sidebar')):
            unwanted.decompose()
        
        content_parts = []
        
        # Process different content elements
        for element in content_area.find_all(['p', 'h1', 'h2', 'h3', 'h4', 'h5', 'h6', 'blockquote', 'ul', 'ol', 'li']):
            if element.name in ['h1', 'h2', 'h3', 'h4', 'h5', 'h6']:
                text = element.get_text().strip()
                if text:
                    content_parts.append(f"<{element.name}>{text}</{element.name}>")
            elif element.name == 'p':
                p_content = self._clean_paragraph_html(element)
                if p_content.strip():
                    content_parts.append(f"<p>{p_content}</p>")
            elif element.name == 'blockquote':
                quote_text = element.get_text().strip()
                if quote_text:
                    content_parts.append(f"<blockquote>{quote_text}</blockquote>")
            elif element.name in ['ul', 'ol']:
                list_items = element.find_all('li')
                if list_items:
                    list_content = []
                    for li in list_items:
                        li_text = li.get_text().strip()
                        if li_text:
                            list_content.append(f"<li>{li_text}</li>")
                    if list_content:
                        list_html = '\n'.join(list_content)
                        content_parts.append(f"<{element.name}>\n{list_html}\n</{element.name}>")
        
        return '\n'.join(content_parts)

    def _clean_paragraph_html(self, paragraph) -> str:
        """Clean paragraph content while preserving basic formatting"""
        # Preserve basic formatting tags
        allowed_tags = ['strong', 'b', 'em', 'i', 'a', 'span']
        
        # Remove unwanted nested elements
        for unwanted in paragraph.find_all(['script', 'style', 'iframe']):
            unwanted.decompose()
        
        text = ""
        for content in paragraph.contents:
            if hasattr(content, 'name'):
                if content.name in allowed_tags:
                    if content.name == 'a':
                        href = content.get('href', '')
                        text += f'<a href="{href}">{content.get_text()}</a>'
                    else:
                        text += f'<{content.name}>{content.get_text()}</{content.name}>'
                else:
                    text += content.get_text()
            else:
                text += str(content)
        
        return text.strip()

    def _extract_description(self, soup: BeautifulSoup) -> str:
        """Extract description/summary from meta tags or content"""
        # Try meta description first
        meta_desc = soup.find('meta', attrs={'name': 'description'})
        if meta_desc and meta_desc.get('content'):
            return meta_desc.get('content').strip()
        
        # Try Open Graph description
        og_desc = soup.find('meta', attrs={'property': 'og:description'})
        if og_desc and og_desc.get('content'):
            return og_desc.get('content').strip()
        
        # Try Twitter description
        twitter_desc = soup.find('meta', attrs={'name': 'twitter:description'})
        if twitter_desc and twitter_desc.get('content'):
            return twitter_desc.get('content').strip()
        
        # Try article lead/excerpt
        lead_selectors = ['.article-lead', '.excerpt', '.summary', '.intro']
        for selector in lead_selectors:
            element = soup.select_one(selector)
            if element:
                text = element.get_text().strip()
                if text and len(text) > 50:
                    return text[:300] + '...' if len(text) > 300 else text
        
        # Fallback: use first substantial paragraph
        paragraphs = soup.find_all('p')
        for p in paragraphs:
            text = p.get_text().strip()
            if text and len(text) > 100:
                return text[:300] + '...' if len(text) > 300 else text
        
        return 'No description available'

    def _extract_author(self, soup: BeautifulSoup) -> str:
        """Extract author information"""
        author_selectors = [
            '[rel="author"]',
            '.author',
            '.byline',
            '[itemprop="author"]',
            '.post-author'
        ]
        
        for selector in author_selectors:
            element = soup.select_one(selector)
            if element:
                author = element.get_text().strip()
                if author:
                    return author
        
        return 'Unknown Author'

    def _extract_main_image(self, soup: BeautifulSoup, base_url: str) -> str:
        """Extract main image URL"""
        # Try Open Graph image first
        og_image = soup.find('meta', attrs={'property': 'og:image'})
        if og_image and og_image.get('content'):
            return urljoin(base_url, og_image.get('content'))
        
        # Try Twitter image
        twitter_image = soup.find('meta', attrs={'name': 'twitter:image'})
        if twitter_image and twitter_image.get('content'):
            return urljoin(base_url, twitter_image.get('content'))
        
        # Try to find first significant image in content
        images = soup.find_all('img')
        for img in images:
            src = img.get('src')
            if src and not any(x in src.lower() for x in ['logo', 'icon', 'avatar', 'button']):
                return urljoin(base_url, src)
        
        return ''

    def _extract_tags(self, soup: BeautifulSoup) -> List[str]:
        """Extract tags or keywords"""
        tags = []
        
        # Try meta keywords
        keywords_meta = soup.find('meta', attrs={'name': 'keywords'})
        if keywords_meta and keywords_meta.get('content'):
            tags.extend([tag.strip() for tag in keywords_meta.get('content').split(',')])
        
        # Try to find tag elements
        tag_selectors = ['.tags a', '.tag', '.category', '.label']
        for selector in tag_selectors:
            elements = soup.select(selector)
            for element in elements:
                tag_text = element.get_text().strip()
                if tag_text and tag_text not in tags:
                    tags.append(tag_text)
        
        return tags[:10]  # Limit to 10 tags

    def _extract_category(self, soup: BeautifulSoup) -> str:
        """Extract category information"""
        category_selectors = [
            '.category',
            '.section',
            '[rel="category"]',
            '.breadcrumb a'
        ]
        
        for selector in category_selectors:
            element = soup.select_one(selector)
            if element:
                category = element.get_text().strip()
                if category:
                    return category
        
        return 'General'

    def _determine_content_type(self, soup: BeautifulSoup) -> str:
        """Determine the type of content"""
        # Check for article indicators
        if soup.find('article') or soup.find('[itemtype*="Article"]'):
            return 'article'
        
        # Check for blog post indicators
        if any(class_name in str(soup) for class_name in ['blog', 'post', 'entry']):
            return 'blog_post'
        
        # Check for news indicators
        if any(indicator in str(soup).lower() for indicator in ['news', 'breaking', 'report']):
            return 'news'
        
        return 'webpage'

    def _extract_source(self, soup: BeautifulSoup, url: str) -> str:
        """Extract source/publisher information"""
        # Try to find publisher meta tag
        publisher_meta = soup.find('meta', attrs={'property': 'og:site_name'})
        if publisher_meta and publisher_meta.get('content'):
            return publisher_meta.get('content')
        
        # Extract from URL domain
        parsed_url = urlparse(url)
        domain = parsed_url.netloc
        if domain.startswith('www.'):
            domain = domain[4:]
        
        return domain
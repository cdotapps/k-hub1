#!/usr/bin/env python3
"""
Batch Processor - Process multiple URLs from a file
Reads URLs from a file and processes them one by one with configurable delays
"""

import sys
import os
import time
from urllib.parse import urlparse
from datetime import datetime
from typing import List, Optional

# Add the src directory to Python path
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from scraper.web_scraper import WebScraper
from ai_agent.content_analyzer import ContentAnalyzer
from ai_agent.summarizer import Summarizer
from models.catalog import Catalog, CatalogData
from utils.json_handler import save_to_json
from config.settings import OUTPUT_DIR
from services.catalog_service import authenticate, post_catalog_item, validate_catalog_service_connection, prepare_catalog_data_for_api

class BatchProcessor:
    def __init__(self, delay_seconds: int = 20):
        self.delay_seconds = delay_seconds
        self.scraper = WebScraper()
        self.analyzer = ContentAnalyzer()
        self.summarizer = Summarizer()
        self.processed_count = 0
        self.failed_count = 0
        self.failed_urls = []

    def validate_url(self, url: str) -> bool:
        """Validate if the provided URL is valid"""
        try:
            result = urlparse(url.strip())
            return all([result.scheme, result.netloc])
        except:
            return False

    def read_urls_from_file(self, file_path: str) -> List[str]:
        """Read URLs from a file, one per line"""
        urls = []
        try:
            with open(file_path, 'r', encoding='utf-8') as file:
                for line_num, line in enumerate(file, 1):
                    url = line.strip()
                    if url and not url.startswith('#'):  # Skip empty lines and comments
                        if self.validate_url(url):
                            urls.append(url)
                        else:
                            print(f"⚠️ Invalid URL on line {line_num}: {url}")
            
            print(f"📖 Found {len(urls)} valid URLs in {file_path}")
            return urls
            
        except FileNotFoundError:
            print(f"❌ File not found: {file_path}")
            return []
        except Exception as e:
            print(f"❌ Error reading file: {str(e)}")
            return []

    def process_single_url(self, url: str, url_index: int, total_urls: int) -> bool:
        """Process a single URL and return success status"""
        try:
            print(f"\n{'='*60}")
            print(f"Processing URL {url_index + 1}/{total_urls}")
            print(f"🔍 Scraping: {url}")
            
            # Scrape content
            scraped_data = self.scraper.scrape(url)
            print("✅ Content scraped successfully")
            
            # Analyze content
            print("🧠 Analyzing content...")
            analyzed_data = self.analyzer.analyze(scraped_data)
            print("✅ Content analysis completed")
            
            # Generate summary
            print("📝 Generating summary...")
            summary = self.summarizer.summarize(analyzed_data['content'])
            analyzed_data['summary'] = summary
            print("✅ Summary generated")
            
            # Create catalog entry
            catalog_data = CatalogData(**analyzed_data)
            catalog_entry = Catalog(
                key=analyzed_data['key'],
                obj_in=catalog_data,
                child_ids_data=[]
            )
            
            # Save locally
            timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
            filename = os.path.join(OUTPUT_DIR, f"catalog_output_{timestamp}.json")
            save_to_json(catalog_entry, filename)
            print(f"💾 Saved locally: {filename}")
            
            # Post to catalog service
            success = self.post_to_catalog_service(catalog_entry)
            
            if success:
                print(f"✅ Successfully processed: {analyzed_data['title'][:60]}...")
                self.processed_count += 1
                return True
            else:
                print(f"⚠️ Failed to post to catalog service: {url}")
                self.failed_count += 1
                self.failed_urls.append(url)
                return False
                
        except Exception as e:
            print(f"❌ Error processing {url}: {str(e)}")
            self.failed_count += 1
            self.failed_urls.append(url)
            return False

    def post_to_catalog_service(self, catalog_entry: Catalog) -> bool:
        """Post catalog entry to the catalog service API"""
        try:
            # Check if catalog service is available
            if not validate_catalog_service_connection():
                print("❌ Catalog service not available")
                return False
            
            # Authenticate (reuse token if possible)
            if not hasattr(self, 'access_token'):
                print("🔐 Authenticating with catalog service...")
                self.access_token = authenticate()
            
            headers = {
                "accept": "application/json",
                "Content-Type": "application/json",
                "Authorization": f"Bearer {self.access_token}"
            }
            
            # Prepare and post data
            catalog_data = catalog_entry.to_dict()
            api_data = prepare_catalog_data_for_api(catalog_data)
            
            print("📡 Posting to catalog service...")
            response = post_catalog_item(api_data, headers)
            
            if response and "error" not in response:
                if isinstance(response, dict) and "id" in response:
                    print(f"📋 Catalog ID: {response['id']}")
                return True
            else:
                print(f"❌ API Error: {response}")
                # Token might be expired, clear it for next attempt
                if hasattr(self, 'access_token'):
                    delattr(self, 'access_token')
                return False
                
        except Exception as e:
            print(f"❌ Catalog service error: {str(e)}")
            # Clear token on auth errors
            if "Authentication" in str(e) and hasattr(self, 'access_token'):
                delattr(self, 'access_token')
            return False

    def process_urls(self, urls: List[str]):
        """Process all URLs with delays"""
        total_urls = len(urls)
        start_time = datetime.now()
        
        print(f"\n🚀 Starting batch processing of {total_urls} URLs")
        print(f"⏱️ Delay between items: {self.delay_seconds} seconds")
        print(f"🕐 Estimated total time: {(total_urls * self.delay_seconds) // 60} minutes")
        print(f"{'='*60}")
        
        for i, url in enumerate(urls):
            # Process the URL
            self.process_single_url(url, i, total_urls)
            
            # Add delay between items (except for the last one)
            if i < total_urls - 1:
                print(f"\n⏳ Waiting {self.delay_seconds} seconds before next item...")
                time.sleep(self.delay_seconds)
        
        # Print final summary
        end_time = datetime.now()
        duration = end_time - start_time
        
        print(f"\n{'='*60}")
        print("🏁 BATCH PROCESSING COMPLETED")
        print(f"📊 Results:")
        print(f"   ✅ Successfully processed: {self.processed_count}")
        print(f"   ❌ Failed: {self.failed_count}")
        print(f"   📈 Success rate: {(self.processed_count / total_urls * 100):.1f}%")
        print(f"   ⏱️ Total time: {duration}")
        
        if self.failed_urls:
            print(f"\n❌ Failed URLs:")
            for url in self.failed_urls:
                print(f"   - {url}")

def main():
    """Main function for batch processing"""
    print("=== News Agent Batch Processor ===")
    print("Processing URLs from URL.txt file with 20-second delays.\n")
    
    # Use the URL.txt file from the project root
    project_root = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    file_path = os.path.join(project_root, "URL.txt")
    
    if not os.path.exists(file_path):
        print(f"❌ URL.txt file not found at: {file_path}")
        print("💡 Please create a URL.txt file in the project root directory")
        return 1
    
    # Use 20 seconds delay as specified
    delay_seconds = 20
    
    # Create processor and read URLs
    processor = BatchProcessor(delay_seconds)
    urls = processor.read_urls_from_file(file_path)
    
    if not urls:
        print("❌ No valid URLs found in URL.txt")
        return 1
    
    # Start processing immediately without confirmation
    print(f"📋 Found {len(urls)} URLs to process")
    print(f"⏱️ Using {delay_seconds}s delays between items")
    print(f"🕐 Estimated total time: {(len(urls) * delay_seconds) // 60} minutes\n")
    
    processor.process_urls(urls)
    return 0

if __name__ == "__main__":
    exit_code = main()
    sys.exit(exit_code)
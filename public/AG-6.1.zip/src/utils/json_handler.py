import json
import os
from typing import Any, Dict
from datetime import datetime

def save_to_json(catalog_obj, file_path: str) -> None:
    """Save catalog object to JSON file"""
    try:
        # Ensure output directory exists
        os.makedirs(os.path.dirname(file_path), exist_ok=True)
        
        # Convert catalog object to dictionary
        if hasattr(catalog_obj, 'to_dict'):
            data = catalog_obj.to_dict()
        else:
            # Fallback if object doesn't have to_dict method
            data = catalog_obj.__dict__
        
        # Write to JSON file
        with open(file_path, 'w', encoding='utf-8') as file:
            json.dump(data, file, indent=2, ensure_ascii=False, default=str)
        
        print(f"Catalog data saved successfully to: {file_path}")
        
    except Exception as e:
        print(f"Error saving catalog data: {str(e)}")
        raise

def read_json(file_path: str) -> Dict[str, Any]:
    """Read JSON file and return the data"""
    try:
        with open(file_path, 'r', encoding='utf-8') as file:
            return json.load(file)
    except FileNotFoundError:
        print(f"File not found: {file_path}")
        return {}
    except json.JSONDecodeError as e:
        print(f"Error decoding JSON from {file_path}: {str(e)}")
        return {}
    except Exception as e:
        print(f"Error reading file {file_path}: {str(e)}")
        return {}

def write_json(data: Dict[str, Any], file_path: str) -> None:
    """Write data to JSON file"""
    try:
        # Ensure output directory exists
        os.makedirs(os.path.dirname(file_path), exist_ok=True)
        
        with open(file_path, 'w', encoding='utf-8') as file:
            json.dump(data, file, indent=2, ensure_ascii=False, default=str)
        
        print(f"Data saved successfully to: {file_path}")
        
    except Exception as e:
        print(f"Error writing JSON file: {str(e)}")
        raise

def append_to_json_array(new_data: Dict[str, Any], file_path: str) -> None:
    """Append new data to existing JSON array file"""
    try:
        # Read existing data
        if os.path.exists(file_path):
            existing_data = read_json(file_path)
            if isinstance(existing_data, list):
                data_array = existing_data
            else:
                data_array = [existing_data]
        else:
            data_array = []
        
        # Append new data
        data_array.append(new_data)
        
        # Write back to file
        write_json(data_array, file_path)
        
    except Exception as e:
        print(f"Error appending to JSON array: {str(e)}")
        raise
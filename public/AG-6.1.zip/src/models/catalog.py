import uuid
import json
from datetime import datetime
from typing import List, Optional, Dict, Any

class CatalogData:
    """Helper class to hold catalog data before creating Catalog object"""
    def __init__(self, **kwargs):
        for key, value in kwargs.items():
            setattr(self, key, value)

class Catalog:
    def __init__(self, key: str, obj_in: CatalogData, child_ids_data: List[str] = None):
        self.id = str(uuid.uuid4())
        self.key = key
        self.title = getattr(obj_in, 'title', '')
        self.description = getattr(obj_in, 'description', '')
        self.summary = getattr(obj_in, 'summary', '')
        self.type = getattr(obj_in, 'type', 'article')
        self.content = getattr(obj_in, 'content', '')
        self.url = getattr(obj_in, 'url', '')
        self.image = getattr(obj_in, 'image', '')
        self.imageUrl = getattr(obj_in, 'imageUrl', '')
        self.display = getattr(obj_in, 'display', True)
        self.tags = getattr(obj_in, 'tags', [])
        self.author = getattr(obj_in, 'author', '')
        self.author_id = getattr(obj_in, 'author_id', None)
        self.owner_id = getattr(obj_in, 'owner_id', None)
        self.created_date = getattr(obj_in, 'created_date', datetime.now().isoformat())
        self.updated_date = getattr(obj_in, 'updated_date', datetime.now().isoformat())
        self.expire_date = getattr(obj_in, 'expire_date', None)
        self.due_date = getattr(obj_in, 'due_date', None)
        self.custom = getattr(obj_in, 'custom', {})
        self.category = getattr(obj_in, 'category', '')
        self.parent_id = getattr(obj_in, 'parent_id', None)
        self.child_ids = child_ids_data or []
        self.priority = getattr(obj_in, 'priority', None)
        self.severity = getattr(obj_in, 'severity', None)
        self.urgent = getattr(obj_in, 'urgent', False)
        self.important = getattr(obj_in, 'important', False)
        self.likes = getattr(obj_in, 'likes', 0)
        self.usages = getattr(obj_in, 'usages', 0)
        self.favorites = getattr(obj_in, 'favorites', 0)
        self.views = getattr(obj_in, 'views', 0)
        self.shares = getattr(obj_in, 'shares', 0)
        self.approved_by = getattr(obj_in, 'approved_by', '')
        self.reviewed_by = getattr(obj_in, 'reviewed_by', '')
        self.source = getattr(obj_in, 'source', '')
        self.status = getattr(obj_in, 'status', 'active')
        self.private = getattr(obj_in, 'private', True)
        self.shared_with = getattr(obj_in, 'shared_with', None)
        self.conversations = getattr(obj_in, 'conversations', None)
        self.read_by = []  # Initialize as empty list

    def to_dict(self) -> Dict[str, Any]:
        """Convert catalog object to dictionary"""
        return {
            'id': self.id,
            'key': self.key,
            'title': self.title,
            'description': self.description,
            'summary': self.summary,
            'type': self.type,
            'content': self.content,
            'url': self.url,
            'image': self.image,
            'imageUrl': self.imageUrl,
            'display': self.display,
            'tags': self.tags,
            'author': self.author,
            'author_id': self.author_id,
            'owner_id': self.owner_id,
            'created_date': self.created_date,
            'updated_date': self.updated_date,
            'expire_date': self.expire_date,
            'due_date': self.due_date,
            'custom': self.custom,
            'category': self.category,
            'parent_id': self.parent_id,
            'child_ids': self.child_ids,
            'priority': self.priority,
            'severity': self.severity,
            'urgent': self.urgent,
            'important': self.important,
            'likes': self.likes,
            'usages': self.usages,
            'favorites': self.favorites,
            'views': self.views,
            'shares': self.shares,
            'approved_by': self.approved_by,
            'reviewed_by': self.reviewed_by,
            'source': self.source,
            'status': self.status,
            'private': self.private,
            'shared_with': self.shared_with,
            'conversations': self.conversations,
            'read_by': self.read_by
        }

    def to_json(self) -> str:
        """Convert catalog object to JSON string"""
        return json.dumps(self.to_dict(), indent=2, ensure_ascii=False)
#!/usr/bin/env python3
"""
Test Catalog Service - Direct call to catalog service for testing
Tests the catalog service connection and posts sample data
"""

import sys
import os
import json
from datetime import datetime

# Add the src directory to Python path
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from services.catalog_service import (
    validate_catalog_service_connection, 
    post_catalog_item, 
    prepare_catalog_data_for_api,
    post_json_catalog_data
)

def test_catalog_service_connection():
    """Test if catalog service is available"""
    print("=== Testing Catalog Service Connection ===")
    
    if validate_catalog_service_connection():
        print("✅ Catalog service is available at http://localhost:8000")
        return True
    else:
        print("❌ Catalog service is not available at http://localhost:8000")
        print("💡 Make sure your catalog service is running on localhost:8000")
        return False

def create_test_data():
    """Create sample test data for posting"""
    return {
        "title": "Test Article - Direct Catalog Service Call",
        "description": "This is a test article created by calling the catalog service directly",
        "summary": "Test summary for direct catalog service call validation",
        "type": "article",
        "content": "<p>This is test content for validating the catalog service integration.</p><p>The content includes HTML formatting and should be properly processed by the catalog service.</p>",
        "url": "https://example.com/test-article",
        "image": "https://example.com/test-image.jpg",
        "tags": ["test", "catalog", "validation"],
        "author": "Test User",
        "category": "Testing",
        "source": "Test Source",
        "status": "active",
        "priority": "medium",
        "urgent": False,
        "important": True
    }

def test_direct_post():
    """Test posting data directly to catalog service"""
    print("\n=== Testing Direct POST to Catalog Service ===")
    
    # Create test data
    test_data = create_test_data()
    print(f"📝 Created test data with title: {test_data['title']}")
    
    # Prepare data for API
    print("🔧 Preparing data for catalog API...")
    api_data = prepare_catalog_data_for_api(test_data)
    
    # Post to catalog service
    print("📡 Posting to catalog service...")
    response = post_catalog_item(api_data)
    
    if "error" not in response:
        print("✅ Successfully posted to catalog service!")
        if isinstance(response, dict) and "id" in response:
            print(f"📋 Catalog ID: {response['id']}")
        print(f"📄 Response: {json.dumps(response, indent=2)}")
        return True
    else:
        print(f"❌ Failed to post to catalog service: {response.get('error', 'Unknown error')}")
        return False

def test_with_custom_token():
    """Test posting with a custom JWT token"""
    print("\n=== Testing with Custom Token ===")
    
    # You can replace this with your actual JWT token
    custom_token = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.test.token"
    
    test_data = create_test_data()
    test_data["title"] = "Test Article with Custom Token"
    
    api_data = prepare_catalog_data_for_api(test_data)
    
    print(f"🔑 Using custom token: {custom_token[:20]}...")
    response = post_catalog_item(api_data, token=custom_token)
    
    if "error" not in response:
        print("✅ Successfully posted with custom token!")
        if isinstance(response, dict) and "id" in response:
            print(f"📋 Catalog ID: {response['id']}")
        return True
    else:
        print(f"❌ Failed with custom token: {response.get('error', 'Unknown error')}")
        return False

def test_with_frontend_jwt():
    """Test with an actual JWT token like the one from your frontend"""
    print("\n=== Testing with Frontend-style JWT Token ===")
    print("💡 Replace the token below with your actual JWT token from the frontend")
    
    # Replace this with your actual JWT token from the frontend
    # You can find this in your browser's network tab when making a request
    frontend_jwt = input("Enter your JWT token (or press Enter to skip): ").strip()
    
    if not frontend_jwt:
        print("⏭️ Skipping JWT test - no token provided")
        return False
    
    test_data = create_test_data()
    test_data["title"] = "Test Article with Frontend JWT"
    
    api_data = prepare_catalog_data_for_api(test_data)
    
    print(f"🔑 Using frontend JWT token: {frontend_jwt[:30]}...")
    response = post_catalog_item(api_data, token=frontend_jwt)
    
    if "error" not in response:
        print("✅ Successfully posted with frontend JWT!")
        if isinstance(response, dict) and "id" in response:
            print(f"📋 Catalog ID: {response['id']}")
            print(f"📄 Response: {json.dumps(response, indent=2)}")
        return True
    else:
        print(f"❌ Failed with frontend JWT: {response.get('error', 'Unknown error')}")
        return False

def test_post_from_json_file():
    """Test posting from an existing JSON file"""
    print("\n=== Testing POST from JSON File ===")
    
    # Look for an existing output file
    output_files = [
        "src/output/catalog_output_20250710_013124.json",  # The CNN article with good data
        "output/catalog_output.json"
    ]
    
    for file_path in output_files:
        if os.path.exists(file_path):
            print(f"📁 Found existing file: {file_path}")
            success = post_json_catalog_data(file_path)
            if success:
                print("✅ Successfully posted from JSON file!")
                return True
            else:
                print("❌ Failed to post from JSON file")
        else:
            print(f"📁 File not found: {file_path}")
    
    return False

def main():
    """Main test function"""
    print("🧪 Catalog Service Direct Test")
    print("=" * 50)
    
    # Test 1: Connection
    if not test_catalog_service_connection():
        print("\n❌ Cannot proceed with tests - catalog service is not available")
        return 1
    
    # Test 2: Direct POST with default token
    success1 = test_direct_post()
    
    # Test 3: POST with custom token (optional)
    success2 = test_with_custom_token()
    
    # Test 4: POST with frontend JWT
    success3 = test_with_frontend_jwt()
    
    # Test 5: POST from existing JSON file
    success4 = test_post_from_json_file()
    
    # Summary
    print("\n" + "=" * 50)
    print("🏁 Test Summary:")
    print(f"   ✅ Connection Test: {'PASS' if True else 'FAIL'}")
    print(f"   ✅ Direct POST: {'PASS' if success1 else 'FAIL'}")
    print(f"   ✅ Custom Token POST: {'PASS' if success2 else 'FAIL'}")
    print(f"   ✅ Frontend JWT POST: {'PASS' if success3 else 'FAIL'}")
    print(f"   ✅ JSON File POST: {'PASS' if success4 else 'FAIL'}")
    
    if success1 or success2 or success3 or success4:
        print("\n🎉 At least one test passed - catalog service is working!")
        return 0
    else:
        print("\n❌ All tests failed - check catalog service authentication")
        print("\n💡 Troubleshooting:")
        print("   1. Check what authentication token your catalog service expects")
        print("   2. Try using the same JWT token that works in your frontend")
        print("   3. Check if the catalog service authentication configuration matches")
        return 1

if __name__ == "__main__":
    exit_code = main()
    sys.exit(exit_code)
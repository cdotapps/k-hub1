#!/usr/bin/env python3
"""
News Agent API Client - Example client for testing the News Agent API
"""

import requests
import json
from typing import Dict, Any

class NewsAgentClient:
    def __init__(self, base_url: str = "http://localhost:8001", api_key: str = "news-agent-api-key-2025"):
        self.base_url = base_url
        self.api_key = api_key
        self.headers = {
            "Authorization": f"Bearer {api_key}",
            "Content-Type": "application/json"
        }

    def health_check(self) -> Dict[str, Any]:
        """Check if the API is healthy"""
        try:
            response = requests.get(f"{self.base_url}/health")
            response.raise_for_status()
            return response.json()
        except requests.RequestException as e:
            return {"error": str(e)}

    def get_status(self) -> Dict[str, Any]:
        """Get API status (requires authentication)"""
        try:
            response = requests.get(f"{self.base_url}/status", headers=self.headers)
            response.raise_for_status()
            return response.json()
        except requests.RequestException as e:
            return {"error": str(e)}

    def scrape_url(self, url: str) -> Dict[str, Any]:
        """Scrape a URL and create catalog entry"""
        try:
            payload = {"url": url}
            response = requests.post(
                f"{self.base_url}/scrape",
                headers=self.headers,
                json=payload
            )
            response.raise_for_status()
            return response.json()
        except requests.RequestException as e:
            return {"error": str(e)}

def main():
    """Example usage of the News Agent API"""
    print("=== News Agent API Client ===")
    
    # Initialize client
    client = NewsAgentClient()
    
    # Health check
    print("🔍 Checking API health...")
    health = client.health_check()
    if "error" in health:
        print(f"❌ API not available: {health['error']}")
        return
    print(f"✅ API is healthy: {health['status']}")
    
    # Get status
    print("\n📊 Getting API status...")
    status = client.get_status()
    if "error" in status:
        print(f"❌ Status check failed: {status['error']}")
        return
    print(f"✅ API Status: {status['status']}")
    print(f"📋 Catalog service available: {status['catalog_service_available']}")
    
    # Example URL scraping
    test_url = "https://example.com"
    print(f"\n🔍 Testing URL scraping: {test_url}")
    result = client.scrape_url(test_url)
    
    if "error" in result:
        print(f"❌ Scraping failed: {result['error']}")
    else:
        print(f"✅ Scraping successful!")
        print(f"📋 Title: {result.get('title', 'N/A')}")
        print(f"👤 Author: {result.get('author', 'N/A')}")
        print(f"📂 Category: {result.get('category', 'N/A')}")
        print(f"🆔 Catalog ID: {result.get('catalog_id', 'N/A')}")
        print(f"📄 Local file: {result.get('local_file', 'N/A')}")

if __name__ == "__main__":
    main()
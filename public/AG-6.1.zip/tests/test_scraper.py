import unittest
from src.scraper.web_scraper import WebScraper

class TestWebScraper(unittest.TestCase):

    def setUp(self):
        self.scraper = WebScraper()

    def test_scrape_valid_url(self):
        url = "https://example.com"
        content = self.scraper.scrape(url)
        self.assertIsNotNone(content)
        self.assertIn('<html>', content)  # Check if HTML content is returned

    def test_scrape_invalid_url(self):
        url = "invalid-url"
        with self.assertRaises(ValueError):
            self.scraper.scrape(url)

    def test_scrape_non_existent_url(self):
        url = "https://nonexistentwebsite.com"
        content = self.scraper.scrape(url)
        self.assertIsNone(content)  # Assuming the method returns None for non-existent URLs

if __name__ == '__main__':
    unittest.main()
import unittest
from src.ai_agent.content_analyzer import ContentAnalyzer
from src.ai_agent.summarizer import Summarizer

class TestAIAgent(unittest.TestCase):

    def setUp(self):
        self.content_analyzer = ContentAnalyzer()
        self.summarizer = Summarizer()

    def test_content_analysis(self):
        raw_content = "<html><body><h1>Test Title</h1><p>Test description.</p></body></html>"
        expected_output = {
            "title": "Test Title",
            "description": "Test description.",
            "content": raw_content,
            "url": "http://example.com",
            "tags": ["test", "example"],
            "author": "Test Author"
        }
        analyzed_content = self.content_analyzer.analyze(raw_content, "http://example.com")
        self.assertEqual(analyzed_content, expected_output)

    def test_summary_generation(self):
        content = {
            "title": "Test Title",
            "description": "Test description.",
            "content": "This is a longer piece of content that needs summarization."
        }
        expected_summary = "This is a longer piece of content that needs summarization."
        summary = self.summarizer.generate_summary(content)
        self.assertEqual(summary, expected_summary)

if __name__ == '__main__':
    unittest.main()
import unittest
from src.models.catalog import Catalog

class TestCatalog(unittest.TestCase):

    def setUp(self):
        self.catalog_data = {
            'key': 'test_key',
            'title': 'Test Title',
            'description': 'Test Description',
            'summary': 'Test Summary',
            'type': 'article',
            'content': 'This is a test content.',
            'url': 'http://example.com',
            'image': 'image.png',
            'imageUrl': 'http://example.com/image.png',
            'display': True,
            'tags': ['test', 'example'],
            'author': 'Test Author',
            'author_id': 'author_id_123',
            'owner_id': 'owner_id_123',
            'created_date': '2023-01-01',
            'updated_date': '2023-01-02',
            'expire_date': '2023-12-31',
            'due_date': '2023-06-30',
            'custom': {},
            'category': 'Test Category',
            'parent_id': None,
            'child_ids': [],
            'priority': 1,
            'severity': 2,
            'urgent': False,
            'important': True,
            'likes': 10,
            'usages': 5,
            'favorites': 3,
            'views': 100,
            'shares': 20,
            'approved_by': 'admin',
            'reviewed_by': 'reviewer',
            'source': 'source_name',
            'status': 'published',
            'private': False,
            'shared_with': None,
            'conversations': None,
            'read_by': []
        }
        self.catalog = Catalog(**self.catalog_data)

    def test_catalog_initialization(self):
        self.assertEqual(self.catalog.key, self.catalog_data['key'])
        self.assertEqual(self.catalog.title, self.catalog_data['title'])
        self.assertEqual(self.catalog.description, self.catalog_data['description'])
        self.assertEqual(self.catalog.summary, self.catalog_data['summary'])
        self.assertEqual(self.catalog.type, self.catalog_data['type'])
        self.assertEqual(self.catalog.content, self.catalog_data['content'])
        self.assertEqual(self.catalog.url, self.catalog_data['url'])
        self.assertEqual(self.catalog.image, self.catalog_data['image'])
        self.assertEqual(self.catalog.imageUrl, self.catalog_data['imageUrl'])
        self.assertEqual(self.catalog.display, self.catalog_data['display'])
        self.assertEqual(self.catalog.tags, self.catalog_data['tags'])
        self.assertEqual(self.catalog.author, self.catalog_data['author'])
        self.assertEqual(self.catalog.author_id, self.catalog_data['author_id'])
        self.assertEqual(self.catalog.owner_id, self.catalog_data['owner_id'])
        self.assertEqual(self.catalog.created_date, self.catalog_data['created_date'])
        self.assertEqual(self.catalog.updated_date, self.catalog_data['updated_date'])
        self.assertEqual(self.catalog.expire_date, self.catalog_data['expire_date'])
        self.assertEqual(self.catalog.due_date, self.catalog_data['due_date'])
        self.assertEqual(self.catalog.custom, self.catalog_data['custom'])
        self.assertEqual(self.catalog.category, self.catalog_data['category'])
        self.assertEqual(self.catalog.parent_id, self.catalog_data['parent_id'])
        self.assertEqual(self.catalog.child_ids, self.catalog_data['child_ids'])
        self.assertEqual(self.catalog.priority, self.catalog_data['priority'])
        self.assertEqual(self.catalog.severity, self.catalog_data['severity'])
        self.assertEqual(self.catalog.urgent, self.catalog_data['urgent'])
        self.assertEqual(self.catalog.important, self.catalog_data['important'])
        self.assertEqual(self.catalog.likes, self.catalog_data['likes'])
        self.assertEqual(self.catalog.usages, self.catalog_data['usages'])
        self.assertEqual(self.catalog.favorites, self.catalog_data['favorites'])
        self.assertEqual(self.catalog.views, self.catalog_data['views'])
        self.assertEqual(self.catalog.shares, self.catalog_data['shares'])
        self.assertEqual(self.catalog.approved_by, self.catalog_data['approved_by'])
        self.assertEqual(self.catalog.reviewed_by, self.catalog_data['reviewed_by'])
        self.assertEqual(self.catalog.source, self.catalog_data['source'])
        self.assertEqual(self.catalog.status, self.catalog_data['status'])
        self.assertEqual(self.catalog.private, self.catalog_data['private'])
        self.assertEqual(self.catalog.shared_with, self.catalog_data['shared_with'])
        self.assertEqual(self.catalog.conversations, self.catalog_data['conversations'])
        self.assertEqual(self.catalog.read_by, self.catalog_data['read_by'])

    def test_catalog_to_json(self):
        json_output = self.catalog.to_json()
        self.assertIsInstance(json_output, str)  # Ensure output is a string
        self.assertIn('"key": "test_key"', json_output)  # Check for key in JSON output

if __name__ == '__main__':
    unittest.main()
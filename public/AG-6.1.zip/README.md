# News Agent Project

## Overview
The News Agent project is an AI-driven application designed to scrape content from specified URLs, analyze the content, and generate structured summaries. The output is formatted into a catalog structure and saved as a JSON file.

## Project Structure
```
news-agent
├── src
│   ├── __init__.py
│   ├── main.py
│   ├── scraper
│   │   ├── __init__.py
│   │   └── web_scraper.py
│   ├── ai_agent
│   │   ├── __init__.py
│   │   ├── content_analyzer.py
│   │   └── summarizer.py
│   ├── models
│   │   ├── __init__.py
│   │   └── catalog.py
│   ├── utils
│   │   ├── __init__.py
│   │   ├── json_handler.py
│   │   └── url_validator.py
│   └── config
│       ├── __init__.py
│       └── settings.py
├── tests
│   ├── __init__.py
│   ├── test_scraper.py
│   ├── test_ai_agent.py
│   └── test_models.py
├── output
│   └── .gitkeep
├── requirements.txt
├── .env.example
├── .gitignore
└── README.md
```

## Installation
1. Clone the repository:
   ```
   git clone <repository-url>
   ```
2. Navigate to the project directory:
   ```
   cd news-agent
   ```
3. Install the required dependencies:
   ```
   pip install -r requirements.txt
   ```

## Usage
To run the application, execute the following command:
```
python src/main.py <url>
```
Replace `<url>` with the target URL you wish to scrape.

## Components
- **Web Scraper**: Responsible for fetching content from the web.
- **Content Analyzer**: Processes the scraped content to extract relevant information.
- **Summarizer**: Generates a concise summary of the content.
- **Catalog Model**: Defines the structure of the output data.
- **JSON Handler**: Manages reading and writing JSON files.

## Testing
To run the tests, use:
```
pytest
```

## Contributing
Contributions are welcome! Please submit a pull request or open an issue for any enhancements or bug fixes.

## License
This project is licensed under the MIT License. See the LICENSE file for more details.
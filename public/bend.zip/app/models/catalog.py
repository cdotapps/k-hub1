from sqlalchemy import Column, String, Boolean, DateTime, Enum, Integer, Text, JSON
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.sql import func
from typing import Optional, List, Dict, Any
from pydantic import Field
import enum
import uuid

Base = declarative_base()

class SharePointListConfig:
    def __init__(self, list_name: str, list_title: str, endpoint_name: str, fields: Dict[str, str], required_fields: List[str], searchable_fields: List[str]):
        self.list_name = list_name
        self.list_title = list_title
        self.endpoint_name = endpoint_name
        self.fields = fields
        self.required_fields = required_fields
        self.searchable_fields = searchable_fields

class CatalogStatus(str, enum.Enum):
    DRAFT = "draft"
    PUBLISHED = "published"
    ARCHIVED = "archived"
    UNDER_REVIEW = "under_review"
    REJECTED = "rejected"

class CatalogType(str, enum.Enum):
    NEWS = "news"
    DOCUMENT = "document"
    TUTORIAL = "tutorial"
    VIDEO = "video"
    ARTICLE = "article"
    REFERENCE = "reference"
    TOOL = "tool"

class Catalog(Base):
    __tablename__ = "catalogs"

    id = Column(String, primary_key=True, index=True, default=lambda: str(uuid.uuid4()))
    title = Column(String, nullable=False, index=True)  # Field(..., description="Catalog item title")
    description = Column(Text, nullable=True)  # Field(None, description="Catalog item description")
    summary = Column(String, nullable=True, index=True)  # Field(None, description="Brief summary of the catalog item")
    type = Column(String, nullable=False, index=True)  # Field(..., description="Type of catalog item (document, prompt, blog, product, etc.)")
    content = Column(Text, nullable=True)  # Field(None, description="The main content of the catalog item")
    url = Column(String, nullable=True)  # Field(None, description="URL associated with the catalog item")
    image = Column(String, nullable=True)  # Field(None, description="Image URL or path for the catalog item")
    imageUrl = Column(String, nullable=True)  # Field(None, description="Direct image URL for web display")
    display = Column(String, nullable=True)  # Field(None, description="Display settings or visibility options")
    tags = Column(JSON, nullable=True)  # Field(default=None, description="Tags for categorizing the catalog item")
    author = Column(String, nullable=True, index=True)  # Field(None, description="Author of the catalog item")
    created_date = Column(String, nullable=True)  # Field(None, description="Creation date")
    updated_date = Column(String, nullable=True)  # Field(None, description="Last update date")
    custom = Column(JSON, nullable=True)  # Field(default=None, description="Custom fields for type-specific attributes")
    category = Column(String, nullable=True, index=True)  # Field(None, description="Primary category for the content")
    
    # Metric attributes
    likes = Column(Integer, default=0, nullable=False)  # Field(default=0, description="Number of likes for the content")
    usages = Column(Integer, default=0, nullable=False)  # Field(default=0, description="Number of times the content has been used")
    favorites = Column(Integer, default=0, nullable=False)  # Field(default=0, description="Number of times the content has been favorited")
    views = Column(Integer, default=0, nullable=False)  # Field(default=0, description="Number of views for the content")
    shares = Column(Integer, default=0, nullable=False)  # Field(default=0, description="Number of times the content has been shared")
    
    # Approval process attributes
    approved_by = Column(String, nullable=True, index=True)  # Field(None, description="Email or name of the person who approved the content")
    reviewed_by = Column(String, nullable=True, index=True)  # Field(None, description="Email or name of the person who reviewed the content")
    source = Column(String, nullable=True, index=True)  # Field(None, description="Source or origin of the content")
    status = Column(String, nullable=False, default="draft", index=True)  # Field(default="draft", description="Status of the catalog item (draft, published, archived)")
    
    @classmethod
    def get_list_config(cls) -> SharePointListConfig:
        return SharePointListConfig(
            list_name="Catalog",
            list_title="Content Catalog",
            endpoint_name="catalog",
            fields={
                "Title": "title",
                "Description": "description",
                "Summary": "summary",
                "Type": "type",
                "Content": "content",
                "Url": "url",
                "Image": "image",
                "ImageUrl": "imageUrl",
                "Display": "display",
                "Tags": "tags",
                "Author": "author",
                "CreatedDate": "created_date",
                "UpdatedDate": "updated_date",
                "Custom": "custom",
                "Category": "category",
                "Likes": "likes",
                "Usages": "usages",
                "Favorites": "favorites",
                "Views": "views",
                "Shares": "shares",
                "ApprovedBy": "approved_by",
                "ReviewedBy": "reviewed_by",
                "Source": "source",
                "Status": "status"
            },
            required_fields=["title", "type", "status"],
            searchable_fields=["title", "description", "summary", "type", "tags", "content", "category", "author", "status", "approved_by", "reviewed_by", "source"]
        )
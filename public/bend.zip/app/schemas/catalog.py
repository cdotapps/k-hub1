from typing import Optional, List, Dict, Any
from pydantic import BaseModel, Field
from datetime import datetime

class CatalogBase(BaseModel):
    title: Optional[str] = Field(None, description="Catalog item title")
    description: Optional[str] = Field(None, description="Catalog item description")
    summary: Optional[str] = Field(None, description="Brief summary of the catalog item")
    type: Optional[str] = Field(None, description="Type of catalog item (document, prompt, blog, product, etc.)")
    content: Optional[str] = Field(None, description="The main content of the catalog item")
    url: Optional[str] = Field(None, description="URL associated with the catalog item")
    image: Optional[str] = Field(None, description="Image URL or path for the catalog item")
    imageUrl: Optional[str] = Field(None, description="Direct image URL for web display")
    display: Optional[str] = Field(None, description="Display settings or visibility options")
    tags: Optional[List[str]] = Field(default=None, description="Tags for categorizing the catalog item")
    author: Optional[str] = Field(None, description="Author of the catalog item")
    created_date: Optional[str] = Field(None, description="Creation date")
    updated_date: Optional[str] = Field(None, description="Last update date")
    custom: Optional[Dict[str, Any]] = Field(default=None, description="Custom fields for type-specific attributes")
    category: Optional[str] = Field(None, description="Primary category for the content")
    
    # Metric attributes
    likes: int = Field(default=0, description="Number of likes for the content")
    usages: int = Field(default=0, description="Number of times the content has been used")
    favorites: int = Field(default=0, description="Number of times the content has been favorited")
    views: int = Field(default=0, description="Number of views for the content")
    shares: int = Field(default=0, description="Number of times the content has been shared")
    
    # Approval process attributes
    approved_by: Optional[str] = Field(None, description="Email or name of the person who approved the content")
    reviewed_by: Optional[str] = Field(None, description="Email or name of the person who reviewed the content")
    source: Optional[str] = Field(None, description="Source or origin of the content")
    status: str = Field(default="draft", description="Status of the catalog item (draft, published, archived)")

class CatalogCreate(CatalogBase):
    title: str = Field(..., description="Catalog item title")
    type: str = Field(..., description="Type of catalog item (document, prompt, blog, product, etc.)")
    status: str = Field(default="draft", description="Status of the catalog item (draft, published, archived)")

class CatalogUpdate(CatalogBase):
    pass

class CatalogInDBBase(CatalogBase):
    id: str

    class Config:
        from_attributes = True

class Catalog(CatalogInDBBase):
    pass

class CatalogInDB(CatalogInDBBase):
    pass

class CatalogSearch(BaseModel):
    query: Optional[str] = None
    type: Optional[str] = None
    category: Optional[str] = None
    status: Optional[str] = None
    author: Optional[str] = None
    approved_by: Optional[str] = None
    reviewed_by: Optional[str] = None
    source: Optional[str] = None
    tags: Optional[str] = None  # Keep as string for searching within tag arrays
    limit: Optional[int] = 50
    offset: Optional[int] = 0

class CatalogResponse(BaseModel):
    items: List[Catalog]
    total: int
    limit: int
    offset: int
    page: Optional[int] = None
    page_size: Optional[int] = None
    total_pages: Optional[int] = None

class Msg(BaseModel):
    msg: str
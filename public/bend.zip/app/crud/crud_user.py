from typing import Any, Dict, Optional, Union, List
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, update, delete
from sqlalchemy.sql import func
from datetime import datetime
import bcrypt
import uuid

from app.models.user import User, UserRole
from app.schemas.user import UserCreate, UserUpdate


class CRUDUser:
    def __init__(self, model: type[User]):
        """
        CRUD object with default methods to Create, Read, Update, Delete (CRUD).
        """
        self.model = model

    async def get(self, db: AsyncSession, id: str) -> Optional[User]:
        """Get user by ID"""
        result = await db.execute(select(self.model).where(self.model.id == id))
        return result.scalar_one_or_none()

    async def get_by_email(self, db: AsyncSession, *, email: str) -> Optional[User]:
        """Get user by email"""
        result = await db.execute(select(self.model).where(self.model.email == email))
        return result.scalar_one_or_none()

    async def get_by_user_id(self, db: AsyncSession, *, user_id: str) -> Optional[User]:
        """Get user by user_id"""
        result = await db.execute(select(self.model).where(self.model.user_id == user_id))
        return result.scalar_one_or_none()

    async def get_multi(
        self, db: AsyncSession, *, skip: int = 0, limit: int = 100
    ) -> List[User]:
        """Get multiple users with pagination"""
        result = await db.execute(
            select(self.model).offset(skip).limit(limit).order_by(self.model.created_at.desc())
        )
        return result.scalars().all()

    async def create(self, db: AsyncSession, *, obj_in: UserCreate) -> User:
        """Create new user"""
        hashed_password = self.get_password_hash(obj_in.password)
        db_obj = User(
            id=str(uuid.uuid4()),
            user_id=obj_in.user_id,
            email=obj_in.email,
            hashed_password=hashed_password,
            first_name=obj_in.first_name,
            last_name=obj_in.last_name,
            is_active=getattr(obj_in, 'is_active', True),
            role=getattr(obj_in, 'role', UserRole.USER),
            is_superuser=getattr(obj_in, 'is_superuser', False),
            email_verified=getattr(obj_in, 'email_verified', False),
            manager_id=getattr(obj_in, 'manager_id', None),
            portfolio_id=getattr(obj_in, 'portfolio_id', None),
            organization_id=getattr(obj_in, 'organization_id', None),
            costcenter_id=getattr(obj_in, 'costcenter_id', None),
            user_type=getattr(obj_in, 'user_type', None),
            designation=getattr(obj_in, 'designation', "associate"),
        )
        db.add(db_obj)
        await db.commit()
        await db.refresh(db_obj)
        return db_obj

    async def update(
        self,
        db: AsyncSession,
        *,
        db_obj: User,
        obj_in: Union[UserUpdate, Dict[str, Any]]
    ) -> User:
        """Update user"""
        if isinstance(obj_in, dict):
            update_data = obj_in
        else:
            update_data = obj_in.dict(exclude_unset=True)
        
        # Handle password update
        if "password" in update_data:
            hashed_password = self.get_password_hash(update_data["password"])
            del update_data["password"]
            update_data["hashed_password"] = hashed_password
        
        # Set updated_at timestamp
        update_data["updated_at"] = datetime.utcnow()
        
        # Update the database
        await db.execute(
            update(self.model)
            .where(self.model.id == db_obj.id)
            .values(**update_data)
        )
        await db.commit()
        await db.refresh(db_obj)
        
        return db_obj

    async def remove(self, db: AsyncSession, *, id: str) -> User:
        """Delete user"""
        obj = await self.get(db, id=id)
        await db.execute(delete(self.model).where(self.model.id == id))
        await db.commit()
        return obj

    async def authenticate(
        self, db: AsyncSession, *, user_id: str, password: str
    ) -> Optional[User]:
        """Authenticate user with user_id and password"""
        user = await self.get_by_user_id(db, user_id=user_id)
        if not user:
            return None
        if not self.verify_password(password, user.hashed_password):
            return None
        return user

    async def update_last_login(self, db: AsyncSession, *, user: User) -> User:
        """Update user's last login timestamp"""
        await db.execute(
            update(self.model)
            .where(self.model.id == user.id)
            .values(last_login=datetime.utcnow())
        )
        await db.commit()
        await db.refresh(user)
        return user

    def get_password_hash(self, password: str) -> str:
        """Hash password using bcrypt"""
        return bcrypt.hashpw(password.encode('utf-8'), bcrypt.gensalt()).decode('utf-8')

    def verify_password(self, plain_password: str, hashed_password: str) -> bool:
        """Verify password against hash"""
        return bcrypt.checkpw(plain_password.encode('utf-8'), hashed_password.encode('utf-8'))

    def is_active(self, user: User) -> bool:
        """Check if user is active"""
        return user.is_active

    def is_superuser(self, user: User) -> bool:
        """Check if user is superuser"""
        return user.is_superuser

    def is_admin(self, user: User) -> bool:
        """Check if user has admin role"""
        return user.role == UserRole.ADMIN or user.is_superuser


user = CRUDUser(User)
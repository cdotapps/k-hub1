import asyncio
import os
from dotenv import load_dotenv

from app.db.session import async_session, create_tables
from app import crud
from app.schemas.user import UserCreate
from app.schemas.catalog import CatalogCreate, CatalogSearch
from app.models.user import UserRole

# Import the user loading functionality
from load_users import load_users_from_csv_file

load_dotenv()

# Load configuration from environment variables
APP_NAME = os.getenv('APP_NAME', 'User Auth API').lower().replace(' ', '')
ADMIN_USER_ID = os.getenv('ADMIN_USER_ID', 'admin')
ADMIN_EMAIL = f"admin@{APP_NAME}.com"
ADMIN_PASSWORD = os.getenv('ADMIN_PASSWORD', 'admin123')
ADMIN_FIRST_NAME = "System"
ADMIN_LAST_NAME = "Administrator"

# Sample users configuration
SAMPLE_USERS = [
    {
        "user_id": "demo1",
        "email": f"demoemp@{APP_NAME}.com",
        "password": "demo123",
        "first_name": "Demo",
        "last_name": "Employee",
        "role": UserRole.USER,
        "user_type": "employee",
        "organization_id": "ORG001",
        "costcenter_id": "CC001",
        "portfolio_id": "PF001",
        "is_active": True,
        "email_verified": True,
        "designation": "senior associate"
    },
    {
        "user_id": "demo2",
        "email": f"democont@{APP_NAME}.com",
        "password": "demo123",
        "first_name": "Demo",
        "last_name": "Contractor",
        "role": UserRole.USER,
        "user_type": "contractor",
        "organization_id": "ORG002",
        "costcenter_id": "CC002",
        "portfolio_id": "PF002",
        "is_active": True,
        "email_verified": True,
        "designation": "consultant"
    }
]

# Sample catalog news items
SAMPLE_NEWS = [
    {
        "title": "Title:Company Launches New AI-Powered Analytics Platform",
        "description": "Desc:Our organization has successfully launched a cutting-edge analytics platform that leverages artificial intelligence to provide real-time business insights and predictive analytics capabilities.",
        "summary": "Summary:AI-powered analytics platform launched with real-time insights and predictive capabilities",
        "type": "news",
        "imageUrl": "6.jpg",
        "content": "Content:Today marks a significant milestone in our company's digital transformation journey. The new AI-powered analytics platform, developed over the past 18 months, offers unprecedented capabilities in data processing and business intelligence. Key features include real-time dashboard visualization, predictive modeling, and automated reporting systems that will enhance decision-making across all departments.",
        "category": "Technology",
        "tags": ["AI", "Analytics", "Platform", "Technology", "Business Intelligence"],
        "author": "Tech Communications Team",
        "status": "published",
        "source": "Internal Communications",
        "likes": 45,
        "views": 156,
        "shares": 12,
        "favorites": 23,
        "usages": 8
    },
    {
        "title": "Q1 2025 Financial Results Exceed Expectations",
        "description": "The company reports strong Q1 2025 financial performance with revenue growth of 15% year-over-year, surpassing analyst expectations and demonstrating continued market leadership.",
        "summary": "Q1 2025 revenue grows 15% year-over-year, exceeding analyst expectations",
        "type": "news",
        "content": "We are pleased to announce our Q1 2025 financial results, which demonstrate robust performance across all business segments. Revenue increased by 15% compared to Q1 2024, reaching $2.3 billion. Operating margin improved to 18.5%, reflecting our continued focus on operational efficiency and strategic investments in high-growth areas. These results position us well for the remainder of 2025.",
        "category": "Technology",
        "imageUrl": "7.jpg",
        "tags": ["Finance", "Q1", "Results", "Revenue", "Performance"],
        "author": "Finance Department",
        "status": "published",
        "source": "Financial Communications",
        "likes": 78,
        "views": 234,
        "shares": 28,
        "favorites": 41,
        "usages": 15
    },
    {
        "title": "New Sustainability Initiative Reduces Carbon Footprint by 30%",
        "description": "Our comprehensive sustainability program has achieved a 30% reduction in carbon emissions through renewable energy adoption, waste reduction, and green technology implementations.",
        "summary": "Sustainability initiative achieves 30% carbon footprint reduction through green initiatives",
        "type": "news",
        "content": "We are proud to announce the success of our company-wide sustainability initiative, which has resulted in a 30% reduction in our carbon footprint over the past year. This achievement was made possible through the implementation of renewable energy sources, comprehensive waste reduction programs, and the adoption of green technologies across our facilities. The initiative also includes employee engagement programs and partnerships with environmental organizations.",
        "category": "Business",
        "tags": ["Sustainability", "Environment", "Carbon", "Green", "Initiative"],
        "author": "Sustainability Team",
        "status": "published",
        "imageUrl": "8.jpg",
        "source": "Corporate Communications",
        "likes": 92,
        "views": 187,
        "shares": 35,
        "favorites": 56,
        "usages": 22
    },
    {
        "title": "Employee Wellness Program Expansion Announced",
        "description": "The company is expanding its employee wellness program to include mental health support, fitness facilities, and flexible work arrangements to promote work-life balance.",
        "summary": "Wellness program expands with mental health support, fitness facilities, and flexible work",
        "type": "news",
        "content": "As part of our commitment to employee well-being, we are excited to announce a significant expansion of our wellness program. The enhanced program will include on-site mental health counseling services, state-of-the-art fitness facilities at all major locations, flexible work arrangements including hybrid and remote options, and comprehensive health screenings. These additions reflect our understanding that employee wellness is fundamental to our collective success.",
        "category": "Development",
        "tags": ["Wellness", "Employee", "Health", "Mental Health", "Work-Life Balance"],
        "author": "HR Team",
        "status": "published",
        "source": "Human Resources",
        "likes": 134,
        "views": 298,
        "shares": 67,
        "favorites": 89,
        "usages": 45
    },
    {
        "title": "Article-Partnership with Global Tech Leader Announced",
        "description": "The company has formed a strategic partnership with a leading global technology firm to accelerate innovation in cloud computing and digital transformation solutions.",
        "summary": "Strategic partnership formed with global tech leader for cloud and digital transformation",
        "type": "article",
        "content": "We are thrilled to announce a strategic partnership with one of the world's leading technology companies. This collaboration will focus on accelerating innovation in cloud computing, artificial intelligence, and digital transformation solutions. The partnership will enable us to leverage cutting-edge technologies, expand our service offerings, and provide enhanced value to our clients. Joint research and development initiatives are already underway, with the first collaborative solutions expected to launch in Q3 2025.",
        "category": "Business",
        "tags": ["Partnership", "Technology", "Cloud", "Innovation", "Digital Transformation"],
        "author": "Business Development",
        "status": "published",
        "source": "Corporate Communications",
        "likes": 67,
        "views": 201,
        "shares": 19,
        "favorites": 34,
        "usages": 11
    },
    {
            "title": "New API Features Released",
            "description": "Latest API enhancements include improved authentication and performance optimizations",
            "summary": "API enhanced with OAuth 2.0 support, rate limiting, and improved documentation",
            "type": "news",
            "content": "We're excited to announce new API features including OAuth 2.0 support, rate limiting improvements, and enhanced documentation.",
            "url": "https://news.example.com/api-features-release",
            "imageUrl": "1.jpg",
            "tags": ["api", "features", "release", "authentication"],
            "author": "Product Team",
            "status": "published",
            "category": "Company",
            "likes": 95,
            "usages": 180,
            "favorites": 52,
            "views": 650,
            "shares": 38,
            "approved_by": "product.manager@company.com",
            "reviewed_by": "communications.team@company.com",
            "source": "Product Management"
        },
        {
            "title": "Security Update: Enhanced Protection Measures",
            "description": "Important security updates to strengthen application protection",
            "summary": "Security strengthened with advanced threat detection and improved encryption",
            "type": "news",
            "content": "New security measures have been implemented including advanced threat detection, improved encryption, and enhanced monitoring capabilities.",
            "url": "https://news.example.com/security-updates",
            "imageUrl": "2.jpg",
            "tags": ["security", "updates", "protection", "encryption"],
            "author": "Security Team",
            "status": "published",
            "category": "Technology",
            "likes": 78,
            "usages": 145,
            "favorites": 43,
            "views": 520,
            "shares": 29,
            "approved_by": "security.lead@company.com",
            "reviewed_by": "communications.team@company.com",
            "source": "Information Security"
        },
        {
            "title": "Platform Performance Improvements",
            "description": "System-wide performance optimizations deployed for better user experience",
            "summary": "Platform performance boosted with faster APIs and optimized database queries",
            "type": "news",
            "content": "We've successfully deployed major performance improvements including faster API response times, optimized database queries, and enhanced caching mechanisms.",
            "url": "https://news.example.com/performance-improvements",
            "imageUrl": "5.jpg",
            "tags": ["performance", "optimization", "speed", "improvements"],
            "author": "Engineering Team",
            "status": "published",
            "category": "Business",
            "likes": 112,
            "usages": 205,
            "favorites": 68,
            "views": 780,
            "shares": 45,
            "approved_by": "engineering.lead@company.com",
            "reviewed_by": "communications.team@company.com",
            "source": "Engineering Department"
        },
        {
            "title": "New Integration Partners Announced",
            "description": "Expanding our ecosystem with new third-party integrations and partnerships",
            "summary": "New integrations with Slack, Microsoft Teams, and Jira for enhanced workflows",
            "type": "news",
            "content": "We're excited to announce new partnerships and integrations with leading tools including Slack, Microsoft Teams, and Jira for enhanced workflow automation.",
            "url": "https://news.example.com/new-integrations",
            "imageUrl": "6.jpg",
            "tags": ["integrations", "partnerships", "collaboration", "workflow"],
            "author": "Partnerships Team",
            "status": "published",
            "category": "Developers",
            "likes": 134,
            "usages": 268,
            "favorites": 89,
            "views": 920,
            "shares": 67,
            "approved_by": "partnerships.manager@company.com",
            "reviewed_by": "communications.team@company.com",
            "source": "Business Development"
        }
]

async def init_db():
    """Initialize database with default admin user, sample users, and sample catalog items"""
    # First, create the database tables
    print("Creating database tables...")
    await create_tables()
    print("Database tables created successfully!")
    
    # Check if CSV file exists and load users from it
    csv_file_path = "users.csv"
    if os.path.exists(csv_file_path):
        print(f"\n📋 Found CSV file: {csv_file_path}")
        print("Loading users from CSV file...")
        await load_users_from_csv_file(csv_file_path)
    else:
        print(f"\nℹ️  No CSV file found ({csv_file_path}). Skipping CSV user import.")
    
    async with async_session() as db:
        # Create admin user
        admin_user = await crud.user.get_by_user_id(db, user_id=ADMIN_USER_ID)
        
        if not admin_user:
            print(f"\nCreating default admin user: {ADMIN_EMAIL}")
            
            # Create admin user
            admin_user_in = UserCreate(
                user_id=ADMIN_USER_ID,
                email=ADMIN_EMAIL,
                password=ADMIN_PASSWORD,
                first_name=ADMIN_FIRST_NAME,
                last_name=ADMIN_LAST_NAME,
                role=UserRole.ADMIN,
                is_superuser=True,
                is_active=True,
                email_verified=True,
                designation="administrator"
            )
            
            admin_user = await crud.user.create(db, obj_in=admin_user_in)
            print(f"✅ Admin user created with ID: {admin_user.id}")
            print(f"   User ID: {ADMIN_USER_ID}, Password: {ADMIN_PASSWORD}")
        else:
            print(f"ℹ️  Admin user already exists: {ADMIN_USER_ID}")

        # Create sample users (only if no CSV was loaded)
        if not os.path.exists(csv_file_path):
            print("\n📝 Creating sample users...")
            for user_data in SAMPLE_USERS:
                existing_user = await crud.user.get_by_user_id(db, user_id=user_data["user_id"])
                
                if not existing_user:
                    user_in = UserCreate(**user_data)
                    new_user = await crud.user.create(db, obj_in=user_in)
                    
                    user_type_icon = "👔" if user_data["user_type"] == "employee" else "🔧"
                    print(f"✅ {user_type_icon} Created {user_data['user_type']}: {user_data['first_name']} {user_data['last_name']}")
                    print(f"   User ID: {user_data['user_id']}, Password: {user_data['password']}")
                    print(f"   Email: {user_data['email']}")
                    print(f"   Organization: {user_data['organization_id']}, Cost Center: {user_data['costcenter_id']}")
                else:
                    print(f"ℹ️  User already exists: {user_data['user_id']}")
        else:
            print("\n✅ Users loaded from CSV file. Skipping sample user creation.")

        # Create sample catalog news items
        print("\n📰 Creating sample news items...")
        for news_data in SAMPLE_NEWS:
            # Check if news item already exists by title
            search_params = CatalogSearch(query=news_data["title"], limit=1, offset=0)
            existing_items, _ = await crud.catalog.search(db, search_params=search_params)
            
            if not existing_items:
                catalog_in = CatalogCreate(**news_data)
                new_catalog = await crud.catalog.create(db, obj_in=catalog_in)
                print(f"✅ 📰 Created news: {news_data['title'][:50]}...")
                print(f"   Category: {news_data['category']}, Status: {news_data['status']}")
                print(f"   Author: {news_data['author']}")
                print(f"   Stats: {news_data['likes']} likes, {news_data['views']} views")
            else:
                print(f"ℹ️  News item already exists: {news_data['title'][:50]}...")

        print("\n🎉 Database initialization completed!")
        print("\n📋 Summary of created content:")
        print("─" * 60)
        print("👑 ADMIN USER:")
        print(f"   User ID: {ADMIN_USER_ID}")
        print(f"   Password: {ADMIN_PASSWORD}")
        print(f"   Email: {ADMIN_EMAIL}")
        
        if os.path.exists(csv_file_path):
            print(f"\n👥 USERS: Loaded from {csv_file_path}")
        else:
            print("\n👥 SAMPLE USERS:")
            for user in SAMPLE_USERS:
                print(f"   User ID: {user['user_id']}, Password: {user['password']}")
        
        print(f"\n📰 SAMPLE NEWS ITEMS: {len(SAMPLE_NEWS)} news articles created")
        print("   - Company AI Analytics Platform Launch")
        print("   - Q1 2025 Financial Results")
        print("   - Sustainability Initiative Success")
        print("   - Employee Wellness Program Expansion")
        print("   - Strategic Technology Partnership")
        print("─" * 60)

if __name__ == "__main__":
    print("🚀 Initializing database with sample users and catalog content...")
    asyncio.run(init_db())
    print("✅ Database initialization complete!")
import openpyxl
from sqlalchemy.orm import Session
from main import engine, AllTables

def load_data():
    # Load the existing Excel file with data
    data_file = "all_tables_data.xlsx"
    workbook = openpyxl.load_workbook(data_file)
    sheet = workbook.active

    # Validate the number of columns
    expected_columns = 12  # Updated to match the actual number of columns in the Excel file
    actual_columns = sheet.max_column
    if actual_columns != expected_columns:
        raise ValueError(f"Expected {expected_columns} columns, but found {actual_columns} columns in the Excel file.")

    # Map column names dynamically
    headers = {cell.value: idx for idx, cell in enumerate(sheet[1], start=0)}

    # Read data from the Excel sheet and insert into the database
    session = Session(bind=engine)

    # Re-added the deletion of existing data to ensure fresh data is loaded each time
    session.query(AllTables).delete()
    session.commit()

    for row in sheet.iter_rows(min_row=2, values_only=True):  # Skip the header row
        entry = AllTables(
            key=row[headers.get("key")],
            type=row[headers.get("type")],
            table=row[headers.get("table")],
            name=row[headers.get("name")],
            data_type=row[headers.get("type")],
            description=row[headers.get("description")],
            custom=None,  # Assuming custom data is not provided in the Excel file
            updated_by=None,  # Assuming updated_by is not provided in the Excel file
            created_by=None,  # Assuming created_by is not provided in the Excel file
            display_name=row[headers.get("displayName")],
            ordinal=row[headers.get("ordinal")],
            precision=row[headers.get("precision")],
            parse_format=row[headers.get("parseFormat")],
            required=row[headers.get("required")],
            external_id=row[headers.get("externalId")]
        )
        session.add(entry)

    session.commit()

    # Load summary
    num_rows = sheet.max_row - 1  # Exclude header row
    num_tables = len(set(row[headers.get("table")] for row in sheet.iter_rows(min_row=2, values_only=True) if row[headers.get("key")] == "TABLE"))
    num_columns = len([row for row in sheet.iter_rows(min_row=2, values_only=True) if row[headers.get("key")] == "COLUMN"])

    session.close()

    print(f"Data from '{data_file}' loaded into the database successfully!")
    print(f"Summary:")
    print(f"- Number of rows: {num_rows}")
    print(f"- Number of tables: {num_tables}")
    print(f"- Number of columns: {num_columns}")

if __name__ == "__main__":
    load_data()
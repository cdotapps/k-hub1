from fastapi import FastAPI, HTTPException, Depends, Security
from sqlalchemy import create_engine, MetaData, Table, Column, Integer, String, DateTime
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker
from datetime import datetime
from sqlalchemy.dialects.sqlite import JSON
from pydantic import BaseModel
from fastapi.security import OAuth2PasswordBearer, APIKeyHeader
import secrets
from fastapi.middleware.cors import CORSMiddleware

# Database setup
DATABASE_URL = "sqlite:///./wd.db"
engine = create_engine(DATABASE_URL)
metadata = MetaData()
Base = declarative_base()
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)

# Updated the `AllTables` table structure to align with the new columns
class AllTables(Base):
    __tablename__ = "all_tables"

    id = Column(Integer, primary_key=True, index=True, autoincrement=True)
    key=Column(String, index=True)
    type = Column(String, index=True)
    table = Column(String, index=True)  # Added `table` column
    name = Column(String, index=True)
    data_type = Column(String, index=True, nullable=True)
    description = Column(String, nullable=True)
    custom = Column(JSON, nullable=True)
    updated_by = Column(String, nullable=True, default=None)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    created_by = Column(String, nullable=True, default=None)
    created_at = Column(DateTime, default=datetime.utcnow)
    display_name = Column(String, nullable=True)
    ordinal = Column(Integer, nullable=True)
    precision = Column(Integer, nullable=True)
    parse_format = Column(String, nullable=True)
    required = Column(String, nullable=True)
    external_id = Column(String, nullable=True)

# Remove the drop_all call to prevent dropping the table
# Instead, delete all existing data in the table before reinserting
from sqlalchemy.orm import Session


# Drop the existing table if it exists and recreate it with the updated schema
Base.metadata.drop_all(bind=engine, tables=[AllTables.__table__])
Base.metadata.create_all(bind=engine, tables=[AllTables.__table__])

# Pydantic models for request validation
class AllTablesCreate(BaseModel):
    type: str
    table: str
    name: str
    data_type: str
    description: str = None
    custom: dict = None
    created_by: str

class AllTablesPatch(BaseModel):
    type: str = None
    table: str = None
    name: str = None
    data_type: str = None
    description: str = None
    custom: dict = None
    updated_by: str

class CustomData(BaseModel):
    custom: dict

# Token generation setup
oauth2_scheme = OAuth2PasswordBearer(tokenUrl="token")

def generate_token():
    return secrets.token_hex(16)

# API Key setup
API_KEY_NAME = "Authorization"
api_key_header = APIKeyHeader(name=API_KEY_NAME, auto_error=True)

def verify_token(api_key: str = Security(api_key_header)):
    # Replace 'your_token_here' with the actual token to validate
    expected_token = "your_token_here"
    if api_key != expected_token:
        raise HTTPException(status_code=403, detail="Invalid or missing token")

# FastAPI app
app = FastAPI()

# Add CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:4200"],  # Allow requests from the Angular frontend
    allow_credentials=True,
    allow_methods=["*"],  # Allow all HTTP methods
    allow_headers=["*"],  # Allow all headers
)

@app.get("/")
def read_root():
    return {"message": "Welcome to the FastAPI application!"}

@app.post("/all_tables/")
def create_all_table(data: AllTablesCreate):
    db = SessionLocal()
    new_entry = AllTables(
        type=data.type,
        table=data.table,
        name=data.name,
        data_type=data.data_type,
        description=data.description,
        custom=data.custom,
        created_by=data.created_by
    )
    db.add(new_entry)
    db.commit()
    db.refresh(new_entry)
    db.close()
    return {"message": "Entry created successfully!", "entry": new_entry}

@app.patch("/all_tables/{entry_id}")
def patch_all_table(entry_id: int, data: AllTablesPatch):
    db = SessionLocal()
    entry = db.query(AllTables).filter(AllTables.id == entry_id).first()
    if not entry:
        db.close()
        raise HTTPException(status_code=404, detail="Entry not found")

    for key, value in data.dict(exclude_unset=True).items():
        setattr(entry, key, value)
    entry.updated_at = datetime.utcnow()
    db.commit()
    db.refresh(entry)
    db.close()
    return {"message": "Entry updated successfully!", "entry": entry}

@app.get("/custom/{entry_id}")
def get_custom(entry_id: int):
    db = SessionLocal()
    entry = db.query(AllTables).filter(AllTables.id == entry_id).first()
    if not entry:
        db.close()
        raise HTTPException(status_code=404, detail="Entry not found")
    db.close()
    return {"custom": entry.custom}

@app.post("/custom/{entry_id}")
def post_custom(entry_id: int, data: CustomData):
    db = SessionLocal()
    entry = db.query(AllTables).filter(AllTables.id == entry_id).first()
    if not entry:
        db.close()
        raise HTTPException(status_code=404, detail="Entry not found")

    entry.custom = data.custom
    entry.updated_at = datetime.utcnow()
    db.commit()
    db.refresh(entry)
    db.close()
    return {"message": "Custom data updated successfully!", "entry": entry}

@app.get("/all_tables/")
def get_all_tables():
    db = SessionLocal()
    entries = db.query(AllTables).all()
    db.close()
    return {"entries": entries}

@app.get("/get_token/")
def get_token():
    token = generate_token()
    return {"token": token}

@app.post("/wd_service/action")
def update_table_action(api_key: str = Security(verify_token)):
    # Logic to update the table
    session = SessionLocal()
    session.query(AllTables).delete()  # Example: Clear the table
    session.commit()
    session.close()
    return {"message": "Table has been updated"}
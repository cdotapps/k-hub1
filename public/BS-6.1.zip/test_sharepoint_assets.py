#!/usr/bin/env python3
"""
Test script for SharePoint Asset Management API
This script demonstrates how to use the asset management endpoints
"""

import asyncio
import json
from app.services.sharepoint_asset_service import SharePointAsset, SharePointConfig, sharepoint_asset_service

async def test_sharepoint_service():
    """Test the SharePoint asset service directly"""
    
    print("🧪 Testing SharePoint Asset Management Service")
    print("=" * 50)
    
    # Example configuration (you'll need to replace with real values)
    config = SharePointConfig(
        site_url="https://yourcompany.sharepoint.com/sites/yoursite",
        list_name="Assets",
        client_id="your-azure-app-client-id",
        client_secret="your-azure-app-client-secret", 
        tenant_id="your-tenant-id"
    )
    
    print("📝 Note: This is a demo script. To actually run:")
    print("1. Replace the SharePoint configuration above with your real values")
    print("2. Set up your SharePoint list and Azure AD app (see SHAREPOINT_ASSET_SETUP.md)")
    print("3. Run this script")
    print()
    
    # Configure the service
    sharepoint_asset_service.configure(config)
    
    # Example asset data
    test_asset = SharePointAsset(
        AssetID="TEST-001",
        AssetName="Test Server",
        Business="IT",
        Block="Infrastructure",
        Capability="Server Management",
        AssetType="Hardware",
        AssetStatus="Active",
        SizeAttributes=json.dumps({"cpu_cores": 8, "ram_gb": 32, "storage_tb": 2}),
        Description="Test server for development environment",
        Location="Data Center 1",
        Owner="IT Team",
        ContactPerson="John Doe",
        ContactEmail="john.doe@company.com",
        Cost=5000.0,
        Currency="USD",
        Vendor="Dell",
        Model="PowerEdge R740",
        Version="Gen 14",
        Tags=json.dumps(["server", "development", "test"]),
        RiskLevel="Low",
        Criticality="Medium"
    )
    
    print("📊 Test Asset Data:")
    print(f"   Asset ID: {test_asset.AssetID}")
    print(f"   Name: {test_asset.AssetName}")
    print(f"   Business: {test_asset.Business}")
    print(f"   Type: {test_asset.AssetType}")
    print(f"   Status: {test_asset.AssetStatus}")
    print()
    
    # Uncomment the following lines to actually test with SharePoint
    # (after configuring your SharePoint settings)
    
    """
    try:
        print("🔗 Testing SharePoint connection...")
        
        # Test connection
        token = await sharepoint_asset_service.get_access_token()
        print("✅ Successfully obtained access token")
        
        # Get all assets
        print("📋 Fetching all assets...")
        assets = await sharepoint_asset_service.get_all_assets()
        print(f"✅ Found {len(assets)} assets in SharePoint")
        
        # Create test asset
        print("➕ Creating test asset...")
        created_asset = await sharepoint_asset_service.create_asset(test_asset)
        print(f"✅ Created asset with SharePoint ID: {created_asset.Id}")
        
        # Get asset by ID
        print("🔍 Retrieving asset by business ID...")
        retrieved_asset = await sharepoint_asset_service.get_asset(test_asset.AssetID)
        if retrieved_asset:
            print(f"✅ Retrieved asset: {retrieved_asset.AssetName}")
        
        # Update asset
        print("✏️  Updating asset...")
        retrieved_asset.Description = "Updated test server description"
        updated_asset = await sharepoint_asset_service.update_asset(retrieved_asset.Id, retrieved_asset)
        print(f"✅ Updated asset: {updated_asset.AssetName}")
        
        # Search assets
        print("🔍 Searching assets...")
        search_results = await sharepoint_asset_service.search_assets({"business": "IT"})
        print(f"✅ Found {len(search_results)} assets for business 'IT'")
        
        # Get statistics
        print("📊 Getting statistics...")
        stats = await sharepoint_asset_service.get_statistics()
        print(f"✅ Statistics: {stats['total_assets']} total assets")
        
        # Clean up - delete test asset
        print("🗑️  Cleaning up test asset...")
        await sharepoint_asset_service.delete_asset(created_asset.Id)
        print("✅ Test asset deleted")
        
        print()
        print("🎉 All tests passed! SharePoint integration is working correctly.")
        
    except Exception as e:
        print(f"❌ Error: {str(e)}")
        print("Please check your SharePoint configuration and setup.")
    """

def main():
    """Main function"""
    print("SharePoint Asset Management Test")
    print("To run actual tests, configure SharePoint settings and uncomment test code.")
    
    # Run async test
    asyncio.run(test_sharepoint_service())

if __name__ == "__main__":
    main()

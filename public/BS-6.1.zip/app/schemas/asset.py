from typing import Optional, List, Dict, Any
from pydantic import BaseModel, Field, validator
from datetime import datetime
from enum import Enum

class AssetStatusEnum(str, Enum):
    ACTIVE = "active"
    INACTIVE = "inactive"
    MAINTENANCE = "maintenance"
    DECOMMISSIONED = "decommissioned"
    PENDING = "pending"
    RETIRED = "retired"

class AssetTypeEnum(str, Enum):
    HARDWARE = "hardware"
    SOFTWARE = "software"
    SERVICE = "service"
    INFRASTRUCTURE = "infrastructure"
    APPLICATION = "application"
    DATABASE = "database"
    NETWORK = "network"
    SECURITY = "security"
    OTHER = "other"

class RiskLevelEnum(str, Enum):
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"
    CRITICAL = "critical"

class CriticalityEnum(str, Enum):
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"
    CRITICAL = "critical"

class AssetBase(BaseModel):
    asset_id: Optional[str] = Field(None, description="Business Asset ID")
    asset_name: Optional[str] = Field(None, description="Asset Name")
    business: Optional[str] = Field(None, description="Business unit")
    block: Optional[str] = Field(None, description="Block or department")
    capability: Optional[str] = Field(None, description="Capability area")
    asset_type: Optional[str] = Field(None, description="Asset Type")
    asset_status: Optional[str] = Field(None, description="Asset Status")
    
    # Size attributes
    size_attributes: Optional[Dict[str, Any]] = Field(default=None, description="Various size metrics")
    
    # Additional metadata
    description: Optional[str] = Field(None, description="Detailed description")
    location: Optional[str] = Field(None, description="Physical or logical location")
    owner: Optional[str] = Field(None, description="Asset owner")
    contact_person: Optional[str] = Field(None, description="Primary contact")
    contact_email: Optional[str] = Field(None, description="Contact email")
    
    # Financial information
    cost: Optional[float] = Field(None, description="Asset cost")
    currency: Optional[str] = Field("USD", description="Currency")
    
    # Lifecycle information
    purchase_date: Optional[datetime] = Field(None, description="Purchase/acquisition date")
    installation_date: Optional[datetime] = Field(None, description="Installation date")
    warranty_expiry: Optional[datetime] = Field(None, description="Warranty expiry date")
    end_of_life: Optional[datetime] = Field(None, description="End of life date")
    
    # Technical specifications
    vendor: Optional[str] = Field(None, description="Vendor/manufacturer")
    model: Optional[str] = Field(None, description="Model number")
    version: Optional[str] = Field(None, description="Version")
    specifications: Optional[Dict[str, Any]] = Field(default=None, description="Technical specifications")
    
    # Dependencies and relationships
    dependencies: Optional[List[str]] = Field(default=None, description="Asset dependencies")
    tags: Optional[List[str]] = Field(default=None, description="Tags for categorization")
    
    # Compliance and governance
    compliance_requirements: Optional[List[str]] = Field(default=None, description="Compliance requirements")
    risk_level: Optional[str] = Field(None, description="Risk assessment level")
    criticality: Optional[str] = Field(None, description="Business criticality")
    
    # Audit fields
    created_date: Optional[datetime] = Field(None, description="Creation date")
    updated_date: Optional[datetime] = Field(None, description="Last update date")
    created_by: Optional[str] = Field(None, description="User who created the record")
    updated_by: Optional[str] = Field(None, description="User who last updated the record")
    
    # Custom fields
    custom_fields: Optional[Dict[str, Any]] = Field(default=None, description="Custom fields")

    @validator('contact_email')
    def validate_email(cls, v):
        if v and '@' not in v:
            raise ValueError('Invalid email format')
        return v

    @validator('cost')
    def validate_cost(cls, v):
        if v is not None and v < 0:
            raise ValueError('Cost cannot be negative')
        return v

class AssetCreate(AssetBase):
    asset_id: str = Field(..., description="Business Asset ID")
    asset_name: str = Field(..., description="Asset Name")
    business: str = Field(..., description="Business unit")
    asset_type: str = Field(..., description="Asset Type")
    asset_status: str = Field(default="active", description="Asset Status")

class AssetUpdate(AssetBase):
    pass

class Asset(AssetBase):
    id: str = Field(..., description="Internal system ID")
    
    class Config:
        from_attributes = True

class AssetSearch(BaseModel):
    business: Optional[str] = Field(None, description="Filter by business unit")
    block: Optional[str] = Field(None, description="Filter by block")
    capability: Optional[str] = Field(None, description="Filter by capability")
    asset_type: Optional[str] = Field(None, description="Filter by asset type")
    asset_status: Optional[str] = Field(None, description="Filter by asset status")
    owner: Optional[str] = Field(None, description="Filter by owner")
    vendor: Optional[str] = Field(None, description="Filter by vendor")
    risk_level: Optional[str] = Field(None, description="Filter by risk level")
    criticality: Optional[str] = Field(None, description="Filter by criticality")
    location: Optional[str] = Field(None, description="Filter by location")
    tags: Optional[List[str]] = Field(None, description="Filter by tags")
    search_term: Optional[str] = Field(None, description="General search term")
    
    # Date range filters
    purchase_date_from: Optional[datetime] = Field(None, description="Purchase date from")
    purchase_date_to: Optional[datetime] = Field(None, description="Purchase date to")
    warranty_expiry_from: Optional[datetime] = Field(None, description="Warranty expiry from")
    warranty_expiry_to: Optional[datetime] = Field(None, description="Warranty expiry to")
    
    # Cost range filters
    cost_min: Optional[float] = Field(None, description="Minimum cost")
    cost_max: Optional[float] = Field(None, description="Maximum cost")

class AssetBulkOperation(BaseModel):
    asset_ids: List[str] = Field(..., description="List of asset IDs to operate on")
    operation: str = Field(..., description="Operation to perform (update_status, update_owner, etc.)")
    parameters: Dict[str, Any] = Field(..., description="Operation parameters")

"""
Configuration settings loaded from environment variables
"""
import os
from typing import Optional
from pydantic_settings import BaseSettings
from dotenv import load_dotenv

# Load environment variables from .env file
load_dotenv()


class Settings(BaseSettings):
    """Application settings"""
    
    # Application Settings
    app_name: str = "User Auth API"
    debug: bool = False
    api_v1_prefix: str = "/api/v1"
    
    # Security
    secret_key: str
    algorithm: str = "HS256"
    access_token_expire_minutes: int = 30
    
    # Database
    database_url: str
    
    # Server Settings
    port: int = 8000
    host: str = "0.0.0.0"
    
    # SharePoint Configuration
    sharepoint_site_url: Optional[str] = None
    sharepoint_list_name: str = "Assets"
    sharepoint_client_id: Optional[str] = None
    sharepoint_client_secret: Optional[str] = None
    sharepoint_tenant_id: Optional[str] = None
    
    class Config:
        env_file = ".env"
        case_sensitive = False


class SharePointSettings(BaseSettings):
    """SharePoint-specific settings"""
    
    site_url: str
    list_name: str = "Assets"
    client_id: str
    client_secret: str
    tenant_id: str
    
    class Config:
        env_prefix = "SHAREPOINT_"
        case_sensitive = False


def get_settings() -> Settings:
    """Get application settings"""
    return Settings()


def get_sharepoint_settings() -> Optional[SharePointSettings]:
    """Get SharePoint settings if configured"""
    try:
        # Check if all required SharePoint settings are present
        required_vars = [
            "SHAREPOINT_SITE_URL",
            "SHAREPOINT_CLIENT_ID", 
            "SHAREPOINT_CLIENT_SECRET",
            "SHAREPOINT_TENANT_ID"
        ]
        
        missing_vars = [var for var in required_vars if not os.getenv(var)]
        
        if missing_vars:
            print(f"⚠️  SharePoint configuration incomplete. Missing: {', '.join(missing_vars)}")
            return None
            
        return SharePointSettings()
    except Exception as e:
        print(f"❌ Error loading SharePoint configuration: {e}")
        return None


# Global settings instance
settings = get_settings()
sharepoint_settings = get_sharepoint_settings()

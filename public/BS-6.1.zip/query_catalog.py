import asyncio
import json
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import text
from app.db.session import async_session
from app.crud.crud_catalog import catalog
from app.models.catalog import Catalog

# Define valid statuses as per your requirements
VALID_STATUSES = [
    '',  # Empty for 'All Statuses' filter
    'draft',
    'under-review',
    'reviewed',
    'feedback-loop',
    'revised',
    'pending-approval',
    'approved',
    'published',
    'archived'
]

# Status mapping for migration (old -> new)
STATUS_MIGRATION_MAP = {
    'pending-approval': 'under-review',
    'pending-approval': 'under-review',
    'under_review': 'under-review',
    'rejected': 'feedback-loop',
    'feedback_loop': 'feedback-loop',
    'feedback-loop': 'feedback-loop',  # Already correct
    'under-review': 'under-review',    # Already correct
    # Clean up whitespace issues
    ' draft ': 'draft',
    ' draft': 'draft',
    'draft ': 'draft',
    ' published ': 'published',
    ' published': 'published',
    'published ': 'published',
    ' under-review ': 'under-review',
    ' reviewed ': 'reviewed',
    ' feedback-loop ': 'feedback-loop',
    ' revised ': 'revised',
    ' approved ': 'approved',
    ' archived ': 'archived',
}

async def validate_catalog_statuses():
    """Validate and report on catalog status alignment"""
    async with async_session() as db:
        try:
            # Get all unique statuses in the database
            result = await db.execute(text("SELECT DISTINCT status, COUNT(*) as count FROM catalogs GROUP BY status ORDER BY count DESC"))
            status_counts = result.fetchall()
            
            print("📊 CATALOG STATUS ANALYSIS")
            print("=" * 50)
            print(f"Total unique statuses found: {len(status_counts)}")
            print()
            
            valid_count = 0
            invalid_count = 0
            migration_needed = []
            
            for status_row in status_counts:
                status_value = status_row[0]
                count = status_row[1]
                
                if status_value in VALID_STATUSES:
                    print(f"✅ VALID: '{status_value}' ({count} items)")
                    valid_count += count
                elif status_value in STATUS_MIGRATION_MAP:
                    new_status = STATUS_MIGRATION_MAP[status_value]
                    print(f"🔄 MIGRATE: '{status_value}' -> '{new_status}' ({count} items)")
                    migration_needed.append((status_value, new_status, count))
                    invalid_count += count
                else:
                    print(f"❌ INVALID: '{status_value}' ({count} items) - NEEDS MANUAL REVIEW")
                    invalid_count += count
            
            print()
            print("📈 SUMMARY")
            print("-" * 30)
            print(f"Valid statuses: {valid_count} items")
            print(f"Need migration/review: {invalid_count} items")
            print(f"Total items: {valid_count + invalid_count}")
            
            if migration_needed:
                print()
                print("🔧 SUGGESTED MIGRATIONS")
                print("-" * 30)
                for old_status, new_status, count in migration_needed:
                    print(f"UPDATE catalogs SET status = '{new_status}' WHERE status = '{old_status}'; -- {count} items")
            
            print()
            print("✨ REQUIRED VALID STATUSES")
            print("-" * 30)
            for status in VALID_STATUSES:
                if status == '':
                    print(f"  '' (empty string for 'All Statuses' filter)")
                else:
                    print(f"  '{status}'")
                    
            return status_counts, migration_needed
            
        except Exception as e:
            print(f"❌ Error validating catalog statuses: {str(e)}")
            return [], []

async def migrate_catalog_statuses(dry_run=True):
    """Migrate catalog statuses to align with valid values"""
    async with async_session() as db:
        try:
            print("🔄 CATALOG STATUS MIGRATION")
            print("=" * 50)
            print(f"Mode: {'DRY RUN' if dry_run else 'EXECUTE'}")
            print()
            
            migrations_performed = 0
            
            for old_status, new_status in STATUS_MIGRATION_MAP.items():
                # Check if there are items with this old status
                result = await db.execute(text("SELECT COUNT(*) FROM catalogs WHERE status = :old_status"), {"old_status": old_status})
                count = result.scalar()
                
                if count > 0:
                    print(f"🔄 Migrating '{old_status}' -> '{new_status}' ({count} items)")
                    
                    if not dry_run:
                        # Perform the actual migration
                        await db.execute(
                            text("UPDATE catalogs SET status = :new_status WHERE status = :old_status"),
                            {"new_status": new_status, "old_status": old_status}
                        )
                        await db.commit()
                        migrations_performed += 1
                    else:
                        print(f"   SQL: UPDATE catalogs SET status = '{new_status}' WHERE status = '{old_status}';")
            
            if not dry_run and migrations_performed > 0:
                print(f"✅ Successfully migrated {migrations_performed} status types")
            elif dry_run:
                print("📝 This was a dry run. Use migrate_catalog_statuses(dry_run=False) to execute.")
            else:
                print("ℹ️  No migrations needed - all statuses are already aligned")
                
        except Exception as e:
            print(f"❌ Error migrating catalog statuses: {str(e)}")

async def get_catalog_by_id_with_status_check(catalog_id: str):
    """Query and display catalog data by ID with status validation"""
    async with async_session() as db:
        try:
            # Get the catalog item
            catalog_item = await catalog.get(db, id=catalog_id)
            
            if catalog_item:
                print(f"Found catalog item with ID: {catalog_id}")
                print("=" * 50)
                
                # Check status validity first
                status_valid = catalog_item.status in VALID_STATUSES
                print(f"📋 STATUS VALIDATION")
                print(f"Current Status: '{catalog_item.status}'")
                print(f"Status Valid: {'✅ YES' if status_valid else '❌ NO'}")
                
                if not status_valid:
                    if catalog_item.status in STATUS_MIGRATION_MAP:
                        suggested = STATUS_MIGRATION_MAP[catalog_item.status]
                        print(f"Suggested Migration: '{catalog_item.status}' -> '{suggested}'")
                    else:
                        print(f"⚠️  Manual review needed - unknown status")
                
                print()
                
                # Display all fields
                print(f"📝 CATALOG DETAILS")
                print(f"ID: {catalog_item.id}")
                print(f"Title: {catalog_item.title}")
                print(f"Description: {catalog_item.description}")
                print(f"Summary: {catalog_item.summary}")
                print(f"Type: {catalog_item.type}")
                print(f"Content: {catalog_item.content}")
                print(f"URL: {catalog_item.url}")
                print(f"Image: {catalog_item.image}")
                print(f"Image URL: {catalog_item.imageUrl}")
                print(f"Display: {catalog_item.display}")
                print(f"Tags: {catalog_item.tags}")
                print(f"Author: {catalog_item.author}")
                print(f"Author ID: {catalog_item.author_id}")
                print(f"Created Date: {catalog_item.created_date}")
                print(f"Updated Date: {catalog_item.updated_date}")
                print(f"Expire Date: {catalog_item.expire_date}")
                print(f"Due Date: {catalog_item.due_date}")
                print(f"Category: {catalog_item.category}")
                print(f"Parent ID: {catalog_item.parent_id}")
                print(f"Child IDs: {catalog_item.child_ids}")
                print(f"Priority: {catalog_item.priority}")
                print(f"Severity: {catalog_item.severity}")
                print(f"Urgent: {catalog_item.urgent}")
                print(f"Important: {catalog_item.important}")
                print(f"Likes: {catalog_item.likes}")
                print(f"Usages: {catalog_item.usages}")
                print(f"Favorites: {catalog_item.favorites}")
                print(f"Views: {catalog_item.views}")
                print(f"Shares: {catalog_item.shares}")
                print(f"Approved By: {catalog_item.approved_by}")
                print(f"Reviewed By: {catalog_item.reviewed_by}")
                print(f"Source: {catalog_item.source}")
                print(f"Status: {catalog_item.status}")
                print(f"Private: {catalog_item.private}")
                print(f"Shared With: {catalog_item.shared_with}")
                print(f"Conversations: {catalog_item.conversations}")
                
                # Display custom fields in a formatted way
                if catalog_item.custom:
                    print("\n🔧 CUSTOM FIELDS")
                    print("-" * 20)
                    for group_name, group_data in catalog_item.custom.items():
                        print(f"  Group: {group_name}")
                        for item in group_data:
                            column = item.get('column', 'N/A')
                            value = item.get('value', 'N/A')
                            print(f"    {column}: {value}")
                        print()
                
                print("=" * 50)
                
                # Also display as JSON for easy copying
                print("\n💾 JSON REPRESENTATION")
                catalog_dict = {
                    "id": catalog_item.id,
                    "title": catalog_item.title,
                    "description": catalog_item.description,
                    "summary": catalog_item.summary,
                    "type": catalog_item.type,
                    "content": catalog_item.content,
                    "url": catalog_item.url,
                    "image": catalog_item.image,
                    "imageUrl": catalog_item.imageUrl,
                    "display": catalog_item.display,
                    "tags": catalog_item.tags,
                    "author": catalog_item.author,
                    "author_id": catalog_item.author_id,
                    "created_date": catalog_item.created_date.isoformat() if catalog_item.created_date else None,
                    "updated_date": catalog_item.updated_date.isoformat() if catalog_item.updated_date else None,
                    "expire_date": catalog_item.expire_date,
                    "due_date": catalog_item.due_date,
                    "custom": catalog_item.custom,
                    "category": catalog_item.category,
                    "parent_id": catalog_item.parent_id,
                    "child_ids": catalog_item.child_ids,
                    "priority": catalog_item.priority,
                    "severity": catalog_item.severity,
                    "urgent": catalog_item.urgent,
                    "important": catalog_item.important,
                    "likes": catalog_item.likes,
                    "usages": catalog_item.usages,
                    "favorites": catalog_item.favorites,
                    "views": catalog_item.views,
                    "shares": catalog_item.shares,
                    "approved_by": catalog_item.approved_by,
                    "reviewed_by": catalog_item.reviewed_by,
                    "source": catalog_item.source,
                    "status": catalog_item.status,
                    "private": catalog_item.private,
                    "shared_with": catalog_item.shared_with,
                    "conversations": catalog_item.conversations
                }
                print(json.dumps(catalog_dict, indent=2, default=str))
                
            else:
                print(f"No catalog item found with ID: {catalog_id}")
                
        except Exception as e:
            print(f"Error querying catalog: {str(e)}")

# Alias the original function for backward compatibility
get_catalog_by_id = get_catalog_by_id_with_status_check

if __name__ == "__main__":
    import sys
    
    if len(sys.argv) > 1:
        command = sys.argv[1]
        
        if command == "validate":
            print("🔍 Validating catalog statuses...")
            asyncio.run(validate_catalog_statuses())
        elif command == "migrate":
            dry_run = "--dry-run" in sys.argv or "-d" in sys.argv
            print("🔄 Migrating catalog statuses...")
            asyncio.run(migrate_catalog_statuses(dry_run=dry_run))
        elif command == "query" and len(sys.argv) > 2:
            catalog_id = sys.argv[2]
            asyncio.run(get_catalog_by_id_with_status_check(catalog_id))
        else:
            print("Usage:")
            print("  python query_catalog.py validate")
            print("  python query_catalog.py migrate [--dry-run]")
            print("  python query_catalog.py query <catalog_id>")
    else:
        # Default behavior - query with the hardcoded ID
        catalog_id = "db1d1828-34a3-4ad6-b5c8-e0bc468379ae"
        asyncio.run(get_catalog_by_id_with_status_check(catalog_id))
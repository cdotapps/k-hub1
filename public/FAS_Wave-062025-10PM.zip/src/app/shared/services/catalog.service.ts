import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable, BehaviorSubject, throwError, timer, Subject } from 'rxjs';
import { map, catchError, switchMap, shareReplay, takeUntil, filter, tap } from 'rxjs/operators';
import { Catalog, CatalogResponse, CatalogCreate, CatalogUpdate, CatalogConversation, ConversationMessage, Webhook, WebhookCreate, WebhookUpdate, WebhookResponse, WebhookTestResult, WebhookEvent } from '../models/user.interface';
import { environment } from '../../../environments/environment';
import { CATALOG_TYPES, filterCatalogTypesByRole } from '../config/site-config';
import { AuthService } from './auth.service';

@Injectable({
  providedIn: 'root'
})
export class CatalogService {
  private readonly API_BASE = `${environment.apiUrl}${environment.apiVersion}`;

  // Add observable streams for reactive data
  private notificationsSubject = new BehaviorSubject<Catalog[]>([]);
  private newsSubject = new BehaviorSubject<Catalog[]>([]);
  
  // Add catalog refresh observable for components to subscribe to
  private catalogRefreshSubject = new BehaviorSubject<boolean>(false);
  private catalogItemsCache = new Map<string, { data: CatalogResponse, timestamp: number }>();
  private lastRefreshTime = 0;
  private refreshIntervalMs = 60000; // Default refresh interval: 1 minute
  private stopPollingSubject = new Subject<void>();
  
  // Expose observables for components
  public notifications$ = this.notificationsSubject.asObservable();
  public news$ = this.newsSubject.asObservable();
  public catalogRefresh$ = this.catalogRefreshSubject.asObservable();

  constructor(
    private http: HttpClient,
    private authService: AuthService
  ) {
    // Start a background refresh cycle with reasonable interval
    this.startPollingForUpdates();
  }
  
  /**
   * Starts polling for catalog updates with a reasonable interval
   * Can be called by components that need frequent updates
   * @param intervalMs Optional custom interval in milliseconds
   */
  startPollingForUpdates(intervalMs?: number): void {
    // Stop any existing polling
    this.stopPollingSubject.next();
    
    // Set custom interval if provided
    if (intervalMs && intervalMs > 0) {
      this.refreshIntervalMs = intervalMs;
    }
    
    // Start polling with the configured interval
    timer(0, this.refreshIntervalMs)
      .pipe(
        takeUntil(this.stopPollingSubject),
        filter(() => this.shouldRefresh())
      )
      .subscribe(() => {
        this.triggerRefresh();
      });
  }

  /**
   * Stops the polling mechanism to prevent unnecessary API calls
   * Can be called when component is destroyed or user navigates away
   */
  stopPollingForUpdates(): void {
    this.stopPollingSubject.next();
  }

  /**
   * Determine if we should refresh based on time elapsed
   * This prevents too frequent refreshes
   */
  private shouldRefresh(): boolean {
    const now = Date.now();
    // Only refresh if it's been at least 30 seconds since last refresh
    return (now - this.lastRefreshTime) > 30000;
  }

  /**
   * Manually trigger a refresh of catalog data
   * Used when immediate refresh is needed (after CRUD operations)
   */
  triggerRefresh(): void {
    this.lastRefreshTime = Date.now();
    this.catalogRefreshSubject.next(true);
    // Clear specific caches that might be affected
    this.clearCacheOlderThan(Date.now() - 60000); // Clear cache older than 1 minute
  }

  /**
   * Clears cache entries older than specified timestamp
   */
  private clearCacheOlderThan(timestamp: number): void {
    for (const [key, value] of this.catalogItemsCache.entries()) {
      if (value.timestamp < timestamp) {
        this.catalogItemsCache.delete(key);
      }
    }
  }

  /**
   * Creates a cache key from query parameters
   */
  private createCacheKey(params: any): string {
    return JSON.stringify(params || {});
  }
  
  /**
   * Get catalog items with optional filters
   */
  getCatalogItems(params?: {
    type?: string;
    query?: string;
    search?: string;
    q?: string;
    title?: string;
    category?: string;
    status?: string;
    author?: string;
    page?: number;
    page_size?: number;
    skip?: number;
    limit?: number;
    sort?: string;
    order?: 'asc' | 'desc';
    date_range?: string;
    useCache?: boolean;
  }): Observable<CatalogResponse> {
    // Extract useCache flag and remove it from params to avoid sending it to API
    const useCache = params?.useCache !== false; // Default to true if not specified
    const apiParams = { ...params };
    delete apiParams.useCache;
    
    let httpParams = new HttpParams();
    
    // Default to sorting by recently updated items if not specified
    const sortBy = apiParams?.sort || 'updated_date';
    const sortOrder = apiParams?.order || 'desc';
    
    if (apiParams) {
      // Add all other params
      Object.keys(apiParams).forEach(key => {
        const value = apiParams[key as keyof typeof apiParams];
        if (value !== undefined && value !== null && key !== 'sort' && key !== 'order') {
          httpParams = httpParams.set(key, value.toString());
        }
      });
    }
    
    // Add sort parameters
    httpParams = httpParams.set('sort', sortBy);
    httpParams = httpParams.set('order', sortOrder);

    const cacheKey = this.createCacheKey(apiParams);
    
    // Check cache first if useCache is true
    if (useCache) {
      const cachedData = this.catalogItemsCache.get(cacheKey);
      const now = Date.now();
      
      // Use cache if it's less than 1 minute old and it's not page 1 (first page should be fresh)
      if (cachedData && (now - cachedData.timestamp < 60000) && (apiParams?.page && apiParams.page > 1)) {
        return new Observable(observer => {
          observer.next(cachedData.data);
          observer.complete();
        });
      }
    }

    // Cache miss or forced refresh, get from API
    return this.http.get<CatalogResponse>(`${this.API_BASE}/catalog/`, { params: httpParams })
      .pipe(
        map(response => {
          // Update cache with fresh data
          this.catalogItemsCache.set(cacheKey, {
            data: response,
            timestamp: Date.now()
          });
          return response;
        }),
        catchError(this.handleError)
      );
  }

  /**
   * Search catalog items
   */
  searchCatalogItems(params?: {
    query?: string;
    type?: string;
    category?: string;
    status?: string;
    author?: string;
    approved_by?: string;
    reviewed_by?: string;
    source?: string;
    tags?: string;
    skip?: number;
    limit?: number;
    sort?: string;
    order?: 'asc' | 'desc';
  }): Observable<CatalogResponse> {
    let httpParams = new HttpParams();
    
    // Default to sorting by recently updated items if not specified
    const sortBy = params?.sort || 'updated_date';
    const sortOrder = params?.order || 'desc';
    
    if (params) {
      // Add all other params
      Object.keys(params).forEach(key => {
        const value = params[key as keyof typeof params];
        if (value !== undefined && value !== null && key !== 'sort' && key !== 'order') {
          httpParams = httpParams.set(key, value.toString());
        }
      });
    }
    
    // Add sort parameters
    httpParams = httpParams.set('sort', sortBy);
    httpParams = httpParams.set('order', sortOrder);

    return this.http.get<CatalogResponse>(`${this.API_BASE}/catalog/search`, { params: httpParams })
      .pipe(
        catchError(this.handleError)
      );
  }

  /**
   * Get catalog item by ID
   */
  getCatalogItem(id: string): Observable<Catalog> {
    return this.http.get<Catalog>(`${this.API_BASE}/catalog/${id}`)
      .pipe(
        catchError(this.handleError)
      );
  }

  /**
   * Create new catalog item
   */
  createCatalogItem(item: CatalogCreate): Observable<Catalog> {
    return this.http.post<Catalog>(`${this.API_BASE}/catalog/`, item)
      .pipe(
        catchError(this.handleError)
      );
  }

  /**
   * Create new catalog item (alias for backward compatibility)
   */
  createArticle(item: CatalogCreate): Observable<Catalog> {
    return this.createCatalogItem(item);
  }

  /**
   * Update catalog item
   */
  updateCatalogItem(id: string, item: CatalogUpdate): Observable<Catalog> {
    return this.http.put<Catalog>(`${this.API_BASE}/catalog/${id}`, item)
      .pipe(
        catchError(this.handleError)
      );
  }

  /**
   * Delete catalog item
   */
  deleteCatalogItem(id: string): Observable<void> {
    return this.http.delete<void>(`${this.API_BASE}/catalog/${id}`)
      .pipe(
        catchError(this.handleError)
      );
  }

  /**
   * Like catalog item
   */
  likeCatalogItem(id: string): Observable<Catalog> {
    return this.http.post<Catalog>(`${this.API_BASE}/catalog/${id}/like`, {})
      .pipe(
        catchError(this.handleError)
      );
  }

  /**
   * Mark catalog item as used
   */
  useCatalogItem(id: string): Observable<Catalog> {
    return this.http.post<Catalog>(`${this.API_BASE}/catalog/${id}/use`, {})
      .pipe(
        catchError(this.handleError)
      );
  }

  /**
   * Approve catalog item (admin only)
   */
  approveCatalogItem(id: string): Observable<Catalog> {
    return this.http.patch<Catalog>(`${this.API_BASE}/catalog/${id}/approve`, {})
      .pipe(
        catchError(this.handleError)
      );
  }

  /**
   * Request approval for catalog item - sets approved_by to current user's manager
   */
  requestApprovalForItem(id: string): Observable<Catalog> {
    // Use the correct API endpoint for requesting approval
    return this.http.patch<Catalog>(`${this.API_BASE}/catalog/${id}/request_approval`, {})
      .pipe(
        catchError(this.handleError)
      );
  }

  /**
   * Review catalog item (admin only)
   */
  reviewCatalogItem(id: string, status: string): Observable<Catalog> {
    return this.http.patch<Catalog>(`${this.API_BASE}/catalog/${id}/review`, { status })
      .pipe(
        catchError(this.handleError)
      );
  }

  /**
   * Get catalogs by type
   */
  getCatalogsByType(type: string, params?: { 
    skip?: number; 
    limit?: number;
    sort?: string;
    order?: 'asc' | 'desc';
  }): Observable<Catalog[]> {
    let httpParams = new HttpParams();
    
    // Default to sorting by recently updated items if not specified
    const sortBy = params?.sort || 'updated_date';
    const sortOrder = params?.order || 'desc';
    
    if (params) {
      // Add all other params
      Object.keys(params).forEach(key => {
        const value = params[key as keyof typeof params];
        if (value !== undefined && value !== null && key !== 'sort' && key !== 'order') {
          httpParams = httpParams.set(key, value.toString());
        }
      });
    }
    
    // Add sort parameters
    httpParams = httpParams.set('sort', sortBy);
    httpParams = httpParams.set('order', sortOrder);

    return this.http.get<Catalog[]>(`${this.API_BASE}/catalog/by-type/${type}`, { params: httpParams })
      .pipe(
        catchError(this.handleError)
      );
  }

  /**
   * Get catalogs by status
   */
  getCatalogsByStatus(status: string, params?: { 
    skip?: number; 
    limit?: number;
    sort?: string;
    order?: 'asc' | 'desc';
  }): Observable<Catalog[]> {
    let httpParams = new HttpParams();
    
    // Default to sorting by recently updated items if not specified
    const sortBy = params?.sort || 'updated_date';
    const sortOrder = params?.order || 'desc';
    
    if (params) {
      // Add all other params
      Object.keys(params).forEach(key => {
        const value = params[key as keyof typeof params];
        if (value !== undefined && value !== null && key !== 'sort' && key !== 'order') {
          httpParams = httpParams.set(key, value.toString());
        }
      });
    }
    
    // Add sort parameters
    httpParams = httpParams.set('sort', sortBy);
    httpParams = httpParams.set('order', sortOrder);

    return this.http.get<Catalog[]>(`${this.API_BASE}/catalog/by-status/${status}`, { params: httpParams })
      .pipe(
        catchError(this.handleError)
      );
  }

  /**
   * Get news items (shortcut for news type catalog items)
   */
  getNews(params?: { page?: number; page_size?: number; query?: string }): Observable<CatalogResponse> {
    return this.getCatalogItems({ 
      type: 'news', 
      status: 'published',
      ...params 
    });
  }

  /**
   * Get notifications (shortcut for notification type catalog items)
   */
  getNotifications(params?: { page?: number; page_size?: number; limit?: number }): Observable<Catalog[]> {
    // Get recent notifications/announcements
    return this.getCatalogItems({ 
      type: 'notification', 
      status: 'published',
      page_size: params?.limit || 10,
      ...params 
    }).pipe(
      map(response => response.items || [])
    );
  }

  /**
   * Get documents (shortcut for document type catalog items)
   */
  getDocuments(params?: { page?: number; page_size?: number; query?: string }): Observable<CatalogResponse> {
    return this.getCatalogItems({ 
      type: 'document', 
      status: 'published',
      ...params 
    });
  }

  /**
   * Get recent notifications with limit
   */
  getRecentNotifications(limit: number = 5): Observable<Catalog[]> {
    return this.getNotifications({ limit }).pipe(
      map(notifications => {
        this.notificationsSubject.next(notifications);
        return notifications;
      })
    );
  }

  /**
   * Get recent news with limit
   */
  getRecentNews(limit: number = 6): Observable<Catalog[]> {
    return this.getCatalogItems({ 
      type: 'news', 
      status: 'published',
      limit 
    }).pipe(
      map(response => {
        const news = response.items || [];
        this.newsSubject.next(news);
        return news;
      })
    );
  }

  /**
   * Check if there are unread news items
   */
  hasUnreadNews(): Observable<boolean> {
    return this.getCatalogItems({ 
      type: 'news', 
      status: 'published',
      limit: 1 
    }).pipe(
      map(response => (response.items || []).length > 0)
    );
  }

  /**
   * Mark news as read (placeholder implementation)
   */
  markNewsAsRead(): Observable<any> {
    // This would typically mark news as read for the current user
    // For now, return a successful response
    return new Observable(observer => {
      observer.next({ success: true });
      observer.complete();
    });
  }

  /**
   * Get available catalog types for filter dropdown
   */
  getCatalogTypes(): Observable<string[]> {
    return new Observable<string[]>(observer => {
      // Get the current user from AuthService
      this.authService.currentUser$.subscribe(currentUser => {
        if (currentUser) {
          // Filter catalog types based on user role
          const userRole = currentUser.role;
          const allowedTypes = filterCatalogTypesByRole(userRole);
          
          // Extract just the type values and sort them
          const typeValues = allowedTypes.map(type => type.value).sort();
          
          observer.next(typeValues);
          observer.complete();
        } else {
          // If no user is logged in, return empty array
          observer.next([]);
          observer.complete();
        }
      });
    });
  }

  /**
   * Get available catalog types with full metadata based on user role
   */
  getCatalogTypesWithMetadata() {
    return new Observable(observer => {
      this.authService.currentUser$.subscribe(currentUser => {
        if (currentUser) {
          // Filter catalog types based on user role
          const userRole = currentUser.role;
          const allowedTypes = filterCatalogTypesByRole(userRole);
          
          observer.next(allowedTypes);
          observer.complete();
        } else {
          // If no user is logged in, return empty array
          observer.next([]);
          observer.complete();
        }
      });
    });
  }

  /**
   * Get authors for filter dropdown
   */
  getAuthors(): Observable<string[]> {
    // Since there's no dedicated authors endpoint in the API, we'll get unique authors from catalog items
    // Using limit of 100 (API maximum) instead of 1000
    return this.getCatalogItems({ limit: 100 }).pipe(
      map(response => {
        const authors = response.items
          .map(item => item.author)
          .filter((author, index, self) => author && self.indexOf(author) === index) as string[];
        return authors.sort();
      }),
      catchError(this.handleError)
    );
  }

  /**
   * Increment view count for a catalog item
   * Note: This endpoint doesn't exist in the API, so we'll make a placeholder call
   */
  incrementViewCount(id: string): Observable<any> {
    // Since this endpoint doesn't exist in the API, we'll return a successful response
    // In a real implementation, this might be handled by the backend automatically
    return new Observable(observer => {
      observer.next({ success: true, message: 'View count incremented' });
      observer.complete();
    });
  }

  /**
   * Toggle like status for a catalog item
   * Note: The API only has a like endpoint, not toggle, so this simulates toggle behavior
   */
  toggleLike(id: string, action: string): Observable<any> {
    // Since the API only has a like endpoint, we'll use that for now
    // In a real implementation, you might need separate like/unlike endpoints
    if (action === 'like') {
      return this.likeCatalogItem(id);
    } else {
      // For unlike, we'll return a successful response since there's no unlike endpoint
      return new Observable(observer => {
        observer.next({ success: true, message: 'Item unliked' });
        observer.complete();
      });
    }
  }

  /**
   * Get conversations for a catalog item
   */
  getCatalogConversations(catalogId: string): Observable<CatalogConversation> {
    return this.http.get<any>(`${this.API_BASE}/catalog/${catalogId}/conversations`)
      .pipe(
        map((response: any) => {
          console.log('✅ Conversation API response received:', response);
          
          // Handle the actual API response format
          if (Array.isArray(response)) {
            // API returns array directly with format: { message, user_id, timestamp }
            const messages: ConversationMessage[] = response.map((item: any, index: number) => ({
              id: item.id || `msg_${Date.now()}_${index}`, // Generate ID if not provided
              user_id: item.user_id || '',
              user_name: item.user_name || item.user_id || 'Unknown User', // Fallback to user_id if user_name not available
              message: item.message || '',
              created_date: item.timestamp || item.created_date || new Date().toISOString(), // Map timestamp to created_date
              updated_date: item.updated_date,
              parent_id: item.parent_id,
              likes: item.likes || 0,
              replies: item.replies || []
            }));
            
            console.log('✅ Mapped conversation messages:', messages);
            
            return {
              messages: messages,
              total_messages: messages.length,
              last_activity: messages.length > 0 ? messages[messages.length - 1].created_date : new Date().toISOString()
            };
          }
          
          // Handle other possible response formats
          if (response && typeof response === 'object') {
            // If response is already in the expected format
            if ('messages' in response && Array.isArray(response.messages)) {
              return {
                messages: response.messages,
                total_messages: response.total_messages || response.messages.length,
                last_activity: response.last_activity || new Date().toISOString()
              };
            }
            // If response has a data property containing the conversations
            else if ('data' in response && response.data) {
              const data = response.data as any;
              if (Array.isArray(data)) {
                // Handle data array with same mapping logic
                const messages: ConversationMessage[] = data.map((item: any, index: number) => ({
                  id: item.id || `msg_${Date.now()}_${index}`,
                  user_id: item.user_id || '',
                  user_name: item.user_name || item.user_id || 'Unknown User',
                  message: item.message || '',
                  created_date: item.timestamp || item.created_date || new Date().toISOString(),
                  updated_date: item.updated_date,
                  parent_id: item.parent_id,
                  likes: item.likes || 0,
                  replies: item.replies || []
                }));
                
                return {
                  messages: messages,
                  total_messages: messages.length,
                  last_activity: messages.length > 0 ? messages[messages.length - 1].created_date : new Date().toISOString()
                };
              } else {
                return {
                  messages: Array.isArray(data.messages) ? data.messages : [],
                  total_messages: data.total_messages || (Array.isArray(data.messages) ? data.messages.length : 0),
                  last_activity: data.last_activity || new Date().toISOString()
                };
              }
            }
          }
          
          // Fallback for unexpected response structure
          console.warn('⚠️ Unexpected conversation API response structure:', response);
          return {
            messages: [],
            total_messages: 0,
            last_activity: new Date().toISOString()
          };
        }),
        catchError(this.handleError)
      );
  }

  /**
   * Add a message to catalog conversations
   */
  addConversationMessage(catalogId: string, message: string, parentId?: string): Observable<ConversationMessage> {
    const payload = {
      message,
      parent_id: parentId
    };
    
    console.log('📤 Sending conversation message:', payload);
    
    return this.http.post<any>(`${this.API_BASE}/catalog/${catalogId}/conversations`, payload)
      .pipe(
        map((response: any) => {
          console.log('✅ Conversation message API response:', response);
          
          // Handle different possible API response formats
          if (response && typeof response === 'object') {
            // If response has the expected ConversationMessage format
            if ('id' in response && 'message' in response) {
              return response as ConversationMessage;
            }
            // If response has a data property containing the message
            else if ('data' in response && response.data) {
              return response.data as ConversationMessage;
            }
            // If response has the simple format like { message, user_id, timestamp }
            else if ('message' in response && 'user_id' in response) {
              return {
                id: response.id || Date.now().toString(),
                user_id: response.user_id || '',
                user_name: response.user_name || response.user_id || 'Unknown User',
                message: response.message || '',
                created_date: response.timestamp || response.created_date || new Date().toISOString(),
                updated_date: response.updated_date,
                parent_id: response.parent_id,
                likes: response.likes || 0,
                replies: response.replies || []
              } as ConversationMessage;
            }
          }
          
          // Fallback response structure
          console.warn('⚠️ Unexpected message API response structure:', response);
          return {
            id: Date.now().toString(),
            user_id: '',
            user_name: 'Unknown User',
            message: message,
            created_date: new Date().toISOString(),
            likes: 0,
            replies: []
          } as ConversationMessage;
        }),
        catchError(this.handleError)
      );
  }

  /**
   * Update a conversation message
   */
  updateConversationMessage(catalogId: string, messageId: string, message: string): Observable<ConversationMessage> {
    const payload = { message };
    
    console.log('📝 Updating conversation message:', { messageId, payload });
    
    return this.http.put<any>(`${this.API_BASE}/catalog/${catalogId}/conversations/${messageId}`, payload)
      .pipe(
        map((response: any) => {
          console.log('✅ Update message API response:', response);
          
          // Handle different possible API response formats
          if (response && typeof response === 'object') {
            // If response has the message data directly
            if ('id' in response && 'message' in response) {
              return response as ConversationMessage;
            }
            // If response has a data property containing the message
            else if ('data' in response && response.data) {
              return response.data as ConversationMessage;
            }
          }
          
          // Fallback response structure
          console.warn('⚠️ Unexpected update message API response structure:', response);
          return {
            id: messageId,
            user_id: '',
            user_name: 'Unknown User',
            message: message,
            created_date: new Date().toISOString(),
            updated_date: new Date().toISOString()
          } as ConversationMessage;
        }),
        catchError(this.handleError)
      );
  }

  /**
   * Delete a conversation message
   */
  deleteConversationMessage(catalogId: string, messageId: string): Observable<void> {
    console.log('🗑️ Deleting conversation message:', messageId);
    
    return this.http.delete<void>(`${this.API_BASE}/catalog/${catalogId}/conversations/${messageId}`)
      .pipe(
        catchError(this.handleError)
      );
  }

  /**
   * Like a conversation message
   */
  likeConversationMessage(catalogId: string, messageId: string): Observable<ConversationMessage> {
    console.log('👍 Liking conversation message:', messageId);
    
    return this.http.post<any>(`${this.API_BASE}/catalog/${catalogId}/conversations/${messageId}/like`, {})
      .pipe(
        map((response: any) => {
          console.log('✅ Like message API response:', response);
          
          // Handle different possible API response formats
          if (response && typeof response === 'object') {
            // If response has the message data directly
            if ('id' in response) {
              return response as ConversationMessage;
            }
            // If response has a data property containing the message
            else if ('data' in response && response.data) {
              return response.data as ConversationMessage;
            }
          }
          
          // Fallback response structure
          console.warn('⚠️ Unexpected like message API response structure:', response);
          return {
            id: messageId,
            user_id: '',
            user_name: 'Unknown User',
            message: '',
            created_date: new Date().toISOString(),
            likes: 1
          } as ConversationMessage;
        }),
        catchError(this.handleError)
      );
  }

  /**
   * WEBHOOK MANAGEMENT FUNCTIONALITY
   * The following methods implement webhook API endpoints for subscription to system events
   */
  
  /**
   * Create a new webhook
   */
  createWebhook(webhook: WebhookCreate): Observable<Webhook> {
    return this.http.post<Webhook>(`${this.API_BASE}/webhooks/`, webhook)
      .pipe(
        catchError(this.handleError)
      );
  }

  /**
   * Get all webhooks with optional pagination
   */
  getWebhooks(params?: { 
    page?: number; 
    page_size?: number;
    limit?: number;
    sort?: string;
    order?: 'asc' | 'desc';
  }): Observable<WebhookResponse> {
    let httpParams = new HttpParams();
    
    // Default to sorting by recently created items if not specified
    const sortBy = params?.sort || 'created_date';
    const sortOrder = params?.order || 'desc';
    
    if (params) {
      // Add all other params
      Object.keys(params).forEach(key => {
        const value = params[key as keyof typeof params];
        if (value !== undefined && value !== null && key !== 'sort' && key !== 'order') {
          httpParams = httpParams.set(key, value.toString());
        }
      });
    }
    
    // Add sort parameters
    httpParams = httpParams.set('sort', sortBy);
    httpParams = httpParams.set('order', sortOrder);

    return this.http.get<WebhookResponse>(`${this.API_BASE}/webhooks/`, { params: httpParams })
      .pipe(
        catchError(this.handleError)
      );
  }

  /**
   * Get a specific webhook by ID
   */
  getWebhook(id: string): Observable<Webhook> {
    return this.http.get<Webhook>(`${this.API_BASE}/webhooks/${id}`)
      .pipe(
        catchError(this.handleError)
      );
  }

  /**
   * Update a webhook
   */
  updateWebhook(id: string, webhook: WebhookUpdate): Observable<Webhook> {
    return this.http.put<Webhook>(`${this.API_BASE}/webhooks/${id}`, webhook)
      .pipe(
        catchError(this.handleError)
      );
  }

  /**
   * Delete a webhook
   */
  deleteWebhook(id: string): Observable<void> {
    return this.http.delete<void>(`${this.API_BASE}/webhooks/${id}`)
      .pipe(
        catchError(this.handleError)
      );
  }

  /**
   * Test a webhook by sending a test event
   */
  testWebhook(id: string): Observable<WebhookTestResult> {
    return this.http.post<WebhookTestResult>(`${this.API_BASE}/webhooks/${id}/test`, {})
      .pipe(
        catchError(this.handleError)
      );
  }

  /**
   * Toggle webhook enabled/disabled status
   */
  toggleWebhook(id: string): Observable<Webhook> {
    return this.http.patch<Webhook>(`${this.API_BASE}/webhooks/${id}/toggle`, {})
      .pipe(
        catchError(this.handleError)
      );
  }

  /**
   * Get webhook delivery history
   */
  getWebhookDeliveries(id: string, params?: { 
    page?: number; 
    page_size?: number;
    limit?: number;
    sort?: string;
    order?: 'asc' | 'desc';
  }): Observable<any> {
    let httpParams = new HttpParams();
    
    // Default to sorting by most recent deliveries if not specified
    const sortBy = params?.sort || 'created_date';
    const sortOrder = params?.order || 'desc';
    
    if (params) {
      // Add all other params
      Object.keys(params).forEach(key => {
        const value = params[key as keyof typeof params];
        if (value !== undefined && value !== null && key !== 'sort' && key !== 'order') {
          httpParams = httpParams.set(key, value.toString());
        }
      });
    }
    
    // Add sort parameters
    httpParams = httpParams.set('sort', sortBy);
    httpParams = httpParams.set('order', sortOrder);

    return this.http.get<any>(`${this.API_BASE}/webhooks/${id}/deliveries`, { params: httpParams })
      .pipe(
        catchError(this.handleError)
      );
  }

  /**
   * Get available webhook events
   */
  getAvailableWebhookEvents(): Observable<WebhookEvent[]> {
    return this.http.get<WebhookEvent[]>(`${this.API_BASE}/webhooks/events/available`)
      .pipe(
        catchError(this.handleError)
      );
  }

  /**
   * Handle HTTP errors
   */
  private handleError(error: any): Observable<never> {
    console.error('Catalog service error:', error);
    
    let errorMessage = 'An error occurred while processing your request.';
    
    if (error.error?.detail) {
      if (Array.isArray(error.error.detail)) {
        errorMessage = error.error.detail.map((e: any) => e.msg).join(', ');
      } else {
        errorMessage = error.error.detail;
      }
    } else if (error.message) {
      errorMessage = error.message;
    }
    
    return throwError(() => new Error(errorMessage));
  }

  /**
   * Share catalog item with users
   */
  shareCatalogItem(catalogId: string, userIds: string[], message?: string): Observable<any> {
    const payload = {
      user_ids: userIds,
      message: message
    };
    
    console.log('📤 Sharing catalog item:', { catalogId, payload });
    
    return this.http.post<any>(`${this.API_BASE}/catalog/${catalogId}/share`, payload)
      .pipe(
        map((response: any) => {
          console.log('✅ Share catalog API response:', response);
          return response;
        }),
        catchError(this.handleError)
      );
  }

  /**
   * Update catalog sharing information
   */
  updateCatalogSharing(catalogId: string, sharedUsers: any[]): Observable<any> {
    const payload = {
      shared_with: sharedUsers.map(user => user.id || user.user_id || user)
    };
    
    console.log('📤 Updating catalog sharing:', { catalogId, payload });
    
    return this.http.put<any>(`${this.API_BASE}/catalog/${catalogId}`, payload)
      .pipe(
        map((response: any) => {
          console.log('✅ Update catalog sharing API response:', response);
          return response;
        }),
        catchError(this.handleError)
      );
  }
}
import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class TemplateService {
  private templateCache = new Map<string, string>();

  constructor(private http: HttpClient) {}

  /**
   * Load an HTML template and replace placeholders with provided data
   */
  loadTemplate(templateName: string, data: { [key: string]: any }): Observable<string> {
    const templatePath = `/assets/templates/${templateName}.template.html`;
    
    return this.http.get(templatePath, { responseType: 'text' }).pipe(
      map(template => this.replacePlaceholders(template, data))
    );
  }

  /**
   * Replace placeholders in template with actual data
   */
  private replacePlaceholders(template: string, data: { [key: string]: any }): string {
    let processedTemplate = template;

    // Replace simple placeholders like {{key}}
    Object.keys(data).forEach(key => {
      const placeholder = `{{${key}}}`;
      const value = data[key] || '';
      processedTemplate = processedTemplate.replace(new RegExp(placeholder, 'g'), value);
    });

    // Handle conditional blocks like {{#if key}}...{{/if}}
    processedTemplate = this.processConditionals(processedTemplate, data);

    return processedTemplate;
  }

  /**
   * Process conditional blocks in templates
   */
  private processConditionals(template: string, data: { [key: string]: any }): string {
    // Handle {{#if key}}...{{/if}} blocks
    const ifPattern = /\{\{#if\s+(\w+)\}\}([\s\S]*?)\{\{\/if\}\}/g;
    
    return template.replace(ifPattern, (match, key, content) => {
      const value = data[key];
      // Return content if value exists and is truthy, otherwise return empty string
      return (value && value !== '') ? content : '';
    });
  }
}
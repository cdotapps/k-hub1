import { Component, Input } from '@angular/core';
import { IconDefinition } from '@fortawesome/fontawesome-svg-core';

@Component({
  selector: 'app-icon',
  template: `
    <!-- Font Awesome Icon -->
    <fa-icon 
      *ngIf="faIcon" 
      [icon]="faIcon" 
      [class]="iconClasses"
      [style.color]="color"
      [spin]="spin">
    </fa-icon>
    
    <!-- Custom SVG Icon -->
    <span 
      *ngIf="!faIcon && name" 
      [class]="iconClasses" 
      [innerHTML]="iconSvg">
    </span>
    
    <!-- Fallback -->
    <span 
      *ngIf="!faIcon && !name" 
      [class]="iconClasses">
      <svg viewBox="0 0 24 24"><text x="12" y="16" text-anchor="middle" font-size="16">?</text></svg>
    </span>
  `,
  styles: [`
    :host {
      display: inline-flex;
      align-items: center;
      justify-content: center;
    }

    .icon {
      display: inline-flex;
      align-items: center;
      justify-content: center;
      font-style: normal;
      line-height: 1;
      text-align: center;
      flex-shrink: 0;
    }

    .icon svg {
      width: 1em;
      height: 1em;
      fill: currentColor;
      stroke: currentColor;
      stroke-width: 0;
    }

    .icon-stroke svg {
      fill: none;
      stroke: currentColor;
      stroke-width: 2;
      stroke-linecap: round;
      stroke-linejoin: round;
    }

    /* Standardized icon sizes with consistent containers */
    .icon-xs {
      font-size: 0.75rem;
      width: 1rem;
      height: 1rem;
    }

    .icon-sm {
      font-size: 1rem;
      width: 1.25rem;
      height: 1.25rem;
    }

    .icon-md {
      font-size: 1.25rem;
      width: 1.5rem;
      height: 1.5rem;
    }

    .icon-lg {
      font-size: 1.5rem;
      width: 2rem;
      height: 2rem;
    }

    .icon-xl {
      font-size: 2rem;
      width: 2.5rem;
      height: 2.5rem;
    }

    .icon-2xl {
      font-size: 2.5rem;
      width: 3rem;
      height: 3rem;
    }

    /* Container shapes with consistent padding */
    .icon-rounded {
      background-color: var(--fm-gray-lighter);
      border-radius: 50%;
      padding: 0.375em;
    }

    .icon-square {
      background-color: var(--fm-gray-lighter);
      border-radius: 0.25rem;
      padding: 0.375em;
    }

    /* Container shapes for larger icons */
    .icon-rounded.icon-lg,
    .icon-rounded.icon-xl,
    .icon-rounded.icon-2xl {
      padding: 0.5em;
    }

    .icon-square.icon-lg,
    .icon-square.icon-xl,
    .icon-square.icon-2xl {
      padding: 0.5em;
    }

    /* Color variants */
    .icon-primary {
      color: var(--fm-primary-blue);
    }

    .icon-secondary {
      color: var(--fm-secondary-blue);
    }

    .icon-success {
      color: var(--fm-green);
    }

    .icon-warning {
      color: var(--fm-orange);
    }

    .icon-danger {
      color: var(--fm-red);
    }

    .icon-muted {
      color: var(--fm-gray-light);
    }

    .icon-white {
      color: var(--fm-white);
    }

    /* Container background variants */
    .icon-rounded.icon-primary,
    .icon-square.icon-primary {
      background-color: rgba(0, 63, 127, 0.1);
      color: var(--fm-primary-blue);
    }

    .icon-rounded.icon-secondary,
    .icon-square.icon-secondary {
      background-color: rgba(0, 102, 204, 0.1);
      color: var(--fm-secondary-blue);
    }

    .icon-rounded.icon-success,
    .icon-square.icon-success {
      background-color: rgba(40, 167, 69, 0.1);
      color: var(--fm-green);
    }

    .icon-rounded.icon-warning,
    .icon-square.icon-warning {
      background-color: rgba(253, 126, 20, 0.1);
      color: var(--fm-orange);
    }

    .icon-rounded.icon-danger,
    .icon-square.icon-danger {
      background-color: rgba(220, 53, 69, 0.1);
      color: var(--fm-red);
    }
  `]
})
export class IconComponent {
  @Input() name: string = '';
  @Input() faIcon?: IconDefinition; // Font Awesome icon
  @Input() size: 'xs' | 'sm' | 'md' | 'lg' | 'xl' | '2xl' = 'md';
  @Input() color?: string;
  @Input() variant?: 'primary' | 'secondary' | 'success' | 'warning' | 'danger' | 'muted' | 'white';
  @Input() shape?: 'rounded' | 'square';
  @Input() type: 'fill' | 'stroke' = 'fill';
  @Input() spin: boolean = false;

  // Map of icon names to minimalistic SVG paths
  private iconMap: { [key: string]: string } = {
    // Navigation
    'home': '<svg viewBox="0 0 24 24"><path d="M3 9l9-7 9 7v11a2 2 0 01-2 2H5a2 2 0 01-2-2z"/><polyline points="9,22 9,12 15,12 15,22"/></svg>',
    'menu': '<svg viewBox="0 0 24 24"><line x1="3" y1="6" x2="21" y2="6"/><line x1="3" y1="12" x2="21" y2="12"/><line x1="3" y1="18" x2="21" y2="18"/></svg>',
    'close': '<svg viewBox="0 0 24 24"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>',
    'arrow-left': '<svg viewBox="0 0 24 24"><line x1="19" y1="12" x2="5" y2="12"/><polyline points="12,19 5,12 12,5"/></svg>',
    'arrow-right': '<svg viewBox="0 0 24 24"><line x1="5" y1="12" x2="19" y2="12"/><polyline points="12,5 19,12 12,19"/></svg>',
    'arrow-up': '<svg viewBox="0 0 24 24"><line x1="12" y1="19" x2="12" y2="5"/><polyline points="5,12 12,5 19,12"/></svg>',
    'arrow-down': '<svg viewBox="0 0 24 24"><line x1="12" y1="5" x2="12" y2="19"/><polyline points="19,12 12,19 5,12"/></svg>',
    
    // Actions
    'search': '<svg viewBox="0 0 24 24"><circle cx="11" cy="11" r="8"/><path d="21 21l-4.35-4.35"/></svg>',
    'edit': '<svg viewBox="0 0 24 24"><path d="M11 4H4a2 2 0 00-2 2v14a2 2 0 002 2h14a2 2 0 002-2v-7"/><path d="M18.5 2.5a2.121 2.121 0 013 3L12 15l-4 1 1-4 9.5-9.5z"/></svg>',
    'delete': '<svg viewBox="0 0 24 24"><polyline points="3,6 5,6 21,6"/><path d="M19 6v14a2 2 0 01-2 2H7a2 2 0 01-2-2V6m3 0V4a2 2 0 012-2h4a2 2 0 012 2v2"/><line x1="10" y1="11" x2="10" y2="17"/><line x1="14" y1="11" x2="14" y2="17"/></svg>',
    'save': '<svg viewBox="0 0 24 24"><path d="M19 21H5a2 2 0 01-2-2V5a2 2 0 012-2h11l5 5v11a2 2 0 01-2 2z"/><polyline points="17,21 17,13 7,13 7,21"/><polyline points="7,3 7,8 15,8"/></svg>',
    'download': '<svg viewBox="0 0 24 24"><path d="M21 15v4a2 2 0 01-2 2H5a2 2 0 01-2-2v-4"/><polyline points="7,10 12,15 17,10"/><line x1="12" y1="15" x2="12" y2="3"/></svg>',
    'upload': '<svg viewBox="0 0 24 24"><path d="M21 15v4a2 2 0 01-2 2H5a2 2 0 01-2-2v-4"/><polyline points="17,8 12,3 7,8"/><line x1="12" y1="3" x2="12" y2="15"/></svg>',
    'copy': '<svg viewBox="0 0 24 24"><rect x="9" y="9" width="13" height="13" rx="2" ry="2"/><path d="M5 15H4a2 2 0 01-2-2V4a2 2 0 012-2h9a2 2 0 012 2v1"/></svg>',
    'share': '<svg viewBox="0 0 24 24"><circle cx="18" cy="5" r="3"/><circle cx="6" cy="12" r="3"/><circle cx="18" cy="19" r="3"/><line x1="8.59" y1="13.51" x2="15.42" y2="17.49"/><line x1="15.41" y1="6.51" x2="8.59" y2="10.49"/></svg>',
    
    // Content
    'user': '<svg viewBox="0 0 24 24"><path d="M20 21v-2a4 4 0 00-4-4H8a4 4 0 00-4 4v2"/><circle cx="12" cy="7" r="4"/></svg>',
    'users': '<svg viewBox="0 0 24 24"><path d="M17 21v-2a4 4 0 00-4-4H5a4 4 0 00-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 00-3-3.87"/><path d="M16 3.13a4 4 0 010 7.75"/></svg>',
    'email': '<svg viewBox="0 0 24 24"><path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"/><polyline points="22,6 12,13 2,6"/></svg>',
    'phone': '<svg viewBox="0 24 24"><path d="M22 16.92v3a2 2 0 01-2.18 2 19.79 19.79 0 01-8.63-3.07 19.5 19.5 0 01-6-6 19.79 19.79 0 01-3.07-8.67A2 2 0 014.11 2h3a2 2 0 012 1.72 12.84 12.84 0 00.7 2.81 2 2 0 01-.45 2.11L8.09 9.91a16 16 0 006 6l1.27-1.27a2 2 0 012.11-.45 12.84 12.84 0 002.81.7A2 2 0 0122 16.92z"/></svg>',
    'location': '<svg viewBox="0 0 24 24"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0118 0z"/><circle cx="12" cy="10" r="3"/></svg>',
    'calendar': '<svg viewBox="0 0 24 24"><rect x="3" y="4" width="18" height="18" rx="2" ry="2"/><line x1="16" y1="2" x2="16" y2="6"/><line x1="8" y1="2" x2="8" y2="6"/><line x1="3" y1="10" x2="21" y2="10"/></svg>',
    'clock': '<svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="10"/><polyline points="12,6 12,12 16,14"/></svg>',
    'document': '<svg viewBox="0 0 24 24"><path d="M14,2H6A2,2 0 0,0 4,4V20A2,2 0 0,0 6,22H18A2,2 0 0,0 20,20V8L14,2M18,20H6V4H13V9H18V20Z"/></svg>',
    'folder': '<svg viewBox="0 0 24 24"><path d="M22 19a2 2 0 01-2 2H4a2 2 0 01-2-2V5a2 2 0 012-2h5l2 3h9a2 2 0 012 2z"/></svg>',
    'image': '<svg viewBox="0 0 24 24"><rect x="3" y="3" width="18" height="18" rx="2" ry="2"/><circle cx="8.5" cy="8.5" r="1.5"/><polyline points="21,15 16,10 5,21"/></svg>',
    
    // Status
    'check': '<svg viewBox="0 0 24 24"><polyline points="20,6 9,17 4,12"/></svg>',
    'warning': '<svg viewBox="0 0 24 24"><path d="M10.29 3.86L1.82 18a2 2 0 001.71 3h16.94a2 2 0 001.71-3L13.71 3.86a2 2 0 00-3.42 0z"/><line x1="12" y1="9" x2="12" y2="13"/><line x1="12" y1="17" x2="12.01" y2="17"/></svg>',
    'error': '<svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="10"/><line x1="15" y1="9" x2="9" y2="15"/><line x1="9" y1="9" x2="15" y2="15"/></svg>',
    'info': '<svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="10"/><line x1="12" y1="16" x2="12" y2="12"/><line x1="12" y1="8" x2="12.01" y2="8"/></svg>',
    'star': '<svg viewBox="0 0 24 24"><polygon points="12,2 15.09,8.26 22,9.27 17,14.14 18.18,21.02 12,17.77 5.82,21.02 7,14.14 2,9.27 8.91,8.26"/></svg>',
    'heart': '<svg viewBox="0 0 24 24"><path d="M20.84 4.61a5.5 5.5 0 00-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 00-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 000-7.78z"/></svg>',
    'thumbs-up': '<svg viewBox="0 0 24 24"><path d="M14 9V5a3 3 0 00-3-3l-4 9v11h11.28a2 2 0 002-1.7l1.38-9a2 2 0 00-2-2.3zM7 22H4a2 2 0 01-2-2v-7a2 2 0 012-2h3"/></svg>',
    'thumbs-down': '<svg viewBox="0 0 24 24"><path d="M10 15v4a3 3 0 003 3l4-9V2H5.72a2 2 0 00-2 1.7l-1.38 9a2 2 0 002 2.3zm7-13h2.67A2.31 2.31 0 0122 4v7a2.31 2.31 0 01-2.33 2H17"/></svg>',
    
    // Business/Financial
    'chart': '<svg viewBox="0 0 24 24"><polyline points="23,6 13.5,15.5 8.5,10.5 1,18"/><polyline points="17,6 23,6 23,12"/></svg>',
    'chart-down': '<svg viewBox="0 0 24 24"><polyline points="23,18 13.5,8.5 8.5,13.5 1,6"/><polyline points="17,18 23,18 23,12"/></svg>',
    'dollar': '<svg viewBox="0 0 24 24"><line x1="12" y1="1" x2="12" y2="23"/><path d="M17 5H9.5a3.5 3.5 0 000 7h5a3.5 3.5 0 010 7H6"/></svg>',
    'bank': '<svg viewBox="0 0 24 24"><path d="M3 21h18"/><path d="M5 21V7l8-4 8 4v14"/><path d="M9 9v12"/><path d="M15 9v12"/></svg>',
    'credit-card': '<svg viewBox="0 0 24 24"><rect x="1" y="4" width="22" height="16" rx="2" ry="2"/><line x1="1" y1="10" x2="23" y2="10"/></svg>',
    'calculator': '<svg viewBox="0 0 24 24"><rect x="4" y="2" width="16" height="20" rx="2"/><line x1="8" y1="6" x2="16" y2="6"/><line x1="8" y1="10" x2="8" y2="10"/><line x1="12" y1="10" x2="12" y2="10"/><line x1="16" y1="10" x2="16" y2="10"/><line x1="8" y1="14" x2="8" y2="14"/><line x1="12" y1="14" x2="12" y2="14"/><line x1="16" y1="14" x2="16" y2="14"/><line x1="8" y1="18" x2="8" y2="18"/><line x1="12" y1="18" x2="12" y2="18"/><line x1="16" y1="18" x2="16" y2="18"/></svg>',
    'briefcase': '<svg viewBox="0 0 24 24"><rect x="2" y="7" width="20" height="14" rx="2" ry="2"/><path d="M16 21V5a2 2 0 00-2-2h-4a2 2 0 00-2-2v16"/></svg>',
    'building': '<svg viewBox="0 0 24 24"><path d="M6 22V4a2 2 0 012-2h8a2 2 0 012 2v18z"/><path d="M6 12h4m0 0h4m-4 0v10"/></svg>',
    
    // Technology
    'computer': '<svg viewBox="0 0 24 24"><rect x="2" y="3" width="20" height="14" rx="2" ry="2"/><line x1="8" y1="21" x2="16" y2="21"/><line x1="12" y1="17" x2="12" y2="21"/></svg>',
    'mobile': '<svg viewBox="0 0 24 24"><rect x="5" y="2" width="14" height="20" rx="2" ry="2"/><line x1="12" y1="18" x2="12.01" y2="18"/></svg>',
    'wifi': '<svg viewBox="0 0 24 24"><path d="M5 12.55a11 11 0 0114.08 0"/><path d="M1.42 9a16 16 0 0121.16 0"/><path d="M8.53 16.11a6 6 0 016.95 0"/><line x1="12" y1="20" x2="12.01" y2="20"/></svg>',
    'settings': '<svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.65 1.65 0 00.33 1.82l.06.06a2 2 0 010 2.83 2 2 0 01-2.83 0l-.06-.06a1.65 1.65 0 00-1.82-.33 1.65 1.65 0 00-1 1.51V21a2 2 0 01-2 2 2 2 0 01-2-2v-.09A1.65 1.65 0 009 19.4a1.65 1.65 0 00-1.82.33l-.06.06a2 2 0 01-2.83 0 2 2 0 010-2.83l.06-.06a1.65 1.65 0 00.33-1.82 1.65 1.65 0 00-1.51-1H3a2 2 0 01-2-2 2 2 0 012-2h.09A1.65 1.65 0 004.6 9a1.65 1.65 0 00-.33-1.82l-.06-.06a2 2 0 010-2.83 2 2 0 012.83 0l.06.06a1.65 1.65 0 001.82.33H9a1.65 1.65 0 001-1.51V3a2 2 0 012-2 2 2 0 012 2v.09a1.65 1.65 0 001 1.51 1.65 1.65 0 001.82-.33l.06-.06a2 2 0 012.83 0 2 2 0 010 2.83l-.06.06a1.65 1.65 0 00-.33 1.82V9a1.65 1.65 0 001.51 1H21a2 2 0 012 2 2 2 0 01-2 2h-.09a1.65 1.65 0 00-1.51 1z"/></svg>',
    'cloud': '<svg viewBox="0 0 24 24"><path d="M18 10h-1.26A8 8 0 109 20h9a5 5 0 000-10z"/></svg>',
    'database': '<svg viewBox="0 0 24 24"><ellipse cx="12" cy="5" rx="9" ry="3"/><path d="M21 12c0 1.66-4 3-9 3s-9-1.34-9-3"/><path d="M3 5v14c0 1.66 4 3 9 3s9-1.34 9-3V5"/></svg>',
    'code': '<svg viewBox="0 0 24 24"><polyline points="16,18 22,12 16,6"/><polyline points="8,6 2,12 8,18"/></svg>',
    'bug': '<svg viewBox="0 0 24 24"><path d="M8 6V4a2 2 0 012-2h4a2 2 0 012 2v2h4v2h-1.6c.45 1.07.6 2.22.6 3.5 0 1.28-.15 2.43-.6 3.5H20v2h-4v1a4 4 0 01-8 0v-1H4v-2h1.6c-.45-1.07-.6-2.22-.6-3.5 0-1.28.15-2.43.6-3.5H4V6h4z"/><line x1="12" y1="16" x2="12" y2="16"/><line x1="8" y1="14" x2="8" y2="14"/><line x1="16" y1="14" x2="16" y2="14"/></svg>',
    'ai': '<svg viewBox="0 0 24 24"><path d="M2.5 9.2L12 11.8L14.8 20.5L16.2 12.2L23.5 8.8L16 8.2L13.2 1.5L11.8 8.2L2.5 9.2Z" fill="#00B0F0"/><path d="M19.2 7.5L20.8 6.8L22.5 7.6L21.4 6.2L22.2 4.6L20.8 5.5L19.2 4.9L20.2 6.3L19.2 7.5Z" fill="#32536D"/><path d="M4.8 16.5L6.4 15.8L8.1 16.6L7 15.2L7.8 13.6L6.4 14.5L4.8 13.9L5.8 15.3L4.8 16.5Z" fill="#00B0F0"/></svg>',
    
    // Features from home page
    'innovation': '<svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="5"/><line x1="12" y1="1" x2="12" y2="3"/><line x1="12" y1="21" x2="12" y2="23"/><line x1="4.22" y1="4.22" x2="5.64" y2="5.64"/><line x1="18.36" y1="18.36" x2="19.78" y2="19.78"/><line x1="1" y1="12" x2="3" y2="12"/><line x1="21" y1="12" x2="23" y2="12"/><line x1="4.22" y1="19.78" x2="5.64" y2="18.36"/><line x1="18.36" y1="5.64" x2="19.78" y2="4.22"/></svg>',
    'collaboration': '<svg viewBox="0 0 24 24"><path d="M17 21v-2a4 4 0 00-4-4H5a4 4 0 00-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 00-3-3.87"/><path d="M16 3.13a4 4 0 010 7.75"/></svg>',
    'growth': '<svg viewBox="0 0 24 24"><polyline points="23,6 13.5,15.5 8.5,10.5 1,18"/><polyline points="17,6 23,6 23,12"/></svg>',
    'rocket': '<svg viewBox="0 0 24 24"><path d="M4.5 16.5c-1.5 1.26-2 5-2 5s3.74-.5 5-2c.71-.84.7-2.13-.09-2.91a2.18 2.18 0 00-2.91-.09z"/><path d="M12 15l-3-3a22 22 0 012-3.95A12.88 12.88 0 0122 2c0 2.72-.78 7.5-6 11a22.35 22.35 0 01-4 2z"/><path d="M9 12H4s.55-3.03 2-4c1.62-1.08 5 0 5 0"/><path d="M12 15v5s3.03-.55 4-2c1.08-1.62 0-5 0-5"/></svg>'
  };

  get iconClasses(): string {
    const classes = ['icon', `icon-${this.size}`];
    
    if (this.type === 'stroke') {
      classes.push('icon-stroke');
    }
    
    if (this.variant) {
      classes.push(`icon-${this.variant}`);
    }
    
    if (this.shape) {
      classes.push(`icon-${this.shape}`);
    }
    
    return classes.join(' ');
  }

  get iconSvg(): string {
    const svg = this.iconMap[this.name];
    if (!svg) {
      return `<svg viewBox="0 0 24 24"><text x="12" y="16" text-anchor="middle" font-size="16">?</text></svg>`;
    }
    
    // Apply custom color if provided
    if (this.color) {
      return svg.replace('<svg', `<svg style="color: ${this.color}"`);
    }
    
    return svg;
  }
}
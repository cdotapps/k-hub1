import { Component, Input, Output, EventEmitter } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FontAwesomeModule } from '@fortawesome/angular-fontawesome';
import { IconDefinition } from '@fortawesome/fontawesome-svg-core';

export type ToolButtonVariant = 'default' | 'active' | 'clear' | 'filter' | 'sort';
export type ToolButtonSize = 'small' | 'medium';

@Component({
  selector: 'app-tool-button',
  standalone: true,
  imports: [CommonModule, FontAwesomeModule],
  template: `
    <button 
      [class]="getButtonClasses()"
      [disabled]="disabled"
      (click)="handleClick($event)"
      [type]="type"
      [title]="tooltip"
    >
      <fa-icon 
        *ngIf="icon" 
        [icon]="icon"
        [spin]="spinning"
        class="tool-icon"
      ></fa-icon>
      <span *ngIf="!iconOnly" class="tool-text">
        <ng-content></ng-content>
      </span>
      <span *ngIf="badge" class="tool-badge">{{ badge }}</span>
    </button>
  `,
  styles: [`
    .tool-button {
      display: inline-flex;
      align-items: center;
      justify-content: center;
      gap: 0.5rem;
      border: 2px solid #e9ecef;
      border-radius: 8px;
      font-weight: 500;
      cursor: pointer;
      transition: all 0.3s ease;
      font-family: 'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', system-ui, sans-serif;
      background: var(--fm-white);
      color: var(--fm-text-secondary);
      position: relative;
    }

    .tool-button:disabled {
      opacity: 0.5;
      cursor: not-allowed;
      pointer-events: none;
    }

    /* Sizes */
    .tool-button.small {
      padding: 0.5rem 0.75rem;
      font-size: 0.85rem;
      gap: 0.375rem;
    }

    .tool-button.medium {
      padding: 0.75rem 1rem;
      font-size: 0.9rem;
      gap: 0.5rem;
    }

    /* Variants */
    .tool-button.default:hover:not(:disabled) {
      border-color: var(--fm-secondary-blue);
      color: var(--fm-secondary-blue);
      background: rgba(0, 102, 204, 0.02);
    }

    .tool-button.active {
      border-color: var(--fm-secondary-blue);
      color: var(--fm-secondary-blue);
      background: rgba(0, 102, 204, 0.05);
    }

    .tool-button.active:hover:not(:disabled) {
      background: rgba(0, 102, 204, 0.08);
    }

    .tool-button.clear {
      border-color: transparent;
      color: var(--fm-text-light);
      background: transparent;
    }

    .tool-button.clear:hover:not(:disabled) {
      border-color: var(--fm-red);
      color: var(--fm-red);
      background: rgba(220, 53, 69, 0.05);
    }

    .tool-button.filter {
      border-color: var(--fm-orange);
      color: var(--fm-orange);
      background: rgba(253, 126, 20, 0.05);
    }

    .tool-button.filter:hover:not(:disabled) {
      background: rgba(253, 126, 20, 0.1);
    }

    .tool-button.sort {
      border-color: var(--fm-green);
      color: var(--fm-green);
      background: rgba(40, 167, 69, 0.05);
    }

    .tool-button.sort:hover:not(:disabled) {
      background: rgba(40, 167, 69, 0.1);
    }

    /* Icon only styles */
    .tool-button.icon-only {
      aspect-ratio: 1;
      padding: 0.75rem;
    }

    .tool-button.icon-only.small {
      padding: 0.5rem;
    }

    .tool-icon {
      flex-shrink: 0;
    }

    .tool-text {
      white-space: nowrap;
      overflow: hidden;
      text-overflow: ellipsis;
    }

    .tool-badge {
      background: var(--fm-red);
      color: var(--fm-white);
      font-size: 0.7rem;
      font-weight: 600;
      padding: 0.125rem 0.375rem;
      border-radius: 10px;
      min-width: 1.25rem;
      height: 1.25rem;
      display: flex;
      align-items: center;
      justify-content: center;
      line-height: 1;
    }

    /* Badge positioning for icon-only buttons */
    .tool-button.icon-only .tool-badge {
      position: absolute;
      top: -0.25rem;
      right: -0.25rem;
      min-width: 1rem;
      height: 1rem;
      font-size: 0.65rem;
      padding: 0.125rem 0.25rem;
    }

    /* Responsive */
    @media (max-width: 768px) {
      .tool-button {
        font-size: 0.85rem;
      }
      
      .tool-button.medium {
        padding: 0.625rem 0.875rem;
        font-size: 0.85rem;
      }
    }
  `]
})
export class ToolButtonComponent {
  @Input() variant: ToolButtonVariant = 'default';
  @Input() size: ToolButtonSize = 'medium';
  @Input() icon?: IconDefinition;
  @Input() disabled = false;
  @Input() iconOnly = false;
  @Input() spinning = false;
  @Input() badge?: string | number;
  @Input() tooltip?: string;
  @Input() type: 'button' | 'submit' | 'reset' = 'button';

  @Output() buttonClick = new EventEmitter<Event>();

  getButtonClasses(): string {
    const classes = ['tool-button'];
    
    classes.push(this.variant);
    classes.push(this.size);
    
    if (this.iconOnly) {
      classes.push('icon-only');
    }
    
    return classes.join(' ');
  }

  handleClick(event: Event): void {
    if (!this.disabled) {
      this.buttonClick.emit(event);
    }
  }
}
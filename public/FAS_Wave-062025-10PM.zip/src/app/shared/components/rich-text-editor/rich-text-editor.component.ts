import { Component, Input, Output, EventEmitter, forwardRef, ViewChild, ElementRef } from '@angular/core';
import { ControlValueAccessor, NG_VALUE_ACCESSOR } from '@angular/forms';
import { 
  faBold, faItalic, faUnderline, faStrikethrough, faListUl, faListOl, 
  faLink, faHeading, faQuoteLeft, faCode, faUndo, faRedo,
  faAlignLeft, faAlignCenter, faAlignRight, faTable, faImage,
  faCopy, faFileCode, faEye, faEdit
} from '@fortawesome/free-solid-svg-icons';

@Component({
  selector: 'app-rich-text-editor',
  templateUrl: './rich-text-editor.component.html',
  styleUrls: ['./rich-text-editor.component.css'],
  providers: [
    {
      provide: NG_VALUE_ACCESSOR,
      useExisting: forwardRef(() => RichTextEditorComponent),
      multi: true
    }
  ]
})
export class RichTextEditorComponent implements ControlValueAccessor {
  @Input() placeholder: string = 'Enter your content here...';
  @Input() minHeight: string = '200px';
  @Input() disabled: boolean = false;
  @Output() contentChange = new EventEmitter<string>();
  @Output() wordCountChange = new EventEmitter<number>();

  @ViewChild('editor', { static: true }) editor!: ElementRef<HTMLDivElement>;

  // FontAwesome icons
  faBold = faBold;
  faItalic = faItalic;
  faUnderline = faUnderline;
  faStrikethrough = faStrikethrough;
  faListUl = faListUl;
  faListOl = faListOl;
  faLink = faLink;
  faHeading = faHeading;
  faQuoteLeft = faQuoteLeft;
  faCode = faCode;
  faUndo = faUndo;
  faRedo = faRedo;
  faAlignLeft = faAlignLeft;
  faAlignCenter = faAlignCenter;
  faAlignRight = faAlignRight;
  faTable = faTable;
  faImage = faImage;
  faCopy = faCopy;
  faFileCode = faFileCode; // Using faFileCode instead of faHtml5
  faEye = faEye;
  faEdit = faEdit;

  private content: string = '';
  private onChange = (value: string) => {};
  private onTouched = () => {};

  // New properties for HTML code input
  showHtmlModal = false;
  htmlCodeInput = '';
  isPreviewMode = false;

  ngOnInit() {
    // Initialize editor content
    this.updateEditorContent();
  }

  // ControlValueAccessor implementation
  writeValue(value: string): void {
    this.content = value || '';
    this.updateEditorContent();
  }

  registerOnChange(fn: (value: string) => void): void {
    this.onChange = fn;
  }

  registerOnTouched(fn: () => void): void {
    this.onTouched = fn;
  }

  setDisabledState(isDisabled: boolean): void {
    this.disabled = isDisabled;
    if (this.editor) {
      this.editor.nativeElement.contentEditable = (!isDisabled).toString();
    }
  }

  private updateEditorContent(): void {
    if (this.editor && this.editor.nativeElement) {
      this.editor.nativeElement.innerHTML = this.content;
      this.updateWordCount();
    }
  }

  insertList(ordered: boolean): void {
    // Save current selection
    const selection = window.getSelection();
    const range = selection?.getRangeAt(0);
    
    this.execCommand(ordered ? 'insertOrderedList' : 'insertUnorderedList');
    
    // Fix indentation after list creation
    setTimeout(() => {
      this.fixListIndentation();
    }, 10);
  }

  onBlur(): void {
    this.onTouched();
  }

  private updateWordCount(): void {
    const text = this.getPlainText();
    const wordCount = text.trim() ? text.trim().split(/\s+/).length : 0;
    this.wordCountChange.emit(wordCount);
  }

  getPlainText(): string {
    if (this.editor) {
      return this.editor.nativeElement.textContent || '';
    }
    return '';
  }

  getWordCount(): number {
    const text = this.getPlainText();
    return text.trim() ? text.trim().split(/\s+/).length : 0;
  }

  private fixListIndentation(): void {
    if (!this.editor) return;
    
    const lists = this.editor.nativeElement.querySelectorAll('ul, ol');
    lists.forEach((list: Element) => {
      const htmlList = list as HTMLElement;
      // Ensure proper styling is applied
      htmlList.style.paddingLeft = '2.5rem';
      htmlList.style.marginLeft = '0';
      htmlList.style.listStylePosition = 'outside';
      
      // Fix nested lists
      const nestedLists = htmlList.querySelectorAll('ul, ol');
      nestedLists.forEach((nestedList: Element, index) => {
        const htmlNestedList = nestedList as HTMLElement;
        const depth = this.getListNestingDepth(htmlNestedList);
        switch (depth) {
          case 2:
            htmlNestedList.style.paddingLeft = '2rem';
            break;
          case 3:
            htmlNestedList.style.paddingLeft = '1.5rem';
            break;
          default:
            htmlNestedList.style.paddingLeft = '2rem';
        }
      });
      
      // Fix list items
      const listItems = htmlList.querySelectorAll('li');
      listItems.forEach((li: Element) => {
        const htmlLi = li as HTMLElement;
        htmlLi.style.display = 'list-item';
        htmlLi.style.paddingLeft = '0.5rem';
        htmlLi.style.marginLeft = '0';
      });
    });
  }

  private getListNestingDepth(element: HTMLElement): number {
    let depth = 0;
    let parent = element.parentElement;
    
    while (parent && parent !== this.editor.nativeElement) {
      if (parent.tagName === 'UL' || parent.tagName === 'OL') {
        depth++;
      }
      parent = parent.parentElement;
    }
    
    return depth;
  }

  // Add indent and outdent functionality
  indentList(): void {
    const selection = window.getSelection();
    if (!selection || selection.rangeCount === 0) return;
    
    const range = selection.getRangeAt(0);
    const listItem = this.findParentElement(range.commonAncestorContainer, 'LI');
    
    if (listItem) {
      this.execCommand('indent');
      setTimeout(() => this.fixListIndentation(), 10);
    }
  }

  outdentList(): void {
    const selection = window.getSelection();
    if (!selection || selection.rangeCount === 0) return;
    
    const range = selection.getRangeAt(0);
    const listItem = this.findParentElement(range.commonAncestorContainer, 'LI');
    
    if (listItem) {
      this.execCommand('outdent');
      setTimeout(() => this.fixListIndentation(), 10);
    }
  }

  private findParentElement(node: Node, tagName: string): HTMLElement | null {
    let current = node as HTMLElement;
    
    while (current && current !== this.editor.nativeElement) {
      if (current.tagName === tagName) {
        return current;
      }
      current = current.parentElement as HTMLElement;
    }
    
    return null;
  }

  // Toolbar actions
  execCommand(command: string, value?: string): void {
    document.execCommand(command, false, value);
    this.onContentChange();
    this.editor.nativeElement.focus();
  }

  insertHeading(level: number): void {
    this.execCommand('formatBlock', `h${level}`);
  }

  insertLink(): void {
    const url = prompt('Enter the URL:');
    if (url) {
      this.execCommand('createLink', url);
    }
  }

  formatText(format: string): void {
    this.execCommand(format);
  }

  insertBlockquote(): void {
    this.execCommand('formatBlock', 'blockquote');
  }

  insertCodeBlock(): void {
    this.execCommand('formatBlock', 'pre');
  }

  setTextAlignment(alignment: string): void {
    this.execCommand('justify' + alignment.charAt(0).toUpperCase() + alignment.slice(1));
  }

  insertTable(): void {
    const rows = prompt('Number of rows:', '3');
    const cols = prompt('Number of columns:', '3');
    
    if (rows && cols) {
      const numRows = parseInt(rows);
      const numCols = parseInt(cols);
      
      let tableHTML = '<table border="1" style="border-collapse: collapse; width: 100%;">';
      
      for (let i = 0; i < numRows; i++) {
        tableHTML += '<tr>';
        for (let j = 0; j < numCols; j++) {
          tableHTML += `<td style="padding: 8px; border: 1px solid #ddd;">${i === 0 ? `Header ${j + 1}` : `Cell ${i},${j + 1}`}</td>`;
        }
        tableHTML += '</tr>';
      }
      
      tableHTML += '</table>';
      this.execCommand('insertHTML', tableHTML);
    }
  }

  insertImage(): void {
    const url = prompt('Enter image URL:');
    const alt = prompt('Enter alt text:');
    
    if (url) {
      const imgHTML = `<img src="${url}" alt="${alt || 'Image'}" style="max-width: 100%; height: auto;">`;
      this.execCommand('insertHTML', imgHTML);
    }
  }

  undo(): void {
    this.execCommand('undo');
  }

  redo(): void {
    this.execCommand('redo');
  }

  /**
   * Open HTML code input modal
   */
  openHtmlCodeInput(): void {
    this.htmlCodeInput = this.content || '';
    this.showHtmlModal = true;
  }

  /**
   * Close HTML code input modal
   */
  closeHtmlModal(): void {
    this.showHtmlModal = false;
    this.htmlCodeInput = '';
    this.isPreviewMode = false;
  }

  /**
   * Apply HTML code to editor
   */
  applyHtmlCode(): void {
    if (this.htmlCodeInput.trim()) {
      this.content = this.htmlCodeInput;
      this.updateEditorContent();
      this.onChange(this.content);
      this.contentChange.emit(this.content);
      this.updateWordCount();
    }
    this.closeHtmlModal();
  }

  /**
   * Toggle between HTML code view and preview mode in modal
   */
  togglePreviewMode(): void {
    this.isPreviewMode = !this.isPreviewMode;
  }

  /**
   * Sanitize HTML to prevent XSS attacks (public method for template access)
   */
  public sanitizeHtml(html: string): string {
    // Create a temporary div to parse and clean HTML
    const tempDiv = document.createElement('div');
    tempDiv.innerHTML = html;

    // Remove script tags and event handlers for security
    const scripts = tempDiv.querySelectorAll('script');
    scripts.forEach(script => script.remove());

    // Remove dangerous attributes
    const allElements = tempDiv.querySelectorAll('*');
    allElements.forEach(element => {
      const attributes = element.attributes;
      for (let i = attributes.length - 1; i >= 0; i--) {
        const attrName = attributes[i].name.toLowerCase();
        if (attrName.startsWith('on') || attrName === 'javascript:') {
          element.removeAttribute(attrName);
        }
      }
    });

    return tempDiv.innerHTML;
  }

  /**
   * Get formatted HTML with proper indentation for display
   */
  getFormattedHtml(html: string): string {
    if (!html) return '';
    
    // Simple HTML formatting - add line breaks and indentation
    let formatted = html
      .replace(/></g, '>\n<')
      .replace(/^\s*\n/gm, '')
      .trim();

    const lines = formatted.split('\n');
    let indentLevel = 0;
    const indentSize = 2;

    return lines.map(line => {
      const trimmedLine = line.trim();
      
      // Decrease indent for closing tags
      if (trimmedLine.startsWith('</')) {
        indentLevel = Math.max(0, indentLevel - indentSize);
      }
      
      const indentedLine = ' '.repeat(indentLevel) + trimmedLine;
      
      // Increase indent for opening tags (but not self-closing)
      if (trimmedLine.startsWith('<') && 
          !trimmedLine.startsWith('</') && 
          !trimmedLine.endsWith('/>') &&
          !this.isSelfClosingTag(trimmedLine)) {
        indentLevel += indentSize;
      }
      
      return indentedLine;
    }).join('\n');
  }

  /**
   * Check if a tag is self-closing
   */
  private isSelfClosingTag(tagLine: string): boolean {
    const selfClosingTags = ['br', 'hr', 'img', 'input', 'meta', 'link', 'area', 'base', 'col', 'embed', 'source', 'track', 'wbr'];
    const tagMatch = tagLine.match(/<(\w+)/);
    if (tagMatch) {
      const tagName = tagMatch[1].toLowerCase();
      return selfClosingTags.includes(tagName);
    }
    return false;
  }

  // Content Actions
  copyContent(): void {
    const content = this.getPlainText();
    
    if (content.trim()) {
      // Use the modern Clipboard API if available
      if (navigator.clipboard && window.isSecureContext) {
        navigator.clipboard.writeText(content).then(() => {
          this.showCopySuccess();
        }).catch((err) => {
          console.error('Failed to copy content: ', err);
          this.fallbackCopyText(content);
        });
      } else {
        // Fallback for older browsers
        this.fallbackCopyText(content);
      }
    } else {
      alert('No content to copy!');
    }
  }

  private fallbackCopyText(text: string): void {
    // Create a temporary textarea element
    const textArea = document.createElement('textarea');
    textArea.value = text;
    textArea.style.position = 'fixed';
    textArea.style.opacity = '0';
    textArea.style.left = '-999999px';
    textArea.style.top = '-999999px';
    
    document.body.appendChild(textArea);
    textArea.focus();
    textArea.select();
    
    try {
      document.execCommand('copy');
      this.showCopySuccess();
    } catch (err) {
      console.error('Fallback copy failed: ', err);
      alert('Failed to copy content. Please select and copy manually.');
    }
    
    document.body.removeChild(textArea);
  }

  private showCopySuccess(): void {
    // Show a temporary success message
    const message = document.createElement('div');
    message.textContent = 'Content copied to clipboard!';
    message.style.cssText = `
      position: fixed;
      top: 20px;
      right: 20px;
      background: #28a745;
      color: white;
      padding: 12px 20px;
      border-radius: 6px;
      font-size: 14px;
      font-weight: 500;
      z-index: 1000;
      box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
      animation: slideInRight 0.3s ease-out;
    `;
    
    document.body.appendChild(message);
    
    // Remove the message after 3 seconds
    setTimeout(() => {
      if (message.parentNode) {
        message.parentNode.removeChild(message);
      }
    }, 3000);
  }

  openAIAssistant(): void {
    // Placeholder for future AI assistant functionality
    alert('AI Assistant feature coming soon! This will help you with content generation, editing suggestions, and more.');
    
    // TODO: Implement AI assistant functionality
    // This could include:
    // - Content generation based on prompts
    // - Grammar and style suggestions
    // - Content enhancement
    // - Summarization
    // - Translation
    // - Tone adjustment
    
    console.log('AI Assistant clicked - Future implementation will go here');
  }

  // Override the content change handler to fix lists automatically
  onContentChange(): void {
    if (this.editor) {
      this.content = this.editor.nativeElement.innerHTML;
      this.onChange(this.content);
      this.contentChange.emit(this.content);
      this.updateWordCount();
      
      // Auto-fix list indentation when content changes
      setTimeout(() => this.fixListIndentation(), 50);
    }
  }
}
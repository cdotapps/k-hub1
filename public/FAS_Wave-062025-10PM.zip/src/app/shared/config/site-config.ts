import { faMeetup } from '@fortawesome/free-brands-svg-icons';
import { 
  faHome, faChevronDown, faCode, faRocket, faMobile, 
  faCloud, faRobot, faBitcoinSign, faWifi, faCogs, 
  faChartLine, faUsers, faTasks, faShieldAlt, faLightbulb, 
  faCreditCard, faBell, faUser, faSignOutAlt, faNewspaper,
  faFileAlt, faBook, faGraduationCap, faBlog, faFlask, 
  faFileContract, faFileImage, faChartLine as faChartLineAlt, 
  faLightbulb as faLightbulbAlt, faInfoCircle,
  faNoteSticky, faPlus, faWrench, faTrophy, faCheckCircle,
  faFolder, faChartBar,
  faBriefcase
} from '@fortawesome/free-solid-svg-icons';
import { IconDefinition } from '@fortawesome/fontawesome-svg-core';

// Interface for menu items
export interface MenuItem {
  label: string;
  path?: string;
  icon?: any;
  variant?: 'primary' | 'secondary' | 'success' | 'warning' | 'danger' | 'muted';
  children?: MenuItem[];
  roles?: string[]; // Which roles can see this item
  external?: boolean; // If true, opens in new tab
}

// Interface for menu items
export interface MenuItem {
  label: string;
  path?: string;
  icon?: any;
  variant?: 'primary' | 'secondary' | 'success' | 'warning' | 'danger' | 'muted';
  children?: MenuItem[];
  roles?: string[]; // Which roles can see this item
  external?: boolean; // If true, opens in new tab
  description?: string; // Optional description for hover display
}

// Interface for mega menu sections
export interface MegaMenuSection {
  title: string;
  type: 'links' | 'apps' | 'enhanced-links'; // Added enhanced-links type
  items: MenuItem[];
}

// Interface for mega menu
export interface MegaMenu {
  id: string;
  label: string;
  icon?: any;
  width?: string;
  sections: MegaMenuSection[];
  roles?: string[]; // Which roles can see this mega menu
}

// Interface for app icon items
export interface AppIconItem {
  icon: any;
  label: string;
  variant: 'primary' | 'secondary' | 'success' | 'warning' | 'danger' | 'muted';
  path?: string;
}

// Interface for home navigation buttons
export interface HomeNavigationButton {
  icon: IconDefinition;
  label: string;
  badgeCount?: number;
  isActive?: boolean;
  iconVariant?: 'primary' | 'secondary' | 'success' | 'warning' | 'danger' | 'muted' | 'white';
  route: string;
}

// Interface for CatalogType
export interface CatalogType {
  value: string;
  label: string;
  icon: any;
  color: string;
  background: string;
  description: string;
  roles?: string[]; // Which roles can see/use this catalog type
}

// App configuration
export const APP_CONFIG = {
  name: 'FST-Hub',
  logo: '/assets/images/title.png',
  logoAlt: 'FST Hub Logo'
};

// Catalog Types configuration
export const CATALOG_TYPES: CatalogType[] = [
  {
    value: 'news',
    label: 'News',
    icon: faNewspaper,
    color: '#ffffff',
    background: '#1a73e8',
    roles: ['user', 'admin', 'manager', 'developer'],
    description: 'Company news, updates, and announcements',
  },
  {
    value: 'notification',
    label: 'Notification',
    icon: faBell,
    color: '#ffffff',
    background: '#e53935',
    roles: ['admin', 'manager'],
    description: 'Important alerts and time-sensitive information',
  },
  {
    value: 'news-letter',
    label: 'News Letter',
    icon: faFileAlt,
    color: '#ffffff',
    background: '#4caf50',
    roles: ['user', 'admin', 'manager', 'developer'],
    description: 'Regular digest of company highlights and activities',
  },
  {
    value: 'shoutout',
    label: 'Shoutout',
    icon: faUsers,
    color: '#ffffff',
    background: '#ff9800',
    roles: ['user', 'admin', 'manager', 'developer'],
    description: 'Recognition and appreciation for team members',
  },
  {
    value: 'quick-win',
    label: 'Quick Win',
    icon: faLightbulb,
    color: '#ffffff',
    background: '#9c27b0',
    roles: ['user', 'admin', 'manager', 'developer'],
    description: 'Small achievements and successful initiatives',
  },
  {
    value: 'meeting-note',
    label: 'Meeting Note',
    icon: faNoteSticky,
    color: '#ffffff',
    background: '#1a73e8',
    roles: ['user', 'admin', 'manager', 'developer'],
    description: 'Detailed records of meeting discussions and decisions',
  },
  {
    value: 'presentation',
    label: 'Presentation',
    icon: faFileImage,
    color: '#ffffff',
    background: '#00897b',
    roles: ['user', 'admin', 'manager', 'developer'],
    description: 'Important Slides and presentation materials',
  },
];

// Home navigation buttons configuration
export const HOME_NAVIGATION_BUTTONS: HomeNavigationButton[] = [
  {
    icon: faHome,
    label: 'Dashboard',
    isActive: false,
    iconVariant: 'primary',
    route: 'dashboard'
  },
  {
    icon: faTrophy,
    label: 'Quick Wins',
    isActive: false,
    iconVariant: 'secondary',
    route: 'quick-wins'
  },
  {
    icon: faCheckCircle,
    label: 'Approvals',
    isActive: false,
    iconVariant: 'success',
    route: 'approvals'
  },
  {
    icon: faWrench,
    label: 'Assets',
    isActive: false,
    iconVariant: 'primary',
    route: 'team'
  },
  {
    icon: faBriefcase,
    label: 'Catalog',
    isActive: false,
    iconVariant: 'primary',
    route: 'catalog'
  },
  {
    icon: faChartBar,
    label: 'Reports',
    isActive: false,
    iconVariant: 'secondary',
    route: 'reports'
  }
];

// Helper function to filter catalog types by user role
export const filterCatalogTypesByRole = (userRole?: string | null): CatalogType[] => {
  if (!userRole) return [];
  
  return CATALOG_TYPES.filter(type => {
    // If no roles specified, show to everyone
    if (!type.roles || type.roles.length === 0) return true;
    
    // Show if user role is in the allowed roles
    return type.roles.includes(userRole);
  });
};

// Technology mega menu section
const TECHNOLOGY_MEGA_MENU: MegaMenu = {
  id: 'technology',
  label: 'Technology',
  icon: faChevronDown,
  width: '600px',
  sections: [
    {
      title: 'Development & Infrastructure',
      type: 'links',
      items: [
        { label: 'Web Development', path: '/technology/web' },
        { label: 'Mobile Apps', path: '/technology/mobile' },
        { label: 'API Integration', path: '/technology/api' },
        { label: 'Cloud Solutions', path: '/technology/cloud' },
        { label: 'DevOps', path: '/technology/devops' },
        { label: 'Microservices', path: '/technology/microservices' },
       ]
    },
    {
      title: 'Innovation Apps',
      type: 'apps',
      items: [
        // First column
        { label: 'AI Studio', icon: faRobot, variant: 'primary', path: '/technology/ai' },
        { label: 'IoT Hub', icon: faWifi, variant: 'secondary', path: '/technology/iot' },
        { label: 'Dev Tools', icon: faCode, variant: 'primary', path: '/technology/tools' },
        // Second column
        { label: 'Blockchain', icon: faBitcoinSign, variant: 'warning', path: '/technology/blockchain' },
        { label: 'Automation', icon: faCogs, variant: 'success', path: '/technology/automation' },
        { label: 'Cloud Ops', icon: faCloud, variant: 'secondary', path: '/technology/cloud-ops' },
      ]
    }
  ],
  roles: ['user', 'admin', 'developer'] // All authenticated users can see this
};

// Business mega menu section
const BUSINESS_MEGA_MENU: MegaMenu = {
  id: 'business',
  label: 'Business',
  icon: faChevronDown,
  width: '600px',
  sections: [
    {
      title: 'Financial Services & Strategy',
      type: 'links',
      items: [
        { label: 'Banking Solutions', path: '/business/banking' },
        { label: 'Payment Systems', path: '/business/payments' },
        { label: 'Risk Management', path: '/business/risk' },
        { label: 'Compliance', path: '/business/compliance' },
        { label: 'Digital Transformation', path: '/business/transformation' },
        { label: 'Process Optimization', path: '/business/optimization' },
     ]
    },
    {
      title: 'Business Apps',
      type: 'apps',
      items: [
        // First column
        { label: 'Analytics', icon: faChartLine, variant: 'primary', path: '/business/analytics' },
        { label: 'CRM', icon: faUsers, variant: 'secondary', path: '/business/crm' },
        { label: 'Compliance', icon: faShieldAlt, variant: 'danger', path: '/business/compliance' },
        // Second column
        { label: 'Finance', icon: faCreditCard, variant: 'success', path: '/business/finance' },
        { label: 'Projects', icon: faTasks, variant: 'warning', path: '/business/projects' },
        { label: 'Strategy', icon: faLightbulb, variant: 'warning', path: '/business/strategy' },
      ]
    }
  ],
  roles: ['user', 'admin', 'manager'] // All authenticated users can see this
};

// Tools mega menu section - Simple and clean
const TOOLS_MEGA_MENU: MegaMenu = {
  id: 'tools',
  label: 'Tools',
  icon: faWrench,
  width: '430px',
  sections: [
    {
      title: 'Content Creation',
      type: 'links',
      items: [
        { label: 'Create Newsletter', path: '/user/catalog/create-newsletter' },
        { label: 'Create Article', path: '/user/catalog/create-article' },
        { label: 'Post News', path: '/user/catalog/create-news' },
        { label: 'Template Gallery', path: '/user/catalog/templates' }
      ]
    },
    {
      title: 'Productivity Tools',
      type: 'apps',
      items: [
        // First column
        { label: 'Editor', icon: faFileAlt, variant: 'primary', path: '/tools/editor' },
        { label: 'Scheduler', icon: faPlus, variant: 'secondary', path: '/tools/scheduler' },
        // Second column
        { label: 'Collaborate', icon: faUsers, variant: 'secondary', path: '/tools/collaborate' },
        { label: 'Notifications', icon: faBell, variant: 'danger', path: '/tools/notifications' },
      ]
    }
  ],
  roles: ['user', 'admin', 'manager', 'developer'] // All authenticated users can see this
};

// All mega menus for the header
export const HEADER_MEGA_MENUS: MegaMenu[] = [
  TECHNOLOGY_MEGA_MENU,
  BUSINESS_MEGA_MENU,
  TOOLS_MEGA_MENU
];

// User menu items (shown in the user dropdown)
export const USER_MENU_ITEMS: MenuItem[] = [
  { 
    label: 'Admin Dashboard', 
    path: 'admin/dashboard', 
    icon: faShieldAlt, 
    variant: 'warning',
    roles: ['admin'] // Only admin users can see this
  },
  { 
    label: 'My Profile', 
    path: 'profile', 
    icon: faUser, 
    variant: 'primary',
    roles: ['user', 'admin', 'manager', 'developer'] // All authenticated users can see this
  },
  { 
    label: 'Sign Out', 
    path: '#', // Special case handled in component
    icon: faSignOutAlt, 
    variant: 'danger',
    roles: ['user', 'admin', 'manager', 'developer'] // All authenticated users can see this
  }
];

// Mobile menu items (shown on small screens)
export const MOBILE_MENU_ITEMS: MenuItem[] = [
  { 
    label: 'Technology', 
    path: '/technology', 
    roles: ['user', 'admin', 'manager', 'developer'] 
  },
  { 
    label: 'Business', 
    path: '/business',
    roles: ['user', 'admin', 'manager', 'developer'] 
  },
  { 
    label: 'Tools', 
    path: '/tools',
    roles: ['user', 'admin', 'manager', 'developer'] 
  }
];

// Helper function to filter menu items by user role
export const filterItemsByRole = (items: MenuItem[], userRole?: string | null): MenuItem[] => {
  if (!userRole) return [];
  
  return items.filter(item => {
    // If no roles specified, show to everyone
    if (!item.roles || item.roles.length === 0) return true;
    
    // Show if user role is in the allowed roles
    return item.roles.includes(userRole);
  });
};

// Helper function to filter mega menus by user role
export const filterMegaMenusByRole = (menus: MegaMenu[], userRole?: string | null): MegaMenu[] => {
  if (!userRole) return [];
  
  return menus.filter(menu => {
    // If no roles specified, show to everyone
    if (!menu.roles || menu.roles.length === 0) return true;
    
    // Show if user role is in the allowed roles
    return menu.roles.includes(userRole);
  });
};
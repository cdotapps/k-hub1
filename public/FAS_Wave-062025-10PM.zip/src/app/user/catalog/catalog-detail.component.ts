import { Component, OnInit, OnDestroy } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Subscription } from 'rxjs';

// FontAwesome Icons
import { 
  faNewspaper, faCalendar, faUser, faTag, faEye, faHeart, faShare, faEdit, faTrash,
  faArrowLeft, faExternalLinkAlt, faDownload, faBookmark, faClock, 
  faThumbsUp, faComment, faFlag, faXmark, faSpinner, faExclamationTriangle,
  faCheckCircle, faTimes, faReply, faPaperPlane, faEllipsisV, faPlus,
  faEnvelope, faCopy, faExpand, faInfoCircle, faList, faSliders, faSave, faCheck
} from '@fortawesome/free-solid-svg-icons';

// Services and Models
import { CatalogService } from '../../shared/services/catalog.service';
import { AuthService } from '../../shared/services/auth.service';
import { DateUtilityService } from '../../shared/services/date-utility.service';
import { TemplateService } from '../../shared/services/template.service';
import { Catalog, User, CatalogConversation, ConversationMessage } from '../../shared/models/user.interface';

// Add interface for additional attributes
interface AdditionalAttribute {
  attribute: string;
  value: string;
  group: string;
}

@Component({
  selector: 'app-catalog-detail',
  templateUrl: './catalog-detail.component.html',
  styleUrls: ['./catalog-detail.component.css']
})
export class CatalogDetailComponent implements OnInit, OnDestroy {
  // FontAwesome Icons
  faNewspaper = faNewspaper;
  faCalendar = faCalendar;
  faUser = faUser;
  faTag = faTag;
  faEye = faEye;
  faHeart = faHeart;
  faShare = faShare;
  faEdit = faEdit;
  faTrash = faTrash;
  faArrowLeft = faArrowLeft;
  faExternalLinkAlt = faExternalLinkAlt;
  faDownload = faDownload;
  faBookmark = faBookmark;
  faClock = faClock;
  faThumbsUp = faThumbsUp;
  faComment = faComment;
  faFlag = faFlag;
  faXmark = faXmark;
  faSpinner = faSpinner;
  faExclamationTriangle = faExclamationTriangle;
  faCheckCircle = faCheckCircle;
  faTimes = faTimes;
  faReply = faReply;
  faPaperPlane = faPaperPlane;
  faEllipsisV = faEllipsisV;
  faPlus = faPlus;
  faEnvelope = faEnvelope;
  faCopy = faCopy;
  faExpand = faExpand;
  faInfoCircle = faInfoCircle;
  faList = faList;
  faSliders = faSliders;
  faSave = faSave;
  faCheck = faCheck;

  // Template reference for the "no comments" state
  noComments = null;

  // Data Properties
  catalogItem: Catalog | null = null;
  relatedItems: Catalog[] = [];
  currentUser: User | null = null;
  isLoading = false;
  showShareModal = false;
  showFullView = false;
  errorMessage = '';
  breadcrumbItems: any[] = [];

  // ===== CONVERSATION PROPERTIES =====
  conversations: ConversationMessage[] = [];
  conversationCount = 0; // Track conversation count separately
  isLoadingConversations = false;
  showConversations = false;
  newMessage = '';
  isPostingMessage = false;
  replyingTo: ConversationMessage | null = null;
  replyMessage = '';
  editingMessage: ConversationMessage | null = null;
  editMessageText = '';

  // Messages for chatbox
  messages: ConversationMessage[] = [];

  // Debug Properties
  showDebugInfo = false;

  // Additional attributes popup state
  showAdditionalAttributes = false;
  additionalAttributes: AdditionalAttribute[] = [];

  // Simplified inline editing state (replacing separate edit popup)
  isEditingAttributes = false;
  newAttributeForGroup = '';
  showFirstAttributeForm = false;

  // Edit attributes popup state
  showEditAttributes = false;
  editableAttributes: AdditionalAttribute[] = [];
  newAttributeGroup = 'General';
  newAttributeName = '';
  newAttributeValue = '';
  isSavingAttributes = false;

  // Group management state
  showAddGroupForm = false;
  newGroupName = '';
  isAddingGroup = false;

  // Full view content
  fullViewHTML = '';

  // Modal state for delete confirmation
  showDeleteConfirm = false;

  private subscriptions = new Subscription();

  constructor(
    private route: ActivatedRoute,
    private router: Router,
    private catalogService: CatalogService,
    private authService: AuthService,
    private dateUtilityService: DateUtilityService,
    private templateService: TemplateService
  ) {}

  ngOnInit(): void {
    // Initialize breadcrumbs
    this.initializeBreadcrumbs();

    // Subscribe to authentication state
    this.subscriptions.add(
      this.authService.currentUser$.subscribe((user: User | null) => {
        this.currentUser = user;
      })
    );

    // Subscribe to route params
    this.subscriptions.add(
      this.route.params.subscribe(params => {
        const itemId = params['id'];
        if (itemId) {
          this.loadCatalogItem(itemId);
        }
      })
    );
  }

  ngOnDestroy(): void {
    this.subscriptions.unsubscribe();
  }

  /**
   * Initialize breadcrumb items
   */
  private initializeBreadcrumbs(): void {
    this.breadcrumbItems = [
      { label: 'Dashboard', routerLink: '/user/dashboard' },
      { label: 'Catalog', routerLink: '/user/catalog' },
      { label: 'Article Details', routerLink: null } // Current page
    ];
  }

  /**
   * Update breadcrumbs with article title once loaded
   */
  private updateBreadcrumbs(): void {
    if (this.catalogItem) {
      this.breadcrumbItems = [
        { label: 'Dashboard', routerLink: '/user/dashboard' },
        { label: 'Catalog', routerLink: '/user/catalog' },
        { label: this.catalogItem.title, routerLink: null } // Current article title
      ];
    }
  }

  /**
   * Load catalog item details
   */
  loadCatalogItem(itemId: string): void {
    this.isLoading = true;

    this.catalogService.getCatalogItem(itemId).subscribe({
      next: (item) => {
        this.catalogItem = item;
        this.isLoading = false;
        
        // Update breadcrumbs with article title
        this.updateBreadcrumbs();
        
        // Update view count
        this.incrementViewCount();
        
        // Load related items
        this.loadRelatedItems();
        
        // Load comment count only (not the full conversations)
        this.loadCommentCount();
      },
      error: (error) => {
        console.error('Failed to load catalog item:', error);
        this.isLoading = false;
        // Navigate back to catalog on error
        this.router.navigate(['/user/catalog']);
      }
    });
  }

  /**
   * Increment view count
   */
  private incrementViewCount(): void {
    if (!this.catalogItem) return;

    this.catalogService.incrementViewCount(this.catalogItem.id).subscribe({
      next: (updatedItem) => {
        if (this.catalogItem) {
          this.catalogItem.views_count = updatedItem.views_count;
        }
      },
      error: (error) => {
        console.error('Failed to increment view count:', error);
      }
    });
  }

  /**
   * Load related items
   */
  private loadRelatedItems(): void {
    if (!this.catalogItem) return;

    const params = {
      category: this.catalogItem.category,
      limit: 4,
      exclude: this.catalogItem.id
    };

    this.catalogService.getCatalogItems(params).subscribe({
      next: (response) => {
        this.relatedItems = response.items || [];
      },
      error: (error) => {
        console.error('Failed to load related items:', error);
        this.relatedItems = [];
      }
    });
  }

  /**
   * Navigate back to catalog
   */
  goBack(): void {
    this.router.navigate(['/user/catalog']);
  }

  /**
   * Navigate to related item
   */
  goToRelatedItem(item: Catalog): void {
    this.router.navigate(['/user/catalog', item.id]);
  }

  /**
   * Toggle like status
   */
  toggleLike(): void {
    if (!this.catalogItem || !this.currentUser) return;

    const isLiked = this.catalogItem.user_has_liked;
    const action = isLiked ? 'unlike' : 'like';

    this.catalogService.toggleLike(this.catalogItem.id, action).subscribe({
      next: (response) => {
        if (this.catalogItem) {
          this.catalogItem.user_has_liked = !isLiked;
          this.catalogItem.likes_count = response.likes_count;
        }
      },
      error: (error) => {
        console.error('Failed to toggle like:', error);
      }
    });
  }

  /**
   * Share item
   */
  shareItem(): void {
    if (!this.catalogItem) return;

    if (navigator.share) {
      // Use native sharing if available
      navigator.share({
        title: this.catalogItem.title,
        text: this.catalogItem.description || this.getExcerpt(this.catalogItem.content || '', 100),
        url: window.location.href
      }).catch(console.error);
    } else {
      // Fallback to custom share modal
      this.showShareModal = true;
    }
  }

  /**
   * Close share modal
   */
  closeShareModal(): void {
    this.showShareModal = false;
  }

  /**
   * Copy link to clipboard
   */
  copyLink(): void {
    navigator.clipboard.writeText(window.location.href).then(() => {
      console.log('Link copied to clipboard');
      this.closeShareModal();
    }).catch(console.error);
  }

  /**
   * Email article
   */
  emailArticle(): void {
    if (!this.catalogItem) return;
    
    const subject = encodeURIComponent(`Article: ${this.catalogItem.title}`);
    
    // Convert HTML content to plain text and limit length
    const rawContent = this.catalogItem.content || this.catalogItem.description || '';
    const plainTextContent = this.stripHtmlTags(rawContent);
    const articleContent = plainTextContent.length > 1500 
      ? plainTextContent.substring(0, 1500) + '...' 
      : plainTextContent;
    
    const body = encodeURIComponent(`
Hi,

I thought you might be interested in this article:

Title: ${this.catalogItem.title}
Author: ${this.getAuthorDisplayName()}
Read Time: ${this.getReadingTime()}

${articleContent}

Read the full article here: ${window.location.href}

Best regards
    `);
    
    window.location.href = `mailto:?subject=${subject}&body=${body}`;
  }

  /**
   * Copy article link
   */
  copyArticleLink(): void {
    navigator.clipboard.writeText(window.location.href).then(() => {
      // Show success message (you could implement a toast service here)
      console.log('Article link copied to clipboard');
      // You could add a toast notification here
    }).catch(error => {
      console.error('Failed to copy link:', error);
    });
  }

  /**
   * Check if user can edit this item
   */
  canEdit(): boolean {
    // For testing purposes, always return true to see the edit options
    // You should remove this override after testing
    return true;
    
    // Original implementation:
    // if (!this.catalogItem || !this.currentUser) return false;
    // return this.currentUser?.user_id === this.catalogItem.author_id || 
    //       this.currentUser?.role === 'admin';
  }

  /**
   * Check if user can delete this item
   */
  canDelete(): boolean {
    if (!this.catalogItem || !this.currentUser) return false;
    return this.currentUser?.user_id === this.catalogItem.author_id || 
           this.currentUser?.role === 'admin';
  }

  /**
   * Edit item
   */
  editItem(): void {
    if (!this.catalogItem || !this.canEdit()) return;
    
    // Navigate to edit page using create-article component with the id parameter
    // This will load the item in edit mode
    this.router.navigate(['/user/catalog/edit', this.catalogItem.id]);
  }

  /**
   * Delete item
   */
  deleteItem(): void {
    if (!this.catalogItem || !this.canDelete()) return;

    if (confirm('Are you sure you want to delete this item?')) {
      this.catalogService.deleteCatalogItem(this.catalogItem.id).subscribe({
        next: () => {
          this.router.navigate(['/user/catalog']);
        },
        error: (error) => {
          console.error('Failed to delete item:', error);
        }
      });
    }
  }

  /**
   * Check if user can edit this item (alias for canEdit)
   */
  canEditItem(): boolean {
    return this.canEdit();
  }

  /**
   * Check if user can delete this item (alias for canDelete)
   */
  canDeleteItem(): boolean {
    return this.canDelete();
  }

  /**
   * Get formatted publish date
   */
  getFormattedPublishDate(): string {
    return this.catalogItem?.published_at
      ? this.formatDate(this.catalogItem.published_at)
      : this.formatDate(this.catalogItem?.created_date || '');
  }

  /**
   * Get reading time estimate
   */
  getReadingTime(): string {
    const content = this.catalogItem?.content || '';
    const wordsPerMinute = 200;
    const wordCount = content.split(' ').length;
    const minutes = Math.ceil(wordCount / wordsPerMinute);
    return `${minutes} min`;
  }

  /**
   * Format date for comments (similar to attachment format)
   */
  formatCommentDate(dateString: string | undefined): string {
    if (!dateString) return '';
    
    const date = new Date(dateString);
    const now = new Date();
    const diffInSeconds = Math.floor((now.getTime() - date.getTime()) / 1000);
    const diffInMinutes = Math.floor(diffInSeconds / 60);
    const diffInHours = Math.floor(diffInMinutes / 60);
    const diffInDays = Math.floor(diffInHours / 24);

    if (diffInSeconds < 60) {
      return 'Just now';
    } else if (diffInMinutes < 60) {
      return `${diffInMinutes} min${diffInMinutes > 1 ? 's' : ''} ago`;
    } else if (diffInHours < 24) {
      return `${diffInHours} hour${diffInHours > 1 ? 's' : ''} ago`;
    } else if (diffInDays < 7) {
      return `${diffInDays} day${diffInDays > 1 ? 's' : ''} ago`;
    } else {
      // For older comments, show the actual date
      const options: Intl.DateTimeFormatOptions = { 
        year: 'numeric', 
        month: 'short', 
        day: 'numeric' 
      };
      return date.toLocaleDateString('en-US', options);
    }
  }

  /**
   * Check if item is recently published (within 7 days) - fix null safety
   */
  isRecentlyPublished(): boolean {
    if (!this.catalogItem) return false;
    
    const publishDate = new Date(this.catalogItem?.published_at || this.catalogItem?.created_date || '');
    const now = new Date();
    const daysDiff = (now.getTime() - publishDate.getTime()) / (1000 * 60 * 60 * 24);
    return daysDiff <= 7; // Published within last 7 days
  }

  /**
   * Get publish date for meta tag
   */
  getPublishDateForMeta(): string {
    if (!this.catalogItem) return '';
    const publishDate = new Date(this.catalogItem?.published_at || this.catalogItem?.created_date || '');
    return publishDate.toISOString();
  }

  /**
   * Get last updated text
   */
  getLastUpdated(): string {
    if (!this.catalogItem?.updated_date) return '';
    
    const updatedDate = new Date(this.catalogItem.updated_date);
    const publishDate = new Date(this.catalogItem.published_at || this.catalogItem.created_date || '');
    
    // Only show "Last updated" if it was updated after initial publication
    if (updatedDate > publishDate) {
      return `Last updated ${this.formatRelativeTime(this.catalogItem.updated_date)}`;
    }
    
    return '';
  }

  /**
   * Format date
   */
  formatDate(dateString: string): string {
    if (!dateString) return '';
    return this.dateUtilityService.formatDate(dateString);
  }

  /**
   * Format relative time
   */
  formatRelativeTime(dateString: string | undefined): string {
    if (!dateString) return '';
    return this.dateUtilityService.getRelativeTime(dateString);
  }

  /**
   * Get excerpt from text
   */
  getExcerpt(text: string | undefined, maxLength: number = 150): string {
    if (!text) return '';
    if (text.length <= maxLength) return text;
    return text.substring(0, maxLength) + '...';
  }

  /**
   * Get category CSS class
   */
  getCategoryClass(category: string | undefined): string {
    if (!category) return '';
    const categoryMap: { [key: string]: string } = {
      'news': 'category-news',
      'article': 'category-article',
      'announcement': 'category-announcement',
      'guide': 'category-guide',
      'tutorial': 'category-tutorial',
      'documentation': 'category-documentation',
      'blog': 'category-blog',
      'research': 'category-research',
      'whitepaper': 'category-whitepaper',
      'case-study': 'category-case-study'
    };
    return categoryMap[category] || 'category-default';
  }

  /**
   * Get item status CSS class
   */
  getItemStatusClass(status: string | undefined): string {
    if (!status) return '';
    const statusMap: { [key: string]: string } = {
      'draft': 'status-draft',
      'published': 'status-published',
      'archived': 'status-archived',
      'pending': 'status-pending',
      'approved': 'status-approved',
      'rejected': 'status-rejected'
    };
    return statusMap[status] || 'status-default';
  }

  /**
   * Download article (if URL is available)
   */
  downloadArticle(): void {
    if (!this.catalogItem?.url) return;
    
    const link = document.createElement('a');
    link.href = this.catalogItem.url;
    link.download = this.catalogItem.title;
    link.click();
  }

  /**
   * Open external link
   */
  openExternalLink(): void {
    if (!this.catalogItem?.url) return;
    window.open(this.catalogItem.url, '_blank');
  }

  /**
   * Report content
   */
  reportContent(): void {
    if (!this.catalogItem) return;
    // Implement reporting functionality
    console.log('Report content:', this.catalogItem);
  }

  /**
   * Bookmark item
   */
  bookmarkItem(): void {
    if (!this.catalogItem) return;
    // Implement bookmark functionality
    console.log('Bookmark item:', this.catalogItem);
  }

  /**
   * Get author display name
   */
  getAuthorDisplayName(): string {
    return this.catalogItem?.author || 'Unknown Author';
  }

  /**
   * Get published date
   */
  getPublishedDate(): string {
    return this.catalogItem?.published_at 
      ? this.formatDate(this.catalogItem.published_at)
      : this.formatDate(this.catalogItem?.created_date || '');
  }

  /**
   * Check if comment is recent (within last 24 hours) to show "Pending" status
   */
  isRecentComment(dateString: string | undefined): boolean {
    if (!dateString) return false;
    
    const commentDate = new Date(dateString);
    const oneDayAgo = new Date();
    oneDayAgo.setDate(oneDayAgo.getDate() - 1);
    
    return commentDate > oneDayAgo;
  }

  // ===== CONVERSATION METHODS =====

  /**
   * Get conversation count
   */
  getConversationCount(): number {
    // Return the separate conversation count if available, otherwise fall back to conversations length
    return this.conversationCount || this.conversations?.length || 0;
  }

  /**
   * Load conversation count only (without loading full conversations)
   */
  loadCommentCount(): void {
    if (!this.catalogItem) return;

    // Use the catalog's conversations property if available
    if (this.catalogItem.conversations && this.catalogItem.conversations.total_messages !== undefined) {
      this.conversationCount = this.catalogItem.conversations.total_messages;
      return;
    }

    // Load conversations count from API
    this.catalogService.getCatalogConversations(this.catalogItem.id).subscribe({
      next: (conversations) => {
        this.conversationCount = conversations.total_messages || 0;
        // Store the conversations data for later use
        if (this.catalogItem) {
          this.catalogItem.conversations = {
            messages: conversations.messages || [],
            total_messages: conversations.total_messages || 0,
            last_activity: conversations.last_activity || new Date().toISOString()
          };
        }
      },
      error: (error) => {
        console.error('Failed to load conversation count:', error);
        this.conversationCount = 0;
        
        // Initialize empty conversations structure
        if (this.catalogItem) {
          this.catalogItem.conversations = {
            messages: [],
            total_messages: 0,
            last_activity: new Date().toISOString()
          };
        }
      }
    });
  }

  /**
   * Load conversations for the catalog item
   */
  loadConversations(): void {
    if (!this.catalogItem) return;

    this.isLoadingConversations = true;
    
    // First check if catalog already has conversations loaded
    if (this.catalogItem.conversations && 
        this.catalogItem.conversations.messages && 
        this.catalogItem.conversations.messages.length > 0) {
      // Sort conversations by most recent first (newest at top)
      this.conversations = this.catalogItem.conversations.messages.sort((a, b) => 
        new Date(b.created_date).getTime() - new Date(a.created_date).getTime()
      );
      this.conversationCount = this.catalogItem.conversations.total_messages;
      this.isLoadingConversations = false;
      return;
    }

    // Load conversations from API
    this.catalogService.getCatalogConversations(this.catalogItem.id).subscribe({
      next: (conversations) => {
        // Sort conversations by most recent first (newest at top)
        this.conversations = (conversations.messages || []).sort((a, b) => 
          new Date(b.created_date).getTime() - new Date(a.created_date).getTime()
        );
        
        // Update conversation count
        this.conversationCount = conversations.total_messages || 0;
        
        // Update the catalog item's conversations property
        if (this.catalogItem) {
          this.catalogItem.conversations = {
            messages: this.conversations,
            total_messages: this.conversationCount,
            last_activity: conversations.last_activity || new Date().toISOString()
          };
        }
        
        this.isLoadingConversations = false;
      },
      error: (error) => {
        console.error('Failed to load conversations:', error);
        this.conversations = [];
        this.conversationCount = 0;
        
        // Initialize empty conversations structure
        if (this.catalogItem) {
          this.catalogItem.conversations = {
            messages: [],
            total_messages: 0,
            last_activity: new Date().toISOString()
          };
        }
        
        this.isLoadingConversations = false;
      }
    });
  }

  /**
   * Toggle conversations display
   */
  toggleConversations(): void {
    this.showConversations = !this.showConversations;
    if (this.showConversations && this.conversations.length === 0) {
      this.loadConversations();
    }
  }

  /**
   * Close conversations
   */
  closeConversations(): void {
    this.showConversations = false;
  }

  /**
   * Check if there are conversation messages
   */
  hasConversationMessages(): boolean {
    return this.conversations && this.conversations.length > 0;
  }

  /**
   * Track function for ngFor on messages
   */
  trackByMessageId(index: number, message: ConversationMessage): string {
    return message.id;
  }

  /**
   * Get user initials for avatar
   */
  getUserInitials(name: string): string {
    if (!name) return 'U';
    const names = name.split(' ');
    if (names.length === 1) {
      return names[0].charAt(0).toUpperCase();
    }
    return (names[0].charAt(0) + names[names.length - 1].charAt(0)).toUpperCase();
  }

  /**
   * Get message user display name
   */
  getMessageUserDisplayName(message: ConversationMessage): string {
    return message.user_name || 'Unknown User';
  }

  /**
   * Handle textarea keydown for posting messages
   */
  onTextareaKeydown(event: KeyboardEvent, type: 'post' | 'edit' | 'reply'): void {
    if (event.key === 'Enter' && (event.ctrlKey || event.metaKey)) {
      event.preventDefault();
      switch (type) {
        case 'post':
          this.postMessage();
          break;
        case 'edit':
          this.saveEdit();
          break;
        case 'reply':
          this.postReply();
          break;
      }
    }
  }

  /**
   * Post a new message - using stub implementation
   */
  postMessage(): void {
    if (!this.newMessage.trim() || !this.catalogItem || !this.currentUser) return;

    this.isPostingMessage = true;
    
    console.log('🔄 Posting message with current user:', {
      id: this.currentUser.id,
      user_id: this.currentUser.user_id,
      first_name: this.currentUser.first_name,
      last_name: this.currentUser.last_name,
      profile_image: this.currentUser.profile_image
    });
    
    // Use the API to post the message
    this.catalogService.addConversationMessage(this.catalogItem.id, this.newMessage.trim()).subscribe({
      next: (newMessage) => {
        console.log('📨 Received new message from API:', newMessage);
        
        // Ensure the message has proper user information
        const enrichedMessage: ConversationMessage = {
          ...newMessage,
          user_id: newMessage.user_id || this.currentUser!.id,
          user_name: newMessage.user_name || this.getUserDisplayName(this.currentUser!),
          user_profile_image: newMessage.user_profile_image || this.currentUser!.profile_image || undefined
        };
        
        console.log('✨ Enriched message:', enrichedMessage);
        
        // Add new message to the beginning (most recent first)
        this.conversations = [enrichedMessage, ...this.conversations];
        
        // Update conversation count
        this.conversationCount = this.conversations.length;
        
        // Initialize conversations structure if it doesn't exist
        if (!this.catalogItem!.conversations) {
          this.catalogItem!.conversations = {
            messages: [],
            total_messages: 0,
            last_activity: new Date().toISOString()
          };
        }
        
        // Update the catalog item's conversations property
        this.catalogItem!.conversations = {
          messages: this.conversations,
          total_messages: this.conversationCount,
          last_activity: new Date().toISOString()
        };
        
        this.newMessage = '';
        this.isPostingMessage = false;
      },
      error: (error) => {
        console.error('Failed to post message:', error);
        this.isPostingMessage = false;
        // TODO: Show error message to user
      }
    });
  }

  /**
   * Get current user display name
   */
  private getUserDisplayName(user: User): string {
    if (!user) return 'Unknown User';
    
    // Try to build full name from first and last name
    const firstName = (user.first_name || '').trim();
    const lastName = (user.last_name || '').trim();
    const fullName = `${firstName} ${lastName}`.trim();
    
    if (fullName) {
      return fullName;
    }
    
    // Fall back to user_id, email, or default
    return user.user_id || user.email || user.id || 'Unknown User';
  }

  /**
   * Like a message - using stub implementation
   */
  likeMessage(message: ConversationMessage): void {
    if (!this.catalogItem || !this.currentUser) return;

    // Stub implementation - replace with actual API call when available
    message.likes = (message.likes || 0) + 1;
  }

  /**
   * Start replying to a message
   */
  startReply(message: ConversationMessage): void {
    this.replyingTo = message;
    this.replyMessage = '';
  }

  /**
   * Cancel reply
   */
  cancelReply(): void {
    this.replyingTo = null;
    this.replyMessage = '';
  }

  /**
   * Post a reply - using stub implementation
   */
  postReply(): void {
    if (!this.replyMessage.trim() || !this.replyingTo || !this.catalogItem || !this.currentUser) return;

    // Stub implementation - replace with actual API call when available
    const newReply: ConversationMessage = {
      id: Date.now().toString(),
      user_id: this.currentUser.id,
      user_name: this.getUserDisplayName(this.currentUser),
      user_profile_image: this.currentUser.profile_image || undefined,
      message: this.replyMessage.trim(),
      created_date: new Date().toISOString(),
      parent_id: this.replyingTo.id,
      likes: 0,
      replies: []
    };

    if (this.replyingTo) {
      if (!this.replyingTo.replies) {
        this.replyingTo.replies = [];
      }
      this.replyingTo.replies.push(newReply);
    }
    this.cancelReply();
  }

  /**
   * Check if user can edit a message
   */
  canEditMessage(message: ConversationMessage): boolean {
    if (!this.currentUser) return false;
    return message.user_id === this.currentUser.id || this.currentUser.role === 'admin';
  }

  /**
   * Check if user can delete a message
   */
  canDeleteMessage(message: ConversationMessage): boolean {
    if (!this.currentUser) return false;
    return message.user_id === this.currentUser.id || this.currentUser.role === 'admin';
  }

  /**
   * Start editing a message
   */
  startEdit(message: ConversationMessage): void {
    this.editingMessage = message;
    this.editMessageText = message.message;
  }

  /**
   * Cancel edit
   */
  cancelEdit(): void {
    this.editingMessage = null;
    this.editMessageText = '';
  }

  /**
   * Save edit - using stub implementation
   */
  saveEdit(): void {
    if (!this.editMessageText.trim() || !this.editingMessage || !this.catalogItem) return;

    // Use the API to update the message
    this.catalogService.updateConversationMessage(
      this.catalogItem.id, 
      this.editingMessage.id, 
      this.editMessageText.trim()
    ).subscribe({
      next: (updatedMessage) => {
        // Update the message in the local array
        const index = this.conversations.findIndex(m => m.id === this.editingMessage!.id);
        if (index !== -1) {
          this.conversations[index] = updatedMessage;
        }
        
        // Initialize conversations structure if it doesn't exist
        if (!this.catalogItem!.conversations) {
          this.catalogItem!.conversations = {
            messages: [],
            total_messages: 0,
            last_activity: new Date().toISOString()
          };
        }
        
        // Update the catalog item's conversations property
        this.catalogItem!.conversations = {
          messages: this.conversations,
          total_messages: this.conversationCount,
          last_activity: new Date().toISOString()
        };
        
        this.cancelEdit();
      },
      error: (error) => {
        console.error('Failed to update message:', error);
        // TODO: Show error message to user
        this.cancelEdit();
      }
    });
  }

  /**
   * Delete a message
   */
  deleteMessage(message: ConversationMessage): void {
    if (!confirm('Are you sure you want to delete this message?')) return;
    if (!this.catalogItem) return;

    // Use the API to delete the message
    this.catalogService.deleteConversationMessage(this.catalogItem.id, message.id).subscribe({
      next: () => {
        // Remove message from local array
        this.conversations = this.conversations.filter(m => m.id !== message.id);
        
        // Update conversation count
        this.conversationCount = this.conversations.length;
        
        // Initialize conversations structure if it doesn't exist
        if (!this.catalogItem!.conversations) {
          this.catalogItem!.conversations = {
            messages: [],
            total_messages: 0,
            last_activity: new Date().toISOString()
          };
        }
        
        // Update the catalog item's conversations property
        this.catalogItem!.conversations = {
          messages: this.conversations,
          total_messages: this.conversationCount,
          last_activity: this.conversations.length > 0 ? this.conversations[0].created_date : new Date().toISOString()
        };
      },
      error: (error) => {
        console.error('Failed to delete message:', error);
        // TODO: Show error message to user
      }
    });
  }

  /**
   * Like the main item (alias for toggleLike)
   */
  likeItem(): void {
    this.toggleLike();
  }

  /**
   * View related item
   */
  viewRelatedItem(item: Catalog): void {
    this.router.navigate(['/user/catalog', item.id]);
  }

  /**
   * Go to catalog page
   */
  goToCatalog(): void {
    this.router.navigate(['/user/catalog']);
  }

  /**
   * Show delete confirmation
   */
  showDeleteConfirmation(): void {
    this.showDeleteConfirm = true;
  }

  /**
   * Cancel delete
   */
  cancelDelete(): void {
    this.showDeleteConfirm = false;
  }

  /**
   * Confirm delete
   */
  confirmDelete(): void {
    this.showDeleteConfirm = false;
    this.deleteItem();
  }

  /**
   * Get created date with full timestamp
   */
  getCreatedDateWithTime(): string {
    if (!this.catalogItem?.created_date) return 'Unknown';
    return this.dateUtilityService.formatDateWithTime(this.catalogItem.created_date);
  }

  /**
   * Get updated date with full timestamp
   */
  getUpdatedDateWithTime(): string {
    if (!this.catalogItem?.updated_date) return 'Unknown';
    return this.dateUtilityService.formatDateWithTime(this.catalogItem.updated_date);
  }

  /**
   * Check if the item has been updated (updated_date is different from created_date)
   */
  hasBeenUpdated(): boolean {
    if (!this.catalogItem?.updated_date || !this.catalogItem?.created_date) return false;
    
    const createdDate = new Date(this.catalogItem.created_date);
    const updatedDate = new Date(this.catalogItem.updated_date);
    
    // Consider it updated if the difference is more than 1 minute
    const diffInMinutes = Math.abs(updatedDate.getTime() - createdDate.getTime()) / (1000 * 60);
    return diffInMinutes > 1;
  }

  /**
   * Check if catalog item has tags
   */
  hasTags(): boolean {
    return !!(this.catalogItem?.tags && this.catalogItem.tags.length > 0);
  }

  /**
   * Get catalog item tags safely
   */
  getTags(): string[] {
    return this.catalogItem?.tags || [];
  }

  /**
   * Close chatbox
   */
  closeChatbox(): void {
    this.showConversations = false;
  }

  /**
   * Send a new message in chatbox
   */
  sendMessage(): void {
    if (this.newMessage.trim()) {
      const newMessage: ConversationMessage = {
        user_name: `${this.currentUser?.first_name || ''} ${this.currentUser?.last_name || 'Anonymous'}`.trim(),
        created_date: new Date().toISOString(),
        message: this.newMessage.trim(),
        id: Date.now().toString(),
        user_id: this.currentUser?.id || '0',
        likes: 0,
        replies: []
      };
      this.conversations.push(newMessage);
      this.newMessage = '';
    }
  }

  /**
   * Auto-resize textarea based on content
   */
  autoResizeTextarea(event: any): void {
    const textarea = event.target;
    textarea.style.height = 'auto';
    textarea.style.height = Math.min(textarea.scrollHeight, 120) + 'px'; // Max height of 120px
  }

  /**
   * Open full view modal for copy/paste
   */
  openFullView(): void {
    this.showFullView = true;
    this.generateFullViewHTML();
  }

  /**
   * Close full view modal
   */
  closeFullView(): void {
    this.showFullView = false;
    this.fullViewHTML = '';
  }

  /**
   * Copy full article HTML to clipboard
   */
  copyFullArticleHTML(): void {
    if (this.fullViewHTML) {
      navigator.clipboard.writeText(this.fullViewHTML).then(() => {
        console.log('Full article HTML copied to clipboard');
        // You could add a toast notification here
      }).catch(error => {
        console.error('Failed to copy full article HTML:', error);
      });
    } else {
      this.generateFullArticleHTML();
    }
  }

  /**
   * Generate full view HTML for display in modal
   */
  generateFullViewHTML(): void {
    if (!this.catalogItem) return;

    const templateData = {
      title: this.catalogItem.title,
      category: this.catalogItem.category || 'Article',
      author: this.getAuthorDisplayName(),
      publishedDate: this.getPublishedDate(),
      readingTime: this.getReadingTime(),
      description: this.catalogItem.description || '',
      content: this.catalogItem.content || '',
      originalUrl: window.location.href,
      generatedDate: new Date().toLocaleDateString()
    };

    this.templateService.loadTemplate('full-article', templateData).subscribe({
      next: (html) => {
        this.fullViewHTML = html;
      },
      error: (error) => {
        console.error('Failed to load template:', error);
        // Fallback to the old method if template loading fails
        this.fullViewHTML = this.generateFallbackHTMLString();
      }
    });
  }

  /**
   * Generate full article HTML for copy/paste using template service
   */
  generateFullArticleHTML(): void {
    if (!this.catalogItem) return;

    const templateData = {
      title: this.catalogItem.title,
      category: this.catalogItem.category || 'Article',
      author: this.getAuthorDisplayName(),
      publishedDate: this.getPublishedDate(),
      readingTime: this.getReadingTime(),
      description: this.catalogItem.description || '',
      content: this.catalogItem.content || '',
      originalUrl: window.location.href,
      generatedDate: new Date().toLocaleDateString()
    };

    this.templateService.loadTemplate('full-article', templateData).subscribe({
      next: (html) => {
        navigator.clipboard.writeText(html).then(() => {
          console.log('Full article HTML copied to clipboard');
          // You could add a toast notification here
        }).catch(error => {
          console.error('Failed to copy full article HTML:', error);
        });
      },
      error: (error) => {
        console.error('Failed to load template:', error);
        // Fallback to the old method if template loading fails
        const fallbackHTML = this.generateFallbackHTMLString();
        navigator.clipboard.writeText(fallbackHTML).then(() => {
          console.log('Fallback article HTML copied to clipboard');
        }).catch(error => {
          console.error('Failed to copy fallback HTML:', error);
        });
      }
    });
  }

  /**
   * Fallback method for generating HTML if template fails - returns string
   */
  private generateFallbackHTMLString(): string {
    if (!this.catalogItem) return '';

    return `
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>${this.catalogItem.title}</title>
    <style>
        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
            line-height: 1.6;
            max-width: 800px;
            margin: 0 auto;
            padding: 40px 20px;
            color: #333;
        }
        .article-header { border-bottom: 2px solid #e9ecef; padding-bottom: 20px; margin-bottom: 30px; }
        .article-title { font-size: 1.5rem; font-weight: 700; color: #1a1a1a; margin: 20px 0; }
        .article-meta { display: flex; gap: 20px; font-size: 0.95rem; color: #666; margin-bottom: 15px; }
        .article-content { margin: 30px 0; }
        .article-footer { border-top: 1px solid #e9ecef; padding-top: 20px; margin-top: 40px; }
    </style>
</head>
<body>
    <article>
        <header class="article-header">
            <h1 class="article-title">${this.catalogItem.title}</h1>
            <div class="meta">
              By ${this.getAuthorDisplayName()} | ${this.getPublishedDate()} | ${this.getReadingTime()} read
            </div>
        </header>
        <div class="article-content">${this.catalogItem.content || this.catalogItem.description || ''}</div>
        <footer class="article-footer">
            <p>Originally published at: ${window.location.href}</p>
            <p>Generated on: ${new Date().toLocaleDateString()}</p>
        </footer>
    </article>
</body>
</html>`;
  }

  /**
   * Open additional attributes popup
   */
  openAdditionalAttributes(): void {
    console.log('🔍 Opening additional attributes popup');
    console.log('📊 Catalog item:', this.catalogItem);
    console.log('🎯 Custom property:', this.catalogItem?.custom);
    
    this.showAdditionalAttributes = true;
    this.loadAdditionalAttributes();
    
    console.log('✅ Additional attributes loaded:', this.additionalAttributes);
  }

  /**
   * Close additional attributes popup
   */
  closeAdditionalAttributes(): void {
    this.showAdditionalAttributes = false;
  }

  /**
   * Load additional attributes from catalog item's custom property with enhanced formatting
   */
  private loadAdditionalAttributes(): void {
    this.additionalAttributes = [];
    
    if (!this.catalogItem?.custom) {
      console.log('❌ No custom property found');
      return;
    }

    console.log('🎯 Processing custom property:', this.catalogItem.custom);

    // Handle the actual structure: custom['custom_attributes'] array
    if (this.catalogItem.custom['custom_attributes'] && Array.isArray(this.catalogItem.custom['custom_attributes'])) {
      this.catalogItem.custom['custom_attributes'].forEach((customAttr: any, index: number) => {
        console.log(`📋 Processing attribute ${index}:`, customAttr);
        
        if (customAttr && typeof customAttr === 'object' && 'value' in customAttr && 'group' in customAttr && 'attribute' in customAttr) {
          const formattedAttribute = this.formatCustomAttributeFromArray(customAttr);
          if (formattedAttribute) {
            this.additionalAttributes.push(formattedAttribute);
          }
        }
      });
    } else {
      console.log('❌ custom_attributes not found or not an array');
    }

    // Sort attributes by group name and then by attribute name within each group
    this.additionalAttributes.sort((a, b) => {
      if (a.group !== b.group) {
        return a.group.localeCompare(b.group);
      }
      return a.attribute.localeCompare(b.attribute);
    });

    console.log('✅ Final processed attributes:', this.additionalAttributes);
  }

  /**
   * Format a custom attribute from the custom_attributes array
   */
  private formatCustomAttributeFromArray(customAttr: any): AdditionalAttribute | null {
    // Skip if value is empty
    if (!customAttr || customAttr.value === null || customAttr.value === undefined || customAttr.value === '') {
      return null;
    }

    // Use the group from the object (required field)
    const group = customAttr.group || 'General';
    
    // Use the attribute name (required field)  
    const attributeName = customAttr.attribute;
    
    // Format the attribute label from the attribute name
    const formattedLabel = this.formatAttributeLabel(attributeName);
    
    // Format the value based on its type and content
    const formattedValue = this.formatAttributeValue(attributeName, customAttr.value);

    return {
      attribute: formattedLabel,
      value: formattedValue,
      group: group
    };
  }

  /**
   * Format attribute label from key with intelligent capitalization
   */
  private formatAttributeLabel(key: string): string {
    // Handle common abbreviations and acronyms
    const acronyms = ['id', 'uuid', 'guid', 'url', 'api', 'html', 'css', 'js', 'sql', 'xml', 'json', 'pdf', 'csv', 'ui', 'ux', 'seo'];
    
    let formatted = key
      // Convert camelCase to space-separated words
      .replace(/([A-Z])/g, ' $1')
      // Replace underscores and hyphens with spaces
      .replace(/[_-]/g, ' ')
      // Clean up multiple spaces
      .replace(/\s+/g, ' ')
      .trim()
      // Capitalize each word
      .split(' ')
      .map(word => {
        const lowerWord = word.toLowerCase();
        // Handle acronyms
        if (acronyms.includes(lowerWord)) {
          return word.toUpperCase();
        }
        // Handle special cases
        if (lowerWord === 'api') return 'API';
        if (lowerWord === 'url') return 'URL';
        if (lowerWord === 'id') return 'ID';
        if (lowerWord === 'uuid') return 'UUID';
        if (lowerWord === 'guid') return 'GUID';
        if (lowerWord === 'html') return 'HTML';
        if (lowerWord === 'css') return 'CSS';
        if (lowerWord === 'json') return 'JSON';
        if (lowerWord === 'xml') return 'XML';
        if (lowerWord === 'pdf') return 'PDF';
        if (lowerWord === 'csv') return 'CSV';
        
        // Regular capitalization
        return word.charAt(0).toUpperCase() + word.slice(1).toLowerCase();
      })
      .join(' ');

    return formatted;
  }

  /**
   * Format attribute value with type-aware formatting
   */
  private formatAttributeValue(key: string, value: any): string {
    const keyLower = key.toLowerCase();
    
    // Handle null/undefined
    if (value === null || value === undefined) {
      return 'Not specified';
    }
    
    // Handle arrays
    if (Array.isArray(value)) {
      if (value.length === 0) return 'None';
      return value.map(item => this.formatSingleValue(key, item)).join(', ');
    }
    
    // Handle objects
    if (typeof value === 'object') {
      // Try to format as JSON, but make it readable
      try {
        return JSON.stringify(value, null, 2);
      } catch {
        return String(value);
      }
    }
    
    return this.formatSingleValue(key, value);
  }

  /**
   * Format a single value based on its type and context
   */
  private formatSingleValue(key: string, value: any): string {
    const keyLower = key.toLowerCase();
    const stringValue = String(value);
    
    // Handle boolean values
    if (typeof value === 'boolean') {
      return value ? 'Yes' : 'No';
    }
    
    // Handle date-like values
    if (this.isDateLike(keyLower) && this.isValidDateString(stringValue)) {
      return this.formatDateValue(stringValue);
    }
    
    // Handle file sizes
    if (this.isFileSizeLike(keyLower) && this.isNumeric(stringValue)) {
      return this.formatFileSize(Number(stringValue));
    }
    
    // Handle URLs
    if (this.isUrlLike(stringValue)) {
      return this.formatUrl(stringValue);
    }
    
    // Handle email addresses
    if (this.isEmailLike(stringValue)) {
      return stringValue.toLowerCase();
    }
    
    // Handle numbers with context
    if (this.isNumeric(stringValue)) {
      return this.formatNumber(key, Number(stringValue));
    }
    
    // Handle long text (truncate if too long)
    if (stringValue.length > 100) {
      return stringValue.substring(0, 97) + '...';
    }
    
    // Default string formatting
    return stringValue;
  }

  /**
   * Check if a key suggests a date value
   */
  private isDateLike(key: string): boolean {
    return ['date', 'time', 'created', 'updated', 'modified', 'published', 'expire', 'due', 'scheduled'].some(pattern => 
      key.includes(pattern) || key.startsWith(pattern) || key.endsWith(pattern)
    );
  }

  /**
   * Check if a key suggests a file size value
   */
  private isFileSizeLike(key: string): boolean {
    return ['size', 'bytes', 'length', 'capacity'].some(pattern => 
      key.includes(pattern) || key.startsWith(pattern) || key.endsWith(pattern)
    );
  }

  /**
   * Check if a string is a valid date
   */
  private isValidDateString(value: string): boolean {
    if (!value) return false;
    const date = new Date(value);
    return !isNaN(date.getTime()) && value.length > 8; // Basic date validation
  }

  /**
   * Check if a string is numeric
   */
  private isNumeric(value: string): boolean {
    return !isNaN(Number(value)) && !isNaN(parseFloat(value)) && isFinite(Number(value));
  }

  /**
   * Check if a string looks like a URL
   */
  private isUrlLike(value: string): boolean {
    try {
      new URL(value);
      return true;
    } catch {
      return value.toLowerCase().startsWith('http') || value.toLowerCase().startsWith('www.');
    }
  }

  /**
   * Check if a string looks like an email
   */
  private isEmailLike(value: string): boolean {
    return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value);
  }

  /**
   * Format date values
   */
  private formatDateValue(dateString: string): string {
    try {
      const date = new Date(dateString);
      const now = new Date();
      const diffInDays = Math.floor((now.getTime() - date.getTime()) / (1000 * 60 * 60 * 24));
      
      // Format based on how recent the date is
      if (Math.abs(diffInDays) < 1) {
        return this.dateUtilityService.getRelativeTime(dateString);
      } else if (Math.abs(diffInDays) < 7) {
        return `${Math.abs(diffInDays)} day${Math.abs(diffInDays) !== 1 ? 's' : ''} ${diffInDays < 0 ? 'from now' : 'ago'}`;
      } else {
        return this.dateUtilityService.formatDate(dateString);
      }
    } catch {
      return dateString;
    }
  }

  /**
   * Format file sizes in human-readable format
   */
  private formatFileSize(bytes: number): string {
    if (bytes === 0) return '0 Bytes';
    
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB', 'TB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
  }

  /**
   * Format URLs to be more readable
   */
  private formatUrl(url: string): string {
    try {
      const urlObj = new URL(url);
      // Return a shortened version for display
      const domain = urlObj.hostname;
      const path = urlObj.pathname;
      
      if (path.length > 30) {
        return `${domain}${path.substring(0, 27)}...`;
      }
      return `${domain}${path}`;
    } catch {
      return url.length > 50 ? url.substring(0, 47) + '...' : url;
    }
  }

  /**
   * Format numbers with context awareness
   */
  private formatNumber(key: string, value: number): string {
    const keyLower = key.toLowerCase();
    
    // Handle percentages
    if (keyLower.includes('percent') || keyLower.includes('rate') || (value <= 1 && value >= 0)) {
      return `${(value * 100).toFixed(1)}%`;
    }
    
    // Handle counts and metrics
    if (keyLower.includes('count') || keyLower.includes('views') || keyLower.includes('clicks')) {
      return this.formatMetricNumber(value);
    }
    
    // Handle currencies (basic detection)
    if (keyLower.includes('price') || keyLower.includes('cost') || keyLower.includes('amount') || keyLower.includes('savings')) {
      return new Intl.NumberFormat('en-US', { 
        style: 'currency', 
        currency: 'USD',
        minimumFractionDigits: 0,
        maximumFractionDigits: 2 
      }).format(value);
    }
    
    // Default number formatting
    return new Intl.NumberFormat('en-US').format(value);
  }

  /**
   * Format large numbers for metrics (e.g., 1.2K, 1.5M)
   */
  private formatMetricNumber(value: number): string {
    if (value >= 1000000) {
      return (value / 1000000).toFixed(1) + 'M';
    } else if (value >= 1000) {
      return (value / 1000).toFixed(1) + 'K';
    }
    return value.toString();
  }

  /**
   * Group additional attributes by group
   */
  getGroupedAttributes(): { [group: string]: AdditionalAttribute[] } {
    const grouped: { [group: string]: AdditionalAttribute[] } = {};
    
    this.additionalAttributes.forEach(attr => {
      if (!grouped[attr.group]) {
        grouped[attr.group] = [];
      }
      grouped[attr.group].push(attr);
    });
    
    return grouped;
  }

  /**
   * Get attribute groups in sorted order with enhanced group management
   */
  getAttributeGroups(): string[] {
    const groups = Object.keys(this.getGroupedAttributes());
    return groups.sort();
  }

  /**
   * Get available group options for dropdowns
   */
  getAvailableGroups(): string[] {
    const existingGroups = this.getAttributeGroups();
    const defaultGroups = ['General', 'Technical', 'Business', 'Content', 'Metadata', 'Custom'];
    
    // Combine existing groups with default options, removing duplicates
    const allGroups = [...new Set([...existingGroups, ...defaultGroups])];
    return allGroups.sort();
  }

  /**
   * Check if a group has any attributes
   */
  hasAttributesInGroup(group: string): boolean {
    const groupedAttributes = this.getGroupedAttributes();
    return groupedAttributes[group] && groupedAttributes[group].length > 0;
  }

  /**
   * Show add group form
   */
  showAddGroup(): void {
    this.showAddGroupForm = true;
    this.newGroupName = '';
  }

  /**
   * Cancel adding new group
   */
  cancelAddGroup(): void {
    this.showAddGroupForm = false;
    this.newGroupName = '';
  }

  /**
   * Add new group
   */
  addNewGroup(): void {
    if (!this.newGroupName.trim()) {
      return;
    }

    const trimmedGroupName = this.newGroupName.trim();
    
    // Check if group already exists (case-insensitive)
    const existingGroups = this.getAttributeGroups();
    const groupExists = existingGroups.some(group => 
      group.toLowerCase() === trimmedGroupName.toLowerCase()
    );

    if (groupExists) {
      alert('A group with this name already exists.');
      return;
    }

    // Initialize custom structure if needed
    if (!this.catalogItem?.custom) {
      this.catalogItem!.custom = { custom_attributes: [] };
    }
    if (!this.catalogItem!.custom['custom_attributes']) {
      this.catalogItem!.custom['custom_attributes'] = [];
    }

    // Add a placeholder attribute to create the group
    const placeholderAttribute = {
      attribute: 'Group Created',
      value: `Group "${trimmedGroupName}" was created. Add attributes to this group.`,
      group: trimmedGroupName
    };

    this.catalogItem!.custom['custom_attributes'].push(placeholderAttribute);
    
    // Reload the display
    this.loadAdditionalAttributes();
    
    // Clear form
    this.cancelAddGroup();
    
    // Set the new group as the selected group for new attributes
    this.newAttributeGroup = trimmedGroupName;
  }

  /**
   * Delete an entire group and all its attributes
   */
  deleteGroup(groupName: string): void {
    if (!this.catalogItem?.custom?.['custom_attributes']) {
      return;
    }

    const groupedAttributes = this.getGroupedAttributes();
    const attributesInGroup = groupedAttributes[groupName] || [];
    
    if (attributesInGroup.length === 0) {
      return;
    }

    // Confirm deletion
    const confirmMessage = `Are you sure you want to delete the group "${groupName}" and all ${attributesInGroup.length} attribute(s) in it?`;
    if (!confirm(confirmMessage)) {
      return;
    }

    // Remove all attributes in this group
    this.catalogItem.custom['custom_attributes'] = this.catalogItem.custom['custom_attributes'].filter((attr: any) => 
      attr.group !== groupName
    );
    
    // Reload the display
    this.loadAdditionalAttributes();
    
    console.log(`🗑️ Deleted group "${groupName}" with ${attributesInGroup.length} attributes`);
  }

  /**
   * Rename a group
   */
  renameGroup(oldGroupName: string, newGroupName: string): void {
    if (!this.catalogItem?.custom?.['custom_attributes'] || !newGroupName.trim()) {
      return;
    }

    const trimmedNewName = newGroupName.trim();
    
    // Check if new group name already exists (case-insensitive)
    const existingGroups = this.getAttributeGroups();
    const groupExists = existingGroups.some(group => 
      group.toLowerCase() === trimmedNewName.toLowerCase() && group !== oldGroupName
    );

    if (groupExists) {
      alert('A group with this name already exists.');
      return;
    }

    // Update all attributes in the old group to use the new group name
    this.catalogItem.custom['custom_attributes'].forEach((attr: any) => {
      if (attr.group === oldGroupName) {
        attr.group = trimmedNewName;
      }
    });
    
    // Reload the display
    this.loadAdditionalAttributes();
    
    console.log(`✏️ Renamed group "${oldGroupName}" to "${trimmedNewName}"`);
  }

  /**
   * Check if group can be deleted (has attributes and user can edit)
   */
  canDeleteGroup(groupName: string): boolean {
    return this.canEditItem() && this.isEditingAttributes && this.hasAttributesInGroup(groupName);
  }

  /**
   * Get group attribute count
   */
  getGroupAttributeCount(groupName: string): number {
    const groupedAttributes = this.getGroupedAttributes();
    return groupedAttributes[groupName] ? groupedAttributes[groupName].length : 0;
  }

  /**
   * Strip HTML tags from text and convert to plain text
   */
  private stripHtmlTags(html: string): string {
    if (!html) return '';
    // Create a temporary div element to parse HTML
    const tempDiv = document.createElement('div');
    tempDiv.innerHTML = html;
    return tempDiv.textContent || tempDiv.innerText || '';
  }

  // ===== SIMPLIFIED INLINE EDITING METHODS =====

  /**
   * Toggle attribute edit mode
   */
  toggleAttributeEdit(): void {
    this.isEditingAttributes = !this.isEditingAttributes;
    if (!this.isEditingAttributes) {
      // Cancel any pending additions
      this.cancelAddAttribute();
      this.cancelAddFirstAttribute();
      // Reload original attributes to discard changes
      this.loadAdditionalAttributes();
    }
  }

  /**
   * Save attributes to the catalog item
   */
  saveAttributes(): void {
    if (!this.catalogItem) {
      console.error('No catalog item to save attributes to');
      return;
    }

    this.isSavingAttributes = true;
    console.log('💾 Saving attributes...', this.catalogItem.custom);

    // Prepare the update payload - only send the custom field
    const updatePayload = {
      custom: this.catalogItem.custom
    };

    console.log('📤 Sending update payload:', updatePayload);

    // Use the catalog service to update the item
    this.catalogService.updateCatalogItem(this.catalogItem.id, updatePayload).subscribe({
      next: (updatedItem) => {
        console.log('✅ Attributes saved successfully:', updatedItem);
        
        // Update the local catalog item
        this.catalogItem = updatedItem;
        
        // Reload the additional attributes for the view
        this.loadAdditionalAttributes();
        
        this.isSavingAttributes = false;
        
        // Exit edit mode
        this.isEditingAttributes = false;
        
        // Show success message (you could implement a toast service here)
        console.log('🎉 Attributes updated successfully!');
      },
      error: (error) => {
        console.error('❌ Failed to save attributes:', error);
        this.isSavingAttributes = false;
        
        // Show error message (you could implement a toast service here)
        alert('Failed to save attributes. Please try again.');
      }
    });
  }

  /**
   * Add attribute to specific group
   */
  addAttributeToGroup(group: string): void {
    this.newAttributeForGroup = group;
    this.resetNewAttributeForm();
    // Focus will be handled by template reference
  }

  /**
   * Cancel adding attribute
   */
  cancelAddAttribute(): void {
    this.newAttributeForGroup = '';
    this.resetNewAttributeForm();
  }

  /**
   * Confirm adding attribute to group
   */
  confirmAddAttribute(group: string): void {
    if (!this.newAttributeName.trim() || !this.newAttributeValue.trim() || !this.catalogItem) {
      return;
    }

    // Find the custom_attributes array and add to it
    if (!this.catalogItem.custom) {
      this.catalogItem.custom = { custom_attributes: [] };
    }
    if (!this.catalogItem.custom['custom_attributes']) {
      this.catalogItem.custom['custom_attributes'] = [];
    }

    const newAttribute = {
      attribute: this.newAttributeName.trim(),
      value: this.newAttributeValue.trim(),
      group: group
    };

    this.catalogItem.custom['custom_attributes'].push(newAttribute);
    
    // Reload the display
    this.loadAdditionalAttributes();
    
    // Clear form
    this.cancelAddAttribute();
  }

  /**
   * Remove attribute from group
   */
  removeAttributeFromGroup(group: string, index: number): void {
    if (!this.catalogItem?.custom?.['custom_attributes']) return;

    const groupedAttrs = this.getGroupedAttributes();
    const attributeToRemove = groupedAttrs[group][index];
    
    // Find and remove from the main array
    const mainIndex = this.catalogItem.custom['custom_attributes'].findIndex((attr: any) => 
      attr.attribute === attributeToRemove.attribute && 
      attr.group === attributeToRemove.group &&
      attr.value === attributeToRemove.value
    );

    if (mainIndex !== -1) {
      this.catalogItem.custom['custom_attributes'].splice(mainIndex, 1);
      // Reload the display
      this.loadAdditionalAttributes();
    }
  }

  /**
   * Add first attribute when none exist
   */
  addFirstAttribute(): void {
    this.showFirstAttributeForm = true;
    this.resetNewAttributeForm();
  }

  /**
   * Cancel adding first attribute
   */
  cancelAddFirstAttribute(): void {
    this.showFirstAttributeForm = false;
    this.resetNewAttributeForm();
  }

  /**
   * Confirm adding first attribute
   */
  confirmAddFirstAttribute(): void {
    if (!this.newAttributeName.trim() || !this.newAttributeValue.trim() || !this.catalogItem) {
      return;
    }

    // Initialize custom structure if needed
    if (!this.catalogItem.custom) {
      this.catalogItem.custom = { custom_attributes: [] };
    }
    if (!this.catalogItem.custom['custom_attributes']) {
      this.catalogItem.custom['custom_attributes'] = [];
    }

    const newAttribute = {
      attribute: this.newAttributeName.trim(),
      value: this.newAttributeValue.trim(),
      group: this.newAttributeGroup
    };

    this.catalogItem.custom['custom_attributes'].push(newAttribute);
    
    // Reload the display
    this.loadAdditionalAttributes();
    
    // Clear form
    this.cancelAddFirstAttribute();
  }

  /**
   * Reset new attribute form
   */
  private resetNewAttributeForm(): void {
    this.newAttributeGroup = 'General';
    this.newAttributeName = '';
    this.newAttributeValue = '';
  }
}
#!/bin/bash

# Script to set up and run the catalog service with a specific user

# User credentials
USER_ID="suresh"
PASSWORD="${USER_ID}_123"

# Authenticate and retrieve access token
RESPONSE=$(curl -s -X POST "http://localhost:8000/api/v1/auth/login" \
  -H "accept: application/json" \
  -H "Content-Type: application/json" \
  -d "{\"user_id\": \"$USER_ID\", \"password\": \"$PASSWORD\"}")

# Debugging: Print the raw response
echo "API Response: $RESPONSE"

ACCESS_TOKEN=$(echo "$RESPONSE" | jq -r '.access_token')

if [ "$ACCESS_TOKEN" == "null" ] || [ -z "$ACCESS_TOKEN" ]; then
  echo "Authentication failed. Please check your credentials."
  exit 1
fi

# Export access token for the service
export ACCESS_TOKEN

# Create and activate virtual environment
python3 -m venv venv
source venv/bin/activate

# Upgrade pip
pip install --upgrade pip

# Install dependencies
pip install -r requirements.txt

# Run the catalog service
python3 catalog_service.py
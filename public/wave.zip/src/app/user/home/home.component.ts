import { Component, OnInit, OnDestroy } from '@angular/core';
import { Router } from '@angular/router';
import { faHome, faChartLine, faFolder, faFileAlt, faLightbulb, faHandshake, faRocket, faUser, faCog, faBookmark, faHeart, faTrophy, faCheckCircle, faUsers, faChartBar } from '@fortawesome/free-solid-svg-icons';
import { CatalogService } from '../../shared/services/catalog.service';
import { UserService } from '../../shared/services/user.service';
import { AuthService } from '../../shared/services/auth.service';
import { User } from '../../shared/models/user.interface';
import { OverlapButtonConfig } from '../../shared/components/overlap-button/overlap-button.component';
import { Subscription } from 'rxjs';
import { forkJoin } from 'rxjs';

@Component({
  selector: 'app-user-home',
  template: `
    <div class="home-container">
      <section class="hero-section">
        <app-container>
          <div class="hero-content">
            <h1 class="hero-title">Welcome to FST-Hub</h1>
            <p class="hero-subtitle">Your personal workspace for innovation, collaboration, and professional growth</p>
            <app-button variant="primary" size="lg" (click)="navigateTo('dashboard')">Go to Dashboard</app-button>
          </div>
        </app-container>
      </section>
      
      <!-- Overlapping Navigation -->
      <app-overlap-navigation 
        [buttons]="navigationButtons" 
        (navigate)="navigateTo($event)">
      </app-overlap-navigation>
      
      <section class="features-section">
        <app-container>
          <h2>What You Can Do</h2>
          <div class="features-grid">
            <app-card variant="feature" size="lg" [clickable]="true" (click)="navigateTo('projects')">
              <app-icon [faIcon]="faFolder" size="xl" variant="primary"></app-icon>
              <h3>Explore Projects</h3>
              <p>Discover innovative projects, collaborate with teams, and contribute to cutting-edge solutions</p>
            </app-card>
            <app-card variant="feature" size="lg" [clickable]="true" (click)="navigateTo('resources')">
              <app-icon [faIcon]="faLightbulb" size="xl" variant="secondary"></app-icon>
              <h3>Access Resources</h3>
              <p>Browse documentation, tutorials, and knowledge base to enhance your skills and expertise</p>
            </app-card>
            <app-card variant="feature" size="lg" [clickable]="true" (click)="navigateTo('profile')">
              <app-icon [faIcon]="faUser" size="xl" variant="success"></app-icon>
              <h3>Manage Profile</h3>
              <p>Update your personal information, skills, and preferences to showcase your expertise</p>
            </app-card>
          </div>
        </app-container>
      </section>
      
      <section class="activity-section">
        <app-container>
          <h2>Your Activity</h2>
          <div class="activity-grid">
            <div class="activity-card">
              <div class="activity-icon">
                <app-icon [faIcon]="faFolder" size="xl" variant="primary"></app-icon>
              </div>
              <div class="activity-content">
                <div class="activity-number">{{ myProjectsCount }}</div>
                <div class="activity-label">My Projects</div>
              </div>
            </div>
            <div class="activity-card">
              <div class="activity-icon">
                <app-icon [faIcon]="faBookmark" size="xl" variant="secondary"></app-icon>
              </div>
              <div class="activity-content">
                <div class="activity-number">{{ bookmarksCount }}</div>
                <div class="activity-label">Bookmarked Items</div>
              </div>
            </div>
            <div class="activity-card">
              <div class="activity-icon">
                <app-icon [faIcon]="faHeart" size="xl" variant="danger"></app-icon>
              </div>
              <div class="activity-content">
                <div class="activity-number">{{ favoritesCount }}</div>
                <div class="activity-label">Favorites</div>
              </div>
            </div>
            <div class="activity-card">
              <div class="activity-icon">
                <app-icon [faIcon]="faChartLine" size="xl" variant="success"></app-icon>
              </div>
              <div class="activity-content">
                <div class="activity-number">{{ getAccountAge() }}</div>
                <div class="activity-label">Days Active</div>
              </div>
            </div>
          </div>
        </app-container>
      </section>
      
      <section class="cta-section">
        <app-container size="md">
          <div class="cta-content">
            <h2>Ready to Start Exploring?</h2>
            <p>Dive into the world of financial technology innovation and connect with like-minded professionals.</p>
            <div class="cta-buttons">
              <app-button variant="primary" size="lg" (click)="navigateTo('projects')">Browse Projects</app-button>
              <app-button variant="outline" size="lg" (click)="navigateTo('resources')">View Resources</app-button>
            </div>
          </div>
        </app-container>
      </section>
    </div>
  `,
  styles: [`
    .home-container {
      width: 100%;
      position: relative;
    }
    
    .hero-section {
      background: linear-gradient(135deg, var(--fm-primary-hero) 0%, var(--fm-secondary-hero) 100%);
      color: var(--fm-white);
      padding: 4rem 0;
      text-align: center;
      min-height: 400px;
      display: flex;
      align-items: center;
      justify-content: center;
      position: relative;
      z-index: 1;
    }
    
    .hero-content {
      max-width: 700px;
      margin: 0 auto;
    }
    
    .hero-title {
      font-size: 3rem;
      font-weight: 700;
      margin-bottom: 1rem;
      line-height: 1.2;
      color: var(--fm-white);
    }
    
    .hero-subtitle {
      font-size: 1.25rem;
      margin-bottom: 2rem;
      opacity: 0.85;
      line-height: 1.5;
      color: var(--fm-white);
    }
    
    .features-section {
      padding: 3rem 0;
      background: var(--fm-bg-light);
    }
    
    .features-section h2 {
      text-align: center;
      font-size: 2.5rem;
      font-weight: 700;
      margin-bottom: 3rem;
      color: var(--fm-text-primary);
    }
    
    .features-grid {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
      gap: 2rem;
      margin-top: 2rem;
    }
    
    .activity-section {
      padding: 3rem 0;
      background: var(--fm-white);
    }
    
    .activity-section h2 {
      text-align: center;
      font-size: 2.5rem;
      font-weight: 700;
      margin-bottom: 3rem;
      color: var(--fm-text-primary);
    }
    
    .activity-grid {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
      gap: 2rem;
      margin-top: 2rem;
    }
    
    .activity-card {
      background: var(--fm-white);
      border-radius: 12px;
      padding: 2rem;
      text-align: center;
      box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
      border: 1px solid #e9ecef;
      transition: all 0.3s ease;
    }
    
    .activity-card:hover {
      transform: translateY(-5px);
      box-shadow: 0 8px 25px rgba(0, 0, 0, 0.15);
    }
    
    .activity-icon {
      margin-bottom: 1rem;
    }
    
    .activity-number {
      font-size: 2.5rem;
      font-weight: 700;
      color: var(--fm-text-primary);
      margin-bottom: 0.5rem;
    }
    
    .activity-label {
      font-size: 1rem;
      color: var(--fm-text-secondary);
      font-weight: 500;
    }
    
    .cta-section {
      background: var(--fm-bg-dark);
      color: var(--fm-white);
      padding: 5rem 0;
      text-align: center;
    }
    
    .cta-content h2 {
      font-size: 2.5rem;
      font-weight: 700;
      margin-bottom: 1rem;
    }
    
    .cta-content p {
      font-size: 1.25rem;
      margin-bottom: 2rem;
      opacity: 0.9;
    }
    
    .cta-buttons {
      display: flex;
      gap: 1rem;
      justify-content: center;
      flex-wrap: wrap;
    }
    
    /* Responsive Design */
    @media (max-width: 768px) {
      .hero-title {
        font-size: 2rem;
      }
      
      .hero-subtitle {
        font-size: 1rem;
      }
      
      .features-section h2,
      .activity-section h2 {
        font-size: 2rem;
      }
      
      .activity-grid {
        grid-template-columns: repeat(auto-fit, minmax(150px, 1fr));
        gap: 1rem;
      }
      
      .activity-card {
        padding: 1.5rem;
      }
      
      .activity-number {
        font-size: 2rem;
      }
      
      .cta-content h2 {
        font-size: 2rem;
      }
      
      .cta-buttons {
        flex-direction: column;
        align-items: center;
      }
    }
  `]
})
export class UserHomeComponent implements OnInit, OnDestroy {
  // Font Awesome icons
  faHome = faHome;
  faChartLine = faChartLine;
  faFolder = faFolder;
  faFileAlt = faFileAlt;
  faLightbulb = faLightbulb;
  faHandshake = faHandshake;
  faRocket = faRocket;
  faUser = faUser;
  faCog = faCog;
  faBookmark = faBookmark;
  faHeart = faHeart;
  faTrophy = faTrophy;
  faCheckCircle = faCheckCircle;
  faUsers = faUsers;
  faChartBar = faChartBar;

  // Navigation buttons configuration
  navigationButtons: OverlapButtonConfig[] = [];

  // Badge counts from API
  dashboardCount = 0;
  weeklyWinsCount = 0;
  approvalsCount = 0;
  teamCount = 0;
  catalogCount = 0;
  reportsCount = 0;
  
  // Legacy counts for activity section
  projectsCount = 0;
  resourcesCount = 0;
  bookmarksCount = 0;
  myProjectsCount = 0;
  favoritesCount = 0;
  
  private subscription = new Subscription();

  constructor(
    private router: Router,
    private catalogService: CatalogService,
    private userService: UserService,
    private authService: AuthService
  ) { }

  ngOnInit(): void {
    this.setupNavigationButtons();
    this.loadUserCounts();
  }

  ngOnDestroy(): void {
    this.subscription.unsubscribe();
  }

  /**
   * Setup navigation buttons configuration
   */
  private setupNavigationButtons(): void {
    this.navigationButtons = [
      {
        icon: this.faHome,
        label: 'Dashboard',
        badgeCount: this.dashboardCount,
        isActive: false,
        iconVariant: 'primary',
        route: 'dashboard'
      },
      {
        icon: this.faTrophy,
        label: 'Weekly Wins',
        badgeCount: this.weeklyWinsCount,
        isActive: false,
        iconVariant: 'secondary',
        route: 'weekly-wins'
      },
      {
        icon: this.faCheckCircle,
        label: 'Approvals',
        badgeCount: this.approvalsCount,
        isActive: false,
        iconVariant: 'success',
        route: 'approvals'
      },
      {
        icon: this.faUsers,
        label: 'Team',
        badgeCount: this.teamCount,
        isActive: false,
        iconVariant: 'primary',
        route: 'team'
      },
      {
        icon: this.faFolder,
        label: 'Catalog',
        badgeCount: this.catalogCount,
        isActive: false,
        iconVariant: 'primary',
        route: 'catalog'
      },
      {
        icon: this.faChartBar,
        label: 'Reports',
        badgeCount: this.reportsCount,
        isActive: false,
        iconVariant: 'secondary',
        route: 'reports'
      }
    ];
  }

  /**
   * Update navigation buttons with latest counts
   */
  private updateNavigationButtons(): void {
    this.navigationButtons.forEach(button => {
      switch(button.route) {
        case 'dashboard':
          button.badgeCount = this.dashboardCount;
          break;
        case 'weekly-wins':
          button.badgeCount = this.weeklyWinsCount;
          break;
        case 'approvals':
          button.badgeCount = this.approvalsCount;
          break;
        case 'team':
          button.badgeCount = this.teamCount;
          break;
        case 'catalog':
          button.badgeCount = this.catalogCount;
          break;
        case 'reports':
          button.badgeCount = this.reportsCount;
          break;
      }
    });
  }

  /**
   * Load user dashboard counts from API
   */
  private loadUserCounts(): void {
    this.subscription.add(
      forkJoin({
        projects: this.catalogService.getCatalogItems({ type: 'project', limit: 1 }),
        resources: this.catalogService.getCatalogItems({ type: 'document', limit: 1 })
      }).subscribe({
        next: (results) => {
          this.projectsCount = results.projects.total || 0;
          this.resourcesCount = results.resources.total || 0;
          this.catalogCount = this.projectsCount + this.resourcesCount;
          
          // Set navigation badge counts
          this.dashboardCount = this.calculateUserDashboardItems();
          this.weeklyWinsCount = this.calculateWeeklyWinsCount();
          this.approvalsCount = this.calculateApprovalsCount();
          this.teamCount = this.calculateTeamCount();
          this.reportsCount = this.calculateReportsCount();
          
          // Set activity section counts
          this.bookmarksCount = this.calculateBookmarksCount();
          this.myProjectsCount = this.calculateMyProjectsCount();
          this.favoritesCount = this.calculateFavoritesCount();
          
          // Update navigation buttons with new counts
          this.updateNavigationButtons();
        },
        error: (error) => {
          console.error('Failed to load user counts:', error);
          // Set fallback values
          this.dashboardCount = 0;
          this.weeklyWinsCount = 0;
          this.approvalsCount = 0;
          this.teamCount = 0;
          this.catalogCount = 0;
          this.reportsCount = 0;
          this.projectsCount = 0;
          this.resourcesCount = 0;
          this.bookmarksCount = 0;
          this.myProjectsCount = 0;
          this.favoritesCount = 0;
          
          // Update navigation buttons with fallback counts
          this.updateNavigationButtons();
        }
      })
    );
  }

  /**
   * Calculate weekly wins count
   */
  private calculateWeeklyWinsCount(): number {
    // Placeholder - would come from weekly wins API
    return Math.floor(Math.random() * 5);
  }

  /**
   * Calculate pending approvals count
   */
  private calculateApprovalsCount(): number {
    // Placeholder - would come from approvals API
    return Math.floor(Math.random() * 3);
  }

  /**
   * Calculate team members count
   */
  private calculateTeamCount(): number {
    // Placeholder - would come from team API
    return Math.floor(Math.random() * 12) + 5;
  }

  /**
   * Calculate reports count
   */
  private calculateReportsCount(): number {
    // Placeholder - would come from reports API
    return Math.floor(Math.random() * 8);
  }

  /**
   * Calculate user dashboard items count
   */
  private calculateUserDashboardItems(): number {
    // User dashboard could show notifications, updates, etc.
    return Math.min(this.myProjectsCount + this.bookmarksCount, 99);
  }

  /**
   * Calculate bookmarks count
   */
  private calculateBookmarksCount(): number {
    // Placeholder - would come from user's bookmarks API
    return Math.floor(Math.random() * 10);
  }

  /**
   * Calculate user's projects count
   */
  private calculateMyProjectsCount(): number {
    // Placeholder - would come from user's projects API
    return Math.floor(Math.random() * 5);
  }

  /**
   * Calculate favorites count
   */
  private calculateFavoritesCount(): number {
    // Placeholder - would come from user's favorites API
    return Math.floor(Math.random() * 8);
  }

  /**
   * Get account age in days
   */
  getAccountAge(): number {
    const user = this.authService.getCurrentUserValue();
    if (user?.created_date) {
      const createdDate = new Date(user.created_date);
      const now = new Date();
      const diffTime = Math.abs(now.getTime() - createdDate.getTime());
      return Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    }
    return 0;
  }
  
  navigateTo(section: string): void {
    console.log(`User navigating to: ${section}`);
    this.router.navigate([section]);
  }
}
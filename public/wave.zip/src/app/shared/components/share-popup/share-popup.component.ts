import { Component, Input, Output, EventEmitter, OnInit, OnDestroy } from '@angular/core';
import { Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';
import { faShare, faTimes, faUsers, faUserPlus, faCheck, faSpinner, faSearch, faUserTie, faUserFriends } from '@fortawesome/free-solid-svg-icons';
import { User, Catalog } from '../../models/user.interface';
import { UserService } from '../../services/user.service';
import { CatalogService } from '../../services/catalog.service';

export interface ShareRequest {
  catalogId: string;
  userIds: string[];
  message?: string;
}

@Component({
  selector: 'app-share-popup',
  template: `
    <div class="share-popup-overlay" (click)="onOverlayClick($event)" *ngIf="show || isVisible">
      <app-popup-container 
        title="Share with Team" 
        [position]="{ x: 0, y: 0 }" 
        mode="panel"
        (close)="closePopup()"
        (click)="$event.stopPropagation()">
        
        <div class="share-popup-content">
          <!-- Search Bar -->
          <div class="search-bar">
            <fa-icon [icon]="faSearch" class="search-icon"></fa-icon>
            <input
              type="text"
              class="search-input"
              [(ngModel)]="searchTerm"
              placeholder="Search by name or user ID..."
              maxlength="100">
            <button *ngIf="searchTerm" class="clear-search-btn" (click)="clearSearch()" type="button">
              <fa-icon [icon]="faTimes"></fa-icon>
            </button>
          </div>

          <!-- Loading State -->
          <div class="loading-state" *ngIf="isLoading">
            <fa-icon [icon]="faSpinner" class="loading-icon fa-spin"></fa-icon>
            <p>Loading team members...</p>
          </div>

          <!-- Tabs -->
          <div class="tabs-container" *ngIf="!isLoading">
            <div class="tabs-header">
              <button 
                *ngIf="manager"
                class="tab-button"
                [class.active]="activeTab === 'manager'"
                (click)="setActiveTab('manager')"
                type="button">
                <fa-icon [icon]="faUserTie" class="tab-icon"></fa-icon>
                My Manager
                <span class="tab-count" *ngIf="getFilteredManager().length > 0">({{ getFilteredManager().length }})</span>
              </button>
              
              <button 
                class="tab-button"
                [class.active]="activeTab === 'peers'"
                (click)="setActiveTab('peers')"
                type="button">
                <fa-icon [icon]="faUsers" class="tab-icon"></fa-icon>
                My Peers
                <span class="tab-count">({{ getFilteredPeers().length }})</span>
              </button>
              
              <button 
                class="tab-button"
                [class.active]="activeTab === 'team'"
                (click)="setActiveTab('team')"
                type="button">
                <fa-icon [icon]="faUserFriends" class="tab-icon"></fa-icon>
                My Team
                <span class="tab-count">({{ getFilteredTeam().length }})</span>
              </button>
            </div>

            <!-- Tab Content -->
            <div class="tab-content">
              <!-- Manager Tab -->
              <div class="tab-panel" *ngIf="activeTab === 'manager' && manager">
                <div class="users-list">
                  <div 
                    *ngFor="let user of getFilteredManager()"
                    class="user-option"
                    [class.selected]="isUserSelected(user)"
                    (click)="toggleUserSelection(user)"
                    (keydown)="onUserKeyDown($event, user)"
                    [attr.tabindex]="0"
                    [attr.aria-label]="getUserAriaLabel(user)">
                    <div class="user-avatar">{{ getUserInitials(user) }}</div>
                    <div class="user-info">
                      <div class="user-name">{{ getUserDisplayName(user) }}</div>
                      <div class="user-details">
                        <span *ngIf="user.designation" class="user-designation">{{ user.designation }}</span>
                      </div>
                    </div>
                    <div class="selection-checkbox">
                      <fa-icon [icon]="faCheck" *ngIf="isUserSelected(user)"></fa-icon>
                    </div>
                  </div>
                </div>
              </div>

              <!-- Peers Tab -->
              <div class="tab-panel" *ngIf="activeTab === 'peers'">
                <div class="users-list" *ngIf="getFilteredPeers().length > 0">
                  <div 
                    *ngFor="let user of getFilteredPeers()"
                    class="user-option"
                    [class.selected]="isUserSelected(user)"
                    (click)="toggleUserSelection(user)"
                    (keydown)="onUserKeyDown($event, user)"
                    [attr.tabindex]="0"
                    [attr.aria-label]="getUserAriaLabel(user)">
                    <div class="user-avatar">{{ getUserInitials(user) }}</div>
                    <div class="user-info">
                      <div class="user-name">{{ getUserDisplayName(user) }}</div>
                      <div class="user-details">
                        <span *ngIf="user.designation" class="user-designation">{{ user.designation }}</span>
                      </div>
                    </div>
                    <div class="selection-checkbox">
                      <fa-icon [icon]="faCheck" *ngIf="isUserSelected(user)"></fa-icon>
                    </div>
                  </div>
                </div>
                <div class="empty-tab-state" *ngIf="getFilteredPeers().length === 0">
                  <fa-icon [icon]="faUsers" class="empty-icon"></fa-icon>
                  <h4>No Peers Found</h4>
                  <p>{{ searchTerm ? 'No peers match your search.' : 'You don\'t have any peers to share with.' }}</p>
                </div>
              </div>

              <!-- Team Tab -->
              <div class="tab-panel" *ngIf="activeTab === 'team'">
                <div class="users-list" *ngIf="getFilteredTeam().length > 0">
                  <div 
                    *ngFor="let user of getFilteredTeam()"
                    class="user-option"
                    [class.selected]="isUserSelected(user)"
                    (click)="toggleUserSelection(user)"
                    (keydown)="onUserKeyDown($event, user)"
                    [attr.tabindex]="0"
                    [attr.aria-label]="getUserAriaLabel(user)">
                    <div class="user-avatar">{{ getUserInitials(user) }}</div>
                    <div class="user-info">
                      <div class="user-name">{{ getUserDisplayName(user) }}</div>
                      <div class="user-details">
                        <span *ngIf="user.designation" class="user-designation">{{ user.designation }}</span>
                      </div>
                    </div>
                    <div class="selection-checkbox">
                      <fa-icon [icon]="faCheck" *ngIf="isUserSelected(user)"></fa-icon>
                    </div>
                  </div>
                </div>
                <div class="empty-tab-state" *ngIf="getFilteredTeam().length === 0">
                  <fa-icon [icon]="faUserFriends" class="empty-icon"></fa-icon>
                  <h4>No Team Members Found</h4>
                  
                </div>
              </div>
            </div>
          </div>

          <!-- Empty State when no data -->
          <div class="empty-state" *ngIf="!isLoading && !hasAnyUsers()">
            <fa-icon [icon]="faUsers" class="empty-icon"></fa-icon>
            <h4>No Team Members Available</h4>
            <p>You don't have any accessible team members, peers, or manager information for sharing.</p>
          </div>

          <!-- Message Section -->
          <div class="message-section" *ngIf="selectedUsers.length > 0">
            <label class="message-label">Add a message (optional):</label>
            <textarea
              class="message-textarea"
              [(ngModel)]="shareMessage"
              placeholder="Add a personal message with this share..."
              rows="3"
              maxlength="500">
            </textarea>
            <div class="character-count">{{ shareMessage.length }}/500</div>
          </div>

          <!-- Selected Users Summary - Moved to Bottom -->
          <div class="selected-users-bottom" *ngIf="selectedUsers.length > 0">
            <div class="selected-header">
              <span class="selected-count">
                <fa-icon [icon]="faCheck" class="check-icon"></fa-icon>
                {{ selectedUsers.length }} selected
              </span>
              <button class="clear-all-btn" (click)="clearAllSelections()" type="button">
                <fa-icon [icon]="faTimes"></fa-icon>
                Clear all
              </button>
            </div>
            <div class="selected-users-compact" [class.show-all]="showAllSelected">
              <div class="selected-user-item" 
                   *ngFor="let user of selectedUsers; let i = index"
                   [class.overflow-item]="i >= 2 && !showAllSelected">
                <div class="user-avatar-mini">{{ getUserInitials(user) }}</div>
                <span class="user-name-mini">{{ getUserDisplayName(user) }}</span>
                <button class="remove-user-btn" (click)="removeUser(user)" type="button">
                  <fa-icon [icon]="faTimes"></fa-icon>
                </button>
              </div>
              <div class="show-more-btn" *ngIf="selectedUsers.length > 2" (click)="toggleShowAllSelected()">
                <span *ngIf="!showAllSelected">+{{ selectedUsers.length - 2 }} more</span>
                <span *ngIf="showAllSelected">Show less</span>
              </div>
            </div>
          </div>

          <!-- Footer -->
          <div class="share-popup-footer">
            <button 
              class="btn btn-secondary" 
              (click)="closePopup()"
              type="button">
              Cancel
            </button>
            <button 
              class="btn btn-primary" 
              (click)="shareWithSelectedUsers()"
              [disabled]="selectedUsers.length === 0 || isSharing"
              type="button">
              <fa-icon [icon]="faSpinner" *ngIf="isSharing" class="fa-spin"></fa-icon>
              <fa-icon [icon]="faShare" *ngIf="!isSharing"></fa-icon>
              {{ isSharing ? 'Sharing...' : 'Share (' + selectedUsers.length + ')' }}
            </button>
          </div>
        </div>
        
      </app-popup-container>
    </div>
  `,
  styleUrls: ['./share-popup.component.css']
})
export class SharePopupComponent implements OnInit, OnDestroy {
  // FontAwesome icons
  faShare = faShare;
  faTimes = faTimes;
  faUsers = faUsers;
  faUserPlus = faUserPlus;
  faCheck = faCheck;
  faSpinner = faSpinner;
  faSearch = faSearch;
  faUserTie = faUserTie;
  faUserFriends = faUserFriends;

  // Inputs
  @Input() catalogItem: Catalog | null = null;
  @Input() show: boolean = false;
  @Input() catalogId: string = '';
  @Input() isVisible: boolean = false;

  // Outputs
  @Output() close = new EventEmitter<void>();
  @Output() shareComplete = new EventEmitter<{ users: any[], catalogItem: Catalog }>();

  // Component state
  peers: User[] = [];
  team: User[] = [];
  manager: User | null = null;
  selectedUsers: User[] = [];
  shareMessage: string = '';
  isLoading: boolean = false;
  isSharing: boolean = false;
  searchTerm: string = '';
  activeTab: 'manager' | 'peers' | 'team' = 'peers';
  showAllSelected: boolean = false;

  private destroy$ = new Subject<void>();

  constructor(
    private userService: UserService,
    private catalogService: CatalogService
  ) {}

  ngOnInit(): void {
    // Set catalogId from catalogItem if provided
    if (this.catalogItem && this.catalogItem.id) {
      this.catalogId = this.catalogItem.id;
    }
    this.loadShareableUsers();
    
    // Set default active tab based on available data
    this.setDefaultActiveTab();
  }

  ngOnDestroy(): void {
    this.destroy$.next();
    this.destroy$.complete();
  }

  /**
   * Load all shareable users (peers, team, and manager)
   */
  loadShareableUsers(): void {
    this.isLoading = true;
    this.userService.getShareableUsers()
      .pipe(takeUntil(this.destroy$))
      .subscribe({
        next: (result) => {
          this.peers = result.peers;
          this.team = result.team;
          this.manager = result.manager;
          this.isLoading = false;
          
          // Set default active tab after data is loaded
          this.setDefaultActiveTab();
        },
        error: (error) => {
          console.error('Error loading shareable users:', error);
          this.isLoading = false;
        }
      });
  }

  /**
   * Get all available users for display
   */
  get allAvailableUsers(): User[] {
    const users: User[] = [];
    
    // Add manager if available
    if (this.manager) {
      users.push(this.manager);
    }
    
    // Add peers
    users.push(...this.peers);
    
    // Add team members
    users.push(...this.team);
    
    return users;
  }

  /**
   * Get filtered users based on search term
   */
  get filteredUsers(): User[] {
    const users = this.allAvailableUsers;
    
    if (!this.searchTerm) {
      return users;
    }
    
    const searchLower = this.searchTerm.toLowerCase();
    return users.filter(user => {
      const displayName = this.getUserDisplayName(user).toLowerCase();
      const userId = (user.user_id || '').toLowerCase();
      return displayName.includes(searchLower) || userId.includes(searchLower);
    });
  }

  /**
   * Handle user selection from search component
   */
  onUserSelected(user: User | null): void {
    if (user && !this.isUserSelected(user)) {
      this.selectedUsers.push(user);
    }
  }

  /**
   * Toggle user selection from team members list
   */
  toggleUserSelection(user: User): void {
    if (this.isUserSelected(user)) {
      this.removeUser(user);
    } else {
      this.selectedUsers.push(user);
    }
  }

  /**
   * Remove user from selection
   */
  removeUser(user: User): void {
    this.selectedUsers = this.selectedUsers.filter(u => u.id !== user.id);
  }

  /**
   * Check if user is selected
   */
  isUserSelected(user: User): boolean {
    return this.selectedUsers.some(u => u.id === user.id);
  }

  /**
   * Share with selected users
   */
  shareWithSelectedUsers(): void {
    if (this.selectedUsers.length === 0 || (!this.catalogId && !this.catalogItem)) return;

    this.isSharing = true;
    
    // Get the catalog item - either from direct input or use catalogId to get current catalogItem
    const catalog = this.catalogItem || { id: this.catalogId } as Catalog;
    
    // Emit the share data in the format expected by the parent component
    this.shareComplete.emit({
      users: this.selectedUsers,
      catalogItem: catalog
    });
    
    // Simulate sharing delay for UX
    setTimeout(() => {
      this.isSharing = false;
      this.closePopup();
    }, 1000);
  }

  /**
   * Close the popup
   */
  closePopup(): void {
    this.isVisible = false;
    this.selectedUsers = [];
    this.shareMessage = '';
    this.showAllSelected = false;
    this.close.emit();
  }

  /**
   * Clear all user selections
   */
  clearAllSelections(): void {
    this.selectedUsers = [];
    this.showAllSelected = false;
  }

  /**
   * Set the active tab for user selection
   */
  setActiveTab(tab: 'manager' | 'peers' | 'team'): void {
    this.activeTab = tab;
  }

  /**
   * Set default active tab based on available data
   */
  setDefaultActiveTab(): void {
    // Prioritize tabs with data: manager > peers > team
    if (this.manager) {
      this.activeTab = 'manager';
    } else if (this.peers.length > 0) {
      this.activeTab = 'peers';
    } else if (this.team.length > 0) {
      this.activeTab = 'team';
    } else {
      this.activeTab = 'peers'; // Default fallback
    }
  }

  /**
   * Toggle showing all selected users
   */
  toggleShowAllSelected(): void {
    this.showAllSelected = !this.showAllSelected;
  }

  /**
   * Clear the search input
   */
  clearSearch(): void {
    this.searchTerm = '';
  }

  /**
   * Track by function for ngFor
   */
  trackByUserId(index: number, user: User): string {
    return user.id;
  }

  /**
   * Get user display name
   */
  getUserDisplayName(user: User): string {
    return this.userService.getUserDisplayName(user);
  }

  /**
   * Get user initials
   */
  getUserInitials(user: User): string {
    return this.userService.getUserInitials(user);
  }

  /**
   * Get filtered manager for current search term
   */
  getFilteredManager(): User[] {
    if (!this.manager) {
      return [];
    }
    return this.isUserVisible(this.manager) ? [this.manager] : [];
  }

  /**
   * Get filtered peers for current search term
   */
  getFilteredPeers(): User[] {
    if (!this.searchTerm) {
      return this.peers;
    }
    return this.peers.filter(peer => {
      const displayName = this.getUserDisplayName(peer).toLowerCase();
      const userId = (peer.user_id || '').toLowerCase();
      return displayName.includes(this.searchTerm.toLowerCase()) || userId.includes(this.searchTerm.toLowerCase());
    });
  }

  /**
   * Get filtered team members for current search term
   */
  getFilteredTeam(): User[] {
    if (!this.searchTerm) {
      return this.team;
    }
    return this.team.filter(member => {
      const displayName = this.getUserDisplayName(member).toLowerCase();
      const userId = (member.user_id || '').toLowerCase();
      return displayName.includes(this.searchTerm.toLowerCase()) || userId.includes(this.searchTerm.toLowerCase());
    });
  }

  /**
   * Check if user is visible based on search term
   */
  isUserVisible(user: User): boolean {
    const searchLower = this.searchTerm.toLowerCase();
    const displayName = this.getUserDisplayName(user).toLowerCase();
    const userId = (user.user_id || '').toLowerCase();
    return displayName.includes(searchLower) || userId.includes(searchLower);
  }

  /**
   * Check if there are any visible users (peers or team)
   */
  hasAnyUsers(): boolean {
    return this.getFilteredPeers().length > 0 || 
           this.getFilteredTeam().length > 0 || 
           (this.manager !== null && this.isUserVisible(this.manager));
  }

  /**
   * Handle keyboard navigation in user list
   */
  onUserKeyDown(event: KeyboardEvent, user: User): void {
    if (event.key === 'Enter' || event.key === ' ') {
      event.preventDefault();
      this.toggleUserSelection(user);
    }
  }

  /**
   * Get accessible description for user option
   */
  getUserAriaLabel(user: User): string {
    const displayName = this.getUserDisplayName(user);
    const designation = user.designation ? `, ${user.designation}` : '';
    const selectionState = this.isUserSelected(user) ? 'selected' : 'not selected';
    return `${displayName}${designation}, ${selectionState}`;
  }

  /**
   * Handle overlay click to close popup (only when clicking outside the panel)
   */
  onOverlayClick(event: MouseEvent): void {
    const target = event.target as HTMLElement;
    if (target.classList.contains('share-popup-overlay')) {
      this.closePopup();
    }
  }
}
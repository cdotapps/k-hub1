import { Component, Input, Output, EventEmitter } from '@angular/core';
import { IconDefinition } from '@fortawesome/fontawesome-svg-core';

@Component({
  selector: 'app-page-hero',
  templateUrl: './page-hero.component.html',
  styleUrls: ['./page-hero.component.css']
})
export class PageHeroComponent {
  @Input() title: string = '';
  @Input() subtitle: string = '';
  @Input() heroIcon: IconDefinition | null = null;
  
  // Metrics inputs
  @Input() metrics: { 
    icon: IconDefinition;
    number?: number | string;
    label: string;
    status?: string;
    isActive?: boolean;
    isClickable?: boolean;
  }[] = [];

  // Action buttons
  @Input() actions: {
    label: string;
    icon: IconDefinition;
    variant: 'primary' | 'secondary' | 'outline' | 'danger';
    isDisabled?: boolean;
    isVisible?: boolean;
  }[] = [];

  // Events
  @Output() metricClick: EventEmitter<number> = new EventEmitter<number>();
  @Output() actionClick: EventEmitter<number> = new EventEmitter<number>();

  onMetricClick(index: number): void {
    this.metricClick.emit(index);
  }

  onActionClick(index: number): void {
    this.actionClick.emit(index);
  }
}

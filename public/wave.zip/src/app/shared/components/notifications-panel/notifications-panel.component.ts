import { Component, EventEmitter, Input, Output, OnChanges, SimpleChanges } from '@angular/core';
import { faChartLine, faShieldAlt, faRocket, faBell } from '@fortawesome/free-solid-svg-icons';
import { Catalog } from '../../models/user.interface';

@Component({
  selector: 'app-notifications-panel',
  template: `
    <div class="notifications-panel" [class.active]="isOpen" [class.refreshing]="isRefreshing">
      <div class="notifications-header">
        <h3>Notifications</h3>
        <button class="close-notifications" (click)="close()">×</button>
      </div>
      <div class="notifications-content">
        <div class="notification-item" *ngFor="let notification of notifications" (click)="handleNotificationClick(notification)">
          <div class="notification-icon">
            <app-icon [faIcon]="getNotificationIcon(notification)" size="sm" [variant]="getNotificationVariant(notification)"></app-icon>
          </div>
          <div class="notification-content">
            <h5>{{ notification.title }}</h5>
            <p>{{ notification.description || notification.summary || 'New notification' }}</p>
            <span class="notification-time">{{ formatTime(notification.created_date) }}</span>
          </div>
        </div>
        <div class="notifications-footer" *ngIf="notifications.length === 0">
          <p>No new notifications</p>
        </div>
      </div>
    </div>
  `,
  styles: [`
    .notifications-panel {
      position: fixed;
      top: 0;
      right: -400px;
      width: 400px;
      height: 100vh;
      background: var(--fm-white);
      box-shadow: -4px 0 20px rgba(0, 0, 0, 0.15);
      transition: right 0.3s ease;
      z-index: 1001;
      overflow-y: auto;
    }
    
    .notifications-panel.active {
      right: 0;
    }
    
    .notifications-panel.refreshing .notifications-content {
      position: relative;
    }
    
    .notifications-panel.refreshing .notifications-content::after {
      content: '';
      position: absolute;
      top: 0;
      left: 0;
      width: 100%;
      height: 3px;
      background: linear-gradient(to right, transparent, var(--fm-primary-blue), transparent);
      animation: refresh-indicator 1s ease-in-out;
      opacity: 0;
    }
    
    @keyframes refresh-indicator {
      0% { transform: translateX(-100%); opacity: 1; }
      100% { transform: translateX(100%); opacity: 0; }
    }
    
    .notifications-header {
      display: flex;
      justify-content: space-between;
      align-items: center;
      padding: 1.5rem;
      border-bottom: 1px solid var(--fm-border-light);
      background: var(--fm-primary-blue);
      color: white;
    }
    
    .notifications-header h3 {
      margin: 0;
      font-size: 1.2rem;
      font-weight: 700;
      color:var(--fm-white);
    }
    
    .close-notifications {
      background: none;
      border: none;
      color: white;
      font-size: 1.5rem;
      cursor: pointer;
      padding: 0.25rem;
      line-height: 1;
    }
    
    .notifications-content {
      padding: 0.5rem;
    }
    
    .notification-item {
      display: flex;
      gap: 0.5rem;
      padding: 0.5rem;
      border-radius: 8px;
      margin-bottom: 0.75rem;
      transition: background 0.3s ease;
      border: 1px solid var(--fm-border-light);
    }
    
    .notification-item:hover {
      background: var(--fm-bg-light);
    }
    
    .notification-icon {
      flex-shrink: 0;
      width: 40px;
      height: 40px;
      border-radius: 50%;
      display: flex;
      align-items: center;
      justify-content: center;
      background: var(--fm-bg-light);
    }
    
    .notification-content h5 {
      margin: 0 0 0.5rem 0;
      font-size: 0.95rem;
      font-weight: 600;
      color: var(--fm-text-primary);
    }
    
    .notification-content p {
      margin: 0 0 0.5rem 0;
      font-size: 0.85rem;
      color: var(--fm-text-secondary);
      line-height: 1.4;
    }
    
    .notification-time {
      font-size: 0.75rem;
      color: var(--fm-text-muted);
    }
    
    .notifications-footer {
      text-align: center;
      padding: 2rem;
      color: var(--fm-text-secondary);
    }
    
    @media (max-width: 768px) {
      .notifications-panel {
        width: 100vw;
        right: -100vw;
      }
    }
  `]
})
export class NotificationsPanelComponent implements OnChanges {
  @Input() isOpen = false;
  @Input() notifications: Catalog[] = [];
  @Input() isRefreshing = false;
  @Output() closePanel = new EventEmitter<void>();
  @Output() notificationClicked = new EventEmitter<Catalog>();

  faChartLine = faChartLine;
  faShieldAlt = faShieldAlt;
  faRocket = faRocket;
  faBell = faBell;
  
  private previousNotificationIds = new Set<string>();

  ngOnChanges(changes: SimpleChanges): void {
    // When notifications change, check if there are new ones
    if (changes['notifications']) {
      this.checkForNewNotifications(changes['notifications'].currentValue, changes['notifications'].previousValue);
    }
  }

  /**
   * Check if there are new notifications since the last update
   */
  private checkForNewNotifications(newNotifications: Catalog[], oldNotifications: Catalog[]): void {
    if (!oldNotifications || !newNotifications) return;
    
    // Get old notification IDs
    if (this.previousNotificationIds.size === 0 && oldNotifications.length > 0) {
      oldNotifications.forEach(notification => {
        this.previousNotificationIds.add(notification.id);
      });
    }
    
    // Check for new notifications
    const newIds = new Set<string>();
    let hasNewNotifications = false;
    
    newNotifications.forEach(notification => {
      newIds.add(notification.id);
      if (!this.previousNotificationIds.has(notification.id)) {
        hasNewNotifications = true;
      }
    });
    
    // Update the previous IDs for next comparison
    this.previousNotificationIds = newIds;
    
    // If new notifications, could trigger a visual indication here
    if (hasNewNotifications) {
      console.log('New notifications received');
      // Could add code here to highlight new notifications
    }
  }

  getNotificationIcon(notification: Catalog) {
    // Map notification types to icons based on category or custom fields
    const type = notification.category || notification.custom?.['type'] || 'primary';
    switch (type) {
      case 'system':
      case 'maintenance': return faShieldAlt;
      case 'success': 
      case 'deployment': return faRocket;
      case 'warning':
      case 'alert': return faBell;
      case 'assignment':
      case 'project': return faChartLine;
      default: return faBell;
    }
  }

  getNotificationVariant(notification: Catalog): 'primary' | 'secondary' | 'success' | 'warning' | 'danger' | 'muted' | undefined {
    const type = notification.category || notification.custom?.['type'] || 'primary';
    switch (type) {
      case 'system':
      case 'maintenance': return 'warning';
      case 'success':
      case 'deployment': return 'success';
      case 'error':
      case 'critical': return 'danger';
      case 'info':
      case 'assignment': return 'primary';
      default: return 'primary';
    }
  }

  /**
   * Format timestamp for display
   */
  formatTime(timestamp?: string): string {
    if (!timestamp) return 'Just now';
    
    try {
      const date = new Date(timestamp);
      const now = new Date();
      const diffMs = now.getTime() - date.getTime();
      const diffMins = Math.floor(diffMs / 60000);
      const diffHours = Math.floor(diffMins / 60);
      const diffDays = Math.floor(diffHours / 24);

      if (diffMins < 1) return 'Just now';
      if (diffMins < 60) return `${diffMins}m ago`;
      if (diffHours < 24) return `${diffHours}h ago`;
      if (diffDays < 7) return `${diffDays}d ago`;
      
      return date.toLocaleDateString();
    } catch (error) {
      return 'Recently';
    }
  }

  /**
   * Handle notification click
   */
  handleNotificationClick(notification: Catalog): void {
    this.notificationClicked.emit(notification);
    
    // Handle notification click based on type or URL
    if (notification.url) {
      window.open(notification.url, '_blank');
    }
  }

  close(): void {
    this.closePanel.emit();
  }
}
import { Component, Input, Output, EventEmitter } from '@angular/core';

@Component({
  selector: 'app-popup-container',
  template: `
    <div class="popup-container" 
         [class.popup-positioned]="mode === 'positioned'"
         [class.popup-panel]="mode === 'panel'"
         [ngStyle]="mode === 'positioned' ? { top: position.y + 'px', left: position.x + 'px' } : {}">
      <div class="popup-header">
        <span>{{ title }}</span>
        <button class="close-button" (click)="onClose()">×</button>
      </div>
      <div class="popup-content">
        <ng-content></ng-content>
      </div>
    </div>
  `,
  styleUrls: ['./popup-container.component.css']
})
export class PopupContainerComponent {
  @Input() title: string = '';
  @Input() position: { x: number; y: number } = { x: 0, y: 0 };
  @Input() mode: 'positioned' | 'panel' = 'positioned'; // New input for display mode
  @Output() close = new EventEmitter<void>();

  onClose(): void {
    this.close.emit();
  }
}

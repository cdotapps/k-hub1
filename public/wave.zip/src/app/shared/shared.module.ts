import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';

// Font Awesome
import { FontAwesomeModule } from '@fortawesome/angular-fontawesome';

import { ButtonComponent } from './components/button/button.component';
import { ActionButtonComponent } from './components/button/action-button.component';
import { ToolButtonComponent } from './components/button/tool-button.component';
import { IconButtonComponent } from './components/button/icon-button.component';
import { CardComponent } from './components/card/card.component';
import { IconComponent } from './components/icon/icon.component';
import { ContainerComponent } from './components/container/container.component';
import { HeaderComponent } from './components/header/header.component';
import { FooterComponent } from './components/footer/footer.component';
import { NewsBarComponent } from './components/news-bar/news-bar.component';
import { ProfileCardComponent } from './components/profile-card/profile-card.component';
import { NotificationsPanelComponent } from './components/notifications-panel/notifications-panel.component';
import { BreadcrumbComponent } from './components/breadcrumb/breadcrumb.component';
import { SearchComponent } from './components/search/search.component';
import { UserSearchComponent } from './components/user-search/user-search.component';
import { OverlapButtonComponent } from './components/overlap-button/overlap-button.component';
import { OverlapNavigationComponent } from './components/overlap-navigation/overlap-navigation.component';
import { RichTextEditorComponent } from './components/rich-text-editor/rich-text-editor.component';
import { PageHeroComponent } from './components/page-hero/page-hero.component';
import { CatalogCardComponent } from './components/card/catalog-card.component';
import { SampleComponent } from './components/sample/sample.component';
import { PopupContainerComponent } from './components/popup-container/popup-container.component';
import { SharePopupComponent } from './components/share-popup/share-popup.component';

@NgModule({
  declarations: [
    ButtonComponent,
    CardComponent,
    IconComponent,
    ContainerComponent,
    HeaderComponent,
    FooterComponent,
    NewsBarComponent,
    ProfileCardComponent,
    NotificationsPanelComponent,
    BreadcrumbComponent,
    SearchComponent,
    UserSearchComponent,
    OverlapButtonComponent,
    OverlapNavigationComponent,
    RichTextEditorComponent,
    PageHeroComponent,
    CatalogCardComponent,
    SampleComponent,
    PopupContainerComponent,
    SharePopupComponent
  ],
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    FontAwesomeModule,
    RouterModule,
    // Import the standalone button components
    ActionButtonComponent,
    ToolButtonComponent,
    IconButtonComponent
  ],
  exports: [
    ButtonComponent,
    ActionButtonComponent,
    ToolButtonComponent,
    IconButtonComponent,
    CardComponent,
    IconComponent,
    ContainerComponent,
    HeaderComponent,
    FooterComponent,
    NewsBarComponent,
    ProfileCardComponent,
    NotificationsPanelComponent,
    BreadcrumbComponent,
    SearchComponent,
    UserSearchComponent,
    OverlapButtonComponent,
    OverlapNavigationComponent,
    RichTextEditorComponent,
    PageHeroComponent,
    CatalogCardComponent,
    PopupContainerComponent,
    SharePopupComponent,
    FontAwesomeModule,
    FormsModule,
    ReactiveFormsModule,
    CommonModule
  ]
})
export class SharedModule { }
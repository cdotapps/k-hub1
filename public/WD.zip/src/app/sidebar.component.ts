import { Component, Input } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { menuConfig } from './site.config';

@Component({
  selector: 'app-sidebar',
  standalone: true,
  imports: [CommonModule, RouterModule],
  template: `
    <aside class="sidebar-dark">
      <div class="sidebar-header">
        <span class="sidebar-title"></span>
      </div>
      <div class="sidebar-search">
        <input type="text" placeholder="Search" />
        <span class="search-icon">🔍</span>
      </div>
      <ul class="sidebar-list">
        <ng-container *ngFor="let item of menuItems">
          <li>
            <button *ngIf="item.children" class="sidebar-link sidebar-parent" (click)="toggleExpand(item.label)">
              <span class="sidebar-icon" aria-label="Folder">
                <svg width="22" height="22" fill="none" stroke="currentColor" stroke-width="1.7" viewBox="0 0 24 24"><path d="M3 7a2 2 0 0 1 2-2h4l2 3h8a2 2 0 0 1 2 2v7a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V7z"/></svg>
              </span>
              {{ item.label }}
              <span class="sidebar-chevron">
                <svg width="18" height="18" fill="none" stroke="#a3a7b3" stroke-width="2.2" viewBox="0 0 24 24" style="vertical-align: middle; transform: translateY(-1px) rotate({{ expanded[item.label] ? 90 : 0 }}deg); transition: transform 0.18s;">
                  <polyline points="9 6 15 12 9 18" />
                </svg>
              </span>
            </button>
            <a *ngIf="!item.children && item.route" [routerLink]="item.route" class="sidebar-link">
              <span class="sidebar-icon" aria-label="Link">
                <svg width="22" height="22" fill="none" stroke="currentColor" stroke-width="1.7" viewBox="0 0 24 24"><circle cx="12" cy="12" r="10"/><path d="M8 12h8"/></svg>
              </span>
              {{ item.label }}
            </a>
            <ul *ngIf="item.children && expanded[item.label]" class="sidebar-submenu">
              <li *ngFor="let child of item.children">
                <a *ngIf="child.route" [routerLink]="child.route" class="sidebar-link">
                  <span class="sidebar-icon" aria-label="Submenu">
                    <svg width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><circle cx="12" cy="12" r="2.5"/></svg>
                  </span>
                  {{ child.label }}
                </a>
                <span *ngIf="!child.route">{{ child.label }}</span>
              </li>
            </ul>
          </li>
        </ng-container>
      </ul>
      <div class="sidebar-robot-button" (click)="openChatbot()">
        <img src="assets/ai-robot.svg" alt="AI Robot" width="24" height="24" />
      </div>
      <div class="sidebar-user">
        <span class="sidebar-avatar sidebar-avatar-icon">
          <svg width="32" height="32" fill="none" stroke="#a3a7b3" stroke-width="1.7" viewBox="0 0 24 24">
            <circle cx="12" cy="8" r="4"/>
            <path d="M4 20c0-4 8-4 8-4s8 0 8 4"/>
          </svg>
        </span>
        <div class="sidebar-user-info">
          <div class="sidebar-user-name">Demo User</div>
          <div class="sidebar-user-email">demo&#64;sample.com</div>
        </div>
        <span class="sidebar-user-menu">⋯</span>
      </div>
    </aside>
  `,
  styles: [
    `
    .sidebar-dark {
      width: 300px;
      background: var(--color-bg-sidebar);
      color: var(--color-gray-900);
      padding: 10px 0 0 0;
      min-height: 85vh;
      display: flex;
      border-radius: 10px;
      flex-direction: column;
      align-items: stretch;
      position: relative;
    }
    .sidebar-header {
      display: flex;
      align-items: center;
      gap: 12px;
      padding: 0 32px 24px 32px;
    }
    .sidebar-logo {
      width: 40px;
      height: 40px;
      border-radius: 10px;
      background: #23272f;
      object-fit: cover;
    }
    .sidebar-title {
      font-size: 1.25rem;
      font-weight: 600;
      color: var(--color-primary);
      letter-spacing: 0.01em;
    }
    .sidebar-search {
      display: flex;
      align-items: center;
      background: #fff;
      border-radius: 30px;
      border:1px solid rgb(140, 147, 162);
      margin: 0 32px 18px 32px;
      padding: 5px 20px;
      height: 30px;
      font-size: 0.75rem;
      box-shadow: 0 1px 4px 0 rgba(60,72,100,0.04);
      position: relative;
    }
    .sidebar-search input {
      background: transparent;
      border: none;
      outline: none;
      color: #23272f;
      font-size: 0.8rem;
      width: 100%;
      padding: 5px 0;
    }
    .search-icon {
      font-size: 1.1rem;
      margin-left: 4px;

    }
    .sidebar-section {
      color: #7b8190;
      font-size: 0.95rem;
      font-weight: 600;
      margin: 18px 0 6px 32px;
      letter-spacing: 0.04em;
      text-transform: none;
    }
    .sidebar-list {
      list-style: none;
      padding: 0 0 0 0;
      margin: 0;
      display: flex;
      flex-direction: column;
      gap: 2px;
    }
    .sidebar-link, .sidebar-parent {
      display: flex;
      align-items: center;
      gap: 14px;
      color: var(--color-gray-900);
      text-decoration: none;
      font-size: 1.08rem;
      font-weight: 500;
      border-radius: 10px;
      padding: 10px 32px;
      transition: background 0.18s, color 0.18s;
      position: relative;
      background: transparent;
    }
    .sidebar-link:hover, .sidebar-link.active, .sidebar-parent:hover, .sidebar-parent.active {
        background: #e6f0fd;
        color: #2563eb;
    }
    .sidebar-link.active::before, .sidebar-parent.active::before {
        background: #e6f0fd;
        color:rgb(17, 46, 109);
    }
    .sidebar-icon {
      font-size: 1.18rem;
      width: 1.7em;
      text-align: center;
      color: var(--color-gray-500);
      display: inline-block;
    }
    .sidebar-badge {
      background: var(--color-secondary);
      color: #fff;
      font-size: 0.85rem;
      border-radius: 8px;
      padding: 2px 8px;
      margin-left: auto;
      font-weight: 600;
      display: inline-block;
    }
    .sidebar-parent {
      width: 100%;
      background: none;
      border: none;
      outline: none;
      color: var(--color-gray-900);
      font-size: 1.08rem;
      font-weight: 500;
      border-radius: 10px;
      padding: 10px 32px;
      display: flex;
      align-items: center;
      gap: 14px;
      cursor: pointer;
      transition: background 0.18s, color 0.18s;
      text-align: left;
      position: relative;
    }
    .sidebar-parent:hover, .sidebar-parent:focus {
      background: #e6f0fd;
      color: #2563eb;
    }
    .sidebar-chevron {
      margin-left: auto;
      font-size: 1.1rem;
      color: #a3a7b3;
      transition: transform 0.18s;
    }
    .sidebar-submenu {
      padding-left: 32px;
      margin-top: 2px;
      display: flex;
      flex-direction: column;
      gap: 2px;
      list-style: none;
    }
    .sidebar-submenu li {
      list-style: none;
    }
    .sidebar-submenu .sidebar-link {
      font-size: 1rem;
      color: #23272f;
      padding: 8px 24px;
      border-radius: 10px;
    }
    .sidebar-submenu .sidebar-link:hover, .sidebar-submenu .sidebar-link.active {
      background: #e6f0fd;
      color: #2563eb;
    }
    .sidebar-user {
      margin-top: auto;
      background: var(--color-bg-sidebar-footer);
      border-radius: 0 0 10px 10px;
      padding: 18px 24px;
      display: flex;
      align-items: center;
      gap: 12px;
      box-shadow: 0 -1px 4px 0 rgba(60,72,100,0.04);
    }
    .sidebar-avatar {
      width: 38px;
      height: 38px;
      border-radius: 50%;
      object-fit: cover;
      background: var(--color-bg-sidebar-user);
      border: 2px solid var(--color-gray-300);
      display: flex;
      align-items: center;
      justify-content: center;
    }
    .sidebar-avatar-icon svg {
      display: block;
      margin: auto;
      stroke: #ffffff; /* Set the user icon color to white */
    }
    .sidebar-user-info {
      flex: 1;
      display: flex;
      flex-direction: column;
      gap: 2px;
    }
    .sidebar-user-name {
      color: var(--color-primary);
      font-size: 1.05rem;
      font-weight: 600;
    }
    .sidebar-user-email {
      color: var(--color-gray-500);
      font-size: 0.93rem;
      font-weight: 400;
    }
    .sidebar-user-menu {
      color: var(--color-gray-500);
      font-size: 1.5rem;
      cursor: pointer;
      padding: 0 4px;
    }
    .sidebar-chatbot {
      margin-top: 12px;
      padding: 8px;
      background: #f0f4ff;
      border-radius: 10px;
      display: flex;
      align-items: center;
      justify-content: center;
      cursor: pointer;
      transition: background 0.18s;
    }
    .sidebar-chatbot:hover {
      background: #e6efff;
    }
    .sidebar-robot-button {
      margin: 12px auto;
      width: 50px;
      height: 50px;
      background: #e6f0fd;
      border-radius: 50%;
      display: flex;
      align-items: center;
      justify-content: center;
      border: 1px solid blue;
      box-shadow: 0 10px 14px rgba(60, 72, 100, 0.04);
      cursor: pointer;
      margin-top: auto;
      transition: background 0.3s;
    }
    .sidebar-robot-button:hover {
      background: #0056b3;
    }
    `
  ]
})
export class SidebarComponent {
  @Input() menuItems: any[] = [];
  expanded: { [key: string]: boolean } = {};
  toggleExpand(label: string) {
    this.expanded[label] = !this.expanded[label];
  }
  openChatbot() {
    let chatbotPopup = document.getElementById('chatbot-popup');

    if (chatbotPopup) {
      chatbotPopup.remove(); // Close the chat window if it exists
      return;
    }

    chatbotPopup = document.createElement('div');
    chatbotPopup.id = 'chatbot-popup';
    chatbotPopup.style.position = 'fixed';
    chatbotPopup.style.bottom = '20px';
    chatbotPopup.style.right = '20px';
    chatbotPopup.style.width = '360px';
    chatbotPopup.style.height = '480px';
    chatbotPopup.style.background = '#ffffff';
    chatbotPopup.style.border = '1px solid #ddd';
    chatbotPopup.style.borderRadius = '12px';
    chatbotPopup.style.boxShadow = '0 4px 16px rgba(0, 0, 0, 0.2)';
    chatbotPopup.style.zIndex = '1000';
    chatbotPopup.style.display = 'flex';
    chatbotPopup.style.flexDirection = 'column';

    chatbotPopup.innerHTML = `
      <div style="padding: 16px; border-bottom: 1px solid #ddd; font-weight: bold; display: flex; align-items: center; background: #f6fafd;">
        <img src="assets/ai-robot.svg" alt="AI Robot" width="24" height="24" style="margin-right: 12px;" />
        <span style="font-size: 1.2rem; color: #333;">AI Chatbot</span>
        <button style="margin-left: auto; background: none; border: none; font-size: 1.2rem; cursor: pointer; color: #999;" onclick="document.getElementById('chatbot-popup').remove()">&times;</button>
      </div>
      <div style="flex: 1; padding: 16px; overflow-y: auto; font-size: 0.95rem; color: #555;">
        <p>Welcome to the AI Chatbot! How can I assist you today?</p>
      </div>
      <div style="padding: 16px; border-top: 1px solid #ddd; display: flex; align-items: center; background: #f6fafd;">
        <input type="text" placeholder="Type a message..." style="flex: 1; padding: 12px; border: 1px solid #ddd; border-radius: 8px; margin-right: 12px; font-size: 0.95rem;" />
        <button style="padding: 12px 24px; background: #007bff; color: #fff; border: none; border-radius: 8px; cursor: pointer; font-size: 0.95rem;">Send</button>
      </div>
    `;

    document.body.appendChild(chatbotPopup);
  }
}

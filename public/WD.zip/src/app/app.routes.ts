import {
  TablesComponent,
  ActionsComponent,
  AddGlueComponent,
  DeleteGlueComponent,
  LandingPageComponent,
  CreateWdComponent,
  UpdateWdComponent,
  GlueTablesComponent,
  GlueActionsComponent,
  WdTablesComponent,
  AiChatbotComponent
} from './components';
import { Routes } from '@angular/router';
import { DefaultPageComponent } from './default-page.component';

export const routes: Routes = [
  { path: '', component: LandingPageComponent },
  { path: 'home', redirectTo: '', pathMatch: 'full' },
  { path: 'dashboard', component: DefaultPageComponent, children: [
    { path: '', redirectTo: 'wd-tables', pathMatch: 'full' },
    { path: 'wd-tables', component: WdTablesComponent },
    { path: 'wd-actions', component: ActionsComponent },
    { path: 'create-wd', component: CreateWdComponent },
    { path: 'update-wd', component: UpdateWdComponent },
    { path: 'glue-tables', component: GlueTablesComponent },
    { path: 'glue-actions', component: GlueActionsComponent },
    { path: 'add-glue', component: AddGlueComponent },
    { path: 'delete-glue', component: DeleteGlueComponent },
    { path: 'update-wd', component: UpdateWdComponent },
    { path: 'ai-chatbot', component: AiChatbotComponent }
  ]}
];

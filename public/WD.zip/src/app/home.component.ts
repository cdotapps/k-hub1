import { Component } from '@angular/core';
import { SidebarComponent } from './sidebar.component';
import { HeaderComponent } from './header.component';
import { CommonModule } from '@angular/common';
import { sidebarMenu } from './site.config';

@Component({
  selector: 'app-home',
  standalone: true,
  imports: [CommonModule, SidebarComponent, HeaderComponent],
  template: `
    <div class="home-layout">
      <app-sidebar [menuItems]="menu"></app-sidebar>
      <div class="main-content">

        <div class="columns">
          <div class="column" *ngFor="let col of columns">
            <div class="column-title">{{ col.title }}</div>
            <div class="card-list">
              <div class="card" *ngFor="let card of col.cards">
                <div class="card-title">{{ card.title }}</div>
                <div class="card-desc">{{ card.desc }}</div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  `,
  styles: [`
    .home-layout {
      display: flex;
      gap: 32px;
      background: #f6fafd;
      min-height: 100vh;
      max-width: 95%;
      margin: 0 auto;
      box-sizing: border-box;
    }
    .main-content {
      flex: 1;
      background: #fff;
      border-radius: 12px;
      box-shadow: 0 2px 8px #e5e9f2;
      padding: 32px;
      min-height: 80vh;
      overflow-x: auto;
      box-sizing: border-box;
    }
    .top-bar {
      display: flex;
      align-items: center;
      justify-content: space-between;
      padding-bottom: 24px;
      border-bottom: 1px solid #e5e9f2;
      margin-bottom: 24px;
    }
    .logo { font-weight: bold; font-size: 1.5rem; color: #3b82f6; }
    .search {
      flex: 1;
      margin: 0 32px;
      padding: 8px 16px;
      border-radius: 6px;
      border: 1px solid #e5e9f2;
      font-size: 1rem;
    }
    .user { color: #222; font-weight: 500; }
    .columns {
      display: flex;
      gap: 24px;
      margin-top: 24px;
      flex-wrap: wrap;
      width: 100%;
      box-sizing: border-box;
    }
    .column {
      background: #f9fafb;
      border-radius: 10px;
      box-shadow: 0 1px 4px #e5e9f2;
      padding: 16px;
      min-width: 220px;
      flex: 1 1 0;
      display: flex;
      flex-direction: column;
      gap: 12px;
      max-width: 340px;
      box-sizing: border-box;
    }
    .column-title {
      font-weight: 600;
      font-size: 1.1rem;
      margin-bottom: 8px;
      color: #3b82f6;
    }
    .card-list { display: flex; flex-direction: column; gap: 10px; }
    .card {
      background: #fff;
      border-radius: 8px;
      box-shadow: 0 1px 2px #e5e9f2;
      padding: 12px 16px;
      font-size: 0.98rem;
    }
    .card-title { font-weight: 500; color: #222; }
    .card-desc { color: #666; font-size: 0.92rem; }
  `]
})
export class HomeComponent {
  menu = sidebarMenu;

  columns = [
    {
      title: 'Column 1',
      cards: [
        { title: 'Card 1-1', desc: 'Description for card 1-1' },
        { title: 'Card 1-2', desc: 'Description for card 1-2' }
      ]
    },
    {
      title: 'Column 2',
      cards: [
        { title: 'Card 2-1', desc: 'Description for card 2-1' },
        { title: 'Card 2-2', desc: 'Description for card 2-2' }
      ]
    },
    {
      title: 'Column 3',
      cards: [
        { title: 'Card 3-1', desc: 'Description for card 3-1' },
        { title: 'Card 3-2', desc: 'Description for card 3-2' }
      ]
    }
  ];
}

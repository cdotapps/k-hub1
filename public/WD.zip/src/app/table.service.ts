import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from '../environments/environment';
import { map } from 'rxjs/operators';

@Injectable({
  providedIn: 'root',
})
export class TableService {
  private apiUrl = environment.apiEndpoint;

  constructor(private http: HttpClient) {}

  getTables(): Observable<any[]> {
    return this.http.get<any>(`${this.apiUrl}all_tables/`).pipe(
      map((response) => {
        const tables = response.entries || [];
        console.log('API Response:', tables);
        return Array.isArray(tables) ? tables.filter((entry) => entry.key === 'TABLE') : [];
      })
    );
  }

  getColumns(tableName: string): Observable<any[]> {
    return this.http.get<any[]>(`${this.apiUrl}all_tables/`).pipe(
      map((columns) => columns.filter((column) => column.type === 'COLUMN' && column.table === tableName))
    );
  }
}
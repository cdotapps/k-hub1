import { CommonModule } from '@angular/common';
import { Component, Input } from '@angular/core';

export interface DataTableColumn {
  key: string;
  label: string;
  title?: string;
  visible: boolean;
  type?: string;
  sortable?: boolean;
}

@Component({
  selector: 'app-data-table',
  standalone: true,
  imports: [CommonModule],
  template: `
    <div class="data-table-header">
      <ng-content select="[header]"></ng-content>
    </div>
    <table>
      <thead>
        <tr>
          <th *ngFor="let column of columns" [hidden]="!column.visible" (click)="sort(column)" [class.sortable]="column.sortable">
            {{ column.label }}
            <span *ngIf="column.sortable" class="sort-icon">{{ getSortIcon(column.key) }}</span>
          </th>
        </tr>
      </thead>
      <tbody>
        <tr *ngFor="let row of visibleData">
          <td *ngFor="let column of columns" [hidden]="!column.visible">
            {{ row[column.key] }}
          </td>
        </tr>
      </tbody>
    </table>
    <div class="data-table-footer" *ngIf="data.length > 0">
      <ng-content select="[footer]"></ng-content>
    </div>
  `,
  styles: [
    `
      table {
        width: 100%;
        border-collapse: collapse;
      }
      th, td {
        border: 1px solid #ddd;
        padding: 8px;
      }
      th {
        background-color: #f4f4f4;
        text-align: left;
        cursor: pointer;
      }
      th.sortable:hover {
        background-color: #e0e0e0;
      }
      .sort-icon {
        margin-left: 8px;
        font-size: 0.8em;
      }
      .data-table-header, .data-table-footer {
        margin: 10px 0;
      }
      .data-table-footer {
        display: flex;
        justify-content: center;
        align-items: center;
        margin: 20px 0;
      }
    `,
  ],
})
export class DataTableComponent {
  @Input() data: any[] = [];
  @Input() columns: DataTableColumn[] = [];
  @Input() metadata: DataTableColumn[] = [];

  visibleData: any[] = [];
  sortKey: string | null = null;
  sortDirection: 'asc' | 'desc' | null = null;

  ngOnInit() {
    this.visibleData = this.data; // Show all data by default
  }

  ngOnChanges(): void {
    this.updateVisibleData(); // Ensure visibleData updates when data changes
  }

  sort(column: DataTableColumn) {
    if (!column.sortable) return;

    if (this.sortKey === column.key) {
      this.sortDirection = this.sortDirection === 'asc' ? 'desc' : 'asc';
    } else {
      this.sortKey = column.key;
      this.sortDirection = 'asc';
    }

    this.data.sort((a, b) => {
      const valueA = a[this.sortKey!];
      const valueB = b[this.sortKey!];

      if (valueA < valueB) return this.sortDirection === 'asc' ? -1 : 1;
      if (valueA > valueB) return this.sortDirection === 'asc' ? 1 : -1;
      return 0;
    });

    this.updateVisibleData();
  }

  updateVisibleData() {
    this.visibleData = this.data; // Ensure all data is visible
  }

  getSortIcon(key: string): string {
    if (this.sortKey !== key) return '⬍'; // Default icon for unsorted columns
    return this.sortDirection === 'asc' ? '⬆' : '⬇'; // Up and down arrows for sort direction
  }
}
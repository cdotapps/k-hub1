import { Component, Input } from '@angular/core';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-toolbar',
  standalone: true,
  imports: [CommonModule],
  template: `
    <div class="toolbar">
      <button *ngFor="let button of buttons" class="icon-button" (click)="button.action()">
        <img [src]="'assets/' + button.icon + '.svg'" alt="{{ button.label }}" class="icon" />
      </button>
    </div>
  `,
  styles: [
    `.toolbar {
      display: flex;
      gap: 8px;
      align-items: center;
      margin-bottom: 16px;
    }
    .icon-button {
      display: flex;
      align-items: center;
      justify-content: center;
      width: 40px;
      height: 40px;
      background: var(--color-primary);
      color: white;
      border-radius: 50%;
      border: none;
      cursor: pointer;
      font-size: 1.2rem;
      transition: background-color 0.3s;
      opacity:0.9;
    }
    .icon-button:hover {
      background-color: var(--color-secondary);
    }
    .icon-button span {
      display: none; /* Remove text */
    }
    .icon-button .icon {
      width: 20px;
      height: 20px;
      stroke: white;
    }`
  ]
})
export class ToolbarComponent {
  @Input() buttons: { icon: string; label: string; action: () => void }[] = [];
}
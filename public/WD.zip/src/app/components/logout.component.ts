import { Component } from '@angular/core';
@Component({
  selector: 'app-logout',
  standalone: true,
  template: `<div>Logout Page Content</div>`
})
export class LogoutComponent {}

import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-create-wd',
  standalone: true,
  imports: [FormsModule, CommonModule],
  template: `
    <div class="form-container">
      <h1>Create Table</h1>
      <form>
        <div class="form-group tenant-select-group">
          <label for="tenant">Select Tenant</label>
          <select id="tenant" name="tenant" [(ngModel)]="selectedTenant" class="form-control tenant-select">
            <option *ngFor="let tenant of tenants" [value]="tenant">{{ tenant }}</option>
          </select>
        </div>

        <div class="button-group">
          <div class="form-group">
            <label for="tableFile">Select Table Structure (CSV)</label>
            <input type="file" id="tableFile" name="tableFile" (change)="onFileSelected($event)" class="form-control" />
          </div>
          <button type="button" class="btn btn-danger" (click)="resetForm()">Reset</button>
        </div>
      </form>

      <div class="data-table-section">
        <h2>Data Table</h2>
        <div *ngIf="tableData.length === 0" class="empty-table-message">
          <p>No data available. Please upload a CSV file to populate the table.</p>
        </div>
        <div *ngIf="tableData.length > 0" class="data-table-container">
          <div class="data-table-scroll">
            <div class="data-table-summary" *ngIf="tableData.length > 0">
              <p>Summary: {{ tableData.length }} rows and {{ tableHeaders.length }} columns</p>
            </div>
            <table>
              <thead>
                <tr>
                  <th *ngFor="let header of tableHeaders.slice(0, 5)">{{ header }}</th>
                </tr>
              </thead>
              <tbody>
                <tr *ngFor="let row of tableData">
                  <td *ngFor="let cell of row.slice(0, 5)">{{ cell }}</td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
      </div>

      <div class="review-section">
        <div class="form-group">
          <input type="checkbox" id="reviewCompleted" [(ngModel)]="reviewCompleted" />
          <label for="reviewCompleted">Review Completed</label>
        </div>
        <button *ngIf="reviewCompleted" class="btn btn-primary" (click)="createTable()">Create Table</button>
      </div>
    </div>
  `,
  styles: [
    `
      .form-container {
        width: 97%;
        margin: 0 auto;
        padding: 20px;
        border: 1px solid #ddd;
        border-radius: 8px;
        background-color: #f9f9f9;
      }
      .form-group {
        margin-bottom: 16px;
      }
      .button-group {
        display: block;
        align-items: center;
        justify-content: center;
        gap: 20px;
        margin-top: 20px;
      }
      label {
        display: block;
        margin-bottom: 8px;
        font-weight: bold;
      }
      .form-control {
        width: 100%;
        padding: 10px;
        border: 1px solid #ccc;
        border-radius: 4px;
        margin-top: 10px;
      }
      table {
        width: 100%;
        border-collapse: collapse;
        margin-top: 20px;
      }
      th,
      td {
        border: 1px solid #ddd;
        padding: 8px;
        text-align: left;
      }
      th {
        background-color: #f4f4f4;
      }
      .btn {
        padding: 10px 20px;
        font-size: 1rem;
        border: none;
        border-radius: 4px;
        cursor: pointer;
        margin-left:12px;
      }
      .btn-primary {
        background-color: #6366f1;
        color: white;
      }
      .btn-primary:hover {
        background-color: #4f46e5;
      }
      .btn-secondary {
        background-color: #6c757d;
        color: white;
      }
      .btn-secondary:hover {
        background-color: #5a6268;
      }
      .btn-danger {
        background-color: #dc3545;
        color: white;
      }
      .btn-danger:hover {
        background-color: #c82333;
      }
      .data-table-section {
        margin-top: 30px;
      }
      .empty-table-message {
        padding: 10px;
        background-color: #e9ecef;
        border-radius: 4px;
        text-align: center;
        color: #495057;
      }
      .data-table-container {
        overflow-x: auto;
        padding: 10px;
        border: 1px solid #ddd;
        border-radius: 4px;
        background-color: #f9f9f9;
      }
      .data-table-scroll {
        min-width: 600px;
      }
      .data-table-summary {
        padding: 10px;
        background-color: #d1e7dd;
        border-radius: 4px;
        margin-bottom: 10px;
        color: #0f5132;
        font-weight: bold;
      }
      .tenant-select {
        height: 35px;
      }
      .review-section {
        margin-top: 20px;
        padding: 10px;
        border: 1px solid #ddd;
        border-radius: 4px;
        background-color: #f1f8e9;
      }
      .review-section .form-group {
        display: flex;
        align-items: center;
        gap: 8px;
      }
      .review-section label {
        margin: 0;
      }
      .tenant-select-group {
        margin: 0;
      }
    `,
  ],
})
export class CreateWdComponent {
  tableData: any[][] = [];
  tableHeaders: string[] = [];
  selectedTenant: string = '';
  tenants: string[] = ['fnm-1', 'fnm-2', 'fnm-3'];
  reviewCompleted: boolean = false;

  onFileSelected(event: Event): void {
    const input = event.target as HTMLInputElement;
    if (input.files && input.files.length > 0) {
      const file = input.files[0];
      const reader = new FileReader();

      reader.onload = (e: any) => {
        const text = e.target.result;
        const rows = text.split('\n');
        this.tableHeaders = rows[0].split(',');
        this.tableData = rows.slice(1).map((row: string) => row.split(','));
      };

      reader.readAsText(file);
    }
  }

  uploadFile(): void {
    console.log('File uploaded');
    // Add logic to handle file upload
  }

  reviewData(): void {
    console.log('Reviewing data:', this.tableData);
    // Add logic to review data
  }

  resetForm(): void {
    this.tableData = [];
    this.tableHeaders = [];
    this.selectedTenant = '';
    this.reviewCompleted = false;
    console.log('Form reset');
  }

  createTable(): void {
    const requestData = {
      tenant: this.selectedTenant,
      headers: this.tableHeaders,
      data: this.tableData,
    };
    console.log('Request Data:', requestData);
    // this.wdService.callWdService(requestData).subscribe(
    //   (response) => {
    //     console.log('Table created successfully:', response);
    //   },
    //   (error) => {
    //     console.error('Error creating table:', error);
    //   }
    // );
  }
}

import { Component } from '@angular/core';
@Component({
  selector: 'app-add-glue',
  standalone: true,
  template: `<div>Add Columns (Glue) Page Content</div>`
})
export class AddGlueComponent {}

import { Component } from '@angular/core';
@Component({
  selector: 'app-delete-wd',
  standalone: true,
  template: `<div>Delete Columns (WD) Page Content</div>`
})
export class DeleteWdComponent {}

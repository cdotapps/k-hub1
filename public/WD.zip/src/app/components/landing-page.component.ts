import { Component } from '@angular/core';

@Component({
  selector: 'app-landing-page',
  standalone: true,
  template: `
    <div class="landing-page">
      <img src="assets/logo.svg" alt="Logo" class="logo" />
      <h1>Welcome to Model Minds innovation for Workday integration</h1>
      <p>Please enter your password to continue.</p>
      <!-- <input type="password" placeholder="Enter your password" class="password-input" /> -->
      <button class="submit-button">Start</button>

      <section class="introduction">
        <h2>Our Innovation</h2>
        <p>Our platform is designed to foster innovation and collaboration. Join us to explore cutting-edge solutions and drive progress together.</p>
      </section>
    </div>
  `,
  styles: [
    `
    .landing-page {
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      height: 100vh;
      background: #f6fafd;
      text-align: center;
    }
    .logo {
      width: 150px;
      margin-bottom: 20px;
    }
    h1 {
      font-size: 2rem;
      color: #3b82f6;
      margin-bottom: 10px;
    }
    p {
      font-size: 1.2rem;
      color: #666;
      margin-bottom: 20px;
    }
    .password-input {
      padding: 10px;
      font-size: 1rem;
      border: 1px solid #e5e9f2;
      border-radius: 6px;
      margin-bottom: 10px;
    }
    .submit-button {
      padding: 10px 20px;
      font-size: 1rem;
      color: #fff;
      background: #3b82f6;
      border: none;
      border-radius: 6px;
      cursor: pointer;
    }
    .submit-button:hover {
      background: #2563eb;
    }
    .introduction {
      margin-top: 40px;
      text-align: left;
    }
    .introduction h2 {
      font-size: 1.5rem;
      color: #333;
      margin-bottom: 10px;
    }
    .introduction p {
      font-size: 1rem;
      color: #666;
      margin-bottom: 20px;
    }
    .footer {
      padding: 20px;
      background: #3b82f6;
      color: #fff;
      text-align: center;
    }
    .footer a {
      color: #fff;
      text-decoration: underline;
    }
    `
  ]
})
export class LandingPageComponent {}
import { Component } from '@angular/core';
@Component({
  selector: 'app-home',
  standalone: true,
  template: `<div>Home Page Content</div>`
})
export class HomeComponent {}

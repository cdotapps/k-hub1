import { Component } from '@angular/core';
@Component({
  selector: 'app-glue-tables',
  standalone: true,
  template: `<div>Glue Tables Page Content</div>`
})
export class GlueTablesComponent {}

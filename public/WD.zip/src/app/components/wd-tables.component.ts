import { Component, OnInit } from '@angular/core';
import { TableService } from '../table.service';
import { CommonModule } from '@angular/common';
import { HttpClientModule } from '@angular/common/http';
import { DataTableComponent, DataTableColumn } from '../shared/data-table/data-table.component';
import { ToolbarComponent } from '../shared/toolbar/toolbar.component';

@Component({
  selector: 'app-wd-tables',
  standalone: true,
  imports: [CommonModule, HttpClientModule, DataTableComponent, ToolbarComponent],
  template: `
    <div>
      <app-toolbar [buttons]="toolbarButtons"></app-toolbar>
      <div class="content-header">
        <h1>WD Tables</h1>
        <span class="badge">Total: {{ filteredTables.length }}</span>
      </div>
      <app-data-table [data]="filteredTables" [columns]="columns" [metadata]="metadata"></app-data-table>
    </div>
  `,
  styles: [
    `
      .content-header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 16px;
      }
      .badge {
        background-color: #6366f1;
        color: white;
        padding: 4px 8px;
        border-radius: 12px;
        font-size: 14px;
      }

    `,
  ],
})
export class WdTablesComponent implements OnInit {
  tables: any[] = [];
  filteredTables: any[] = [];

  columns: DataTableColumn[] = [
    { key: 'key', label: 'Table Name', title: 'Table Name', visible: true, type: 'text', sortable: true },
    { key: 'name', label: 'Table Name', title: 'Table Name', visible: true, type: 'text', sortable: true },
    { key: 'description', label: 'Description', title: 'Description', visible: true, type: 'text', sortable: false },
    { key: 'created_at', label: 'Created At', title: 'Created At', visible: true, type: 'date', sortable: true },
   
  ];

  metadata: DataTableColumn[] = [
    { key: 'name', label: 'Table Name', title: 'Table Name', visible: true },
    { key: 'type', label: 'Table Type', title: 'Table Type', visible: true },
    { key: 'created_at', label: 'Created At', title: 'Created At', visible: true },
  ];

  toolbarButtons = [
    {
      icon: 'add',
      label: 'Add Table',
      action: () => this.addTable(),
    },
  ];

  constructor(private tableService: TableService) { }

  ngOnInit(): void {
    this.tableService.getTables().subscribe(
      (tables) => {
        this.tables = tables;
        this.filteredTables = [...this.tables];

        // // Dynamically generate metadata and filter columns based on metadata
        // if (this.tables.length > 0) {
        //   this.metadata = Object.keys(this.tables[0]).map((key) => ({
        //     key,
        //     label: key.charAt(0).toUpperCase() + key.slice(1), // Capitalize key for label
        //     title: key.charAt(0).toUpperCase() + key.slice(1),
        //     visible: true,
        //   }));

        //   // Filter columns to match metadata
        //   this.columns = this.metadata.map((meta) => ({
        //     key: meta.key,
        //     label: meta.label,
        //     title: meta.title,
        //     visible: meta.visible,
        //     type: 'text',
        //     sortable: true,
        //   }));
        // }
      },
      (error) => {
        console.error('Error fetching tables:', error);
        this.tables = [];
        this.filteredTables = [];
      }
    );
  }

  editTable(table: any): void {
    console.log('Edit table:', table);
  }

  deleteTable(table: any): void {
    console.log('Delete table:', table);
  }

  addTable(): void {
    console.log('Add table action triggered');
    // Logic for adding a new table can be implemented here
  }
}

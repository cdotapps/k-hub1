import { Component } from '@angular/core';
@Component({
  selector: 'app-home',
  standalone: true,
  template: `<div>Home Page Content</div>`
})
export class HomeComponent {}

import { Component as AgentsComponentClass } from '@angular/core';
@Component({
  selector: 'app-agents',
  standalone: true,
  template: `<div>Agents Page Content</div>`
})
export class AgentsComponent {}

import { Component as SettingsComponentClass } from '@angular/core';
@Component({
  selector: 'app-settings',
  standalone: true,
  template: `<div>Settings Page Content</div>`
})
export class SettingsComponent {}

import { Component as LogoutComponentClass } from '@angular/core';
@Component({
  selector: 'app-logout',
  standalone: true,
  template: `<div>Logout Page Content</div>`
})
export class LogoutComponent {}

import { Component as TablesComponentClass } from '@angular/core';
@Component({
  selector: 'app-tables',
  standalone: true,
  template: `<div>WD Tables Page Content</div>`
})
export class TablesComponent {}

import { Component as ActionsComponentClass } from '@angular/core';
@Component({
  selector: 'app-actions',
  standalone: true,
  template: `<div>Actions Page Content</div>`
})
export class ActionsComponent {}

import { Component as AddWdComponentClass } from '@angular/core';
@Component({
  selector: 'app-create-wd',
  standalone: true,
  template: `<div>Add Columns (WD) Page Content</div>`
})
export class AddWdComponent {}

import { Component as DeleteWdComponentClass } from '@angular/core';
@Component({
  selector: 'app-update-wd',
  standalone: true,
  template: `<div>Delete Columns (WD) Page Content</div>`
})
export class DeleteWdComponent {}

import { Component as GroupsComponentClass } from '@angular/core';
@Component({
  selector: 'app-groups',
  standalone: true,
  template: `<div>Glue Tables Page Content</div>`
})
export class GroupsComponent {}

import { Component as AddGlueComponentClass } from '@angular/core';
@Component({
  selector: 'app-add-glue',
  standalone: true,
  template: `<div>Add Columns (Glue) Page Content</div>`
})
export class AddGlueComponent {}

import { Component as DeleteGlueComponentClass } from '@angular/core';
@Component({
  selector: 'app-delete-glue',
  standalone: true,
  template: `<div>Delete Columns (Glue) Page Content</div>`
})
export class DeleteGlueComponent {}

export * from './agents.component';
export * from './settings.component';
export * from './logout.component';
export * from './home.component';
export * from './add-glue.component';
export * from './delete-glue.component';
export * from './delete-wd.component';
export * from './glue-actions.component';
export * from './glue-tables.component';
export * from './wd-actions.component';
export * from './wd-tables.component';
export * from '../shared/toolbar/toolbar.component';
export * from '../shared/data-table/data-table.component';
export * from './landing-page.component';
export * from './create-wd.component';
export * from './update-wd.component';
export { AiChatbotComponent } from './ai-chatbot.component';

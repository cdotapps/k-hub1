import { Component } from '@angular/core';
@Component({
  selector: 'app-delete-glue',
  standalone: true,
  template: `<div>Delete Columns (Glue) Page Content</div>`
})
export class DeleteGlueComponent {}

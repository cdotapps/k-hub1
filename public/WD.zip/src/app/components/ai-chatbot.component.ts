import { Component } from '@angular/core';

@Component({
  selector: 'app-ai-chatbot',
  template: `
    <div class="chatbot-container">
      <h2>AI Chatbot</h2>
      <div class="chat-window">
        <div class="messages">
          <!-- Messages will be displayed here -->
        </div>
        <div class="input-container">
          <input type="text" placeholder="Type your message..." />
          <button>Send</button>
        </div>
      </div>
    </div>
  `,
  styles: [
    `
    .chatbot-container {
      padding: 16px;
      background: #f9f9f9;
      border-radius: 8px;
      box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
    }
    .chat-window {
      border: 1px solid #ddd;
      border-radius: 8px;
      overflow: hidden;
      display: flex;
      flex-direction: column;
      height: 400px;
    }
    .messages {
      flex: 1;
      padding: 8px;
      overflow-y: auto;
      background: #fff;
    }
    .input-container {
      display: flex;
      border-top: 1px solid #ddd;
      padding: 8px;
      background: #f1f1f1;
    }
    .input-container input {
      flex: 1;
      padding: 8px;
      border: 1px solid #ddd;
      border-radius: 4px;
      margin-right: 8px;
    }
    .input-container button {
      padding: 8px 16px;
      background: #007bff;
      color: #fff;
      border: none;
      border-radius: 4px;
      cursor: pointer;
    }
    .input-container button:hover {
      background: #0056b3;
    }
    `
  ]
})
export class AiChatbotComponent {}
import { Component } from '@angular/core';
@Component({
  selector: 'app-agents',
  standalone: true,
  template: `<div>Agents Page Content</div>`
})
export class AgentsComponent {}

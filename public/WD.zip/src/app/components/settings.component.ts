import { Component } from '@angular/core';
@Component({
  selector: 'app-settings',
  standalone: true,
  template: `<div>Settings Page Content</div>`
})
export class SettingsComponent {}

import { Component } from '@angular/core';
@Component({
  selector: 'app-update-wd',
  standalone: true,
  template: `<div>Update Columns (WD) Page Content</div>`
})
export class UpdateWdComponent {}

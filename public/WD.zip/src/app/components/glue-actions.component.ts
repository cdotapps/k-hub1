import { Component } from '@angular/core';
@Component({
  selector: 'app-glue-actions',
  standalone: true,
  template: `<div>Glue Actions Page Content</div>`
})
export class GlueActionsComponent {}

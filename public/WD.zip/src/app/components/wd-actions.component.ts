import { Component } from '@angular/core';
@Component({
  selector: 'app-wd-actions',
  standalone: true,
  template: `<div>WD Actions Page Content</div>`
})
export class WdActionsComponent {}

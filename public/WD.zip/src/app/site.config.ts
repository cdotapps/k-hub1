// Site-wide configuration for menus and metadata

export const menuConfig = {
  headerMenu: [
    {
      label: 'Dashboard',
      route: '/dashboard',
      title: 'WD Tables',
      description: 'View and manage Workday tables.'
    },
    {
      label: 'Agents',
      route: '/agents',
      title: 'Agents - WD',
      description: 'Manage and view your agents.',
      children: [
        {
          label: 'Workflow',
          route: '/workflow',
          title: 'Workflow',
          description: 'View and manage workflows.'
        },
        {
          label: 'Test Run',
          route: '/test-run',
          title: 'Test Run',
          description: 'Run and view test executions.'
        }
      ]
    },
    {
      label: 'Settings',
      route: '/settings',
      title: 'Settings - WD',
      description: 'Manage your application settings.'
    },
    {
      label: 'Logout',
      route: '/logout',
      title: 'Logout - WD',
      description: 'Sign out of your account.'
    }
  ],
  sidebarMenu: [
    {
      label: 'WD Tables',
      route: '/dashboard/wd-tables',
      title: 'WD Tables',
      description: 'Access and manage Workday data tables.'
    },
    {
      label: 'WD Actions',
      route: '/dashboard/wd-actions',
      title: 'WD Actions',
      description: 'Perform operations on Workday data tables.',
      children: [
        {
          label: 'Create Table',
          route: '/dashboard/create-wd',
          title: 'Add Columns (WD)',
          description: 'Add new columns to Workday data tables.'
        },
        {
          label: 'Update Table',
          route: '/dashboard/update-wd',
          title: 'Update Columns (WD)',
          description: 'Modify existing columns in Workday data tables.'
        }
      ]
    },
    {
      label: 'Glue Tables',
      route: '/dashboard/glue-tables',
      title: 'Glue Tables',
      description: 'Access and manage Glue data tables.'
    },
    {
      label: 'Glue Actions',
      route: '/dashboard/glue-actions',
      title: 'Glue Actions',
      description: 'Perform operations on Glue data tables.',
      children: [
        {
          label: 'Create Table',
          route: '/dashboard/add-glue',
          title: 'Add Columns (Glue)',
          description: 'Add new columns to Glue data tables.'
        },
        {
          label: 'Update Table',
          route: '/dashboard/delete-glue',
          title: 'Update Columns (Glue)',
          description: 'Modify existing columns in Glue data tables.'
        }
      ]
    },
  
  ]
};

export const sidebarMenu = menuConfig.sidebarMenu;

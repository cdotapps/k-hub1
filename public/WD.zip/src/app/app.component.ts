import { Component, OnInit } from '@angular/core';
import { HeaderComponent } from './header.component';
import { RouterOutlet, Router } from '@angular/router';
import { SidebarComponent } from './sidebar.component';
import { menuConfig } from './site.config';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [HeaderComponent, SidebarComponent, RouterOutlet, CommonModule],
  template: `
    <app-header></app-header>
    <div style="display: flex; gap: 32px; background: #f6fafd; min-height: 100vh; max-width: 95%; margin: 0 auto; box-sizing: border-box;">
      <app-sidebar *ngIf="showSidebar" [menuItems]="menuConfig.sidebarMenu"></app-sidebar>
      <div style="flex: 1; background: #fff; border-radius: 12px; box-shadow: 0 2px 8px #e5e9f2; padding: 32px; min-height: 100vh; overflow-x: auto; box-sizing: border-box;">
        <router-outlet></router-outlet>
      </div>
    </div>
  `
})
export class AppComponent implements OnInit {
  title = 'WD';
  menuConfig = menuConfig; // Added menuConfig to bind sidebarMenu
  showLandingPage = true;
  showSidebar = false;

  constructor(private router: Router) {}

  ngOnInit() {
    this.router.events.subscribe(() => {
      const currentUrl = this.router.url;
      console.log('Current URL:', currentUrl); // Debugging log
      this.showLandingPage = currentUrl === '/';
      this.showSidebar = !this.showLandingPage; // Show sidebar for all routes except the landing page
      console.log('Show Sidebar:', this.showSidebar); // Debugging log
    });
  }
}

import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router, NavigationEnd, RouterOutlet } from '@angular/router';
import { Title, Meta } from '@angular/platform-browser';
import { menuConfig } from './site.config';
import { filter } from 'rxjs/operators';

@Component({
  selector: 'app-default-page',
  standalone: true,
  template: `
    <div class="default-page-container">
      <h1 class="default-page-title">{{ pageTitle }}</h1>
      <p class="default-page-desc">{{ pageDescription }}</p>
      <section class="default-page-content">
        <router-outlet></router-outlet>
      </section>
    </div>
  `,
  styles: [
    `
    .default-page-container {
      max-width: none;
      margin: 0;
      padding: 10px 32px;
      text-align: left;
      width: 95%;
    }
    .default-page-title {
      font-size: 2.3rem;
      font-weight: 700;
      color: var(--color-primary);
      margin-bottom: 10px;
      letter-spacing: 0.01em;
      text-shadow: 0 2px 8px #e6f0fd;
    }
    .default-page-desc {
      color: var(--color-gray-500);
      font-size: 1.15rem;
      margin-bottom: 32px;
    }
    .default-page-content {
      border-top: 1.5px solid var(--color-gray-300);
      margin-top: 32px;
      padding-top: 28px;
    }
    .default-page-content h2 {
      font-size: 1rem;
      color: var(--color-gray-900);
      margin-bottom: 10px;
      font-weight: 600;
    }
    .default-page-content p {
      color: var(--color-gray-700);
      font-size: 1.05rem;
      margin-bottom: 18px;
    }
    .default-page-content ul {
      color: var(--color-primary);
      font-size: 1.05rem;
    }
    .default-page-content li {
      margin-bottom: 8px;
      color: var(--color-primary);
      list-style: disc;
    }
    `
  ],
  imports: [RouterOutlet]
})
export class DefaultPageComponent implements OnInit {
  pageTitle = '';
  pageDescription = '';

  constructor(
    private router: Router,
    private route: ActivatedRoute,
    private title: Title,
    private meta: Meta
  ) {}

  ngOnInit() {
    this.router.events.pipe(filter(e => e instanceof NavigationEnd)).subscribe(() => {
      this.setMeta();
    });
    // Also update on initial load
    this.setMeta();
  }

  setMeta() {
    let path = this.router.url.split('?')[0];
    if (path.endsWith('/')) path = path.slice(0, -1) || '/';
    // Flatten all menu items and children for lookup
    const allMenuItems = [
      ...menuConfig.headerMenu,
      ...menuConfig.sidebarMenu.flatMap(item => [item, ...(item.children || [])])
    ];
    const meta = allMenuItems.find(item => item.route === path) || { title: 'WD', description: '' };
    this.pageTitle = meta.title;
    this.pageDescription = meta.description;
    this.title.setTitle(meta.title);
    this.meta.updateTag({ name: 'description', content: meta.description });
  }
}

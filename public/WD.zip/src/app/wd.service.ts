import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { environment } from 'src/environments/environment';
import { Observable } from 'rxjs';
import { switchMap } from 'rxjs/operators';

@Injectable({
  providedIn: 'root',
})
export class WdService {
  private tokenEndpoint = environment.tokenEndpoint;
  private wdServiceEndpoint = environment.wdServiceEndpoint;

  constructor(private http: HttpClient) {}

  getToken(): Observable<any> {
    return this.http.get(this.tokenEndpoint);
  }

  callWdService(data: any): Observable<any> {
    return this.getToken().pipe(
      switchMap((token: any) => {
        const headers = new HttpHeaders({
          Authorization: `Bearer ${token}`,
        });
        return this.http.post(this.wdServiceEndpoint, data, { headers });
      })
    );
  }
}
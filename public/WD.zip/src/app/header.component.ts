import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { menuConfig } from './site.config';

@Component({
  selector: 'app-header',
  standalone: true,
  imports: [CommonModule, RouterModule],
  template: `
    <header class="nav-header">
      <nav class="nav-bar">
        <span class="nav-logo">
          <a [routerLink]="'/'">
            <img src="assets/logo.svg" alt="WD Logo" style="height:48px;width:48px;vertical-align:middle;" />
          </a>
        </span>
        <ul class="nav-links">
          <li *ngFor="let item of menu">
            <!-- Dropdown for Agents -->
            <ng-container *ngIf="item.children; else normalLink">
              <span class="dropdown-trigger" (click)="toggleDropdown(item.label)" tabindex="0">
                {{ item.label }}
                <svg class="chevron-icon" width="16" height="16" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                  <path d="M6 8L10 12L14 8" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                </svg>
              </span>
              <ul class="dropdown-menu" *ngIf="dropdownOpen === item.label" (mouseleave)="closeDropdown()">
                <li *ngFor="let child of item.children">
                  <a [routerLink]="child.route" (click)="closeDropdown()">{{ child.label }}</a>
                </li>
              </ul>
            </ng-container>
            <ng-template #normalLink>
              <a *ngIf="item.route" [routerLink]="item.route" routerLinkActive="active" [routerLinkActiveOptions]="{ exact: true }">{{ item.label }}</a>
              <span *ngIf="!item.route">{{ item.label }}</span>
            </ng-template>
          </li>
        </ul>
        <span class="nav-user">Workday Integration Demo &mdash; Innovation Hackathon 2025</span>
      </nav>
    </header>
  `,
  styles: [`
    .nav-header {
      width: 100%;
      background: linear-gradient(90deg, #6366f1 0%, #ec4899 50%, #f59e42 100%);
      color: #fff;
      box-shadow: 0 2px 8px #e5e9f2;
      border-radius: 0 0 18px 18px;
      margin-bottom: 32px;
      position: sticky;
      top: 0;
      z-index: 100;
      height: 80px;
    }
    .nav-bar {
      display: flex;
      align-items: center;
      padding: 16px 36px;
      font-family: 'Inter', 'Roboto', Arial, sans-serif;
    }
    .nav-logo {
      font-weight: 700;
      font-size: 1.5rem;
      letter-spacing: 2px;
      margin-right: 32px;
    }
    .nav-links {
      display: flex;
      align-items: center;
      gap: 0;
      list-style: none;
      margin: 0;
      padding: 0;
      flex: 1;
      height: 100%;
    }
    .nav-links li {
      position: relative;
      display: flex;
      align-items: center;
      height: 100%;
      margin: 0 16px 0 0;
    }
    .nav-links li:last-child {
      margin-right: 0;
    }
    .nav-links li a, .dropdown-trigger {
      display: flex;
      align-items: center;
      height: 48px;
      padding: 0 16px;
      color: #fff;
      text-decoration: none;
      font-weight: 500;
      font-size: 1.05rem;
      border-radius: 6px;
      transition: background 0.2s, color 0.2s;
      background: none;
      box-sizing: border-box;
    }
    .nav-links li a:hover, .dropdown-trigger:hover, .dropdown-trigger:focus {
      /* background: rgba(245, 158, 66, 0.18); */
      color: #f59e42;
      outline: none;
    }
    .nav-user {
      background: rgba(255,255,255,0.18);
      border-radius: 16px;
      padding: 6px 18px;
      font-weight: 500;
      font-size: 1rem;
      letter-spacing: 1px;
      box-shadow: 0 1px 4px #e5e9f2;
    }
    .colorful-header {
      width: 100%;
      background: linear-gradient(90deg, #6366f1 0%, #ec4899 50%, #f59e42 100%);
      color: #fff;
      box-shadow: 0 2px 8px #e5e9f2;
      border-radius: 0 0 18px 18px;
      margin-bottom: 32px;
    }
    .header-content {
      display: flex;
      align-items: center;
      padding: 18px 36px;
      font-family: 'Inter', 'Roboto', Arial, sans-serif;
    }
    .logo {
      font-weight: 700;
      font-size: 1.6rem;
      letter-spacing: 2px;
      margin-right: 24px;
    }
    .title {
      font-size: 1.2rem;
      font-weight: 500;
      flex: none;
    }
    .spacer {
      flex: 1;
    }
    .user-pill {
      background: rgba(255,255,255,0.18);
      border-radius: 16px;
      padding: 6px 18px;
      font-weight: 500;
      font-size: 1rem;
      letter-spacing: 1px;
      box-shadow: 0 1px 4px #e5e9f2;
    }
    .dropdown-trigger {
      cursor: pointer;
      position: relative;
      user-select: none;
      display: flex;
      align-items: center;
      gap: 4px;
      color: #fff;
      font-weight: 500;
      font-size: 1.05rem;
      padding: 6px 12px;
      border-radius: 6px;
      transition: background 0.2s, color 0.2s;
    }
    .dropdown-trigger:hover, .dropdown-trigger:focus {
      /*background: rgba(245, 158, 66, 0.18);*/
      color: #f59e42;
      outline: none;
    }
    .chevron-icon {
      margin-left: 2px;
      vertical-align: middle;
      color: inherit;
      transition: transform 0.2s;
    }
    .dropdown-menu {
      position: absolute;
      background: #232946;
      color: #fff;
      min-width: 180px;
      box-shadow: 0 4px 16px #23294644;
      border-radius: 10px;
      margin-top: 8px;
      z-index: 200;
      padding: 8px 0;
      top: 48px;
      left: 0;
      border: 1px solid #6366f1;
      animation: fadeIn 0.18s;
    }
    .dropdown-menu a {
      display: block;
      padding: 12px 22px;
      color: #fff;
      text-decoration: none;
      font-weight: 500;
      border-radius: 6px;
      transition: background 0.18s, color 0.18s;
    }
    .dropdown-menu a:hover {
      /* background: #6366f1; */
      color: #fff;
    }
    @keyframes fadeIn {
      from { opacity: 0; transform: translateY(-8px); }
      to { opacity: 1; transform: translateY(0); }
    }
  `]
})
export class HeaderComponent {
  menu = menuConfig.headerMenu;
  popupOpen: string | null = null;
  dropdownOpen: string | null = null;

  togglePopup(label: string) {
    this.popupOpen = this.popupOpen === label ? null : label;
  }

  closePopup() {
    this.popupOpen = null;
  }

  toggleDropdown(label: string) {
    this.dropdownOpen = this.dropdownOpen === label ? null : label;
  }

  closeDropdown() {
    this.dropdownOpen = null;
  }
}

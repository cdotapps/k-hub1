export const environment = {
  production: false,
  apiEndpoint: 'http://localhost:8000/',
  tokenEndpoint: 'https://api.example.com/token',
  wdServiceEndpoint: 'https://api.example.com/wd-service',
};
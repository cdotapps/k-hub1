# FST-Hub Design System Components

This document outlines the reusable components available in the FST-Hub application, following fm's design guidelines.

## 🎨 Design System Overview

Our design system is built around fm's color palette and typography:

- **Primary Colors**: Deep blues (`#003f7f`, `#0066cc`)
- **Typography**: Merriweather (headings) + Source Sans Pro (body)
- **Consistent spacing and hover effects**

## 📦 Available Components

### 1. Button Component (`<app-button>`)

A flexible button component with multiple variants and sizes.

#### Usage:
```html
<app-button variant="primary" size="lg">Get Started</app-button>
<app-button variant="outline" size="md">Learn More</app-button>
<app-button variant="secondary" disabled="true">Disabled</app-button>
```

#### Properties:
- `variant`: 'primary' | 'secondary' | 'outline' | 'success' | 'warning' | 'danger'
- `size`: 'sm' | 'md' | 'lg' | 'xl'
- `disabled`: boolean
- `block`: boolean (full width)
- `rounded`: boolean (pill shape)
- `type`: 'button' | 'submit' | 'reset'

#### Examples:
- Primary button: Blue background, white text
- Outline button: Transparent background, blue border
- Block button: Full width of container

### 2. Card Component (`<app-card>`)

A versatile card component for displaying content with consistent styling.

#### Usage:
```html
<app-card title="Card Title" variant="feature" size="lg">
  <p>Card content goes here</p>
  <div slot="footer">
    <app-button variant="primary">Action</app-button>
  </div>
</app-card>
```

#### Properties:
- `title`: string (optional header title)
- `variant`: 'default' | 'elevated' | 'flat' | 'feature' | 'statistics' | 'testimonial'
- `size`: 'sm' | 'md' | 'lg'
- `hover`: boolean (enable hover effects)
- `clickable`: boolean (cursor pointer + enhanced hover)

#### Variants:
- **Default**: Standard card with subtle shadow
- **Feature**: Center-aligned, perfect for feature showcase
- **Statistics**: Left border accent, good for metrics
- **Testimonial**: Top border with quotation mark
- **Elevated**: Higher shadow for prominence
- **Flat**: Minimal shadow, clean look

### 3. Icon Component (`<app-icon>`)

Emoji-based icon system for consistent iconography.

#### Usage:
```html
<app-icon name="innovation" size="xl" variant="primary"></app-icon>
<app-icon name="user" size="md" shape="rounded"></app-icon>
```

#### Properties:
- `name`: string (icon identifier)
- `size`: 'xs' | 'sm' | 'md' | 'lg' | 'xl' | '2xl'
- `color`: string (custom color override)
- `variant`: 'primary' | 'secondary' | 'success' | 'warning' | 'danger' | 'muted'
- `shape`: 'rounded' | 'square' (background shape)

#### Available Icons:
- **Business**: innovation (💡), collaboration (🤝), growth (📈), chart, dollar, bank
- **Navigation**: home, menu, arrow-left, arrow-right
- **Actions**: search, edit, delete, save, share
- **Status**: check, warning, error, info, star
- **Technology**: computer, mobile, settings, cloud

### 4. Container Component (`<app-container>`)

Responsive container for consistent layout and spacing.

#### Usage:
```html
<app-container size="xxl" centered="true">
  <h1>Centered content in extra-large container</h1>
</app-container>
```

#### Properties:
- `size`: 'sm' | 'md' | 'lg' | 'xl' | 'xxl' | 'ultra' | 'fluid'
- `centered`: boolean (center-align content)

#### Container Sizes:
- **sm**: 720px max-width (expanded from 576px)
- **md**: 960px max-width (expanded from 768px)
- **lg**: 1200px max-width (expanded from 992px)
- **xl**: 1440px max-width (expanded from 1200px)
- **xxl**: 1600px max-width (now default, expanded from 1400px)
- **ultra**: 1920px max-width (new ultra-wide option)
- **fluid**: No max-width constraint

## 🚀 Usage Examples

### Feature Card Layout:
```html
<app-container>
  <div class="features-grid">
    <app-card variant="feature" size="lg">
      <app-icon name="innovation" size="xl"></app-icon>
      <h3>Innovation</h3>
      <p>Description text here</p>
    </app-card>
  </div>
</app-container>
```

### Call-to-Action Section:
```html
<app-container size="md">
  <div class="text-center">
    <h2>Ready to Get Started?</h2>
    <p>Join thousands of developers</p>
    <app-button variant="primary" size="lg">Join Now</app-button>
    <app-button variant="outline" size="lg">Learn More</app-button>
  </div>
</app-container>
```

### Statistics Cards:
```html
<app-card variant="statistics" title="Active Users">
  <h2>12,500+</h2>
  <p>Developers using our platform</p>
</app-card>
```

## 🎯 Design Principles

1. **Consistency**: All components follow fm's design language
2. **Flexibility**: Multiple variants and sizes for different use cases
3. **Accessibility**: Proper semantic HTML and ARIA support
4. **Responsiveness**: Mobile-first design approach
5. **Performance**: Lightweight components with minimal dependencies

## 🔧 Customization

Components use CSS custom properties (variables) for theming:

```css
:root {
  --fm-primary-blue: #003f7f;
  --fm-secondary-blue: #0066cc;
  --fm-text-primary: #2c3e50;
  /* ... more variables */
}
```

Override these variables to customize the entire design system while maintaining consistency.

## 📱 Responsive Behavior

All components are designed mobile-first with responsive breakpoints:
- Mobile: < 768px
- Tablet: 768px - 992px  
- Desktop: > 992px

The grid system automatically adjusts for different screen sizes, and text scales appropriately.
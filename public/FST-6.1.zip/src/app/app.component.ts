import { Component } from '@angular/core';
import { APP_CONFIG } from './shared/config/site-config';

@Component({
  selector: 'app-root',
  template: `
    <div class="app-container">
      <app-header></app-header>
      <main class="main-content">
        <router-outlet></router-outlet>
      </main>
      <app-footer></app-footer>
    </div>
  `,
  styles: [`
    .app-container {
      min-height: 100vh;
      display: flex;
      flex-direction: column;
      position: relative;
    }
    
    .main-content {
      flex: 1;
    }
  `]
})
export class AppComponent {
  title = APP_CONFIG.name;
}
import { Component, Input } from '@angular/core';
import { faEnvelope } from '@fortawesome/free-solid-svg-icons';
import { faLinkedin } from '@fortawesome/free-brands-svg-icons';

@Component({
  selector: 'app-profile-card',
  template: `
    <div class="profile-card" [class.profile-card-featured]="featured">
      <div class="profile-image-container">
        <img [src]="imageSrc || 'assets/default-profile.jpg'" [alt]="name" class="profile-image">
        <div class="profile-overlay"></div>
      </div>
      <div class="profile-content">
        <h3 class="profile-name">{{ name }}</h3>
        <p class="profile-title">{{ title }}</p>
        <p class="profile-department" *ngIf="department">{{ department }}</p>
        <div class="profile-actions" *ngIf="showActions">
          <a href="mailto:{{ email }}" *ngIf="email" class="profile-action">
            <app-icon [faIcon]="faEnvelope" size="sm"></app-icon>
          </a>
          <a [href]="linkedIn" target="_blank" rel="noopener noreferrer" *ngIf="linkedIn" class="profile-action">
            <app-icon [faIcon]="faLinkedin" size="sm"></app-icon>
          </a>
        </div>
      </div>
    </div>
  `,
  styles: [`
    .profile-card {
      background: var(--fm-white);
      border-radius: 8px;
      overflow: hidden;
      box-shadow: 0 2px 8px rgba(44, 62, 80, 0.1);
      transition: all 0.3s ease;
      height: 100%;
      display: flex;
      flex-direction: column;
      border: 1px solid #e9ecef;
    }
    
    .profile-card:hover {
      box-shadow: 0 4px 16px rgba(44, 62, 80, 0.15);
      transform: translateY(-2px);
    }
    
    
    
    .profile-image-container {
      position: relative;
      width: 100%;
      padding-top: 100%; /* 1:1 Aspect Ratio */
      overflow: hidden;
    }
    
    .profile-image {
      position: absolute;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      object-fit: cover;
      transition: transform 0.5s ease;
    }
    
    .profile-card:hover .profile-image {
      transform: scale(1.05);
    }
    
    .profile-overlay {
      position: absolute;
      top: 0;
      left: 0;
      right: 0;
      bottom: 0;
      background: linear-gradient(0deg, rgba(0, 63, 127, 0.05) 0%, rgba(0, 0, 0, 0) 50%);
      pointer-events: none;
    }
    
    .profile-content {
      padding: 1.25rem;
      flex-grow: 1;
      display: flex;
      flex-direction: column;
    }
    
    .profile-name {
      font-size: 1.25rem;
      font-weight: 600;
      margin: 0 0 0.5rem;
      color: var(--fm-text-primary);
      line-height: 1.2;
    }
    
    .profile-title {
      font-size: 0.875rem;
      color: var(--fm-text-secondary);
      margin: 0 0 0.75rem;
      line-height: 1.4;
    }
    
    .profile-department {
      font-size: 0.75rem;
      color: var(--fm-text-light);
      margin: 0 0 1rem;
      text-transform: uppercase;
      letter-spacing: 0.025em;
    }
    
    .profile-actions {
      margin-top: auto;
      display: flex;
      gap: 0.75rem;
      padding-top: 0.75rem;
      border-top: 1px solid #e9ecef;
    }
    
    .profile-action {
      color: var(--fm-gray-medium);
      transition: color 0.3s ease;
    }
    
    .profile-action:hover {
      color: var(--fm-primary-blue);
      text-decoration: none;
    }
    
    @media (max-width: 768px) {
      .profile-content {
        padding: 1rem;
      }
      
      .profile-name {
        font-size: 1.125rem;
      }
      
      .profile-title {
        font-size: 0.8125rem;
      }
    }
  `]
})
export class ProfileCardComponent {
  @Input() name: string = '';
  @Input() title: string = '';
  @Input() department: string = '';
  @Input() imageSrc: string = '';
  @Input() email: string = '';
  @Input() linkedIn: string = '';
  @Input() featured: boolean = false;
  @Input() showActions: boolean = true;
  @Input() status: string = '';
  @Input() lastActivity: string = '';
  
  // Font Awesome icons
  faEnvelope = faEnvelope;
  faLinkedin = faLinkedin;
}

import { Component, Input, TemplateRef } from '@angular/core';
import { IconDefinition } from '@fortawesome/fontawesome-svg-core';

@Component({
  selector: 'app-card-metric',
  template: `
    <div class="card-metric-minimal">
      <div class="metric-icon" *ngIf="icon">
        <fa-icon [icon]="icon"></fa-icon>
      </div>
      <div class="metric-label">{{ label }}</div>
      <div class="metric-value">{{ value }}</div>
      <div class="metric-graphic" *ngIf="graphic">
        <ng-container *ngIf="graphicImg; else graphicTplBlock">
          <img [src]="graphicImg" alt="graphic" />
        </ng-container>
        <ng-template #graphicTplBlock>
          <ng-container *ngTemplateOutlet="graphicTpl"></ng-container>
        </ng-template>
      </div>
    </div>
  `,
  styles: [`
    .card-metric-minimal {
      display: flex;
      flex-direction: column;
      align-items: center;
      background: var(--fm-white, #fff);
      border-radius: 10px;
      box-shadow: 0 2px 10px rgba(44, 62, 80, 0.08);
      padding: 1rem 0.5rem;
      width: 150px;
      height: 150px;
      gap: 0.5rem;
    }
    .metric-icon fa-icon {
      font-size: 1.5rem;
      color: var(--fm-primary-blue, #007bff);
      margin-bottom: 0.5rem;
    }
    .metric-label {
      font-size: 0.8rem;
      color: var(--fm-text-secondary, #6c757d);
      margin-bottom: 0.25rem;
      text-align: center;
    }
    .metric-value {
      font-size: 2rem;
      font-weight: 700;
      color: var(--fm-text-primary, #222);
      margin-bottom: 0.5rem;
      text-align: center;
    }
    .metric-graphic {
      width: 100%;
      display: flex;
      justify-content: center;
      align-items: center;
      min-height: 40px;
    }
    .metric-graphic img {
      max-width: 80px;
      max-height: 40px;
      object-fit: contain;
    }
  `]
})
export class CardMetricComponent {
  @Input() icon?: IconDefinition;
  @Input() label?: string;
  @Input() value?: string | number;
  @Input() graphic?: string | TemplateRef<any>;

  isGraphicString(): boolean {
    return typeof this.graphic === 'string';
  }

  get graphicImg(): string | null {
    return typeof this.graphic === 'string' ? this.graphic : null;
  }
  get graphicTpl(): TemplateRef<any> | null {
    return this.graphic instanceof TemplateRef ? this.graphic : null;
  }
}
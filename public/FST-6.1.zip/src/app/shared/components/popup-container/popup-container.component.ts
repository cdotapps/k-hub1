import { Component, Input, Output, EventEmitter } from '@angular/core';

@Component({
  selector: 'app-popup-container',
  template: `
    <div class="popup-container" 
         [class.popup-positioned]="mode === 'positioned'"
         [class.popup-panel]="mode === 'panel'"
         [ngStyle]="mode === 'positioned' ? { top: position.y + 'px', left: position.x + 'px' } : {}">
      <div class="popup-header">
        <span class="popup-title">{{ title || 'Details' }}</span>
        <button class="close-button" (click)="onClose()" type="button" aria-label="Close">
          <svg width="16" height="16" viewBox="0 0 16 16" fill="currentColor">
            <path d="M12.854 3.146a.5.5 0 0 0-.708 0L8 7.293 3.854 3.146a.5.5 0 1 0-.708.708L7.293 8l-4.147 4.146a.5.5 0 0 0 .708.708L8 8.707l4.146 4.147a.5.5 0 0 0 .708-.708L8.707 8l4.147-4.146a.5.5 0 0 0 0-.708z"/>
          </svg>
        </button>
      </div>
      <div class="popup-content">
        <ng-content></ng-content>
      </div>
    </div>
  `,
  styleUrls: ['./popup-container.component.css']
})
export class PopupContainerComponent {
  @Input() title: string = '';
  @Input() position: { x: number; y: number } = { x: 0, y: 0 };
  @Input() mode: 'positioned' | 'panel' = 'positioned';
  @Output() close = new EventEmitter<void>();

  onClose(): void {
    this.close.emit();
  }
}

import { Component, Input, Output, EventEmitter } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FontAwesomeModule } from '@fortawesome/angular-fontawesome';
import { IconDefinition } from '@fortawesome/fontawesome-svg-core';
import { faSpinner } from '@fortawesome/free-solid-svg-icons';

export type ActionButtonVariant = 'primary' | 'secondary' | 'success' | 'warning' | 'danger' | 'outline' | 'ghost';
export type ActionButtonSize = 'small' | 'medium' | 'large';

@Component({
  selector: 'app-action-button',
  standalone: true,
  imports: [CommonModule, FontAwesomeModule],
  template: `
    <button 
      [class]="getButtonClasses()"
      [disabled]="disabled || loading"
      (click)="handleClick($event)"
      [type]="type"
    >
      <fa-icon 
        *ngIf="loading" 
        [icon]="loadingIcon || defaultLoadingIcon" 
        [spin]="true"
        class="btn-icon loading"
      ></fa-icon>
      <fa-icon 
        *ngIf="!loading && icon" 
        [icon]="icon"
        class="btn-icon"
      ></fa-icon>
      <span class="btn-text" [class.sr-only]="iconOnly">
        <ng-content></ng-content>
      </span>
    </button>
  `,
  styles: [`
    .action-button {
      display: inline-flex;
      align-items: center;
      justify-content: center;
      gap: 0.5rem;
      border: none;
      border-radius: 8px;
      font-weight: 600;
      cursor: pointer;
      transition: all 0.3s ease;
      text-decoration: none;
      font-family: 'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', system-ui, sans-serif;
      position: relative;
      overflow: hidden;
    }

    .action-button:disabled {
      opacity: 0.5;
      cursor: not-allowed;
      pointer-events: none;
      transform: none !important;
    }

    /* Sizes */
    .action-button.small {
      padding: 0.5rem 1rem;
      font-size: 0.875rem;
      gap: 0.375rem;
    }

    .action-button.medium {
      padding: 0.75rem 1.5rem;
      font-size: 0.95rem;
      gap: 0.5rem;
    }

    .action-button.large {
      padding: 1rem 2rem;
      font-size: 1.1rem;
      gap: 0.625rem;
    }

    /* Variants */
    .action-button.primary {
      background: var(--fm-primary-blue);
      color: var(--fm-white);
      border: 2px solid var(--fm-primary-blue);
    }

    .action-button.primary:hover:not(:disabled) {
      background: var(--fm-navy);
      border-color: var(--fm-navy);
      transform: translateY(-1px);
      box-shadow: 0 4px 12px rgba(0, 63, 127, 0.3);
    }

    .action-button.secondary {
      background: var(--fm-white);
      color: var(--fm-text-primary);
      border: 2px solid #e9ecef;
    }

    .action-button.secondary:hover:not(:disabled) {
      border-color: var(--fm-secondary-blue);
      color: var(--fm-secondary-blue);
      transform: translateY(-1px);
      box-shadow: 0 2px 8px rgba(0, 102, 204, 0.15);
    }

    .action-button.success {
      background: var(--fm-green);
      color: var(--fm-white);
      border: 2px solid var(--fm-green);
    }

    .action-button.success:hover:not(:disabled) {
      background: #1e7e34;
      border-color: #1e7e34;
      transform: translateY(-1px);
      box-shadow: 0 4px 12px rgba(40, 167, 69, 0.3);
    }

    .action-button.warning {
      background: var(--fm-orange);
      color: var(--fm-white);
      border: 2px solid var(--fm-orange);
    }

    .action-button.warning:hover:not(:disabled) {
      background: #e8590c;
      border-color: #e8590c;
      transform: translateY(-1px);
      box-shadow: 0 4px 12px rgba(253, 126, 20, 0.3);
    }

    .action-button.danger {
      background: var(--fm-red);
      color: var(--fm-white);
      border: 2px solid var(--fm-red);
    }

    .action-button.danger:hover:not(:disabled) {
      background: #c82333;
      border-color: #c82333;
      transform: translateY(-1px);
      box-shadow: 0 4px 12px rgba(220, 53, 69, 0.3);
    }

    .action-button.outline {
      background: transparent;
      color: var(--fm-primary-blue);
      border: 2px solid var(--fm-primary-blue);
    }

    .action-button.outline:hover:not(:disabled) {
      background: var(--fm-primary-blue);
      color: var(--fm-white);
      transform: translateY(-1px);
    }

    .action-button.ghost {
      background: transparent;
      color: var(--fm-text-primary);
      border: 2px solid transparent;
    }

    .action-button.ghost:hover:not(:disabled) {
      background: rgba(0, 102, 204, 0.05);
      color: var(--fm-secondary-blue);
      border-color: rgba(0, 102, 204, 0.1);
    }

    /* Icon only styles */
    .action-button.icon-only {
      aspect-ratio: 1;
      padding: 0.75rem;
    }

    .action-button.icon-only.small {
      padding: 0.5rem;
    }

    .action-button.icon-only.large {
      padding: 1rem;
    }

    .btn-icon {
      flex-shrink: 0;
    }

    .btn-icon.loading {
      color: currentColor;
    }

    .btn-text {
      white-space: nowrap;
      overflow: hidden;
      text-overflow: ellipsis;
    }

    .sr-only {
      position: absolute;
      width: 1px;
      height: 1px;
      padding: 0;
      margin: -1px;
      overflow: hidden;
      clip: rect(0, 0, 0, 0);
      white-space: nowrap;
      border: 0;
    }

    /* Full width */
    .action-button.full-width {
      width: 100%;
    }

    /* Loading state */
    .action-button.loading {
      pointer-events: none;
    }
  `]
})
export class ActionButtonComponent {
  @Input() variant: ActionButtonVariant = 'primary';
  @Input() size: ActionButtonSize = 'medium';
  @Input() icon?: IconDefinition;
  @Input() disabled = false;
  @Input() loading = false;
  @Input() iconOnly = false;
  @Input() fullWidth = false;
  @Input() type: 'button' | 'submit' | 'reset' = 'button';
  @Input() loadingIcon?: IconDefinition;

  @Output() buttonClick = new EventEmitter<Event>();

  // Default loading icon
  defaultLoadingIcon = faSpinner;

  getButtonClasses(): string {
    const classes = ['action-button'];
    
    classes.push(this.variant);
    classes.push(this.size);
    
    if (this.iconOnly) {
      classes.push('icon-only');
    }
    
    if (this.fullWidth) {
      classes.push('full-width');
    }
    
    if (this.loading) {
      classes.push('loading');
    }
    
    return classes.join(' ');
  }

  handleClick(event: Event): void {
    if (!this.disabled && !this.loading) {
      this.buttonClick.emit(event);
    }
  }
}
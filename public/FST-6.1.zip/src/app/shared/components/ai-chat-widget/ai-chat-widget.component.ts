import { Component, OnInit, OnDestroy, ViewChild, ElementRef, AfterViewChecked } from '@angular/core';
import { 
  faRobot, faPaperPlane, faSpinner, faTimes, faUser, 
  faExpand, faCompress, faCopy, faThumbsUp, faThumbsDown,
  faMinimize, faMaximize, faLink, faComments, faMinus
} from '@fortawesome/free-solid-svg-icons';
import { AiChatService, AIChatSession, AIChatMessage } from '../../services/ai-chat.service';
import { AuthService } from '../../services/auth.service';
import { Subscription } from 'rxjs';

@Component({
  selector: 'app-ai-chat-widget',
  templateUrl: './ai-chat-widget.component.html',
  styleUrls: ['./ai-chat-widget.component.css']
})
export class AiChatWidgetComponent implements OnInit, OnDestroy, AfterViewChecked {
  @ViewChild('messagesContainer') messagesContainer!: ElementRef;

  // FontAwesome icons
  faRobot = faRobot;
  faPaperPlane = faPaperPlane;
  faSpinner = faSpinner;
  faTimes = faTimes;
  faUser = faUser;
  faExpand = faExpand;
  faCompress = faCompress;
  faCopy = faCopy;
  faThumbsUp = faThumbsUp;
  faThumbsDown = faThumbsDown;
  faMinimize = faMinimize;
  faMaximize = faMaximize;
  faLink = faLink;
  faComments = faComments;
  faMinus = faMinus;

  // Chat state
  isOpen = false;
  isMinimized = false;
  isExpanded = false;
  currentMessage = '';
  isLoading = false;
  currentSession: AIChatSession | null = null;
  
  // Position and size
  position: 'bottom-right' | 'bottom-left' | 'sidebar' = 'bottom-right';
  
  // Quick actions
  quickActions = [
    { text: 'Help me with content creation', action: 'content_creation' },
    { text: 'Analyze a webpage', action: 'url_analysis' },
    { text: 'Summarize text', action: 'qa_help' },
    { text: 'Answer questions', action: 'qa_help' }
  ];

  private subscription = new Subscription();
  private shouldScrollToBottom = false;

  constructor(
    private aiChatService: AiChatService,
    private authService: AuthService
  ) {}

  ngOnInit(): void {
    // Subscribe to current chat session
    this.subscription.add(
      this.aiChatService.currentSession$.subscribe(session => {
        this.currentSession = session;
        if (session) {
          this.shouldScrollToBottom = true;
        }
      })
    );
  }

  ngOnDestroy(): void {
    this.subscription.unsubscribe();
  }

  ngAfterViewChecked(): void {
    if (this.shouldScrollToBottom) {
      this.scrollToBottom();
      this.shouldScrollToBottom = false;
    }
  }

  // Chat widget controls
  toggleChat(): void {
    if (!this.isOpen) {
      this.openChat();
    } else {
      this.closeChat();
    }
  }

  openChat(context?: string): void {
    this.isOpen = true;
    this.isMinimized = false;
    
    if (!this.currentSession) {
      this.aiChatService.startNewSession(context);
    }
  }

  closeChat(): void {
    this.isOpen = false;
    this.isMinimized = false;
  }

  minimizeChat(): void {
    this.isMinimized = true;
  }

  maximizeChat(): void {
    this.isMinimized = false;
  }

  toggleExpanded(): void {
    this.isExpanded = !this.isExpanded;
  }

  // Message handling
  sendMessage(): void {
    if (!this.currentMessage.trim() || this.isLoading) return;

    const messageText = this.currentMessage.trim();
    this.currentMessage = '';

    // Add user message
    this.aiChatService.addMessage({
      content: messageText,
      isUser: true
    });

    // Add loading message
    const loadingMessageId = this.generateId();
    this.aiChatService.addMessage({
      content: '',
      isUser: false,
      isLoading: true,
      id: loadingMessageId
    } as any);

    this.isLoading = true;

    // Send to AI and get response
    this.aiChatService.sendToAI(messageText, this.currentSession?.context)
      .then(response => {
        // Remove loading message
        this.aiChatService.removeMessage(loadingMessageId);
        
        // Add AI response
        this.aiChatService.addMessage({
          content: response,
          isUser: false
        });
        
        this.isLoading = false;
      })
      .catch(error => {
        console.error('AI response error:', error);
        
        // Remove loading message and add error message
        this.aiChatService.removeMessage(loadingMessageId);
        this.aiChatService.addMessage({
          content: "I'm sorry, I encountered an error. Please try again.",
          isUser: false
        });
        
        this.isLoading = false;
      });
  }

  useQuickAction(action: string): void {
    switch (action) {
      case 'content_creation':
        // Set context for content creation and prompt for URL
        if (this.currentSession) {
          this.currentSession.context = 'content creation';
        }
        this.aiChatService.addMessage({
          content: "I'd love to help you create content! Please paste a URL of an article, blog post, or webpage you'd like me to analyze for content creation ideas.",
          isUser: false
        });
        this.currentMessage = '';
        break;
      case 'url_analysis':
        this.currentMessage = 'I want to analyze a webpage: ';
        break;
      case 'summarize':
        this.currentMessage = 'Please summarize this for me: ';
        break;
      case 'qa_help':
        this.currentMessage = 'I have a question about ';
        break;
    }
  }

  // URL Analysis (enhanced from home component)
  analyzeUrl(): void {
    const urlPattern = /https?:\/\/[^\s]+/g;
    const urls = this.currentMessage.match(urlPattern);
    
    if (urls && urls.length > 0) {
      // This would integrate with your existing URL scraping service
      this.aiChatService.addMessage({
        content: `I'll analyze the URL: ${urls[0]}`,
        isUser: false,
        type: 'url_result'
      });
    }
  }

  // Message actions
  copyMessage(content: string): void {
    navigator.clipboard.writeText(content).then(() => {
      // Could show a toast notification here
      console.log('Message copied to clipboard');
    });
  }

  rateMessage(messageId: string, isHelpful: boolean): void {
    // Could send feedback to analytics or AI service
    console.log(`Message ${messageId} rated as ${isHelpful ? 'helpful' : 'not helpful'}`);
  }

  // Keyboard handling
  onKeyPress(event: KeyboardEvent): void {
    if (event.key === 'Enter' && !event.shiftKey) {
      event.preventDefault();
      this.sendMessage();
    }
  }

  // Utility methods
  getMessageTime(timestamp: Date): string {
    return new Intl.DateTimeFormat('en-US', {
      hour: '2-digit',
      minute: '2-digit'
    }).format(timestamp);
  }

  private scrollToBottom(): void {
    if (this.messagesContainer) {
      try {
        const element = this.messagesContainer.nativeElement;
        element.scrollTop = element.scrollHeight;
      } catch (error) {
        console.warn('Could not scroll to bottom:', error);
      }
    }
  }

  private generateId(): string {
    return Math.random().toString(36).substr(2, 9);
  }
}
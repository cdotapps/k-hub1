import { Injectable } from '@angular/core';
import { Observable, BehaviorSubject, timer, Subject } from 'rxjs';
import { takeUntil, filter } from 'rxjs/operators';

export interface CacheEntry<T> {
  data: T;
  timestamp: number;
}

@Injectable({
  providedIn: 'root'
})
export class CacheService {
  private cache = new Map<string, CacheEntry<any>>();
  private defaultTtlMs = 60000; // 1 minute default TTL
  
  // Polling management
  private catalogRefreshSubject = new BehaviorSubject<boolean>(false);
  private stopPollingSubject = new Subject<void>();
  private refreshIntervalMs = 60000;
  private lastRefreshTime = 0;
  
  public catalogRefresh$ = this.catalogRefreshSubject.asObservable();

  constructor() {
    this.startPollingForUpdates();
  }

  /**
   * Get cached data if valid, otherwise return null
   */
  get<T>(key: string, ttlMs?: number): T | null {
    const entry = this.cache.get(key);
    if (!entry) return null;
    
    const now = Date.now();
    const ttl = ttlMs || this.defaultTtlMs;
    
    if (now - entry.timestamp > ttl) {
      this.cache.delete(key);
      return null;
    }
    
    return entry.data;
  }

  /**
   * Set cache entry
   */
  set<T>(key: string, data: T): void {
    this.cache.set(key, {
      data,
      timestamp: Date.now()
    });
  }

  /**
   * Clear specific cache entry
   */
  delete(key: string): void {
    this.cache.delete(key);
  }

  /**
   * Clear all cache entries
   */
  clear(): void {
    this.cache.clear();
  }

  /**
   * Clear cache entries older than specified timestamp
   */
  clearOlderThan(timestamp: number): void {
    for (const [key, value] of this.cache.entries()) {
      if (value.timestamp < timestamp) {
        this.cache.delete(key);
      }
    }
  }

  /**
   * Create cache key from parameters
   */
  createKey(prefix: string, params?: any): string {
    return `${prefix}:${JSON.stringify(params || {})}`;
  }

  /**
   * Get or set cached data with a factory function
   */
  getOrSet<T>(key: string, factory: () => Observable<T>, ttlMs?: number): Observable<T> {
    const cached = this.get<T>(key, ttlMs);
    
    if (cached) {
      return new Observable(observer => {
        observer.next(cached);
        observer.complete();
      });
    }
    
    return new Observable(observer => {
      factory().subscribe({
        next: (data) => {
          this.set(key, data);
          observer.next(data);
        },
        error: (error) => observer.error(error),
        complete: () => observer.complete()
      });
    });
  }

  /**
   * Start polling for catalog updates
   */
  startPollingForUpdates(intervalMs?: number): void {
    this.stopPollingSubject.next();
    
    if (intervalMs && intervalMs > 0) {
      this.refreshIntervalMs = intervalMs;
    }
    
    timer(0, this.refreshIntervalMs)
      .pipe(
        takeUntil(this.stopPollingSubject),
        filter(() => this.shouldRefresh())
      )
      .subscribe(() => {
        this.triggerRefresh();
      });
  }

  /**
   * Stop polling for updates
   */
  stopPollingForUpdates(): void {
    this.stopPollingSubject.next();
  }

  /**
   * Trigger manual refresh
   */
  triggerRefresh(): void {
    this.lastRefreshTime = Date.now();
    this.catalogRefreshSubject.next(true);
    this.clearOlderThan(Date.now() - 60000);
  }

  /**
   * Check if refresh should occur
   */
  private shouldRefresh(): boolean {
    const now = Date.now();
    return (now - this.lastRefreshTime) > 30000;
  }
}
import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable } from 'rxjs';
import { ScrapingService } from './scraping.service';
import { AuthService } from './auth.service';

export interface AIChatMessage {
  id: string;
  content: string;
  isUser: boolean;
  timestamp: Date;
  isLoading?: boolean;
  type?: 'text' | 'url_result' | 'suggestion';
}

export interface AIChatSession {
  id: string;
  title: string;
  messages: AIChatMessage[];
  context?: string; // For catalog items or general context
  lastActivity: Date;
}

@Injectable({
  providedIn: 'root'
})
export class AiChatService {
  private currentSession = new BehaviorSubject<AIChatSession | null>(null);
  private sessions: AIChatSession[] = [];

  currentSession$ = this.currentSession.asObservable();

  constructor(
    private scrapingService: ScrapingService,
    private authService: AuthService
  ) {}

  startNewSession(context?: string, title: string = 'AI Assistant'): AIChatSession {
    const session: AIChatSession = {
      id: this.generateId(),
      title,
      messages: this.getWelcomeMessages(context),
      context,
      lastActivity: new Date()
    };

    this.sessions.push(session);
    this.currentSession.next(session);
    return session;
  }

  addMessage(message: Omit<AIChatMessage, 'id' | 'timestamp'>): void {
    const session = this.currentSession.value;
    if (!session) return;

    const newMessage: AIChatMessage = {
      ...message,
      id: this.generateId(),
      timestamp: new Date()
    };

    session.messages.push(newMessage);
    session.lastActivity = new Date();
    this.currentSession.next(session);
  }

  updateMessage(messageId: string, updates: Partial<AIChatMessage>): void {
    const session = this.currentSession.value;
    if (!session) return;

    const messageIndex = session.messages.findIndex(m => m.id === messageId);
    if (messageIndex !== -1) {
      session.messages[messageIndex] = { ...session.messages[messageIndex], ...updates };
      this.currentSession.next(session);
    }
  }

  removeMessage(messageId: string): void {
    const session = this.currentSession.value;
    if (!session) return;

    session.messages = session.messages.filter(m => m.id !== messageId);
    this.currentSession.next(session);
  }

  private getWelcomeMessages(context?: string): AIChatMessage[] {
    const welcomeMessage: AIChatMessage = {
      id: this.generateId(),
      content: context 
        ? `Hello! I'm here to help you with "${context}". What would you like to know?`
        : "Hello! I'm your AI assistant. I can help you create content, answer questions, or analyze web pages. How can I assist you today?",
      isUser: false,
      timestamp: new Date()
    };

    return [welcomeMessage];
  }

  async sendToAI(message: string, context?: string): Promise<string> {
    // Check if the message contains a URL
    const urlPattern = /https?:\/\/[^\s]+/g;
    const urls = message.match(urlPattern);
    
    if (urls && urls.length > 0) {
      // If we have a URL, determine the intent based on context or default to content analysis
      if (context?.includes('content creation') || message.toLowerCase().includes('content creation')) {
        // Handle URL scraping for content creation
        return this.scrapeUrlForContentCreation(urls[0]);
      } else {
        // Default behavior for any URL - analyze for content creation
        return this.scrapeUrlForContentCreation(urls[0]);
      }
    }
    
    // If no URL, use the existing AI response logic
    return this.generateAIResponse(message, context);
  }

  private async scrapeUrlForContentCreation(url: string): Promise<string> {
    try {
      console.log('🤖 [AI-CHAT] Starting URL scraping:', url);
      
      // Use the dedicated scraping service - API handles catalog creation
      const scrapedData = await this.scrapingService.scrapeUrl(url).toPromise();
      console.log('🤖 [AI-CHAT] Scrape completed:', scrapedData);

      // Simple success response - the API handles catalog creation
      return `✅ **Success!** I've analyzed and added "${scrapedData?.title || 'the webpage'}" to your catalog. You can find it in your drafts section.`;
      
    } catch (error: any) {
      console.error('🤖 [AI-CHAT] URL scraping failed:', error);
      
      // Handle scraping service errors gracefully
      if (error.message) {
        return `❌ ${error.message}`;
      }
      
      return `❌ I encountered an error while analyzing the webpage. Please check the URL and try again.`;
    }
  }

  private generateAIResponse(userMessage: string, context?: string): string {
    const lowerMessage = userMessage.toLowerCase();
    
    if (lowerMessage.includes('summarize') || lowerMessage.includes('summary')) {
      return context 
        ? `Here's a summary of "${context}": This content covers key concepts and practical insights. The main takeaways include important methodologies and actionable recommendations for implementation.`
        : "I'd be happy to help you summarize content! Please share what you'd like me to summarize.";
    }
    
    if (lowerMessage.includes('key takeaway') || lowerMessage.includes('main point')) {
      return "The key takeaways from this content are: 1) Understanding the fundamental concepts, 2) Practical implementation strategies, 3) Best practices for optimization.";
    }
    
    if (lowerMessage.includes('explain') || lowerMessage.includes('simpler')) {
      return "Let me break this down in simpler terms: The content discusses practical approaches and methodologies that can be applied to improve processes and outcomes.";
    }
    
    if (lowerMessage.includes('question')) {
      return "Here are some good questions to consider: 1) How can this be applied in practice?, 2) What are the potential challenges?, 3) What resources are needed for implementation?";
    }

    if (lowerMessage.includes('help') || lowerMessage.includes('assist')) {
      return "I can help you in several ways: analyze web content, answer questions, create summaries, provide insights, or help with content creation. What specific task would you like assistance with?";
    }
    
    return "That's an interesting question! Based on the context, I'd suggest exploring the practical applications and considering how the concepts relate to your specific needs. Could you tell me more about what you're looking for?";
  }

  private generateId(): string {
    return Math.random().toString(36).substr(2, 9);
  }
}
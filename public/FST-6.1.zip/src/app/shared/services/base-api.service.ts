import { Injectable } from '@angular/core';
import { HttpClient, HttpParams, HttpErrorResponse } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { catchError } from 'rxjs/operators';
import { environment } from '../../../environments/environment';

@Injectable({
  providedIn: 'root'
})
export class BaseApiService {
  protected readonly API_BASE = `${environment.apiUrl}${environment.apiVersion}`;

  constructor(protected http: HttpClient) {}

  /**
   * Build HTTP parameters from object
   */
  protected buildHttpParams(params?: Record<string, any>): HttpParams {
    let httpParams = new HttpParams();
    
    if (params) {
      Object.keys(params).forEach(key => {
        const value = params[key];
        if (value !== undefined && value !== null) {
          httpParams = httpParams.set(key, value.toString());
        }
      });
    }
    
    return httpParams;
  }

  /**
   * Add default sorting parameters
   */
  protected addSortParams(params: any, defaultSort = 'updated_date', defaultOrder = 'desc'): any {
    return {
      ...params,
      sort: params?.sort || defaultSort,
      order: params?.order || defaultOrder
    };
  }

  /**
   * Generic GET request
   */
  protected get<T>(endpoint: string, params?: Record<string, any>): Observable<T> {
    const httpParams = this.buildHttpParams(params);
    return this.http.get<T>(`${this.API_BASE}${endpoint}`, { params: httpParams })
      .pipe(catchError(this.handleError));
  }

  /**
   * Generic POST request
   */
  protected post<T>(endpoint: string, body: any): Observable<T> {
    return this.http.post<T>(`${this.API_BASE}${endpoint}`, body)
      .pipe(catchError(this.handleError));
  }

  /**
   * Generic PUT request
   */
  protected put<T>(endpoint: string, body: any): Observable<T> {
    return this.http.put<T>(`${this.API_BASE}${endpoint}`, body)
      .pipe(catchError(this.handleError));
  }

  /**
   * Generic PATCH request
   */
  protected patch<T>(endpoint: string, body: any): Observable<T> {
    return this.http.patch<T>(`${this.API_BASE}${endpoint}`, body)
      .pipe(catchError(this.handleError));
  }

  /**
   * Generic DELETE request
   */
  protected delete<T>(endpoint: string): Observable<T> {
    return this.http.delete<T>(`${this.API_BASE}${endpoint}`)
      .pipe(catchError(this.handleError));
  }

  /**
   * Handle HTTP errors consistently
   */
  private handleError(error: HttpErrorResponse): Observable<never> {
    console.error('API error:', error);
    
    console.error('Full error object:', {
      status: error.status,
      statusText: error.statusText,
      error: error.error,
      headers: error.headers,
      url: error.url
    });
    
    let errorMessage = 'An error occurred while processing your request.';
    
    if (error.error?.detail) {
      if (Array.isArray(error.error.detail)) {
        errorMessage = error.error.detail.map((e: any) => e.msg).join(', ');
      } else {
        errorMessage = error.error.detail;
      }
    } else if (error.error?.message) {
      errorMessage = error.error.message;
    } else if (error.message) {
      errorMessage = error.message;
    }
    
    return throwError(() => new Error(errorMessage));
  }
}
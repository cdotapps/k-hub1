import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { catchError, map } from 'rxjs/operators';
import { AuthService } from './auth.service';

export interface ScrapeRequest {
  url: string;
}

export interface ScrapeResponse {
  title?: string;
  description?: string;
  summary?: string;
  content?: string;
  text?: string;
  tags?: string[];
  author?: string;
  publishedDate?: string;
  imageUrl?: string;
  sourceUrl?: string;
}

export interface ScrapeError {
  error: string;
  message: string;
  statusCode: number;
}

@Injectable({
  providedIn: 'root'
})
export class ScrapingService {
  private readonly SCRAPE_API_URL = 'http://localhost:8001/scrape';
  private readonly API_KEY = 'news-agent-api-key-2025';

  constructor(
    private http: HttpClient,
    private authService: AuthService
  ) {}

  /**
   * Scrape content from a URL
   * @param url The URL to scrape
   * @returns Observable of scraped content
   */
  scrapeUrl(url: string): Observable<ScrapeResponse> {
    const headers = this.buildHeaders();
    const body: ScrapeRequest = { url };

    console.log('🌐 [SCRAPING-SERVICE] Initiating scrape request for:', url);

    return this.http.post<ScrapeResponse>(this.SCRAPE_API_URL, body, { headers })
      .pipe(
        map(response => {
          console.log('✅ [SCRAPING-SERVICE] Scrape successful:', response);
          return this.normalizeResponse(response);
        }),
        catchError(error => {
          console.error('❌ [SCRAPING-SERVICE] Scrape failed:', error);
          return this.handleError(error);
        })
      );
  }

  /**
   * Validate if a URL is scrapeable
   * @param url The URL to validate
   * @returns boolean indicating if URL appears valid for scraping
   */
  isValidUrl(url: string): boolean {
    try {
      const urlObj = new URL(url);
      // Check for supported protocols
      const supportedProtocols = ['http:', 'https:'];
      return supportedProtocols.includes(urlObj.protocol);
    } catch {
      return false;
    }
  }

  /**
   * Extract and clean URLs from text
   * @param text Text that may contain URLs
   * @returns Array of valid URLs found in the text
   */
  extractUrls(text: string): string[] {
    const urlPattern = /https?:\/\/[^\s]+/g;
    const matches = text.match(urlPattern) || [];
    
    return matches
      .map(url => url.replace(/[.,;!?]+$/, '')) // Remove trailing punctuation
      .filter(url => this.isValidUrl(url));
  }

  /**
   * Build HTTP headers for scraping requests
   */
  private buildHeaders(): HttpHeaders {
    return new HttpHeaders({
      'Authorization': `Bearer ${this.API_KEY}`,
      'Content-Type': 'application/json'
    });
  }

  /**
   * Normalize response data to ensure consistent structure
   */
  private normalizeResponse(response: any): ScrapeResponse {
    return {
      title: response.title || response.headline || 'Untitled',
      description: response.description || response.summary || response.excerpt || '',
      summary: response.summary || response.description || '',
      content: response.content || response.text || response.body || '',
      text: response.text || response.content || '',
      tags: response.tags || response.keywords || [],
      author: response.author || response.byline || '',
      publishedDate: response.publishedDate || response.published || response.date || '',
      imageUrl: response.imageUrl || response.image || response.thumbnail || '',
      sourceUrl: response.sourceUrl || response.url || ''
    };
  }

  /**
   * Handle scraping API errors
   */
  private handleError(error: any): Observable<never> {
    let errorMessage = 'Failed to scrape the webpage. Please check the URL and try again.';
    let statusCode = 500;

    if (error.status) {
      statusCode = error.status;
      
      switch (error.status) {
        case 400:
          errorMessage = 'Invalid URL provided. Please check the URL format.';
          break;
        case 401:
          errorMessage = 'Authentication failed. Please contact support.';
          break;
        case 403:
          errorMessage = 'Access forbidden. The website may be blocking scraping requests.';
          break;
        case 404:
          errorMessage = 'The webpage could not be found. Please check the URL.';
          break;
        case 429:
          errorMessage = 'Too many requests. Please wait a moment and try again.';
          break;
        case 500:
          errorMessage = 'Server error occurred while scraping. Please try again later.';
          break;
        case 503:
          errorMessage = 'Scraping service is temporarily unavailable. Please try again later.';
          break;
        default:
          if (error.error?.message) {
            errorMessage = error.error.message;
          }
      }
    } else if (error.message) {
      errorMessage = error.message;
    }

    const scrapeError: ScrapeError = {
      error: 'SCRAPE_FAILED',
      message: errorMessage,
      statusCode
    };

    return throwError(() => scrapeError);
  }

  /**
   * Get scraping service health status
   */
  getHealthStatus(): Observable<{ status: string; timestamp: string }> {
    const headers = this.buildHeaders();
    
    return this.http.get<any>(`${this.SCRAPE_API_URL.replace('/scrape', '/health')}`, { headers })
      .pipe(
        map(response => ({
          status: response.status || 'unknown',
          timestamp: new Date().toISOString()
        })),
        catchError(() => {
          return throwError(() => ({
            status: 'unavailable',
            timestamp: new Date().toISOString()
          }));
        })
      );
  }
}
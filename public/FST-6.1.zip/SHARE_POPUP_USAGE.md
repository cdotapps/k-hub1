# Share Popup Component Usage Guide

## Overview

The share-popup component has been enhanced to provide a modern, user-friendly **right-side panel interface** for sharing content with team members. It features three distinct tabs: "My Manager", "My Peers", and "My Team" in a full-height side panel for optimal user experience.

## Layout Design

### 🎨 Right-Side Panel Layout
- **Position**: Slides in from the right side of the screen
- **Height**: Full viewport height for maximum content visibility
- **Width**: 450px on desktop, responsive on mobile
- **Animation**: Smooth slide-in animation from the right
- **Background**: Semi-transparent overlay with elegant gradient header

## Features

### 🎯 Three Organized Tabs
- **My Manager**: Shows your direct manager for quick access sharing
- **My Peers**: Displays colleagues at your level
- **My Team**: Lists team members you can share with

### 📱 Responsive Right Panel Design
- **Desktop**: 450px width panel with full height
- **Tablet**: Adapts to available screen width
- **Mobile**: Full-width overlay with optimized layout
- **Smooth animations**: Slide-in from right with elegant transitions

### 🔍 Smart Search
- Search across all user categories simultaneously
- Real-time filtering by name or user ID
- Clear search functionality

### ✅ Enhanced User Selection
- Visual feedback for selected users
- **Compact bottom display** for selected users (saves space)
- **Expandable selected list** - shows first 2 users, click to see all
- Bulk selection management with clear all option
- Individual user removal from selected list
- Count indicators on tabs

### 📦 Space Optimization

The share popup has been optimized for better space utilization:

#### Selected Users Display
- **Bottom positioning**: Selected users now appear at the bottom instead of top
- **Compact design**: Shows only first 2 selected users by default
- **Expandable**: Click "+X more" to see all selected users
- **Quick removal**: Individual remove buttons for each selected user
- **Space efficient**: Pills design takes minimal vertical space

#### Benefits
- **More room for browsing**: Main content area has more space for user lists
- **Better workflow**: Select users first, review selection at bottom
- **Less scrolling**: Compact design reduces need for scrolling
- **Mobile friendly**: Responsive design works well on all screen sizes

### 🎨 Modern UI/UX
- Full-height right-side panel design
- Gradient header with brand colors
- Custom scrollbar styling
- Smooth animations and transitions
- Accessibility features (keyboard navigation, ARIA labels)
- Responsive design for all screen sizes

## Design Specifications

### Layout Dimensions
- **Panel Width**: 450px (desktop), responsive (mobile)
- **Panel Height**: 100vh (full viewport height)
- **Position**: Right-aligned, full-height
- **Overlay**: Semi-transparent background (rgba(0, 0, 0, 0.3))

### Visual Design
- **Header**: Gradient background (primary to secondary blue)
- **Animation**: Slide-in from right (slideInFromRight)
- **Shadow**: Left-side shadow (-4px 0 20px rgba(0, 0, 0, 0.15))
- **Scrollbars**: Custom styled for better visual integration

### Responsive Breakpoints
- **Mobile (≤768px)**: Full-width panel
- **Small Mobile (≤480px)**: Optimized padding and layout

## Basic Usage

```typescript
// In your component template
<app-share-popup
  [show]="showSharePopup"
  [catalogItem]="selectedCatalog"
  (close)="onSharePopupClose()"
  (shareComplete)="onShareComplete($event)">
</app-share-popup>

// In your component class
export class YourComponent {
  showSharePopup = false;
  selectedCatalog: Catalog | null = null;

  openSharePopup(catalog: Catalog) {
    this.selectedCatalog = catalog;
    this.showSharePopup = true;
  }

  onSharePopupClose() {
    this.showSharePopup = false;
    this.selectedCatalog = null;
  }

  onShareComplete(event: { users: any[], catalogItem: Catalog }) {
    console.log('Shared with users:', event.users);
    console.log('Catalog item:', event.catalogItem);
    // Handle successful share
    this.showSharePopup = false;
  }
}
```

## Input Properties

| Property | Type | Default | Description |
|----------|------|---------|-------------|
| `show` | `boolean` | `false` | Controls popup visibility |
| `isVisible` | `boolean` | `false` | Alternative visibility control |
| `catalogItem` | `Catalog \| null` | `null` | The catalog item to share |
| `catalogId` | `string` | `''` | Direct catalog ID (if catalogItem not provided) |

## Output Events

| Event | Type | Description |
|-------|------|-------------|
| `close` | `void` | Emitted when popup is closed |
| `shareComplete` | `{ users: any[], catalogItem: Catalog }` | Emitted when sharing is successful |

## Tab Behavior

### Default Tab Selection
The component intelligently selects the default active tab based on available data:
1. **Manager tab** - if manager data is available
2. **Peers tab** - if peers are available
3. **Team tab** - if team members are available
4. **Peers tab** - as fallback

### User Data Structure
The component expects user data in the following format:
```typescript
interface User {
  id: string;
  user_id?: string;
  name?: string;
  first_name?: string;
  last_name?: string;
  designation?: string;
  // ... other user properties
}
```

## Customization

### Consistent Styling with Global Design System
The component now uses the centralized color variables from `styles.css` for consistent theming:

```css
/* Color variables used from styles.css */
--fm-primary-blue: #003f7f;     /* Primary brand color */
--fm-secondary-blue: #0066cc;   /* Secondary brand color */
--fm-navy: #1e3a5f;            /* Dark accent */
--fm-light-blue: #e6f2ff;      /* Light background */
--fm-gray-lighter: #f5f7fa;    /* Light backgrounds */
--fm-gray-light: #8fa0ad;      /* Borders and subtle elements */
--fm-gray-medium: #5a6c7d;     /* Medium text */
--fm-text-primary: #2c3e50;    /* Primary text */
--fm-text-light: #8fa0ad;      /* Secondary text */
--fm-white: #ffffff;           /* Pure white */
```

### Typography
All text elements use the consistent Inter font family from the global design system:
```css
font-family: 'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', system-ui, sans-serif;
```

### Popup Container Modes
The popup-container component now supports two display modes:
- **positioned**: Traditional absolute positioned popup (default)
- **panel**: Full-height side panel mode

```typescript
// Panel mode for share popup
<app-popup-container 
  title="Share with Team" 
  mode="panel"
  (close)="closePopup()">
```

### Service Dependencies
Make sure your `UserService` implements the `getShareableUsers()` method:
```typescript
getShareableUsers(): Observable<{
  peers: User[];
  team: User[];
  manager: User | null;
}> {
  // Implementation to fetch shareable users
}
```

## Accessibility Features

- Keyboard navigation support (Enter/Space to select users)
- ARIA labels for screen readers
- Proper focus management
- Role and state attributes

## Browser Support

The component supports all modern browsers and follows Angular best practices for compatibility.

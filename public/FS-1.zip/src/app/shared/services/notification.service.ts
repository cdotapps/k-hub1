import { Injectable } from '@angular/core';
import { Observable, of } from 'rxjs';
import { map, catchError } from 'rxjs/operators';
import { CatalogService } from './catalog.service';
import { Catalog } from '../models/user.interface';

// Application interfaces
export interface Notification {
  id: string;
  title: string;
  message: string;
  type: 'info' | 'warning' | 'success' | 'error' | 'announcement' | 'update' | 'reminder';
  category: 'system' | 'news' | 'team' | 'personal' | 'security' | 'product';
  priority: 'high' | 'medium' | 'low';
  isRead: boolean;
  isBookmarked: boolean;
  timestamp: string;
  author?: string;
  authorId?: string;
  relatedItem?: {
    id: string;
    type: string;
    title: string;
  };
  actions?: NotificationAction[];
}

export interface NotificationAction {
  label: string;
  action: string;
  variant: 'primary' | 'secondary' | 'danger';
  icon?: any;
}

export interface NotificationResponse {
  notifications: Notification[];
  totalCount: number;
  currentPage: number;
  totalPages: number;
  pageSize: number;
}

interface NotificationFilters {
  search?: string;
  category?: string;
  notification_type?: string;
  priority_level?: string;
  is_read?: boolean;
  date_from?: string;
  date_to?: string;
  page?: number;
  page_size?: number;
  sort?: string;
  order?: 'asc' | 'desc';
}

@Injectable({
  providedIn: 'root'
})
export class NotificationService {

  constructor(private catalogService: CatalogService) {}

  /**
   * Get notifications with filters and pagination using catalog service
   */
  getNotifications(filters: NotificationFilters = {}): Observable<NotificationResponse> {
    // Convert our filters to catalog query params
    const catalogParams = {
      type: 'notification',
      status: 'published',
      page: filters.page || 1,
      page_size: filters.page_size || 12,
      sort: filters.sort || 'created_at',
      order: filters.order || 'desc',
      search: filters.search
    };

    return this.catalogService.getCatalogItems(catalogParams)
      .pipe(
        map(response => this.transformCatalogResponse(response, filters)),
        catchError(error => {
          console.error('Error fetching notifications from catalog:', error);
          // Return empty response on error
          return of({
            notifications: [],
            totalCount: 0,
            currentPage: 1,
            totalPages: 1,
            pageSize: filters.page_size || 12
          });
        })
      );
  }

  /**
   * Mark notification as read (using catalog custom fields)
   */
  markAsRead(notificationId: string): Observable<Notification> {
    return this.catalogService.getCatalogItem(notificationId)
      .pipe(
        map(catalog => {
          // Update the custom field for read status
          const updatedCustom = {
            ...catalog.custom,
            is_read: true
          };
          
          // Update the catalog item
          this.catalogService.updateCustomAttributes(notificationId, updatedCustom).subscribe();
          
          // Return the transformed notification
          return this.transformCatalogToNotification(catalog);
        })
      );
  }

  /**
   * Mark all notifications as read
   */
  markAllAsRead(filters: NotificationFilters = {}): Observable<{ success: boolean; updated_count: number }> {
    // This would require a bulk update API in the catalog service
    // For now, return a success response
    return of({ success: true, updated_count: 0 });
  }

  /**
   * Toggle bookmark status
   */
  toggleBookmark(notificationId: string, isBookmarked: boolean): Observable<Notification> {
    return this.catalogService.getCatalogItem(notificationId)
      .pipe(
        map(catalog => {
          // Update the custom field for bookmark status
          const updatedCustom = {
            ...catalog.custom,
            is_bookmarked: isBookmarked
          };
          
          // Update the catalog item
          this.catalogService.updateCustomAttributes(notificationId, updatedCustom).subscribe();
          
          // Return the transformed notification
          return this.transformCatalogToNotification(catalog);
        })
      );
  }

  /**
   * Delete notification
   */
  deleteNotification(notificationId: string): Observable<void> {
    return this.catalogService.deleteCatalogItem(notificationId);
  }

  /**
   * Get notification statistics
   */
  getNotificationStats(): Observable<{
    total: number;
    unread: number;
    categories: { [key: string]: number };
  }> {
    return this.catalogService.getCatalogItems({ 
      type: 'notifications', 
      status: 'published',
      page_size: 100 // Get a larger sample for stats
    }).pipe(
      map(response => {
        const notifications = (response.items || []).map((item: Catalog) => this.transformCatalogToNotification(item));
        
        const stats = {
          total: response.total || notifications.length,
          unread: notifications.filter(n => !n.isRead).length,
          categories: {} as { [key: string]: number }
        };

        // Calculate category counts
        notifications.forEach(notification => {
          const category = notification.category;
          stats.categories[category] = (stats.categories[category] || 0) + 1;
        });

        return stats;
      }),
      catchError(error => {
        console.warn('Error getting notification stats:', error);
        return of({
          total: 0,
          unread: 0,
          categories: {}
        });
      })
    );
  }

  /**
   * Transform catalog response to notification response
   */
  private transformCatalogResponse(response: any, filters: NotificationFilters): NotificationResponse {
    const notifications = (response.items || [])
      .map((item: Catalog) => this.transformCatalogToNotification(item))
      .filter((notification: Notification) => this.applyClientSideFilters(notification, filters));

    return {
      notifications,
      totalCount: response.total || notifications.length,
      currentPage: response.page || filters.page || 1,
      totalPages: response.total_pages || Math.ceil((response.total || notifications.length) / (filters.page_size || 12)),
      pageSize: filters.page_size || 12
    };
  }

  /**
   * Transform catalog item to notification
   */
  private transformCatalogToNotification(catalog: Catalog): Notification {
    return {
      id: catalog.id,
      title: catalog.title,
      message: catalog.description || catalog.content || '',
      type: this.mapCatalogTypeToNotificationType(catalog),
      category: this.mapCatalogCategoryToNotificationCategory(catalog),
      priority: this.mapCatalogPriorityToNotificationPriority(catalog),
      isRead: catalog.custom?.['is_read'] || false,
      isBookmarked: catalog.custom?.['is_bookmarked'] || false,
      timestamp: catalog.created_date || catalog.updated_date || new Date().toISOString(),
      author: catalog.author,
      authorId: catalog.author_id,
      relatedItem: catalog.custom?.['related_item'] ? {
        id: catalog.custom['related_item'].id,
        type: catalog.custom['related_item'].type || 'unknown',
        title: catalog.custom['related_item'].title || 'Related Item'
      } : undefined,
      actions: this.extractActionsFromCatalog(catalog)
    };
  }

  /**
   * Apply client-side filters that aren't handled by the catalog API
   */
  private applyClientSideFilters(notification: Notification, filters: NotificationFilters): boolean {
    // Filter by category
    if (filters.category && notification.category !== filters.category) {
      return false;
    }

    // Filter by type
    if (filters.notification_type && notification.type !== filters.notification_type) {
      return false;
    }

    // Filter by priority
    if (filters.priority_level && notification.priority !== filters.priority_level) {
      return false;
    }

    // Filter by read status
    if (filters.is_read !== undefined && notification.isRead !== filters.is_read) {
      return false;
    }

    // Filter by date range
    if (filters.date_from) {
      const notificationDate = new Date(notification.timestamp);
      const fromDate = new Date(filters.date_from);
      if (notificationDate < fromDate) {
        return false;
      }
    }

    if (filters.date_to) {
      const notificationDate = new Date(notification.timestamp);
      const toDate = new Date(filters.date_to);
      if (notificationDate > toDate) {
        return false;
      }
    }

    return true;
  }

  /**
   * Map catalog fields to notification type
   */
  private mapCatalogTypeToNotificationType(catalog: Catalog): Notification['type'] {
    // Check custom fields first
    if (catalog.custom?.['notification_type']) {
      return catalog.custom['notification_type'];
    }
    
    // Check tags
    if (catalog.tags) {
      const tags = Array.isArray(catalog.tags) ? catalog.tags : [catalog.tags];
      const typeTag = tags.find(tag => 
        ['info', 'warning', 'success', 'error', 'announcement', 'update', 'reminder'].includes(tag.toLowerCase())
      );
      if (typeTag) {
        return typeTag.toLowerCase() as Notification['type'];
      }
    }

    // Check priority for type mapping
    if (catalog.priority === 'high') {
      return 'warning';
    }

    // Default mapping
    return 'info';
  }

  /**
   * Map catalog fields to notification category
   */
  private mapCatalogCategoryToNotificationCategory(catalog: Catalog): Notification['category'] {
    // Check custom fields first
    if (catalog.custom?.['category']) {
      return catalog.custom['category'];
    }
    
    // Check catalog category field
    if (catalog.category) {
      const categoryMap: { [key: string]: Notification['category'] } = {
        'system': 'system',
        'news': 'news',
        'team': 'team',
        'personal': 'personal',
        'security': 'security',
        'product': 'product'
      };
      return categoryMap[catalog.category.toLowerCase()] || 'system';
    }

    // Check tags for category
    if (catalog.tags) {
      const tags = Array.isArray(catalog.tags) ? catalog.tags : [catalog.tags];
      const categoryTag = tags.find(tag => 
        ['system', 'news', 'team', 'personal', 'security', 'product'].includes(tag.toLowerCase())
      );
      if (categoryTag) {
        return categoryTag.toLowerCase() as Notification['category'];
      }
    }

    // Default to system
    return 'system';
  }

  /**
   * Map catalog priority to notification priority
   */
  private mapCatalogPriorityToNotificationPriority(catalog: Catalog): Notification['priority'] {
    if (catalog.priority) {
      const priorityMap: { [key: string]: Notification['priority'] } = {
        'high': 'high',
        'medium': 'medium',
        'low': 'low'
      };
      return priorityMap[catalog.priority.toLowerCase()] || 'medium';
    }
    
    // Check custom priority
    if (catalog.custom?.['priority_level']) {
      return catalog.custom['priority_level'];
    }

    return 'medium';
  }

  /**
   * Extract actions from catalog custom fields
   */
  private extractActionsFromCatalog(catalog: Catalog): NotificationAction[] {
    if (catalog.custom?.['actions'] && Array.isArray(catalog.custom['actions'])) {
      return catalog.custom['actions'].map((action: any) => ({
        label: action.label,
        action: action.action,
        variant: action.variant || 'secondary',
        icon: action.icon
      }));
    }
    return [];
  }
}
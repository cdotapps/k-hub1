import { Component, OnInit, OnDestroy, HostListener, Input, OnChanges, SimpleChanges } from '@angular/core';
import { faNewspaper, faFire, faChartLine, faGlobe, faClock, faChevronUp, faChevronDown } from '@fortawesome/free-solid-svg-icons';
import { trigger, state, style, animate, transition } from '@angular/animations';
import { CatalogService } from '../../services/catalog.service';
import { Catalog } from '../../models/user.interface';
import { Subject, takeUntil } from 'rxjs';

export interface NewsHeadline {
  id: string;
  title: string;
  category: 'breaking' | 'technology' | 'business' | 'market' | 'general';
  time: string;
  priority: 'high' | 'medium' | 'low';
  link?: string;
  description?: string;
  author?: string;
}

@Component({
  selector: 'app-news-bar',
  template: `
    <div 
      class="news-bar-wrapper" 
      [@slideInOut]="barState"
      (mouseenter)="pauseAutoHide()"
      (mouseleave)="resumeAutoHide()">
      
      <!-- <div class="toggle-bar" (click)="toggleBarState()">
        <app-icon [faIcon]="barState === 'visible' ? faChevronUp : faChevronDown" size="xs" color="white"></app-icon>
        <span>{{ barState === 'visible' ? 'Hide News' : 'Show News' }}</span>
      </div> -->
      
      <div class="news-bar" *ngIf="barState === 'visible'">
        <div class="news-bar-content">
          <div class="news-label">
            <app-icon [faIcon]="faNewspaper" size="sm" color="white"></app-icon>
            <span>Latest Updates</span>
          </div>
          
          <!-- Loading State -->
          <div class="news-loading" *ngIf="loading">
            <span>Loading news...</span>
          </div>
          
          <!-- Error State -->
          <div class="news-error" *ngIf="error && !loading">
            <span>{{ error }}</span>
            <button class="retry-btn" (click)="loadNews()">Retry</button>
          </div>
          
          <!-- News Ticker -->
          <div class="news-ticker" *ngIf="!loading && !error && headlines.length > 0">
            <div class="news-flip-container">
              <div 
                class="news-item" 
                [class.active]="i === currentIndex"
                [class.priority-high]="headline.priority === 'high'"
                *ngFor="let headline of headlines; let i = index; trackBy: trackByHeadline"
                (click)="openNews(headline)">
                
                <span class="news-category" [ngClass]="'category-' + headline.category">
                  <app-icon [faIcon]="getCategoryIcon(headline.category)" size="xs"></app-icon>
                  {{ getCategoryLabel(headline.category) }}
                </span>
                
                <span class="news-title">{{ headline.title }}</span>
                
                <span class="news-time">
                  <app-icon [faIcon]="faClock" size="xs" color="rgba(255,255,255,0.7)"></app-icon>
                  {{ headline.time }}
                </span>
              </div>
            </div>
            
            <div class="news-indicators" *ngIf="headlines.length > 1">
              <button 
                class="indicator-dot" 
                *ngFor="let headline of headlines; let i = index"
                [class.active]="i === currentIndex"
                (click)="goToNews(i)"
                [title]="headline.title">
              </button>
            </div>
          </div>
          
          <!-- No News Message -->
          <div class="news-empty" *ngIf="!loading && !error && headlines.length === 0">
            <span>No recent news available</span>
          </div>
          
          <div class="news-controls" *ngIf="!loading && !error && headlines.length > 0">
            <!-- <button class="control-btn" (click)="toggleAutoFlip()" [title]="isAutoFlipping ? 'Pause' : 'Play'" *ngIf="headlines.length > 1">
              {{ isAutoFlipping ? '⏸️' : '▶️' }}
            </button> -->
            <!-- <button class="control-btn" (click)="refreshNews()" title="Refresh News">
              🔄
            </button> -->
            <button class="control-btn" (click)="viewAllNews()" title="View All News">
              <app-icon [faIcon]="faGlobe" size="xs" color="white"></app-icon>
            </button>
          </div>
        </div>
      </div>
    </div>
  `,
  styles: [`
    .news-bar-wrapper {
      position: relative;
      z-index: 998;
    }
    
    .toggle-bar {
      cursor: pointer;
      display: flex;
      align-items: center;
      justify-content: center;
      gap: 0.5rem;
      color: white;
      padding: 0.5rem;
      font-size: 0.75rem;
      font-weight: 600;
      box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
      border-bottom-left-radius: 8px;
      border-bottom-right-radius: 8px;
      position: absolute;
      top: 0;
      left: 50%;
      transform: translateX(-50%);
      width: 120px;
      height: 28px;
      text-align: center;
      transition: all 0.3s ease;
      z-index: 1;
    }
    
    .toggle-bar:hover {
      background: var(--fm-primary-blue);
    }
    
    .news-bar {
      background: linear-gradient(135deg, var(--fm-primary-blue) 0%, var(--fm-navy) 100%);
      color: white;
      opacity: 0.95;
      border-bottom: 1px solid rgba(255, 255, 255, 0.1);
      position: relative;
      overflow: hidden;
      box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
    }
    
    .news-bar-content {
      display: flex;
      align-items: center;
      min-height: 56px;
      max-width: 1600px;
      margin: 0 auto;
      padding: 0 2rem;
    }
    
    .news-label {
      display: flex;
      align-items: center;
      gap: 0.5rem;
      font-weight: 600;
      font-size: 0.9rem;
      white-space: nowrap;
      margin-right: 1.5rem;
      padding-right: 1.5rem;
      border-right: 1px solid rgba(255, 255, 255, 0.2);
    }
    
    .news-loading,
    .news-error,
    .news-empty {
      flex: 1;
      display: flex;
      align-items: center;
      gap: 1rem;
      font-size: 0.9rem;
      color: rgba(255, 255, 255, 0.8);
    }
    
    .retry-btn {
      background: rgba(255, 255, 255, 0.2);
      border: 1px solid rgba(255, 255, 255, 0.3);
      color: white;
      padding: 0.3rem 0.6rem;
      border-radius: 4px;
      cursor: pointer;
      font-size: 0.8rem;
      transition: all 0.3s ease;
    }
    
    .retry-btn:hover {
      background: rgba(255, 255, 255, 0.3);
    }
    
    .news-ticker {
      flex: 1;
      display: flex;
      align-items: center;
      gap: 1rem;
      height: 100%;
    }
    
    .news-flip-container {
      flex: 1;
      position: relative;
      height: 40px;
      overflow: hidden;
    }
    
    .news-item {
      position: absolute;
      top: 0;
      left: 0;
      right: 0;
      display: flex;
      align-items: center;
      gap: 1rem;
      height: 100%;
      cursor: pointer;
      padding: 0.5rem 1rem;
      border-radius: 6px;
      transition: all 0.6s cubic-bezier(0.4, 0.0, 0.2, 1);
      border: 1px solid transparent;
      opacity: 0;
      transform: translateY(100%);
    }
    
    .news-item.active {
      opacity: 1;
      transform: translateY(0);
    }
    
    .news-item:hover {
      background: rgba(255, 255, 255, 0.1);
      border-color: rgba(255, 255, 255, 0.2);
    }
    
    .news-item.priority-high {
      background: rgba(239, 68, 68, 0.2);
      border-color: rgba(239, 68, 68, 0.3);
    }
    
    .news-item.priority-high:hover {
      background: rgba(239, 68, 68, 0.3);
    }
    
    .news-category {
      display: flex;
      align-items: center;
      gap: 0.25rem;
      font-size: 0.7rem;
      font-weight: 700;
      text-transform: uppercase;
      letter-spacing: 0.05em;
      padding: 0.2rem 0.5rem;
      border-radius: 12px;
      background: rgba(255, 255, 255, 0.15);
      flex-shrink: 0;
    }
    
    .category-breaking {
      background: rgba(239, 68, 68, 0.8) !important;
      color: white;
    }
    
    .category-technology {
      background: rgba(59, 130, 246, 0.8) !important;
      color: white;
    }
    
    .category-business {
      background: rgba(16, 185, 129, 0.8) !important;
      color: white;
    }
    
    .category-market {
      background: rgba(245, 158, 11, 0.8) !important;
      color: white;
    }
    
    .category-general {
      background: rgba(107, 114, 128, 0.8) !important;
      color: white;
    }
    
    .news-title {
      font-size: 0.9rem;
      font-weight: 500;
      color: white;
      flex: 1;
      white-space: nowrap;
      overflow: hidden;
      text-overflow: ellipsis;
    }
    
    .news-time {
      display: flex;
      align-items: center;
      gap: 0.25rem;
      font-size: 0.75rem;
      color: rgba(255, 255, 255, 0.7);
      font-weight: 500;
      flex-shrink: 0;
    }
    
    .news-indicators {
      display: flex;
      align-items: center;
      gap: 0.4rem;
      margin: 0 1rem;
    }
    
    .indicator-dot {
      width: 8px;
      height: 8px;
      border-radius: 50%;
      border: none;
      background: rgba(255, 255, 255, 0.4);
      cursor: pointer;
      transition: all 0.3s ease;
      padding: 0;
    }
    
    .indicator-dot:hover {
      background: rgba(255, 255, 255, 0.7);
      transform: scale(1.2);
    }
    
    .indicator-dot.active {
      background: white;
      transform: scale(1.3);
    }
    
    .news-controls {
      display: flex;
      align-items: center;
      gap: 0.5rem;
      margin-left: 1.5rem;
      padding-left: 1.5rem;
      border-left: 1px solid rgba(255, 255, 255, 0.2);
    }
    
    .control-btn {
      background: none;
      border: 1px solid rgba(255, 255, 255, 0.3);
      color: white;
      padding: 0.4rem 0.6rem;
      border-radius: 4px;
      cursor: pointer;
      font-size: 0.8rem;
      transition: all 0.3s ease;
      display: flex;
      align-items: center;
      justify-content: center;
      min-width: 32px;
      height: 32px;
    }
    
    .control-btn:hover {
      background: rgba(255, 255, 255, 0.1);
      border-color: rgba(255, 255, 255, 0.5);
      transform: translateY(-1px);
    }
    
    .control-btn:active {
      transform: translateY(0);
    }
    
    /* Mobile responsive */
    @media (max-width: 768px) {
      .news-bar-content {
        padding: 0 1rem;
        min-height: 48px;
      }
      
      .news-label span {
        display: none;
      }
      
      .toggle-bar {
        width: 100px;
        height: 24px;
        font-size: 0.7rem;
      }
      
      .toggle-bar span {
        display: none;
      }
    }
    
    @media (max-width: 480px) {
      .news-bar-content {
        min-height: 44px;
        padding: 0 0.75rem;
      }
      
      .news-flip-container {
        height: 36px;
      }
      
      .news-item {
        gap: 0.5rem;
        padding: 0.3rem 0.6rem;
      }
      
      .news-category {
        font-size: 0.6rem;
      }
      
      .news-title {
        font-size: 0.8rem;
      }
      
      .news-controls {
        gap: 0.25rem;
      }
      
      .control-btn {
        min-width: 24px;
        height: 24px;
        font-size: 0.7rem;
      }
    }
  `],
  animations: [
    trigger('slideInOut', [
      state('visible', style({
        transform: 'translateY(0)',
      })),
      state('hidden', style({
        transform: 'translateY(-100%)',
      })),
      transition('hidden => visible', [
        animate('300ms cubic-bezier(0.4, 0.0, 0.2, 1)')
      ]),
      transition('visible => hidden', [
        animate('300ms cubic-bezier(0.4, 0.0, 0.2, 1)')
      ])
    ])
  ]
})
export class NewsBarComponent implements OnInit, OnDestroy, OnChanges {
  // FontAwesome icons
  faNewspaper = faNewspaper;
  faFire = faFire;
  faChartLine = faChartLine;
  faGlobe = faGlobe;
  faClock = faClock;
  faChevronUp = faChevronUp;
  faChevronDown = faChevronDown;

  headlines: NewsHeadline[] = [];
  loading = false;
  error = '';
  currentIndex = 0;
  isAutoFlipping = true;
  barState: 'visible' | 'hidden' = 'visible';
  
  @Input() forceVisible: boolean = false;

  private destroy$ = new Subject<void>();
  private flipInterval: any;
  private autoHideTimeout: any;
  private readonly flipDelay = 4000; // 4 seconds per news item
  private readonly autoHideDelay = 30000; // 30 seconds before auto-hiding
  private lastRefreshTime = 0;
  private refreshInProgress = false;

  constructor(private catalogService: CatalogService) {}

  @HostListener('window:scroll', [])
  onWindowScroll() {
    // Hide news bar when scrolling down
    if (window.scrollY > 100 && this.barState === 'visible' && !this.forceVisible) {
      this.hideBar();
    }
  }

  ngOnInit(): void {
    this.loadNews();
    
    // Subscribe to catalog refresh events to auto-update news
    this.catalogService.catalogRefresh$
      .pipe(takeUntil(this.destroy$))
      .subscribe(shouldRefresh => {
        if (shouldRefresh && !this.refreshInProgress) {
          // Only refresh if it's been at least 30 seconds since last refresh
          // to avoid too many API calls
          const now = Date.now();
          if (now - this.lastRefreshTime > 30000) {
            this.silentRefresh();
          }
        }
      });
      
    // Set up a polling interval specific to news (every 2 minutes)
    // This is a reasonable interval for news updates
    this.catalogService.startPollingForUpdates(120000); // 2 minutes
  }

  ngOnDestroy(): void {
    this.destroy$.next();
    this.destroy$.complete();
    this.stopAutoFlip();
    this.clearAutoHideTimer();
  }

  ngOnChanges(changes: SimpleChanges): void {
    if (changes['forceVisible'] && changes['forceVisible'].currentValue !== changes['forceVisible'].previousValue) {
      if (this.forceVisible) {
        this.showBar();
        this.refreshNews();
      } else {
        // Only hide if not manually kept open
        if (!this.isManuallyOpen) {
          this.hideBar();
        }
      }
    }
  }

  loadNews(): void {
    this.loading = true;
    this.error = '';
    this.refreshInProgress = true;
    
    this.catalogService.getNews({ page: 1, page_size: 10 })
      .pipe(takeUntil(this.destroy$))
      .subscribe({
        next: (response) => {
          this.headlines = this.transformCatalogToNews(response.items || []);
          this.loading = false;
          this.currentIndex = 0;
          this.lastRefreshTime = Date.now();
          this.refreshInProgress = false;
          
          if (this.headlines.length > 1) {
            this.startAutoFlip();
          }
        },
        error: (error) => {
          this.error = error.message || 'Failed to load news';
          this.loading = false;
          this.refreshInProgress = false;
          console.error('Failed to load news:', error);
        }
      });
  }

  refreshNews(): void {
    this.stopAutoFlip();
    this.loadNews();
  }
  
  /**
   * Silently refresh news without showing loading indicators
   * Used for background auto-refresh
   */
  silentRefresh(): void {
    if (this.refreshInProgress) return;
    
    this.refreshInProgress = true;
    
    this.catalogService.getNews({ page: 1, page_size: 10 })
      .pipe(takeUntil(this.destroy$))
      .subscribe({
        next: (response) => {
          const newHeadlines = this.transformCatalogToNews(response.items || []);
          
          // Only update if there are actually new headlines
          if (this.hasNewHeadlines(newHeadlines)) {
            // Keep current index if possible
            const currentHeadlineId = this.headlines[this.currentIndex]?.id;
            this.headlines = newHeadlines;
            
            // Try to maintain the same headline if it still exists
            if (currentHeadlineId) {
              const newIndex = this.headlines.findIndex(h => h.id === currentHeadlineId);
              if (newIndex >= 0) {
                this.currentIndex = newIndex;
              } else {
                this.currentIndex = 0;
              }
            }
            
            // Show a subtle visual indicator that content was updated
            // This could be enhanced with a more prominent indicator in the UI
            console.log('News silently refreshed with new content');
          }
          
          this.lastRefreshTime = Date.now();
          this.refreshInProgress = false;
        },
        error: (error) => {
          console.error('Silent refresh failed:', error);
          this.refreshInProgress = false;
        }
      });
  }
  
  /**
   * Check if there are new headlines compared to current ones
   */
  private hasNewHeadlines(newHeadlines: NewsHeadline[]): boolean {
    if (newHeadlines.length !== this.headlines.length) return true;
    
    // Check if any IDs are different
    const currentIds = new Set(this.headlines.map(h => h.id));
    return newHeadlines.some(headline => !currentIds.has(headline.id));
  }

  private transformCatalogToNews(catalogItems: Catalog[]): NewsHeadline[] {
    return catalogItems.map(item => ({
      id: item.id,
      title: item.title,
      category: this.determineCategoryFromItem(item),
      time: this.formatTimeAgo(item.created_date || item.created_date),
      priority: this.determinePriority(item),
      link: item.url,
      description: item.description,
      author: item.author
    }));
  }

  private determineCategoryFromItem(item: Catalog): 'breaking' | 'technology' | 'business' | 'market' | 'general' {
    const category = item.category?.toLowerCase() || '';
    const tags = item.tags || [];
    const title = item.title.toLowerCase();
    
    // Check for breaking news indicators
    if (title.includes('breaking') || tags.some(tag => tag.toLowerCase().includes('breaking'))) {
      return 'breaking';
    }
    
    // Check for technology related content
    if (category.includes('tech') || category.includes('ai') || category.includes('digital') ||
        tags.some(tag => ['technology', 'ai', 'digital', 'innovation'].includes(tag.toLowerCase()))) {
      return 'technology';
    }
    
    // Check for business related content
    if (category.includes('business') || category.includes('finance') ||
        tags.some(tag => ['business', 'finance', 'partnership'].includes(tag.toLowerCase()))) {
      return 'business';
    }
    
    // Check for market related content
    if (category.includes('market') || category.includes('investment') ||
        tags.some(tag => ['market', 'investment', 'trading'].includes(tag.toLowerCase()))) {
      return 'market';
    }
    
    return 'general';
  }

  private determinePriority(item: Catalog): 'high' | 'medium' | 'low' {
    const title = item.title.toLowerCase();
    const tags = item.tags || [];
    
    // High priority indicators
    if (title.includes('breaking') || title.includes('urgent') || title.includes('major') ||
        tags.some(tag => ['urgent', 'breaking', 'important'].includes(tag.toLowerCase()))) {
      return 'high';
    }
    
    // Medium priority for recent items or business updates
    const createdTime = new Date(item.created_date || item.created_date || '');
    const hoursAgo = (Date.now() - createdTime.getTime()) / (1000 * 60 * 60);
    
    if (hoursAgo < 2 || title.includes('update') || title.includes('announcement')) {
      return 'medium';
    }
    
    return 'low';
  }

  private formatTimeAgo(dateString?: string): string {
    if (!dateString) return 'Recently';
    
    const date = new Date(dateString);
    const now = new Date();
    const diffInSeconds = Math.floor((now.getTime() - date.getTime()) / 1000);
    
    if (diffInSeconds < 60) return 'Just now';
    if (diffInSeconds < 3600) return `${Math.floor(diffInSeconds / 60)} min ago`;
    if (diffInSeconds < 86400) return `${Math.floor(diffInSeconds / 3600)} hour${Math.floor(diffInSeconds / 3600) > 1 ? 's' : ''} ago`;
    if (diffInSeconds < 604800) return `${Math.floor(diffInSeconds / 86400)} day${Math.floor(diffInSeconds / 86400) > 1 ? 's' : ''} ago`;
    
    return date.toLocaleDateString();
  }

  startAutoFlip(): void {
    if (this.flipInterval) {
      clearInterval(this.flipInterval);
    }

    if (this.headlines.length <= 1) return;

    this.flipInterval = setInterval(() => {
      if (this.isAutoFlipping) {
        this.nextNews();
      }
    }, this.flipDelay);
  }

  stopAutoFlip(): void {
    if (this.flipInterval) {
      clearInterval(this.flipInterval);
      this.flipInterval = null;
    }
  }

  startAutoHideTimer(): void {
    this.clearAutoHideTimer();
    this.autoHideTimeout = setTimeout(() => {
      this.hideBar();
    }, this.autoHideDelay);
  }

  clearAutoHideTimer(): void {
    if (this.autoHideTimeout) {
      clearTimeout(this.autoHideTimeout);
      this.autoHideTimeout = null;
    }
  }

  pauseAutoHide(): void {
    this.clearAutoHideTimer();
  }

  resumeAutoHide(): void {
    if (this.barState === 'visible' && !this.forceVisible) {
      this.startAutoHideTimer();
    }
  }

  private isManuallyOpen = false;

  showBar(): void {
    this.barState = 'visible';
    this.clearAutoHideTimer();
    // Always start auto-hide timer when bar becomes visible (unless forced)
    if (!this.forceVisible) {
      this.startAutoHideTimer();
    }
  }

  hideBar(): void {
    if (this.forceVisible) return; // Don't hide if forced visible
    this.barState = 'hidden';
    this.clearAutoHideTimer();
    this.isManuallyOpen = false;
  }

  toggleBarState(): void {
    if (this.barState === 'visible') {
      this.isManuallyOpen = false;
      this.hideBar();
    } else {
      this.isManuallyOpen = true;
      this.showBar();
      // Start auto-hide timer even for manual toggle
      this.startAutoHideTimer();
    }
  }

  toggleAutoFlip(): void {
    this.isAutoFlipping = !this.isAutoFlipping;
    if (this.isAutoFlipping) {
      this.startAutoFlip();
    } else {
      this.stopAutoFlip();
    }
  }

  nextNews(): void {
    this.currentIndex = (this.currentIndex + 1) % this.headlines.length;
  }

  previousNews(): void {
    this.currentIndex = this.currentIndex === 0 ? this.headlines.length - 1 : this.currentIndex - 1;
  }

  goToNews(index: number): void {
    this.currentIndex = index;
    // Restart auto-flip timer when manually navigating
    if (this.isAutoFlipping) {
      this.startAutoFlip();
    }
  }

  openNews(headline: NewsHeadline): void {
    console.log('Opening news:', headline.title);
    // In a real app, you would navigate to the news article
    if (headline.link) {
      window.open(headline.link, '_blank');
    }
  }

  viewAllNews(): void {
    console.log('Navigate to all news page');
    // In a real app, you would navigate to a news page
    // this.router.navigate(['/news']);
  }

  getCategoryIcon(category: string) {
    switch (category) {
      case 'breaking': return this.faFire;
      case 'technology': return this.faChartLine;
      case 'business': return this.faGlobe;
      case 'market': return this.faGlobe;
      default: return this.faNewspaper;
    }
  }

  getCategoryLabel(category: string): string {
    switch (category) {
      case 'breaking': return 'Breaking';
      case 'technology': return 'Tech';
      case 'business': return 'Business';
      case 'market': return 'Market';
      case 'general': return 'News';
      default: return 'News';
    }
  }

  trackByHeadline(index: number, headline: NewsHeadline): number {
    return headline.id ? parseInt(headline.id) : index;
  }
}
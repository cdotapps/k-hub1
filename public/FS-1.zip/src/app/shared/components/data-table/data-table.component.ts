import { Component, Input, Output, EventEmitter, OnInit, OnChanges } from '@angular/core';
import { 
  faSort, faSortUp, faSortDown, faChevronDown, faSpinner, faInbox, faChevronLeft, faChevronRight 
} from '@fortawesome/free-solid-svg-icons';

export interface DataTableColumn {
  key: string;
  label: string;
  type?: 'text' | 'badge' | 'actions' | 'date' | 'icon' | 'custom';
  sortable?: boolean;
  width?: string;
  align?: 'left' | 'center' | 'right';
  render?: (value: any, row: any) => string;
  // Data mapping properties
  sourceKey?: string; // Key from raw data to map to this column
  transform?: (value: any, rawRow: any) => any; // Transform function for mapping
}

export interface DataTableAction {
  label: string;
  icon?: any;
  variant?: 'primary' | 'secondary' | 'success' | 'warning' | 'danger' | 'muted';
  action: string;
  disabled?: (row: any) => boolean;
  visible?: (row: any) => boolean;
}

export interface DataTableBadge {
  text: string;
  variant: 'primary' | 'secondary' | 'success' | 'warning' | 'danger' | 'muted' | 'light' | 'dark';
  icon?: any;
}

// New interface for data mapping configuration
export interface DataMapping {
  [displayKey: string]: {
    sourceKey: string;
    transform?: (value: any, rawRow: any) => any;
  };
}

@Component({
  selector: 'app-data-table',
  template: `
    <div class="data-table-container" [class.loading]="loading">
      <!-- Loading State -->
      <div *ngIf="loading" class="loading-overlay">
        <div class="loading-content">
          <app-icon [faIcon]="loadingIcon" class="loading-spinner"></app-icon>
          <span>{{ loadingText }}</span>
        </div>
      </div>

      <!-- Div Table with catalog-style layout -->
      <div class="divTable paleBlueRows">
        <!-- Header -->
        <div class="divTableHeading">
          <div class="divTableRow">
            <div *ngIf="selectable" class="divTableHead select-column">
              <input 
                type="checkbox" 
                [checked]="isAllSelected()" 
                [indeterminate]="isSomeSelected()"
                (change)="toggleSelectAll()"
                class="select-all-checkbox">
            </div>
            <div *ngFor="let column of columns" 
              class="divTableHead"
              [style.width]="column.width"
              [class.sortable]="column.sortable"
              [class.sorted]="sortColumn === column.key"
              [class.sort-asc]="sortColumn === column.key && sortDirection === 'asc'"
              [class.sort-desc]="sortColumn === column.key && sortDirection === 'desc'"
              [style.text-align]="column.align || 'left'"
              (click)="onSort(column)">
              <div class="header-content">
                <span class="header-label">{{ column.label }}</span>
                <app-icon *ngIf="column.sortable" 
                  [faIcon]="getSortIcon(column.key)" 
                  class="sort-icon" 
                  size="sm"></app-icon>
              </div>
            </div>
          </div>
        </div>

        <!-- Body -->
        <div class="divTableBody">
          <div *ngFor="let row of data; trackBy: trackByFn; let i = index" 
            class="divTableRow data-row"
            [class.selected]="isRowSelected(row)"
            [class.clickable]="rowClickable"
            (click)="onRowClick(row, i)">
            
            <!-- Selection Column -->
            <div *ngIf="selectable" class="divTableCell select-column">
              <input 
                type="checkbox" 
                [checked]="isRowSelected(row)"
                (change)="toggleRowSelection(row, $event)"
                (click)="$event.stopPropagation()"
                class="row-checkbox">
            </div>

            <!-- Data Columns -->
            <div *ngFor="let column of columns" 
              class="divTableCell"
              [style.text-align]="column.align || 'left'"
              [class]="'column-' + column.type">
              
              <!-- Text Column -->
              <span *ngIf="column.type === 'text' || !column.type" class="cell-text">
                {{ getCellValue(row, column) }}
              </span>

              <!-- Badge Column -->
              <span *ngIf="column.type === 'badge'" 
                class="cell-badge badge"
                [ngClass]="'badge-' + getBadgeVariant(row, column)">
                <app-icon *ngIf="getBadgeIcon(row, column)" 
                  [faIcon]="getBadgeIcon(row, column)" 
                  size="xs"></app-icon>
                {{ getBadgeText(row, column) }}
              </span>

              <!-- Date Column -->
              <span *ngIf="column.type === 'date'" class="cell-date">
                {{ formatDate(getCellValue(row, column)) }}
              </span>

              <!-- Icon Column -->
              <span *ngIf="column.type === 'icon'" class="cell-icon">
                <app-icon [faIcon]="getCellValue(row, column)" size="sm"></app-icon>
              </span>

              <!-- Actions Column -->
              <div *ngIf="column.type === 'actions'" class="cell-actions">
                <button *ngFor="let action of getRowActions(row)"
                  type="button"
                  class="action-btn"
                  [ngClass]="'btn-' + (action.variant || 'secondary')"
                  [disabled]="isActionDisabled(action, row)"
                  [title]="action.label"
                  (click)="onActionClick(action, row, $event)">
                  <app-icon *ngIf="action.icon" [faIcon]="action.icon" size="sm"></app-icon>
                </button>
              </div>

              <!-- Custom Column -->
              <div *ngIf="column.type === 'custom'" class="cell-custom">
                <ng-container [ngSwitch]="column.key">
                  <ng-content 
                    select="[slot='custom-cell']" 
                    *ngSwitchDefault>
                  </ng-content>
                </ng-container>
              </div>
            </div>
          </div>

          <!-- Empty State Row -->
          <div *ngIf="!loading && (!data || data.length === 0)" class="divTableRow empty-row">
            <div [style.grid-column]="'1 / -1'" class="divTableCell empty-cell">
              <div class="empty-state">
                <app-icon [faIcon]="emptyIcon" class="empty-icon" size="xl"></app-icon>
                <h4 class="empty-title">{{ emptyTitle }}</h4>
                <p class="empty-message">{{ emptyMessage }}</p>
                <button *ngIf="emptyActionLabel" 
                  type="button" 
                  class="empty-action-btn"
                  (click)="onEmptyAction()">
                  {{ emptyActionLabel }}
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>

      <!-- Simple Item Count (outside the div table) -->
      <div *ngIf="showRowCount && data && data.length > 0" class="item-count-container">
        <span class="item-count">
          Showing {{ getStartIndex() + 1 }}-{{ getEndIndex() }} of {{ totalRows || data.length || 0 }} items
        </span>
      </div>
    </div>
  `,
  styleUrls: ['./data-table.component.css']
})
export class DataTableComponent implements OnInit, OnChanges {
  @Input() data: any[] = [];
  @Input() rawData: any[] = []; // New: Raw data input
  @Input() dataMapping?: DataMapping; // New: Data mapping configuration
  @Input() columns: DataTableColumn[] = [];
  @Input() actions: DataTableAction[] = [];
  
  // Appearance
  @Input() striped = true;
  @Input() bordered = true;
  @Input() hover = true;
  @Input() selectable = false;
  @Input() rowClickable = true;
  
  // Loading
  @Input() loading = false;
  @Input() loadingText = 'Loading...';
  @Input() loadingIcon: any;
  
  // Sorting
  @Input() sortColumn = '';
  @Input() sortDirection: 'asc' | 'desc' = 'asc';
  
  // Pagination
  @Input() pagination = false;
  @Input() currentPage = 1;
  @Input() totalPages = 1;
  @Input() totalRows?: number;
  @Input() itemsPerPage = 25;

  // Footer
  @Input() showFooter = true;
  @Input() showRowCount = true;
  @Input() showItemsPerPage = true;
  
  // Empty State
  @Input() emptyTitle = 'No data available';
  @Input() emptyMessage = 'There are no items to display.';
  @Input() emptyActionLabel = '';
  @Input() emptyIcon: any;
  
  // Selection
  @Input() selectedRows: any[] = [];
  @Input() selectionKey = 'id';
  
  // Track by function
  @Input() trackByFn = (index: number, item: any) => item.id || index;
  
  // Events
  @Output() rowClick = new EventEmitter<{row: any, index: number}>();
  @Output() actionClick = new EventEmitter<{action: DataTableAction, row: any}>();
  @Output() sort = new EventEmitter<{column: string, direction: 'asc' | 'desc'}>();
  @Output() pageChange = new EventEmitter<number>();
  @Output() itemsPerPageChange = new EventEmitter<number>();
  @Output() selectionChange = new EventEmitter<any[]>();
  @Output() emptyAction = new EventEmitter<void>();

  // Icons
  faChevronLeft = faChevronLeft;
  faChevronRight = faChevronRight;

  // Math functions for template
  Math = Math;

  ngOnInit(): void {
    // Set default icons if not provided
    if (!this.loadingIcon) {
      this.loadingIcon = 'faSpinner'; // You'll need to import this
    }
    if (!this.emptyIcon) {
      this.emptyIcon = 'faInbox'; // You'll need to import this
    }

    // Process data mapping on initialization
    this.processDataMapping();
  }

  ngOnChanges(): void {
    // Re-process data mapping when inputs change
    this.processDataMapping();
  }

  /**
   * Process raw data with mapping configuration
   * If no dataMapping is provided, data equals rawData
   */
  private processDataMapping(): void {
    if (!this.rawData || this.rawData.length === 0) {
      // If no raw data, keep existing data as is
      return;
    }

    if (!this.dataMapping) {
      // No mapping provided, use raw data directly
      this.data = this.rawData;
      return;
    }

    // Apply data mapping transformation
    this.data = this.rawData.map(rawRow => {
      const mappedRow: any = {};
      
      // Apply mapping for each configured key
      Object.entries(this.dataMapping!).forEach(([displayKey, mapping]) => {
        const sourceValue = this.getNestedValue(rawRow, mapping.sourceKey);
        
        if (mapping.transform) {
          mappedRow[displayKey] = mapping.transform(sourceValue, rawRow);
        } else {
          mappedRow[displayKey] = sourceValue;
        }
      });

      // Also apply column-level mapping if defined
      this.columns.forEach(column => {
        if (column.sourceKey && !mappedRow.hasOwnProperty(column.key)) {
          const sourceValue = this.getNestedValue(rawRow, column.sourceKey);
          
          if (column.transform) {
            mappedRow[column.key] = column.transform(sourceValue, rawRow);
          } else {
            mappedRow[column.key] = sourceValue;
          }
        }
      });

      // Include any unmapped properties for backward compatibility
      Object.keys(rawRow).forEach(key => {
        if (!mappedRow.hasOwnProperty(key)) {
          mappedRow[key] = rawRow[key];
        }
      });

      return mappedRow;
    });
  }

  /**
   * Get nested value from object using dot notation
   */
  private getNestedValue(obj: any, path: string): any {
    return path.split('.').reduce((current, key) => current?.[key], obj);
  }

  getCellValue(row: any, column: DataTableColumn): any {
    const keys = column.key.split('.');
    let value = row;
    
    for (const key of keys) {
      value = value?.[key];
    }
    
    if (column.render) {
      return column.render(value, row);
    }
    
    return value;
  }

  getBadgeVariant(row: any, column: DataTableColumn): string {
    const value = this.getCellValue(row, column);
    if (typeof value === 'object' && value.variant) {
      return value.variant;
    }
    return 'secondary';
  }

  getBadgeText(row: any, column: DataTableColumn): string {
    const value = this.getCellValue(row, column);
    if (typeof value === 'object' && value.text) {
      return value.text;
    }
    return value;
  }

  getBadgeIcon(row: any, column: DataTableColumn): any {
    const value = this.getCellValue(row, column);
    if (typeof value === 'object' && value.icon) {
      return value.icon;
    }
    return null;
  }

  formatDate(value: any): string {
    if (!value) return '';
    
    const date = new Date(value);
    if (isNaN(date.getTime())) return value;
    
    const now = new Date();
    const diffInMs = now.getTime() - date.getTime();
    const diffInMinutes = Math.floor(diffInMs / (1000 * 60));
    const diffInHours = Math.floor(diffInMinutes / 60);
    const diffInDays = Math.floor(diffInHours / 24);

    if (diffInMinutes < 1) {
      return 'Just now';
    } else if (diffInMinutes < 60) {
      return `${diffInMinutes}m ago`;
    } else if (diffInHours < 24) {
      return `${diffInHours}h ago`;
    } else if (diffInDays < 7) {
      return `${diffInDays}d ago`;
    } else {
      return date.toLocaleDateString();
    }
  }

  onSort(column: DataTableColumn): void {
    if (!column.sortable) return;
    
    let direction: 'asc' | 'desc' = 'asc';
    
    if (this.sortColumn === column.key) {
      direction = this.sortDirection === 'asc' ? 'desc' : 'asc';
    }
    
    this.sortColumn = column.key;
    this.sortDirection = direction;
    
    this.sort.emit({ column: column.key, direction });
  }

  getSortIcon(columnKey: string): any {
    if (this.sortColumn !== columnKey) {
      return faSort;
    }
    return this.sortDirection === 'asc' ? faSortUp : faSortDown;
  }

  onRowClick(row: any, index: number): void {
    if (this.rowClickable) {
      this.rowClick.emit({ row, index });
    }
  }

  onActionClick(action: DataTableAction, row: any, event: Event): void {
    event.stopPropagation();
    this.actionClick.emit({ action, row });
  }

  getRowActions(row: any): DataTableAction[] {
    return this.actions.filter(action => {
      if (action.visible) {
        return action.visible(row);
      }
      return true;
    });
  }

  isActionDisabled(action: DataTableAction, row: any): boolean {
    if (action.disabled) {
      return action.disabled(row);
    }
    return false;
  }

  isRowSelected(row: any): boolean {
    const id = row[this.selectionKey];
    return this.selectedRows.some(selectedRow => selectedRow[this.selectionKey] === id);
  }

  isAllSelected(): boolean {
    return this.data.length > 0 && this.data.every(row => this.isRowSelected(row));
  }

  isSomeSelected(): boolean {
    return this.selectedRows.length > 0 && !this.isAllSelected();
  }

  toggleSelectAll(): void {
    if (this.isAllSelected()) {
      this.clearSelection();
    } else {
      this.selectAll();
    }
  }

  selectAll(): void {
    this.selectedRows = [...this.data];
    this.selectionChange.emit(this.selectedRows);
  }

  clearSelection(): void {
    this.selectedRows = [];
    this.selectionChange.emit(this.selectedRows);
  }

  onPageChange(page: number): void {
    this.currentPage = page;
    this.pageChange.emit(page);
  }

  // Enhanced Pagination methods
  getPageNumbers(): (number | string)[] {
    const pages: (number | string)[] = [];
    const totalPages = this.totalPages;
    const currentPage = this.currentPage;

    if (totalPages <= 7) {
      // Show all pages if 7 or fewer
      for (let i = 1; i <= totalPages; i++) {
        pages.push(i);
      }
    } else {
      // Always show first page
      pages.push(1);
      
      if (currentPage > 4) {
        pages.push('...');
      }

      // Show pages around current page
      const startPage = Math.max(2, currentPage - 1);
      const endPage = Math.min(totalPages - 1, currentPage + 1);

      for (let i = startPage; i <= endPage; i++) {
        pages.push(i);
      }

      if (currentPage < totalPages - 3) {
        pages.push('...');
      }

      // Always show last page
      if (totalPages > 1) {
        pages.push(totalPages);
      }
    }

    return pages;
  }

  goToPage(page: number | string): void {
    if (typeof page === 'number' && page >= 1 && page <= this.totalPages) {
      this.onPageChange(page);
    }
  }

  getStartIndex(): number {
    return (this.currentPage - 1) * this.itemsPerPage;
  }

  getEndIndex(): number {
    return Math.min(this.getStartIndex() + this.itemsPerPage, this.totalRows || this.data.length);
  }

  onItemsPerPageChange(event: Event): void {
    const target = event.target as HTMLSelectElement;
    const newItemsPerPage = parseInt(target.value, 10);
    this.itemsPerPage = newItemsPerPage;
    this.itemsPerPageChange.emit(newItemsPerPage);
  }

  toggleRowSelection(row: any, event: Event): void {
    event.stopPropagation();
    
    const rowId = row[this.selectionKey];
    const isSelected = this.isRowSelected(row);
    
    if (isSelected) {
      this.selectedRows = this.selectedRows.filter(selected => 
        selected[this.selectionKey] !== rowId
      );
    } else {
      this.selectedRows = [...this.selectedRows, row];
    }
    
    this.selectionChange.emit(this.selectedRows);
  }

  getDisplayedRowCount(): number {
    return this.data?.length || 0;
  }

  getColumnCount(): number {
    let count = this.columns.length;
    if (this.selectable) count++;
    return count;
  }

  onEmptyAction(): void {
    this.emptyAction.emit();
  }
}
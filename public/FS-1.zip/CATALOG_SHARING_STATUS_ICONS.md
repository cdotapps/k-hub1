# Catalog Card Sharing Status Icons

## Overview
The catalog cards now display small visual indicators in the bottom left corner to show the ownership and sharing status of each catalog item. This provides users with immediate visual feedback about their relationship to each item.

## Icon Types

### 👑 Owner (Crown Icon)
- **When shown**: When the current user owns the catalog item but hasn't shared it with anyone
- **Color**: Green background with green crown icon
- **Tooltip**: "You own this item"
- **Meaning**: The user is the original creator/owner of this content

### 👥 Shared by Me (Users Icon)
- **When shown**: When the current user owns the catalog item AND has shared it with other users
- **Color**: Blue background with blue users icon
- **Tooltip**: "Shared with X user(s)" (where X is the number of users)
- **Meaning**: The user owns this content and has shared it with others

### 👫 Shared with Me (User Friends Icon)
- **When shown**: When the catalog item was shared with the current user by someone else
- **Color**: Secondary blue background with secondary blue user-friends icon
- **Tooltip**: "Shared with you"
- **Meaning**: Another user shared this content with the current user

## Technical Implementation

### Component Changes

#### CatalogCardComponent (`/src/app/shared/components/card/catalog-card.component.ts`)
- Added `@Input() currentUserId?: string` to pass the current user's ID
- Added new FontAwesome icons: `faCrown`, `faUsers`, `faUserFriends`
- Added sharing status detection methods:
  - `getSharingStatus()`: Determines the sharing status based on ownership and shared_with data
  - `getSharingStatusIcon()`: Returns the appropriate icon for the status
  - `getSharingStatusTooltip()`: Provides descriptive tooltip text
  - `getSharingStatusClass()`: Returns CSS class for styling

#### Template Changes (`/src/app/shared/components/card/catalog-card.component.html`)
```html
<!-- Sharing Status Icon (Bottom Left) -->
<div class="sharing-status-icon" 
     *ngIf="getSharingStatus()" 
     [class]="getSharingStatusClass()"
     [title]="getSharingStatusTooltip()">
  <app-icon [faIcon]="getSharingStatusIcon()" size="xs"></app-icon>
</div>
```

#### Styling (`/src/app/shared/components/card/catalog-card.component.css`)
- Added `.sharing-status-icon` styles for positioning and base appearance
- Added color-coded styles for each status type:
  - `.sharing-status-owner` (green)
  - `.sharing-status-shared-by-me` (primary blue)
  - `.sharing-status-shared-with-me` (secondary blue)
- Added hover effects for better interactivity

#### Parent Component Integration
Updated both grid and list views in `/src/app/user/catalog/catalog.component.html` to pass `currentUserId`:
```html
[currentUserId]="currentUser?.id"
```

## Visual Design

### Icon Placement
- **Position**: Absolute positioning at bottom left of card
- **Size**: 1.5rem x 1.5rem circular container
- **Icon Size**: Extra small (xs) FontAwesome icons
- **Z-index**: Above card content but below overlays

### Styling Features
- **Background**: White with colored border and background tint
- **Shadow**: Subtle drop shadow for depth
- **Hover Effect**: Scales to 110% with enhanced shadow
- **Responsive**: Maintains position across different card sizes

### Color Scheme
- **Owner**: Green theme using CSS variables (`--fm-success`, `--fm-success-lighter`)
- **Shared by Me**: Primary blue theme (`--fm-primary-blue`, `--fm-primary-lighter`)
- **Shared with Me**: Secondary blue theme (`--fm-secondary-blue`, `--fm-secondary-lighter`)

## Data Requirements

### Catalog Interface
The feature relies on the existing `Catalog` interface properties:
- `author_id`: To determine ownership
- `shared_with`: Array of SharedUser objects or user IDs to determine sharing status

### SharedUser Interface
```typescript
interface SharedUser {
  id: string;
  name: string;
  shared_date: string;
  access: 'read' | 'write' | 'admin';
}
```

## Logic Flow

1. **Ownership Check**: Compare `currentUserId` with `item.author_id` (via `isOwner` input)
2. **Sharing Status Determination**:
   - If owner + has shared_with entries → "shared-by-me"
   - If owner + no shared_with entries → "owner"
   - If not owner + user in shared_with → "shared-with-me"
   - Otherwise → no icon shown
3. **Icon Selection**: Based on status, select appropriate FontAwesome icon
4. **Styling**: Apply status-specific CSS classes for color theming

## Benefits

### User Experience
- **Quick Recognition**: Users can instantly see their relationship to content
- **Visual Hierarchy**: Helps organize content by ownership/access type
- **Status Awareness**: Clear indication of sharing state without opening items

### Information Architecture
- **Ownership Clarity**: Distinguishes between owned and shared content
- **Sharing Feedback**: Shows when content has been successfully shared
- **Access Visualization**: Makes permission levels immediately apparent

## Future Enhancements

### Potential Additions
1. **Access Level Indicators**: Different icons for read/write/admin access
2. **Animation**: Subtle animations when sharing status changes
3. **Badge Numbers**: Show exact count of users for "shared-by-me" items
4. **Customizable Icons**: Allow users to choose preferred icon sets
5. **Keyboard Navigation**: Add keyboard support for icon tooltips

### Technical Improvements
1. **Performance**: Memoize sharing status calculations
2. **Accessibility**: Add ARIA labels for screen readers
3. **Testing**: Add unit tests for sharing status logic
4. **Configuration**: Make icon display configurable per user preferences

---

**Status**: ✅ IMPLEMENTED
**Version**: 1.0
**Last Updated**: June 16, 2025

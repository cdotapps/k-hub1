import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { CatalogDetailComponent } from './catalog-detail.component';

@NgModule({
  declarations: [
    CatalogDetailComponent,
    // ...existing declarations...
  ],
  imports: [
    CommonModule,
    FormsModule,
    // ...existing imports...
  ],
  // ...existing code...
})
export class YourModuleName { }
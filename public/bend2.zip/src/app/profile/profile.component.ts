import { Component, OnInit, OnDestroy } from '@angular/core';
import { FormBuilder, FormGroup, Validators, AbstractControl } from '@angular/forms';
import { AuthService } from '../shared/services/auth.service';
import { UserService } from '../shared/services/user.service';
import { User, UserDesignation } from '../shared/models/user.interface';
import { Subscription } from 'rxjs';
import { 
  faUser, faEnvelope, faBuilding, faIdCard, faCalendarAlt, 
  faEdit, faSave, faTimes, faUserCircle, faShieldAlt, 
  faCheckCircle, faExclamationTriangle, faSpinner, faChartLine, 
  faGlobe, faKey, faClock, faInfoCircle
} from '@fortawesome/free-solid-svg-icons';

@Component({
  selector: 'app-profile',
  templateUrl: './profile.component.html',
  styleUrls: ['./profile.component.css']
})
export class ProfileComponent implements OnInit, OnDestroy {
  currentUser: User | null = null;
  profileForm: FormGroup;
  passwordForm: FormGroup;
  isEditing = false;
  isLoading = false;
  isChangingPassword = false;
  showPasswordModal = false;
  successMessage = '';
  errorMessage = '';
  private originalFormValues: any = {};
  
  // Designation options
  designationOptions = Object.values(UserDesignation);
  
  // Breadcrumb items
  breadcrumbItems = [
    { label: 'Profile', url: '/profile', active: true }
  ];
  
  // Font Awesome icons
  faUser = faUser;
  faEnvelope = faEnvelope;
  faBuilding = faBuilding;
  faIdCard = faIdCard;
  faCalendarAlt = faCalendarAlt;
  faEdit = faEdit;
  faSave = faSave;
  faTimes = faTimes;
  faUserCircle = faUserCircle;
  faShieldAlt = faShieldAlt;
  faCheckCircle = faCheckCircle;
  faExclamationTriangle = faExclamationTriangle;
  faSpinner = faSpinner;
  faChartLine = faChartLine;
  faGlobe = faGlobe;
  faKey = faKey;
  faClock = faClock;
  faInfoCircle = faInfoCircle;

  private subscription = new Subscription();

  constructor(
    private authService: AuthService,
    private userService: UserService,
    private formBuilder: FormBuilder
  ) {
    // Remove designation from the form since it's read-only organizational data
    this.profileForm = this.formBuilder.group({
      first_name: ['', [Validators.required, Validators.minLength(2)]],
      last_name: ['', [Validators.required, Validators.minLength(2)]],
      email: ['', [Validators.email]]
    });

    this.passwordForm = this.formBuilder.group({
      current_password: ['', [Validators.required]],
      new_password: ['', [Validators.required, Validators.minLength(6)]],
      confirm_password: ['', [Validators.required]]
    }, { validators: this.passwordMatchValidator });
  }

  ngOnInit(): void {
    this.loadUserProfile();
    // Also refresh profile from server to ensure we have complete data
    this.refreshUserProfile();
  }

  ngOnDestroy(): void {
    this.subscription.unsubscribe();
  }

  loadUserProfile(): void {
    this.subscription.add(
      this.authService.currentUser$.subscribe((user: User | null) => {
        if (user) {
          console.log('Profile Component - User data received:', user);
          console.log('Organization fields:', {
            manager_id: user.manager_id,
            user_type: user.user_type,
            portfolio_id: user.portfolio_id,
            organization_id: user.organization_id,
            costcenter_id: user.costcenter_id
          });
          this.currentUser = user;
          this.populateForm(user);
        }
      })
    );
  }

  populateForm(user: User): void {
    // Only populate form fields that exist in the form (no organization fields)
    const formValues = {
      first_name: user.first_name || '',
      last_name: user.last_name || '',
      email: user.email || ''
    };
    
    this.profileForm.patchValue(formValues);
    this.originalFormValues = { ...formValues };
  }

  toggleEditMode(): void {
    if (this.isEditing) {
      this.cancelEditing();
    } else {
      this.startEditing();
    }
  }

  startEditing(): void {
    this.isEditing = true;
    this.clearMessages();
  }

  cancelEditing(): void {
    this.isEditing = false;
    if (this.currentUser) {
      this.populateForm(this.currentUser);
    }
    this.clearMessages();
  }

  saveProfile(): void {
    if (this.profileForm.invalid || !this.currentUser) {
      this.markFormGroupTouched(this.profileForm);
      return;
    }

    this.isLoading = true;
    this.clearMessages();

    this.subscription.add(
      this.userService.updateCurrentUserProfile(this.profileForm.value).subscribe({
        next: (updatedUser: User) => {
          this.currentUser = updatedUser;
          this.isEditing = false;
          this.isLoading = false;
          this.successMessage = 'Profile updated successfully!';
          
          // Update the current user in auth service directly (no API call)
          this.authService.setCurrentUser(updatedUser);
          
          // Auto-hide success message after 5 seconds
          setTimeout(() => {
            this.successMessage = '';
          }, 5000);
        },
        error: (error: any) => {
          console.error('Profile update error:', error);
          this.isLoading = false;
          this.errorMessage = error.message || 'Failed to update profile. Please try again.';
        }
      })
    );
  }

  // Password change functionality
  changePassword(): void {
    if (this.passwordForm.invalid) {
      this.markFormGroupTouched(this.passwordForm);
      return;
    }

    this.isChangingPassword = true;
    this.clearMessages();

    const { current_password, new_password } = this.passwordForm.value;

    this.subscription.add(
      this.userService.changePassword(current_password, new_password).subscribe({
        next: () => {
          this.isChangingPassword = false;
          this.showPasswordModal = false;
          this.passwordForm.reset();
          this.successMessage = 'Password changed successfully!';
          
          // Auto-hide success message after 5 seconds
          setTimeout(() => {
            this.successMessage = '';
          }, 5000);
        },
        error: (error: any) => {
          console.error('Password change error:', error);
          this.isChangingPassword = false;
          this.errorMessage = error.message || 'Failed to change password. Please try again.';
        }
      })
    );
  }

  closePasswordModal(): void {
    this.showPasswordModal = false;
    this.passwordForm.reset();
    this.clearMessages();
  }

  // Custom validator for password confirmation
  passwordMatchValidator(control: AbstractControl): { [key: string]: boolean } | null {
    const newPassword = control.get('new_password');
    const confirmPassword = control.get('confirm_password');
    
    if (!newPassword || !confirmPassword) {
      return null;
    }
    
    return newPassword.value !== confirmPassword.value ? { 'passwordMismatch': true } : null;
  }

  private markFormGroupTouched(formGroup: FormGroup): void {
    Object.keys(formGroup.controls).forEach(key => {
      const control = formGroup.get(key);
      control?.markAsTouched();
    });
  }

  private clearMessages(): void {
    this.successMessage = '';
    this.errorMessage = '';
  }

  // Check if form has changes
  hasFormChanges(): boolean {
    if (!this.originalFormValues) return false;
    
    const currentValues = this.profileForm.value;
    return Object.keys(this.originalFormValues).some(key => 
      this.originalFormValues[key] !== currentValues[key]
    );
  }

  // Check if save button should be enabled
  isSaveButtonEnabled(): boolean {
    return !this.isLoading && 
           this.profileForm.valid && 
           this.hasFormChanges();
  }

  // Form validation helpers
  hasFieldError(fieldName: string): boolean {
    const field = this.profileForm.get(fieldName);
    return !!(field && field.invalid && field.touched);
  }

  getFieldError(fieldName: string): string {
    const field = this.profileForm.get(fieldName);
    if (field?.errors && field.touched) {
      if (field.errors['required']) return `${this.getFieldDisplayName(fieldName)} is required`;
      if (field.errors['email']) return 'Please enter a valid email address';
      if (field.errors['minlength']) return `${this.getFieldDisplayName(fieldName)} must be at least ${field.errors['minlength'].requiredLength} characters`;
    }
    return '';
  }

  hasPasswordFieldError(fieldName: string): boolean {
    const field = this.passwordForm.get(fieldName);
    const formErrors = this.passwordForm.errors;
    
    if (fieldName === 'confirm_password' && formErrors?.['passwordMismatch'] && field?.touched) {
      return true;
    }
    
    return !!(field && field.invalid && field.touched);
  }

  getPasswordFieldError(fieldName: string): string {
    const field = this.passwordForm.get(fieldName);
    const formErrors = this.passwordForm.errors;
    
    if (fieldName === 'confirm_password' && formErrors?.['passwordMismatch'] && field?.touched) {
      return 'Passwords do not match';
    }
    
    if (field?.errors && field.touched) {
      if (field.errors['required']) return `${this.getFieldDisplayName(fieldName)} is required`;
      if (field.errors['minlength']) return `Password must be at least ${field.errors['minlength'].requiredLength} characters`;
    }
    return '';
  }

  private getFieldDisplayName(fieldName: string): string {
    const displayNames: { [key: string]: string } = {
      'first_name': 'First name',
      'last_name': 'Last name',
      'email': 'Email',
      'current_password': 'Current password',
      'new_password': 'New password',
      'confirm_password': 'Confirm password'
    };
    return displayNames[fieldName] || fieldName.replace('_', ' ');
  }

  // User display helpers
  getUserDisplayName(): string {
    if (this.currentUser?.first_name && this.currentUser?.last_name) {
      return `${this.currentUser.first_name} ${this.currentUser.last_name}`;
    }
    return this.currentUser?.user_id || 'User';
  }

  getManagerDisplayValue(): string {
    if (this.currentUser?.manager && this.currentUser.manager.first_name && this.currentUser.manager.last_name) {
      return `${this.currentUser.manager.first_name} ${this.currentUser.manager.last_name}`;
    }
    if (this.currentUser?.manager?.user_id) {
      return this.currentUser.manager.user_id;
    }
    if (this.currentUser?.manager_id) {
      return this.currentUser.manager_id;
    }
    return 'Not assigned';
  }

  getRoleDisplayName(): string {
    const role = this.currentUser?.role;
    if (this.currentUser?.is_superuser) return 'Super Admin';
    switch (role) {
      case 'admin': return 'Administrator';
      case 'user': return 'User';
      default: return 'User';
    }
  }

  getAccountStatus(): string {
    if (this.currentUser?.is_active === false) return 'Inactive';
    if (this.currentUser?.email_verified === false) return 'Unverified';
    return 'Active';
  }

  formatDate(dateString: string | undefined): string {
    if (!dateString) return 'Not available';
    try {
      return new Date(dateString).toLocaleDateString('en-US', {
        year: 'numeric',
        month: 'long',
        day: 'numeric',
        hour: '2-digit',
        minute: '2-digit'
      });
    } catch (error) {
      return 'Invalid date';
    }
  }

  getDaysActive(): number {
    if (!this.currentUser?.created_date) return 0;
    
    const createdDate = new Date(this.currentUser.created_date);
    const now = new Date();
    const diffTime = Math.abs(now.getTime() - createdDate.getTime());
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    return diffDays;
  }

  private refreshUserProfile(): void {
    this.subscription.add(
      this.authService.getCurrentUser().subscribe({
        next: (user: User) => {
          console.log('Profile Component - Refreshed user data from server:', user);
          console.log('Refreshed organization fields:', {
            manager_id: user.manager_id,
            user_type: user.user_type,
            portfolio_id: user.portfolio_id,
            organization_id: user.organization_id,
            costcenter_id: user.costcenter_id
          });
        },
        error: (error: any) => {
          console.error('Failed to refresh user profile:', error);
        }
      })
    );
  }

  getUserInitials(): string {
    if (this.currentUser?.first_name && this.currentUser?.last_name) {
      return `${this.currentUser.first_name.charAt(0)}${this.currentUser.last_name.charAt(0)}`.toUpperCase();
    }
    if (this.currentUser?.first_name) {
      return this.currentUser.first_name.charAt(0).toUpperCase();
    }
    if (this.currentUser?.user_id) {
      return this.currentUser.user_id.charAt(0).toUpperCase();
    }
    return 'U';
  }
}

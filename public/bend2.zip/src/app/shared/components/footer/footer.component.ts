import { Component } from '@angular/core';
import { APP_CONFIG } from '../../config/site-config';

@Component({
  selector: 'app-footer',
  template: `
    <footer class="footer">
      <p>&copy; 2025 {{appName}}. All rights reserved.</p>
    </footer>
  `,
  styles: [`
    .footer {
      background-color: var(--fm-gray-dark);
      color: var(--fm-white);
      text-align: center;
      padding: 2rem 1rem;
      margin-top: auto;
    }
    
    .footer p {
      margin: 0;
      font-size: 0.9rem;
      color: var(--fm-gray-light);
    }
  `]
})
export class FooterComponent {
  appName = APP_CONFIG.name;
  constructor() { }
}
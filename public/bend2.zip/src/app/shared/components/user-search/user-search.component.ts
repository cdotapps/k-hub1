import { Component, Input, Output, EventEmitter, forwardRef, OnInit, OnDestroy } from '@angular/core';
import { ControlValueAccessor, NG_VALUE_ACCESSOR } from '@angular/forms';
import { Subject, Observable, BehaviorSubject } from 'rxjs';
import { debounceTime, distinctUntilChanged, switchMap, map, takeUntil, startWith } from 'rxjs/operators';
import { faUser, faUsers, faSearch, faTimes, faChevronDown, faUserShield } from '@fortawesome/free-solid-svg-icons';
import { User } from '../../models/user.interface';
import { UserService } from '../../services/user.service';

export interface UserSearchOption {
  id: string;
  user_id: string;
  displayName: string;
  role?: string;
  status?: string;
  email?: string;
  isActive?: boolean;
  designation?: string;
}

@Component({
  selector: 'app-user-search',
  templateUrl: './user-search.component.html',
  styleUrls: ['./user-search.component.css'],
  providers: [
    {
      provide: NG_VALUE_ACCESSOR,
      useExisting: forwardRef(() => UserSearchComponent),
      multi: true
    }
  ]
})
export class UserSearchComponent implements OnInit, OnDestroy, ControlValueAccessor {
  // FontAwesome icons
  faUser = faUser;
  faUsers = faUsers;
  faSearch = faSearch;
  faTimes = faTimes;
  faChevronDown = faChevronDown;
  faUserShield = faUserShield;

  // Inputs
  @Input() label = 'Select User';
  @Input() placeholder = 'Search for a user...';
  @Input() disabled = false;
  @Input() excludeCurrentUser = false;
  @Input() rolesFilter: string[] = [];
  @Input() activeOnly = false;
  @Input() showUserRole = false;
  @Input() showUserStatus = false;
  @Input() maxResults = 10;
  @Input() allowClear = true;
  @Input() size: 'small' | 'medium' | 'large' = 'medium';

  // Outputs
  @Output() userSelected = new EventEmitter<User | null>();
  @Output() searchChange = new EventEmitter<string>();

  // Component state
  searchTerm = '';
  isOpen = false;
  isLoading = false;
  selectedUser: User | null = null;
  allUsers: User[] = [];
  filteredUsers: UserSearchOption[] = [];
  
  // Store initial value until users are loaded
  private pendingValue: string | null = null;
  
  private searchSubject = new Subject<string>();
  private destroy$ = new Subject<void>();
  private allUsers$ = new BehaviorSubject<User[]>([]);

  // ControlValueAccessor
  private onChange = (value: string) => {};
  private onTouched = () => {};

  constructor(private userService: UserService) {}

  ngOnInit(): void {
    this.loadUsers();
    this.setupSearch();
  }

  ngOnDestroy(): void {
    this.destroy$.next();
    this.destroy$.complete();
  }

  // ControlValueAccessor Implementation
  writeValue(value: string): void {
    if (value) {
      // If users are not loaded yet, store the value for later
      if (this.allUsers.length === 0) {
        this.pendingValue = value;
        return;
      }

      // Find the user by ID and set as selected
      const user = this.allUsers.find(u => u.id === value || u.user_id === value);
      if (user) {
        this.selectedUser = user;
        this.searchTerm = this.getUserDisplayName(user);
      } else {
        // If user not found, store as pending value in case users haven't loaded yet
        this.pendingValue = value;
      }
    } else {
      this.selectedUser = null;
      this.searchTerm = '';
      this.pendingValue = null;
    }
  }

  registerOnChange(fn: (value: string) => void): void {
    this.onChange = fn;
  }

  registerOnTouched(fn: () => void): void {
    this.onTouched = fn;
  }

  setDisabledState(isDisabled: boolean): void {
    this.disabled = isDisabled;
  }

  private loadUsers(): void {
    this.isLoading = true;
    this.userService.getAllUsers()
      .pipe(takeUntil(this.destroy$))
      .subscribe({
        next: (users) => {
          this.allUsers = this.filterUsers(users);
          this.allUsers$.next(this.allUsers);
          this.isLoading = false;

          // If there's a pending value, set it now that users are loaded
          if (this.pendingValue) {
            this.writeValue(this.pendingValue);
            this.pendingValue = null;
          }
        },
        error: (error) => {
          console.error('Error loading users:', error);
          this.isLoading = false;
        }
      });
  }

  private filterUsers(users: User[]): User[] {
    let filtered = [...users];

    // Exclude current user if specified
    if (this.excludeCurrentUser) {
      const currentUser = this.userService.getCurrentUserProfileValue();
      if (currentUser) {
        filtered = filtered.filter(user => user.id !== currentUser.id);
      }
    }

    // Filter by roles if specified
    if (this.rolesFilter.length > 0) {
      filtered = filtered.filter(user => 
        user.role && this.rolesFilter.includes(user.role)
      );
    }

    // Filter active users only if specified
    if (this.activeOnly) {
      filtered = filtered.filter(user => user.is_active !== false);
    }

    return filtered;
  }

  private setupSearch(): void {
    this.searchSubject
      .pipe(
        debounceTime(300),
        distinctUntilChanged(),
        switchMap(term => this.searchUsers(term)),
        takeUntil(this.destroy$)
      )
      .subscribe(results => {
        this.filteredUsers = results;
      });

    // Initial load of all users
    this.allUsers$
      .pipe(
        map(users => this.mapUsersToOptions(users.slice(0, this.maxResults))),
        takeUntil(this.destroy$)
      )
      .subscribe(options => {
        if (!this.searchTerm) {
          this.filteredUsers = options;
        }
      });
  }

  private searchUsers(term: string): Observable<UserSearchOption[]> {
    if (!term || term.length < 2) {
      return this.allUsers$.pipe(
        map(users => this.mapUsersToOptions(users.slice(0, this.maxResults)))
      );
    }

    const searchTerm = term.toLowerCase();
    const filtered = this.allUsers.filter(user => {
      const displayName = this.getUserDisplayName(user).toLowerCase();
      const userId = (user.user_id || '').toLowerCase();
      const email = (user.email || '').toLowerCase();
      
      return displayName.includes(searchTerm) || 
             userId.includes(searchTerm) || 
             email.includes(searchTerm);
    });

    return new Observable(observer => {
      observer.next(this.mapUsersToOptions(filtered.slice(0, this.maxResults)));
      observer.complete();
    });
  }

  private mapUsersToOptions(users: User[]): UserSearchOption[] {
    return users.map(user => ({
      id: user.id,
      user_id: user.user_id || '',
      displayName: this.getUserDisplayName(user),
      role: user.role,
      status: this.getUserStatus(user),
      email: user.email,
      isActive: user.is_active,
      designation: user.designation
    }));
  }

  onSearchInput(event: Event): void {
    const target = event.target as HTMLInputElement;
    this.searchTerm = target.value;
    this.searchChange.emit(this.searchTerm);
    
    if (!this.selectedUser || this.searchTerm !== this.getUserDisplayName(this.selectedUser)) {
      this.selectedUser = null;
      this.onChange('');
    }
    
    this.searchSubject.next(this.searchTerm);
    this.isOpen = true;
  }

  onFocus(): void {
    this.onTouched();
    this.isOpen = true;
    if (!this.searchTerm) {
      this.searchSubject.next('');
    }
  }

  onBlur(): void {
    // Delay closing to allow for option selection
    setTimeout(() => {
      this.isOpen = false;
      
      // If no user is selected and there's text, clear it
      if (!this.selectedUser && this.searchTerm) {
        this.searchTerm = '';
        this.onChange('');
      }
    }, 200);
  }

  selectUser(option: UserSearchOption): void {
    const user = this.allUsers.find(u => u.id === option.id);
    if (user) {
      this.selectedUser = user;
      this.searchTerm = option.displayName;
      this.onChange(user.id);
      this.userSelected.emit(user);
      this.isOpen = false;
    }
  }

  clearSelection(): void {
    this.selectedUser = null;
    this.searchTerm = '';
    this.onChange('');
    this.userSelected.emit(null);
    this.isOpen = false;
  }

  toggleDropdown(): void {
    if (this.disabled) return;
    
    this.isOpen = !this.isOpen;
    if (this.isOpen && !this.searchTerm) {
      this.searchSubject.next('');
    }
  }

  trackByUserId(index: number, option: UserSearchOption): string {
    return option.id;
  }

  getUserDisplayName(user: User): string {
    return this.userService.getUserDisplayName(user);
  }

  getUserInitials(user: User): string {
    return this.userService.getUserInitials(user);
  }

  private getUserStatus(user: User): string {
    return this.userService.getUserStatusDisplay(user);
  }

  getComponentClasses(): string[] {
    const classes = [
      'user-search-component',
      `user-search-${this.size}`
    ];

    if (this.disabled) classes.push('user-search-disabled');
    if (this.isOpen) classes.push('user-search-open');
    if (this.selectedUser) classes.push('user-search-selected');

    return classes;
  }
}
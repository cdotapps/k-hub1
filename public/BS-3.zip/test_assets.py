"""
Simple test script to verify asset management functionality
"""

import asyncio
import json
from datetime import datetime
from app.db.session import get_db
from app.models.asset import Asset
from app.schemas.asset import AssetCreate, AssetSearch
from app.crud.crud_asset import crud_asset

async def test_asset_management():
    """Test basic asset management functionality"""
    
    print("🧪 Testing Asset Management System")
    print("=" * 40)
    
    # Get database session
    db_gen = get_db()
    db = await db_gen.__anext__()
    
    try:
        # Test 1: Create an asset
        print("\n📝 Test 1: Creating a new asset...")
        
        asset_data = AssetCreate(
            asset_id="TEST-001",
            asset_name="Test Server",
            business="IT Department",
            block="Infrastructure",
            capability="Web Hosting",
            asset_type="hardware",
            asset_status="active",
            size_attributes={"cpu_cores": 8, "ram_gb": 32, "storage_gb": 500},
            description="Test server for development",
            location="Development Lab",
            owner="IT Team",
            contact_person="Test User",
            contact_email="test@example.com",
            cost=5000.00,
            currency="USD",
            vendor="Test Vendor",
            model="Test Model v1.0",
            tags=["test", "development", "server"],
            risk_level="low",
            criticality="medium",
            custom_fields={"environment": "test", "backup_required": True}
        )
        
        created_asset = await crud_asset.create(db, obj_in=asset_data, current_user_id="test-user")
        print(f"✅ Asset created with ID: {created_asset.id}")
        print(f"   Asset ID: {created_asset.asset_id}")
        print(f"   Asset Name: {created_asset.asset_name}")
        
        # Test 2: Get the asset
        print("\n🔍 Test 2: Retrieving the asset...")
        retrieved_asset = await crud_asset.get(db, id=created_asset.id)
        print(f"✅ Asset retrieved: {retrieved_asset.asset_name}")
        
        # Test 3: Get asset by business asset ID
        print("\n🔍 Test 3: Retrieving asset by business ID...")
        asset_by_id = await crud_asset.get_by_asset_id(db, asset_id="TEST-001")
        print(f"✅ Asset found by business ID: {asset_by_id.asset_name}")
        
        # Test 4: Search assets
        print("\n🔍 Test 4: Searching assets...")
        search_params = AssetSearch(
            business="IT Department",
            asset_type="hardware",
            search_term="server"
        )
        search_results = await crud_asset.search(db, search_params=search_params)
        print(f"✅ Found {len(search_results)} assets matching search criteria")
        
        # Test 5: Get statistics
        print("\n📊 Test 5: Getting asset statistics...")
        stats = await crud_asset.get_statistics(db)
        print(f"✅ Statistics retrieved:")
        print(f"   Total assets: {stats['total_assets']}")
        print(f"   By status: {stats['by_status']}")
        print(f"   By type: {stats['by_type']}")
        
        # Test 6: Update asset
        print("\n✏️ Test 6: Updating asset...")
        from app.schemas.asset import AssetUpdate
        update_data = AssetUpdate(
            asset_status="maintenance",
            description="Updated description - under maintenance"
        )
        updated_asset = await crud_asset.update(
            db, 
            db_obj=retrieved_asset, 
            obj_in=update_data,
            current_user_id="test-user"
        )
        print(f"✅ Asset updated. New status: {updated_asset.asset_status}")
        
        # Test 7: Clean up - delete the test asset
        print("\n🗑️ Test 7: Cleaning up...")
        await crud_asset.remove(db, id=created_asset.id)
        print("✅ Test asset deleted")
        
        print("\n🎉 All tests passed! Asset management system is working correctly.")
        
    except Exception as e:
        print(f"❌ Test failed with error: {str(e)}")
        import traceback
        traceback.print_exc()
    
    finally:
        await db.close()

if __name__ == "__main__":
    asyncio.run(test_asset_management())

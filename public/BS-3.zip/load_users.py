import asyncio
import csv
import os
from typing import Dict, List, Optional
from dotenv import load_dotenv

from app.db.session import async_session, create_tables
from app import crud
from app.schemas.user import UserCreate, UserUpdate
from app.models.user import UserRole

load_dotenv()

class UserLoader:
    """Class to handle loading users from CSV file"""
    
    def __init__(self, csv_file_path: str):
        self.csv_file_path = csv_file_path
        self.user_id_mapping: Dict[str, str] = {}  # Maps original user_id to database ID
        self.app_name = os.getenv('APP_NAME', 'User Auth API').lower().replace(' ', '')
    
    def read_csv_file(self) -> List[Dict]:
        """Read and parse CSV file"""
        users_data = []
        
        if not os.path.exists(self.csv_file_path):
            print(f"❌ CSV file not found: {self.csv_file_path}")
            return users_data
        
        try:
            with open(self.csv_file_path, 'r', encoding='utf-8-sig') as file:  # Use utf-8-sig to handle BOM
                # Use DictReader to automatically handle headers
                csv_reader = csv.DictReader(file)
                
                # Clean column names to remove any BOM or whitespace
                cleaned_fieldnames = [name.strip() for name in csv_reader.fieldnames]
                csv_reader.fieldnames = cleaned_fieldnames
                
                # Verify required columns exist
                required_columns = {
                    'first_name', 'last_name', 'user_id', 'manager_id', 
                    'designation', 'organization_id', 'portfolio_id', 'costcenter_id'
                }
                
                if not required_columns.issubset(set(csv_reader.fieldnames)):
                    missing_cols = required_columns - set(csv_reader.fieldnames)
                    print(f"❌ Missing required columns: {missing_cols}")
                    print(f"Available columns: {csv_reader.fieldnames}")
                    return users_data
                
                for row_num, row in enumerate(csv_reader, start=2):  # Start at 2 because of header
                    # Skip empty rows
                    if not any(row.values()):
                        continue
                    
                    # Validate required fields - only first_name and last_name are truly required
                    # user_id can be empty since we'll create it from first_name
                    if not row.get('first_name') or not row.get('last_name'):
                        print(f"⚠️  Skipping row {row_num}: Missing required fields (first_name or last_name)")
                        continue
                    
                    # Use first_name as original_user_id if user_id is empty
                    original_user_id = row.get('user_id', '').strip() or row['first_name'].strip()
                    
                    users_data.append({
                        'first_name': row['first_name'].strip(),
                        'last_name': row['last_name'].strip(),
                        'original_user_id': original_user_id,
                        'manager_id': row.get('manager_id', '').strip() or None,
                        'designation': row.get('designation', 'associate').strip(),
                        'organization_id': row.get('organization_id', '').strip() or None,
                        'portfolio_id': row.get('portfolio_id', '').strip() or None,
                        'costcenter_id': row.get('costcenter_id', '').strip() or None,
                    })
                
                print(f"📄 Successfully read {len(users_data)} users from CSV file")
                return users_data
                
        except Exception as e:
            print(f"❌ Error reading CSV file: {str(e)}")
            return users_data
    
    async def create_users(self, users_data: List[Dict]) -> Dict[str, str]:
        """
        Step 1: Create all users with firstname as user_id and firstname_123 as password
        Returns mapping of original_user_id to database ID
        """
        print("\n🔨 Step 1: Creating users...")
        user_id_mapping = {}
        
        async with async_session() as db:
            created_count = 0
            skipped_count = 0
            
            for user_data in users_data:
                first_name = user_data['first_name']
                last_name = user_data['last_name']
                original_user_id = user_data['original_user_id']
                
                # Create user_id as firstname (lowercase)
                new_user_id = first_name.lower()
                
                # Create email
                email = f"{new_user_id}@{self.app_name}.com"
                
                # Create password as firstname_123
                password = f"{first_name.lower()}_123"
                
                # Check if user already exists
                existing_user = await crud.user.get_by_user_id(db, user_id=new_user_id)
                if existing_user:
                    print(f"ℹ️  User already exists: {new_user_id}")
                    user_id_mapping[original_user_id] = existing_user.id
                    skipped_count += 1
                    continue
                
                try:
                    # Create user
                    user_in = UserCreate(
                        user_id=new_user_id,
                        email=email,
                        password=password,
                        first_name=first_name,
                        last_name=last_name,
                        role=UserRole.USER,
                        is_active=True,
                        email_verified=True,
                        designation=user_data['designation'],
                        organization_id=user_data['organization_id'],
                        portfolio_id=user_data['portfolio_id'],
                        costcenter_id=user_data['costcenter_id'],
                        user_type="employee"  # Default to employee
                    )
                    
                    new_user = await crud.user.create(db, obj_in=user_in)
                    user_id_mapping[original_user_id] = new_user.id
                    
                    print(f"✅ Created user: {new_user_id} ({first_name} {last_name})")
                    print(f"   Password: {password}")
                    print(f"   Email: {email}")
                    print(f"   Original ID: {original_user_id} -> DB ID: {new_user.id}")
                    
                    created_count += 1
                    
                except Exception as e:
                    print(f"❌ Failed to create user {new_user_id}: {str(e)}")
            
            print(f"\n📊 Step 1 Summary: {created_count} users created, {skipped_count} already existed")
            
        return user_id_mapping
    
    async def update_manager_relationships(self, users_data: List[Dict], user_id_mapping: Dict[str, str]):
        """
        Step 2: Update manager relationships using the database IDs
        """
        print("\n👥 Step 2: Updating manager relationships...")
        
        async with async_session() as db:
            updated_count = 0
            error_count = 0
            
            for user_data in users_data:
                original_user_id = user_data['original_user_id']
                manager_original_id = user_data['manager_id']
                
                # Skip if no manager specified
                if not manager_original_id:
                    continue
                
                # Get user's database ID
                user_db_id = user_id_mapping.get(original_user_id)
                if not user_db_id:
                    print(f"⚠️  User not found in mapping: {original_user_id}")
                    error_count += 1
                    continue
                
                # Get manager's database ID
                manager_db_id = user_id_mapping.get(manager_original_id)
                if not manager_db_id:
                    print(f"⚠️  Manager not found in mapping: {manager_original_id} for user {original_user_id}")
                    error_count += 1
                    continue
                
                try:
                    # Get user object
                    user = await crud.user.get(db, id=user_db_id)
                    if not user:
                        print(f"⚠️  User not found in database: {user_db_id}")
                        error_count += 1
                        continue
                    
                    # Update manager relationship
                    user_update = UserUpdate(manager_id=manager_db_id)
                    await crud.user.update(db, db_obj=user, obj_in=user_update)
                    
                    # Get manager info for display
                    manager = await crud.user.get(db, id=manager_db_id)
                    manager_name = f"{manager.first_name} {manager.last_name}" if manager else "Unknown"
                    
                    print(f"✅ Updated {user.first_name} {user.last_name} -> Manager: {manager_name}")
                    updated_count += 1
                    
                except Exception as e:
                    print(f"❌ Failed to update manager for {original_user_id}: {str(e)}")
                    error_count += 1
            
            print(f"\n📊 Step 2 Summary: {updated_count} manager relationships updated, {error_count} errors")
    
    async def load_users_from_csv(self):
        """Main method to load users from CSV file"""
        print(f"🚀 Starting user import from: {self.csv_file_path}")
        print("=" * 60)
        
        # Read CSV file
        users_data = self.read_csv_file()
        if not users_data:
            print("❌ No users to import")
            return
        
        # Step 1: Create users
        user_id_mapping = await self.create_users(users_data)
        self.user_id_mapping = user_id_mapping
        
        # Step 2: Update manager relationships
        await self.update_manager_relationships(users_data, user_id_mapping)
        
        print("\n🎉 User import completed!")
        print("=" * 60)
        print(f"📊 Final Summary:")
        print(f"   Total users processed: {len(users_data)}")
        print(f"   Users in database: {len(user_id_mapping)}")
        
        # Show mapping summary
        print(f"\n🔗 User ID Mapping (Original -> New):")
        for original_id, db_id in user_id_mapping.items():
            print(f"   {original_id} -> {db_id}")


async def load_users_from_csv_file(csv_file_path: str = "users.csv"):
    """
    Load users from CSV file into the database
    
    Args:
        csv_file_path: Path to the CSV file containing user data
    
    Expected CSV columns:
        first_name, last_name, user_id, manager_id, designation, 
        organization_id, portfolio_id, costcenter_id
    """
    # Ensure database tables exist
    await create_tables()
    
    # Initialize loader and load users
    loader = UserLoader(csv_file_path)
    await loader.load_users_from_csv()


async def main():
    """Main function for standalone execution"""
    import sys
    
    # Get CSV file path from command line argument or use default
    csv_file_path = sys.argv[1] if len(sys.argv) > 1 else "users.csv"
    
    print("📋 CSV User Loader")
    print("=" * 60)
    print(f"Expected CSV columns: first_name, last_name, user_id, manager_id,")
    print(f"                     designation, organization_id, portfolio_id, costcenter_id")
    print(f"User creation rules:")
    print(f"  - User ID: firstname (lowercase)")
    print(f"  - Password: firstname_123")
    print(f"  - Email: firstname@{os.getenv('APP_NAME', 'userauthapi').lower().replace(' ', '')}.com")
    print("=" * 60)
    
    await load_users_from_csv_file(csv_file_path)


if __name__ == "__main__":
    asyncio.run(main())
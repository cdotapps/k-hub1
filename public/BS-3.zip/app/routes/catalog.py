from fastapi import APIRouter, Depends, HTTPException, Query, status
from sqlalchemy.orm import Session
from typing import List, Optional, Dict, Any
from pydantic import BaseModel, Field, validator
import json

router = APIRouter()

# Database dependency
def get_db():
    # ...existing database session code...
    pass

# Pydantic models
class CatalogBase(BaseModel):
    # ...existing fields...
    custom: Optional[Dict[str, List[Dict[str, Any]]]] = Field(
        default=None, 
        description="Custom fields organized by groups with column-value pairs. Format: {'group_name': [{'column': 'field_name', 'value': field_value}]}"
    )
    # ...existing fields...

    @validator('custom')
    def validate_custom_format(cls, v):
        """Validate the custom field format"""
        if v is None:
            return v
        
        if not isinstance(v, dict):
            raise ValueError("Custom field must be a dictionary")
        
        for group_name, group_data in v.items():
            if not isinstance(group_name, str):
                raise ValueError("Group names must be strings")
            
            if not isinstance(group_data, list):
                raise ValueError(f"Group '{group_name}' must contain a list of items")
            
            for item in group_data:
                if not isinstance(item, dict):
                    raise ValueError(f"Items in group '{group_name}' must be dictionaries")
                
                if 'column' not in item or 'value' not in item:
                    raise ValueError(f"Items in group '{group_name}' must have 'column' and 'value' keys")
                
                if not isinstance(item['column'], str):
                    raise ValueError(f"Column names in group '{group_name}' must be strings")
        
        return v

class CatalogCreate(CatalogBase):
    # ...fields for creation...
    pass

class CatalogUpdate(CatalogBase):
    # ...fields for update...
    pass

class CatalogResponse(CatalogBase):
    # ...response fields...
    pass

# In-memory "database" for demonstration
fake_db = {}

# CRUD operations
@router.post("/", response_model=CatalogResponse)
def create_catalog(catalog: CatalogCreate, db: Session = Depends(get_db)):
    # Validate custom field format if provided
    if catalog.custom:
        try:
            # Create a temporary catalog instance to validate
            temp_catalog = Catalog(custom=catalog.custom)
            if not temp_catalog.validate_custom_format():
                raise HTTPException(
                    status_code=status.HTTP_400_BAD_REQUEST,
                    detail="Invalid custom field format. Expected: {'group_name': [{'column': 'field_name', 'value': field_value}]}"
                )
        except Exception as e:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail=f"Custom field validation error: {str(e)}"
            )
    
    # ...existing code to create catalog...

@router.put("/{catalog_id}", response_model=CatalogResponse)
def update_catalog(catalog_id: str, catalog: CatalogUpdate, db: Session = Depends(get_db)):
    # ...existing code to get catalog...
    
    # Validate custom field format if being updated
    if catalog.custom is not None:
        try:
            # Create a temporary catalog instance to validate
            temp_catalog = Catalog(custom=catalog.custom)
            if not temp_catalog.validate_custom_format():
                raise HTTPException(
                    status_code=status.HTTP_400_BAD_REQUEST,
                    detail="Invalid custom field format. Expected: {'group_name': [{'column': 'field_name', 'value': field_value}]}"
                )
        except Exception as e:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail=f"Custom field validation error: {str(e)}"
            )
    
    # ...existing code to update catalog...

@router.patch("/{catalog_id}/custom/{group}/{column}")
def update_custom_field(
    catalog_id: str, 
    group: str, 
    column: str, 
    value: Dict[str, Any], 
    db: Session = Depends(get_db)
):
    """Update a specific custom field value for a catalog item"""
    db_catalog = db.query(Catalog).filter(Catalog.id == catalog_id).first()
    if not db_catalog:
        raise HTTPException(status_code=404, detail="Catalog not found")
    
    # Validate column name
    if not isinstance(column, str) or not column.strip():
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Column name must be a non-empty string"
        )
    
    # Extract value from request body
    field_value = value.get('value')
    
    # Update the custom field
    db_catalog.set_custom_field(group, column, field_value)
    
    # Validate the updated format
    if not db_catalog.validate_custom_format():
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Invalid custom field format after update"
        )
    
    db.commit()
    db.refresh(db_catalog)
    
    return {
        "message": "Custom field updated successfully",
        "group": group,
        "column": column,
        "value": field_value
    }

@router.get("/{catalog_id}/custom/{group}/{column}")
def get_custom_field(
    catalog_id: str, 
    group: str, 
    column: str, 
    db: Session = Depends(get_db)
):
    """Get a specific custom field value for a catalog item"""
    db_catalog = db.query(Catalog).filter(Catalog.id == catalog_id).first()
    if not db_catalog:
        raise HTTPException(status_code=404, detail="Catalog not found")
    
    value = db_catalog.get_custom_field(group, column)
    
    return {
        "group": group,
        "column": column,
        "value": value,
        "exists": value is not None
    }

# ...existing code...
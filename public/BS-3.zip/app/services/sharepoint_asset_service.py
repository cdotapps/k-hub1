"""
SharePoint Asset Management Service
Direct integration with SharePoint lists for asset management
"""

import json
import logging
from typing import Dict, List, Optional, Any
from datetime import datetime, timedelta
import aiohttp
import asyncio
from pydantic import BaseModel

logger = logging.getLogger(__name__)


class SharePointAsset(BaseModel):
    """Asset model matching SharePoint list structure"""
    Id: Optional[int] = None  # SharePoint ID
    AssetID: str  # Business Asset ID
    AssetName: str  # Asset Name
    Business: str  # Business unit
    Block: Optional[str] = None  # Block or department
    Capability: Optional[str] = None  # Capability area
    AssetType: str  # Asset Type
    AssetStatus: str  # Asset Status
    SizeAttributes: Optional[str] = None  # JSON string of size attributes
    Description: Optional[str] = None
    Location: Optional[str] = None
    Owner: Optional[str] = None
    ContactPerson: Optional[str] = None
    ContactEmail: Optional[str] = None
    Cost: Optional[float] = None
    Currency: Optional[str] = "USD"
    Vendor: Optional[str] = None
    Model: Optional[str] = None
    Version: Optional[str] = None
    Tags: Optional[str] = None  # JSON string of tags
    RiskLevel: Optional[str] = None
    Criticality: Optional[str] = None
    # SharePoint automatically handles Created, Modified, Author, Editor


class SharePointConfig(BaseModel):
    """SharePoint configuration"""
    site_url: str
    list_name: str
    client_id: str
    client_secret: str
    tenant_id: str


class SharePointAssetService:
    """Service for managing assets directly in SharePoint"""
    
    def __init__(self):
        self.config: Optional[SharePointConfig] = None
        self.access_token: Optional[str] = None
        self.token_expires_at: Optional[datetime] = None
        
        # Auto-configure from environment if available
        self._auto_configure()

    def _auto_configure(self):
        """Auto-configure from environment variables"""
        try:
            from app.core.config import sharepoint_settings
            
            if sharepoint_settings:
                config = SharePointConfig(
                    site_url=sharepoint_settings.site_url,
                    list_name=sharepoint_settings.list_name,
                    client_id=sharepoint_settings.client_id,
                    client_secret=sharepoint_settings.client_secret,
                    tenant_id=sharepoint_settings.tenant_id
                )
                self.configure(config)
                logger.info("✅ SharePoint service auto-configured from environment")
            else:
                logger.warning("⚠️  SharePoint environment configuration not found")
        except Exception as e:
            logger.error(f"❌ Failed to auto-configure SharePoint: {e}")

    def configure(self, config: SharePointConfig):
        """Configure SharePoint connection"""
        self.config = config
        self.access_token = None
        self.token_expires_at = None
        logger.info(f"SharePoint configured for site: {config.site_url}")

    def is_configured(self) -> bool:
        """Check if SharePoint is properly configured"""
        return self.config is not None

    async def get_access_token(self) -> str:
        """Get OAuth access token for SharePoint API"""
        if not self.config:
            raise ValueError("SharePoint service not configured")

        # Check if token is still valid
        if (self.access_token and self.token_expires_at and 
            datetime.now() < self.token_expires_at):
            return self.access_token

        # Request new token
        auth_url = f"https://login.microsoftonline.com/{self.config.tenant_id}/oauth2/v2.0/token"
        
        data = {
            'grant_type': 'client_credentials',
            'client_id': self.config.client_id,
            'client_secret': self.config.client_secret,
            'scope': f"{self.config.site_url}/.default"
        }

        async with aiohttp.ClientSession() as session:
            async with session.post(auth_url, data=data) as response:
                if response.status == 200:
                    token_data = await response.json()
                    self.access_token = token_data['access_token']
                    # Set expiration with 5 minute buffer
                    expires_in = token_data.get('expires_in', 3600)
                    self.token_expires_at = datetime.now() + timedelta(seconds=expires_in - 300)
                    return self.access_token
                else:
                    error_text = await response.text()
                    raise Exception(f"Failed to get access token: {response.status} - {error_text}")

    async def _get_form_digest(self) -> str:
        """Get SharePoint form digest for POST operations"""
        token = await self.get_access_token()
        
        api_url = f"{self.config.site_url}/_api/contextinfo"
        
        headers = {
            'Authorization': f'Bearer {token}',
            'Accept': 'application/json;odata=verbose',
            'Content-Type': 'application/json'
        }

        async with aiohttp.ClientSession() as session:
            async with session.post(api_url, headers=headers) as response:
                if response.status == 200:
                    data = await response.json()
                    return data.get('d', {}).get('GetContextWebInformation', {}).get('FormDigestValue', '')
                else:
                    logger.error(f"Failed to get form digest: {response.status}")
                    return ''

    async def get_all_assets(self) -> List[SharePointAsset]:
        """Get all assets from SharePoint list"""
        token = await self.get_access_token()
        
        api_url = f"{self.config.site_url}/_api/web/lists/getbytitle('{self.config.list_name}')/items"
        
        headers = {
            'Authorization': f'Bearer {token}',
            'Accept': 'application/json;odata=verbose'
        }

        async with aiohttp.ClientSession() as session:
            async with session.get(api_url, headers=headers) as response:
                if response.status == 200:
                    data = await response.json()
                    items = data.get('d', {}).get('results', [])
                    return [self._convert_from_sharepoint(item) for item in items]
                else:
                    error_text = await response.text()
                    raise Exception(f"Failed to fetch assets: {response.status} - {error_text}")

    async def get_asset(self, asset_id: str) -> Optional[SharePointAsset]:
        """Get asset by AssetID"""
        assets = await self.get_all_assets()
        for asset in assets:
            if asset.AssetID == asset_id:
                return asset
        return None

    async def get_asset_by_sp_id(self, sp_id: int) -> Optional[SharePointAsset]:
        """Get asset by SharePoint ID"""
        token = await self.get_access_token()
        
        api_url = f"{self.config.site_url}/_api/web/lists/getbytitle('{self.config.list_name}')/items({sp_id})"
        
        headers = {
            'Authorization': f'Bearer {token}',
            'Accept': 'application/json;odata=verbose'
        }

        async with aiohttp.ClientSession() as session:
            async with session.get(api_url, headers=headers) as response:
                if response.status == 200:
                    data = await response.json()
                    item = data.get('d', {})
                    return self._convert_from_sharepoint(item)
                elif response.status == 404:
                    return None
                else:
                    error_text = await response.text()
                    raise Exception(f"Failed to fetch asset: {response.status} - {error_text}")

    async def create_asset(self, asset: SharePointAsset) -> SharePointAsset:
        """Create new asset in SharePoint"""
        token = await self.get_access_token()
        form_digest = await self._get_form_digest()
        
        api_url = f"{self.config.site_url}/_api/web/lists/getbytitle('{self.config.list_name}')/items"
        
        headers = {
            'Authorization': f'Bearer {token}',
            'Accept': 'application/json;odata=verbose',
            'Content-Type': 'application/json',
            'X-RequestDigest': form_digest
        }

        # Convert asset to SharePoint format
        sp_data = self._convert_to_sharepoint(asset)

        async with aiohttp.ClientSession() as session:
            async with session.post(api_url, headers=headers, json=sp_data) as response:
                if response.status == 201:
                    data = await response.json()
                    created_item = data.get('d', {})
                    return self._convert_from_sharepoint(created_item)
                else:
                    error_text = await response.text()
                    raise Exception(f"Failed to create asset: {response.status} - {error_text}")

    async def update_asset(self, sp_id: int, asset: SharePointAsset) -> SharePointAsset:
        """Update existing asset in SharePoint"""
        token = await self.get_access_token()
        form_digest = await self._get_form_digest()
        
        api_url = f"{self.config.site_url}/_api/web/lists/getbytitle('{self.config.list_name}')/items({sp_id})"
        
        headers = {
            'Authorization': f'Bearer {token}',
            'Accept': 'application/json;odata=verbose',
            'Content-Type': 'application/json',
            'X-RequestDigest': form_digest,
            'X-HTTP-Method': 'MERGE',
            'IF-MATCH': '*'
        }

        # Convert asset to SharePoint format
        sp_data = self._convert_to_sharepoint(asset)

        async with aiohttp.ClientSession() as session:
            async with session.post(api_url, headers=headers, json=sp_data) as response:
                if response.status == 204:
                    # Get updated item
                    return await self.get_asset_by_sp_id(sp_id)
                else:
                    error_text = await response.text()
                    raise Exception(f"Failed to update asset: {response.status} - {error_text}")

    async def delete_asset(self, sp_id: int) -> bool:
        """Delete asset from SharePoint"""
        token = await self.get_access_token()
        form_digest = await self._get_form_digest()
        
        api_url = f"{self.config.site_url}/_api/web/lists/getbytitle('{self.config.list_name}')/items({sp_id})"
        
        headers = {
            'Authorization': f'Bearer {token}',
            'Accept': 'application/json;odata=verbose',
            'X-RequestDigest': form_digest,
            'X-HTTP-Method': 'DELETE',
            'IF-MATCH': '*'
        }

        async with aiohttp.ClientSession() as session:
            async with session.post(api_url, headers=headers) as response:
                if response.status == 200:
                    return True
                else:
                    error_text = await response.text()
                    raise Exception(f"Failed to delete asset: {response.status} - {error_text}")

    async def search_assets(self, filters: Dict[str, Any]) -> List[SharePointAsset]:
        """Search assets with filters"""
        # For simplicity, get all assets and filter in memory
        # In production, you'd use SharePoint OData queries
        all_assets = await self.get_all_assets()
        
        filtered_assets = []
        for asset in all_assets:
            matches = True
            
            # Apply filters
            if filters.get('business') and filters['business'].lower() not in asset.Business.lower():
                matches = False
            if filters.get('asset_type') and asset.AssetType != filters['asset_type']:
                matches = False
            if filters.get('asset_status') and asset.AssetStatus != filters['asset_status']:
                matches = False
            if filters.get('owner') and asset.Owner and filters['owner'].lower() not in asset.Owner.lower():
                matches = False
            if filters.get('search_term'):
                search_term = filters['search_term'].lower()
                searchable_text = f"{asset.AssetID} {asset.AssetName} {asset.Description or ''} {asset.Business}".lower()
                if search_term not in searchable_text:
                    matches = False
            
            if matches:
                filtered_assets.append(asset)
        
        return filtered_assets

    async def get_statistics(self) -> Dict[str, Any]:
        """Get asset statistics"""
        assets = await self.get_all_assets()
        
        total_count = len(assets)
        
        # Count by status
        status_counts = {}
        for asset in assets:
            status = asset.AssetStatus
            status_counts[status] = status_counts.get(status, 0) + 1
        
        # Count by type
        type_counts = {}
        for asset in assets:
            asset_type = asset.AssetType
            type_counts[asset_type] = type_counts.get(asset_type, 0) + 1
        
        # Count by business
        business_counts = {}
        for asset in assets:
            business = asset.Business
            business_counts[business] = business_counts.get(business, 0) + 1
        
        return {
            "total_assets": total_count,
            "by_status": status_counts,
            "by_type": type_counts,
            "by_business": business_counts
        }

    def _convert_to_sharepoint(self, asset: SharePointAsset) -> Dict[str, Any]:
        """Convert asset model to SharePoint format"""
        sp_data = {}
        
        # Map all fields
        if asset.AssetID:
            sp_data['AssetID'] = asset.AssetID
        if asset.AssetName:
            sp_data['AssetName'] = asset.AssetName
        if asset.Business:
            sp_data['Business'] = asset.Business
        if asset.Block:
            sp_data['Block'] = asset.Block
        if asset.Capability:
            sp_data['Capability'] = asset.Capability
        if asset.AssetType:
            sp_data['AssetType'] = asset.AssetType
        if asset.AssetStatus:
            sp_data['AssetStatus'] = asset.AssetStatus
        if asset.SizeAttributes:
            sp_data['SizeAttributes'] = asset.SizeAttributes
        if asset.Description:
            sp_data['Description'] = asset.Description
        if asset.Location:
            sp_data['Location'] = asset.Location
        if asset.Owner:
            sp_data['Owner'] = asset.Owner
        if asset.ContactPerson:
            sp_data['ContactPerson'] = asset.ContactPerson
        if asset.ContactEmail:
            sp_data['ContactEmail'] = asset.ContactEmail
        if asset.Cost is not None:
            sp_data['Cost'] = asset.Cost
        if asset.Currency:
            sp_data['Currency'] = asset.Currency
        if asset.Vendor:
            sp_data['Vendor'] = asset.Vendor
        if asset.Model:
            sp_data['Model'] = asset.Model
        if asset.Version:
            sp_data['Version'] = asset.Version
        if asset.Tags:
            sp_data['Tags'] = asset.Tags
        if asset.RiskLevel:
            sp_data['RiskLevel'] = asset.RiskLevel
        if asset.Criticality:
            sp_data['Criticality'] = asset.Criticality
        
        return sp_data

    def _convert_from_sharepoint(self, sp_item: Dict[str, Any]) -> SharePointAsset:
        """Convert SharePoint item to asset model"""
        return SharePointAsset(
            Id=sp_item.get('Id'),
            AssetID=sp_item.get('AssetID', ''),
            AssetName=sp_item.get('AssetName', ''),
            Business=sp_item.get('Business', ''),
            Block=sp_item.get('Block'),
            Capability=sp_item.get('Capability'),
            AssetType=sp_item.get('AssetType', ''),
            AssetStatus=sp_item.get('AssetStatus', ''),
            SizeAttributes=sp_item.get('SizeAttributes'),
            Description=sp_item.get('Description'),
            Location=sp_item.get('Location'),
            Owner=sp_item.get('Owner'),
            ContactPerson=sp_item.get('ContactPerson'),
            ContactEmail=sp_item.get('ContactEmail'),
            Cost=sp_item.get('Cost'),
            Currency=sp_item.get('Currency'),
            Vendor=sp_item.get('Vendor'),
            Model=sp_item.get('Model'),
            Version=sp_item.get('Version'),
            Tags=sp_item.get('Tags'),
            RiskLevel=sp_item.get('RiskLevel'),
            Criticality=sp_item.get('Criticality')
        )


# Global service instance
sharepoint_asset_service = SharePointAssetService()

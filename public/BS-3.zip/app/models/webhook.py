from sqlalchemy import Column, String, Boolean, DateTime, JSON, Text
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.sql import func
import uuid
import enum

Base = declarative_base()

class WebhookEventType(str, enum.Enum):
    CATALOG_CREATED = "catalog.created"
    CATALOG_UPDATED = "catalog.updated"
    CATALOG_DELETED = "catalog.deleted"
    CATALOG_APPROVED = "catalog.approved"
    CATALOG_REJECTED = "catalog.rejected"
    CATALOG_APPROVAL_REQUESTED = "catalog.approval_requested"

class WebhookStatus(str, enum.Enum):
    ACTIVE = "active"
    INACTIVE = "inactive"
    FAILED = "failed"

class Webhook(Base):
    __tablename__ = "webhooks"

    id = Column(String, primary_key=True, index=True, default=lambda: str(uuid.uuid4()))
    name = Column(String, nullable=False, index=True)  # User-friendly name for the webhook
    url = Column(String, nullable=False)  # Target URL to call
    events = Column(JSON, nullable=False)  # List of events to subscribe to
    secret = Column(String, nullable=True)  # Secret for webhook signature verification
    headers = Column(JSON, nullable=True)  # Additional headers to send
    active = Column(Boolean, default=True, nullable=False)  # Whether webhook is active
    status = Column(String, default="active", nullable=False)  # Current status
    created_by = Column(String, nullable=False, index=True)  # User who created the webhook
    created_date = Column(DateTime(timezone=True), server_default=func.now(), nullable=False)
    updated_date = Column(DateTime(timezone=True), onupdate=func.now())
    last_triggered = Column(DateTime(timezone=True), nullable=True)
    success_count = Column(String, default="0", nullable=False)  # Number of successful deliveries
    failure_count = Column(String, default="0", nullable=False)  # Number of failed deliveries
    
    # Optional filters
    filters = Column(JSON, nullable=True)  # Conditions for when to trigger webhook

class WebhookDelivery(Base):
    __tablename__ = "webhook_deliveries"

    id = Column(String, primary_key=True, index=True, default=lambda: str(uuid.uuid4()))
    webhook_id = Column(String, nullable=False, index=True)  # Foreign key to webhook
    event_type = Column(String, nullable=False, index=True)
    payload = Column(JSON, nullable=False)  # The data sent
    response_status = Column(String, nullable=True)  # HTTP response status
    response_body = Column(Text, nullable=True)  # Response body (truncated)
    error_message = Column(Text, nullable=True)  # Error message if failed
    attempts = Column(String, default="1", nullable=False)  # Number of delivery attempts
    delivered_at = Column(DateTime(timezone=True), server_default=func.now(), nullable=False)
    success = Column(Boolean, default=False, nullable=False)  # Whether delivery was successful
from sqlalchemy import Column, String, Boolean, DateTime, Enum, Integer, Text, JSON
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.sql import func
from typing import Optional, List, Dict, Any
from pydantic import Field
import enum
import uuid
import json
import random
import string

Base = declarative_base()

class SharePointListConfig:
    def __init__(self, list_name: str, list_title: str, endpoint_name: str, fields: Dict[str, str], required_fields: List[str], searchable_fields: List[str]):
        self.list_name = list_name
        self.list_title = list_title
        self.endpoint_name = endpoint_name
        self.fields = fields
        self.required_fields = required_fields
        self.searchable_fields = searchable_fields

class CatalogStatus(str, enum.Enum):
    DRAFT = "draft"
    UNDER_REVIEW = "under-review"
    REVIEWED = "reviewed"
    FEEDBACK_LOOP = "feedback-loop"
    REVISED = "revised"
    PENDING_APPROVAL = "pending-approval"
    APPROVED = "approved"
    PUBLISHED = "published"
    ARCHIVED = "archived"

class CatalogType(str, enum.Enum):
    NEWS = "news"
    DOCUMENT = "document"
    TUTORIAL = "tutorial"
    VIDEO = "video"
    ARTICLE = "article"
    REFERENCE = "reference"
    TOOL = "tool"

def genKey(user_firstname: str = "U", catalog_type: str = "C") -> str:
    """
    Generate a key in the format XYZ-AAA-BBB:
    X = first letter of user firstname
    Y = first letter of catalog type
    Z = random A-Z
    AAA = random letters (A-Z)
    BBB = first and last letter of month + year (e.g., JY25 for July 2025)
    """
    import datetime
    X = user_firstname[0].upper() if user_firstname else "U"
    Y = catalog_type[0].upper() if catalog_type else "C"
    Z = str(random.randint(0, 9))
    A = ''.join(random.choices(string.ascii_uppercase, k=1))
    B = str(random.randint(0, 9))
    C = str(random.randint(0, 9))
    now = datetime.datetime.now()
    month_name = now.strftime('%B')
    month_first = month_name[0].upper()
    month_last = month_name[-1].upper()
    year_short = now.strftime('%y')
    MM = f"{month_first}{month_last}"
    return f"{X}{Y}{Z}-{A}{B}{C}-{MM}{year_short}"

class Catalog(Base):
    __tablename__ = "catalogs"

    id = Column(String, primary_key=True, index=True, default=lambda: str(uuid.uuid4()))
    key = Column(String, index=True, default=lambda: genKey())
    title = Column(String, nullable=False, index=True)  # Field(..., description="Catalog item title")
    description = Column(Text, nullable=True)  # Field(None, description="Catalog item description")
    summary = Column(String, nullable=True, index=True)  # Field(None, description="Brief summary of the catalog item")
    type = Column(String, nullable=False, index=True)  # Field(..., description="Type of catalog item (document, prompt, blog, product, etc.)")
    content = Column(Text, nullable=True)  # Field(None, description="The main content of the catalog item")
    url = Column(String, nullable=True)  # Field(None, description="URL associated with the catalog item")
    image = Column(String, nullable=True)  # Field(None, description="Image URL or path for the catalog item")
    imageUrl = Column(String, nullable=True)  # Field(None, description="Direct image URL for web display")
    display = Column(String, nullable=True)  # Field(None, description="Display settings or visibility options")
    tags = Column(JSON, nullable=True)  # Field(default=None, description="Tags for categorizing the catalog item")
    author = Column(String, nullable=True, index=True)  # Field(None, description="Author of the catalog item")
    created_date = Column(DateTime, nullable=False, default=func.now())  # Field(None, description="Creation date")
    updated_date = Column(DateTime, nullable=False, default=func.now(), onupdate=func.now())  # Field(None, description="Last update date")
    expire_date = Column(String, nullable=True)  # Field(None, description="Expire date")
    due_date = Column(String, nullable=True)  # Field(None, description="Due date")
    custom = Column(JSON, nullable=True)  # Field(default=None, description="Custom fields organized by groups with column-value pairs. Format: {'group_name': [{'column': 'field_name', 'value': field_value}]}")
    category = Column(String, default="Unknown", nullable=True, index=True)  # Field(None, description="Primary category for the content")
    parent_id = Column(String, nullable=True, index=True)  # Field(None, description="ID of the parent catalog item for hierarchical structures")
    child_ids = Column(JSON, nullable=True)  # Field(default=None, description="List of child catalog items with metadata. Format: [{'id': 'catalog_id', 'index': 0, 'title': 'optional_title', 'description': 'optional_desc', 'author': 'optional_author', ...additional_props}]")
    priority = Column(String, default="low", nullable=True, index=True)  # Field(None, description="Priority level of the catalog item (high, medium, low)")
    severity = Column(String, default="low", nullable=True, index=True)  # Field(None, description="Severity level of the catalog item")
    urgent = Column(Boolean, default=False, nullable=False)  # Field(default=False, description="Indicates if the catalog item is urgent")
    important = Column(Boolean, default=False, nullable=False)  # Field(default=False, description="Indicates if the catalog item is important")
    # Metric attributes
    likes = Column(Integer, default=0, nullable=False)  # Field(default=0, description="Number of likes for the content")
    usages = Column(Integer, default=0, nullable=False)  # Field(default=0, description="Number of times the content has been used")
    favorites = Column(Integer, default=0, nullable=False)  # Field(default=0, description="Number of times the content has been favorited")
    views = Column(Integer, default=0, nullable=False)  # Field(default=0, description="Number of views for the content")
    shares = Column(Integer, default=0, nullable=False)  # Field(default=0, description="Number of times the content has been shared")
    owner_id = Column(String, nullable=True, index=True)  # Field(None, description="ID of the owner of the catalog item")
    # Author relationship
    author_id = Column(String, nullable=True, index=True)  # Field(None, description="ID of the user who created the content")
    
    # Approval process attributes
    approved_by = Column(String, nullable=True, index=True)  # Field(None, description="Email or name of the person who approved the content")
    reviewed_by = Column(String, nullable=True, index=True)  # Field(None, description="Email or name of the person who reviewed the content")
    source = Column(String, nullable=True, index=True)  # Field(None, description="Source or origin of the content")
    status = Column(String, nullable=False, default="draft", index=True)  # Field(default="draft", description="Status of the catalog item (draft, published, archived)")
    private = Column(Boolean, default=True, nullable=False)  # Indicates if the catalog item is private
    shared_with = Column(JSON, nullable=True)  # Field(default=None, description="List of users or groups the catalog item is shared with")
    conversations = Column(JSON, nullable=True)  # Field(default=None, description="Comments and conversations on the catalog item")
    
    @classmethod
    def get_list_config(cls) -> SharePointListConfig:
        return SharePointListConfig(
            list_name="Catalog",
            list_title="Content Catalog",
            endpoint_name="catalog",
            fields={
                "Title": "title",
                "Description": "description",
                "Summary": "summary",
                "Type": "type",
                "Content": "content",
                "Url": "url",
                "Image": "image",
                "ImageUrl": "imageUrl",
                "Display": "display",
                "Tags": "tags",
                "Author": "author",
                "CreatedDate": "created_date",
                "UpdatedDate": "updated_date",
                "Custom": "custom",
                "Category": "category",
                "Likes": "likes",
                "Usages": "usages",
                "Favorites": "favorites",
                "Views": "views",
                "Shares": "shares",
                "ApprovedBy": "approved_by",
                "ReviewedBy": "reviewed_by",
                "Source": "source",
                "Status": "status"
            },
            required_fields=["title", "type", "status"],
            searchable_fields=["title", "description", "summary", "type", "tags", "content", "category", "author", "status", "approved_by", "reviewed_by", "source"]
        )
    
    def set_custom_field(self, group: str, column: str, value: Any) -> None:
        """
        Set a custom field value for a specific group and column.
        
        Args:
            group: The group name (e.g., 'default', 'group1', 'group2')
            column: The column/field name
            value: The value to set
        """
        if self.custom is None:
            self.custom = {}
        
        # Create a copy to ensure SQLAlchemy detects the change
        custom_copy = dict(self.custom)
        
        if group not in custom_copy:
            custom_copy[group] = []
        
        # Find existing entry or create new one
        found = False
        for item in custom_copy[group]:
            if item.get('column') == column:
                item['value'] = value
                found = True
                break
        
        # Add new entry if not found
        if not found:
            custom_copy[group].append({'column': column, 'value': value})
        
        # Reassign to trigger SQLAlchemy change detection
        self.custom = custom_copy
    
    def get_custom_field(self, group: str, column: str) -> Any:
        """
        Get a custom field value for a specific group and column.
        
        Args:
            group: The group name
            column: The column/field name
            
        Returns:
            The field value or None if not found
        """
        if not self.custom or group not in self.custom:
            return None
        
        for item in self.custom[group]:
            if item.get('column') == column:
                return item.get('value')
        
        return None
    
    def validate_custom_format(self) -> bool:
        """
        Validate that the custom field follows the expected format.
        
        Returns:
            True if valid, False otherwise
        """
        if self.custom is None:
            return True
        
        if not isinstance(self.custom, dict):
            return False
        
        for group_name, group_data in self.custom.items():
            if not isinstance(group_data, list):
                return False
            
            for item in group_data:
                if not isinstance(item, dict):
                    return False
                if 'column' not in item or 'value' not in item:
                    return False
                if not isinstance(item['column'], str):
                    return False
        
        return True
    
    def add_child_item(self, child_id: str, index: int, title: str = None, description: str = None, author: str = None, **kwargs) -> None:
        """
        Add a child item to the catalog.
        
        Args:
            child_id: The catalog ID of the child item
            index: The child index number for ordering (0-based)
            title: Optional title for the child item
            description: Optional description for the child item
            author: Optional author for the child item
            **kwargs: Additional properties for the child item
        """
        if self.child_ids is None:
            self.child_ids = []
        
        # Create a copy to ensure SQLAlchemy detects the change
        child_ids_copy = list(self.child_ids)
        
        # Create child item object
        child_item = {
            'id': child_id,
            'index': index
        }
        
        # Add optional fields if provided
        if title is not None:
            child_item['title'] = title
        if description is not None:
            child_item['description'] = description
        if author is not None:
            child_item['author'] = author
        
        # Add any additional properties
        child_item.update(kwargs)
        
        # Remove existing child with same id if it exists
        child_ids_copy = [item for item in child_ids_copy if item.get('id') != child_id]
        
        # Add the new child item
        child_ids_copy.append(child_item)
        
        # Sort by index
        child_ids_copy.sort(key=lambda x: x.get('index', 0))
        
        # Reassign to trigger SQLAlchemy change detection
        self.child_ids = child_ids_copy
    
    def remove_child_item(self, child_id: str) -> bool:
        """
        Remove a child item from the catalog.
        
        Args:
            child_id: The catalog ID of the child item to remove
            
        Returns:
            True if item was found and removed, False otherwise
        """
        if not self.child_ids:
            return False
        
        # Create a copy to ensure SQLAlchemy detects the change
        original_count = len(self.child_ids)
        child_ids_copy = [item for item in self.child_ids if item.get('id') != child_id]
        
        if len(child_ids_copy) < original_count:
            self.child_ids = child_ids_copy
            return True
        
        return False
    
    def get_child_item(self, child_id: str) -> Optional[Dict[str, Any]]:
        """
        Get a child item by its ID.
        
        Args:
            child_id: The catalog ID of the child item
            
        Returns:
            The child item dictionary or None if not found
        """
        if not self.child_ids:
            return None
        
        for item in self.child_ids:
            if item.get('id') == child_id:
                return item
        
        return None
    
    def update_child_item(self, child_id: str, **updates) -> bool:
        """
        Update properties of a child item.
        
        Args:
            child_id: The catalog ID of the child item
            **updates: Properties to update
            
        Returns:
            True if item was found and updated, False otherwise
        """
        if not self.child_ids:
            return False
        
        # Create a copy to ensure SQLAlchemy detects the change
        child_ids_copy = list(self.child_ids)
        
        for item in child_ids_copy:
            if item.get('id') == child_id:
                item.update(updates)
                # Re-sort if index was updated
                if 'index' in updates:
                    child_ids_copy.sort(key=lambda x: x.get('index', 0))
                self.child_ids = child_ids_copy
                return True
        
        return False
    
    def get_ordered_children(self) -> List[Dict[str, Any]]:
        """
        Get all child items ordered by their index.
        
        Returns:
            List of child item dictionaries sorted by index
        """
        if not self.child_ids:
            return []
        
        return sorted(self.child_ids, key=lambda x: x.get('index', 0))
    
    def validate_child_ids_format(self) -> bool:
        """
        Validate that the child_ids field follows the expected format.
        
        Returns:
            True if valid, False otherwise
        """
        if self.child_ids is None:
            return True
        
        if not isinstance(self.child_ids, list):
            return False
        
        for item in self.child_ids:
            if not isinstance(item, dict):
                return False
            
            # Required fields
            if 'id' not in item or 'index' not in item:
                return False
            
            # Validate id field (string or number)
            if not isinstance(item['id'], (str, int, float)):
                return False
            
            # Validate index field (number)
            if not isinstance(item['index'], (int, float)):
                return False
            
            # Optional fields validation
            if 'title' in item and not isinstance(item['title'], str):
                return False
            if 'description' in item and not isinstance(item['description'], str):
                return False
            if 'author' in item and not isinstance(item['author'], str):
                return False
        
        return True
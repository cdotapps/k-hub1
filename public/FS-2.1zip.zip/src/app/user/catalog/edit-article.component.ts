import { Component, OnInit, OnDestroy } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router, ActivatedRoute } from '@angular/router';
import { Subscription } from 'rxjs';

// FontAwesome Icons
import { 
  faNewspaper, faFileAlt, faBell, faFileContract, faBook, faGraduationCap,
  faBlog, faFlask, faFileImage, faChartLine, faSave, faTimes, faSpinner,
  faEye, faArrowLeft, faInfoCircle, faExclamationTriangle, faCheckCircle,
  faPlus, faTag, faUser, faCalendar, faGlobe, faLock, faEdit, faClock
} from '@fortawesome/free-solid-svg-icons';

// Services and Models
import { CatalogService } from '../../shared/services/catalog.service';
import { AuthService } from '../../shared/services/auth.service';
import { Catalog, User } from '../../shared/models/user.interface';
import { BreadcrumbItem } from '../../shared/components/breadcrumb/breadcrumb.component';
import { CATALOG_TYPES, CatalogType, filterCatalogTypesByRole } from '../../shared/config/site-config';

@Component({
  selector: 'app-edit-article',
  templateUrl: './edit-article.component.html',
  styleUrls: ['./edit-article.component.css']
})
export class EditArticleComponent implements OnInit, OnDestroy {
  // FontAwesome Icons
  faNewspaper = faNewspaper;
  faFileAlt = faFileAlt;
  faBell = faBell;
  faFileContract = faFileContract;
  faBook = faBook;
  faGraduationCap = faGraduationCap;
  faBlog = faBlog;
  faFlask = faFlask;
  faFileImage = faFileImage;
  faChartLine = faChartLine;
  faSave = faSave;
  faTimes = faTimes;
  faSpinner = faSpinner;
  faEye = faEye;
  faArrowLeft = faArrowLeft;
  faInfoCircle = faInfoCircle;
  faExclamationTriangle = faExclamationTriangle;
  faCheckCircle = faCheckCircle;
  faPlus = faPlus;
  faTag = faTag;
  faUser = faUser;
  faCalendar = faCalendar;
  faGlobe = faGlobe;
  faLock = faLock;
  faEdit = faEdit;
  faClock = faClock;

  // Form and Data
  articleForm: FormGroup;
  currentUser: User | null = null;
  selectedCatalogType = '';
  currentArticle: Catalog | null = null;
  articleId: string = '';
  
  // UI State
  isLoading = false;
  isSaving = false;
  isPreviewMode = false;
  successMessage = '';
  errorMessage = '';
  
  // Word count tracking
  private currentWordCount: number = 0;
  
  // Available catalog types (will be filtered by user role)
  catalogTypes: EditArticleCatalogType[] = [];

  breadcrumbItems: BreadcrumbItem[] = [
    { label: 'Dashboard', url: '/user/dashboard' },
    { label: 'Catalog', url: '/user/catalog' },
    { label: 'Edit Article', active: true }
  ];

  private subscriptions = new Subscription();

  // Quill Editor Configuration
  quillConfig = {
    toolbar: [
      ['bold', 'italic', 'underline', 'strike'],        // toggled buttons
      ['blockquote', 'code-block'],
      [{ 'header': 1 }, { 'header': 2 }],               // custom button values
      [{ 'list': 'ordered'}, { 'list': 'bullet' }],
      [{ 'script': 'sub'}, { 'script': 'super' }],      // superscript/subscript
      [{ 'indent': '-1'}, { 'indent': '+1' }],          // outdent/indent
      [{ 'direction': 'rtl' }],                         // text direction
      [{ 'size': ['small', false, 'large', 'huge'] }],  // custom dropdown
      [{ 'header': [1, 2, 3, 4, 5, 6, false] }],
      [{ 'color': [] }, { 'background': [] }],          // dropdown with defaults from theme
      [{ 'font': [] }],
      [{ 'align': [] }],
      ['clean'],                                         // remove formatting button
      ['link', 'image']                                 // link and image, video
    ]
  };

  constructor(
    private formBuilder: FormBuilder,
    private catalogService: CatalogService,
    private authService: AuthService,
    private router: Router,
    private route: ActivatedRoute
  ) {
    this.articleForm = this.createArticleForm();
  }

  ngOnInit(): void {
    // Subscribe to authentication state
    this.subscriptions.add(
      this.authService.currentUser$.subscribe((user: User | null) => {
        this.currentUser = user;
        this.setAvailableCatalogTypes();
      })
    );

    // Get article ID from route params
    this.subscriptions.add(
      this.route.params.subscribe(params => {
        if (params['id']) {
          this.articleId = params['id'];
          this.loadArticle();
        }
      })
    );
  }

  ngOnDestroy(): void {
    this.subscriptions.unsubscribe();
  }

  /**
   * Create article form with validation
   */
  private createArticleForm(): FormGroup {
    return this.formBuilder.group({
      title: ['', [Validators.required, Validators.minLength(3), Validators.maxLength(200)]],
      type: ['', [Validators.required]],
      description: ['', [Validators.maxLength(500)]],
      summary: ['', [Validators.maxLength(300)]],
      content: ['', [Validators.required, Validators.minLength(10)]],
      url: [''],
      image: [''],
      tags: [''],
      status: ['draft', [Validators.required]],
      category: [''],
      parent_id: ['']
    });
  }

  /**
   * Load article data for editing
   */
  private loadArticle(): void {
    if (!this.articleId) return;

    this.isLoading = true;
    this.errorMessage = '';

    this.subscriptions.add(
      this.catalogService.getCatalogItemForEdit(this.articleId).subscribe({
        next: (article) => {
          this.currentArticle = article;
          this.selectedCatalogType = article.type || '';
          this.populateForm(article);
          this.isLoading = false;
          
          // Update breadcrumb with article title
          this.breadcrumbItems = [
            { label: 'Dashboard', url: '/user/dashboard' },
            { label: 'Catalog', url: '/user/catalog' },
            { label: `Edit: ${article.title}`, active: true }
          ];
        },
        error: (error) => {
          console.error('Failed to load article:', error);
          this.errorMessage = 'Failed to load article. Please try again.';
          this.isLoading = false;
        }
      })
    );
  }

  /**
   * Populate form with article data
   */
  private populateForm(article: Catalog): void {
    // Convert tags array to comma-separated string
    const tagsString = Array.isArray(article.tags) ? article.tags.join(', ') : '';

    this.articleForm.patchValue({
      title: article.title || '',
      type: article.type || '',
      description: article.description || '',
      summary: article.summary || '',
      content: article.content || '',
      url: article.url || '',
      image: article.image || '',
      tags: tagsString,
      status: article.status || 'draft',
      category: article.category || '',
      parent_id: article.parent_id || ''
    });

    // Update word count if content exists
    if (article.content) {
      this.updateWordCount(article.content);
    }
  }

  /**
   * Update word count from content
   */
  private updateWordCount(content: string): void {
    // Strip HTML tags and count words
    const textContent = content.replace(/<[^>]*>/g, '');
    const words = textContent.trim().split(/\s+/).filter(word => word.length > 0);
    this.currentWordCount = words.length;
  }

  /**
   * Set available catalog types based on user role
   */
  private setAvailableCatalogTypes(): void {
    if (!this.currentUser) {
      this.catalogTypes = [];
      return;
    }

    // Get allowed catalog types for the current user role
    const allowedTypes = filterCatalogTypesByRole(this.currentUser.role);

    // Map allowed types to catalog types with descriptions from site-config
    this.catalogTypes = allowedTypes.map(type => ({
      value: type.value,
      label: type.label,
      icon: type.icon,
      color: type.color,
      background: type.background,
      description: type.description
    }));
  }

  /**
   * Handle catalog type selection
   */
  onCatalogTypeChange(type: string): void {
    this.selectedCatalogType = type;
    this.articleForm.patchValue({ type });
  }

  /**
   * Get selected catalog type details
   */
  getSelectedCatalogType(): CatalogType | null {
    return this.catalogTypes.find(ct => ct.value === this.selectedCatalogType) || null;
  }

  /**
   * Update article
   */
  updateArticle(publish: boolean = false): void {
    if (this.articleForm.invalid) {
      this.articleForm.markAllAsTouched();
      return;
    }

    this.isSaving = true;
    this.successMessage = '';
    this.errorMessage = '';

    // Transform form data to match API expectations
    const formData = this.articleForm.value;
    
    // Convert tags string to array
    const tagsArray: string[] = [];
    if (formData.tags && typeof formData.tags === 'string') {
      tagsArray.push(...formData.tags.split(',').map((tag: string) => tag.trim()).filter((tag: string) => tag));
    }

    // Prepare update data
    const updateData = {
      title: formData.title,
      type: formData.type,
      description: formData.description || '',
      summary: formData.summary || '',
      content: formData.content,
      url: formData.url || '',
      image: formData.image || '',
      tags: tagsArray,
      status: publish ? 'published' : formData.status,
      category: formData.category || '',
      parent_id: formData.parent_id || '',
      updated_date: new Date().toISOString()
    };

    console.log('Updating article data:', updateData);

    this.subscriptions.add(
      this.catalogService.updateCatalogItem(this.articleId, updateData).subscribe({
        next: (response) => {
          console.log('Article updated successfully:', response);
          this.isSaving = false;
          this.successMessage = publish ? 'Article published successfully!' : 'Article updated successfully!';
          this.errorMessage = '';
          this.articleForm.markAsPristine();
          
          // Update current article reference
          this.currentArticle = { ...this.currentArticle, ...response };
          
          // Redirect to catalog after a short delay
          setTimeout(() => {
            this.router.navigate(['/user/catalog']);
          }, 1500);
        },
        error: (error) => {
          console.error('Error updating article:', error);
          this.isSaving = false;
          
          let errorMessage = 'Failed to update article. Please try again.';
          if (error.message) {
            errorMessage = error.message;
          }
          
          this.errorMessage = errorMessage;
          this.successMessage = '';
        }
      })
    );
  }

  /**
   * Save article as draft
   */
  saveDraft(): void {
    this.articleForm.patchValue({ status: 'draft' });
    this.updateArticle(false);
  }

  /**
   * Publish article
   */
  publishArticle(): void {
    this.updateArticle(true);
  }

  /**
   * Cancel editing and go back to catalog
   */
  cancel(): void {
    this.router.navigate(['/user/catalog']);
  }

  /**
   * Handle word count changes from rich text editor
   */
  onWordCountChange(wordCount: number): void {
    this.currentWordCount = wordCount;
  }

  /**
   * Get word count
   */
  getWordCount(): number {
    return this.currentWordCount;
  }

  /**
   * Get reading time calculation
   */
  getReadingTime(): number {
    const wordsPerMinute = 200;
    return Math.max(1, Math.ceil(this.currentWordCount / wordsPerMinute));
  }

  /**
   * Get preview content method to handle HTML content
   */
  getPreviewContent(): string {
    const content = this.articleForm.get('content')?.value || '';
    return content;
  }

  /**
   * Toggle between form and preview mode
   */
  togglePreview(): void {
    this.isPreviewMode = !this.isPreviewMode;
  }

  /**
   * Handle page hero action clicks
   */
  onHeroActionClick(actionIndex: number): void {
    switch (actionIndex) {
      case 0: // Cancel
        this.cancel();
        break;
      case 1: // Preview/Edit toggle
        this.togglePreview();
        break;
    }
  }

  /**
   * Check if a form field has validation errors
   */
  hasFieldError(fieldName: string): boolean {
    const field = this.articleForm.get(fieldName);
    return !!(field && field.invalid && (field.dirty || field.touched));
  }

  /**
   * Get validation error message for a field
   */
  getFieldError(fieldName: string): string {
    const field = this.articleForm.get(fieldName);
    if (field && field.errors) {
      if (field.errors['required']) {
        return `${fieldName.charAt(0).toUpperCase() + fieldName.slice(1)} is required`;
      }
      if (field.errors['minlength']) {
        return `${fieldName.charAt(0).toUpperCase() + fieldName.slice(1)} must be at least ${field.errors['minlength'].requiredLength} characters`;
      }
      if (field.errors['maxlength']) {
        return `${fieldName.charAt(0).toUpperCase() + fieldName.slice(1)} must not exceed ${field.errors['maxlength'].requiredLength} characters`;
      }
    }
    return '';
  }

  /**
   * Get character count for a field
   */
  getCharacterCount(fieldName: string): number {
    const value = this.articleForm.get(fieldName)?.value;
    return value ? value.length : 0;
  }

  /**
   * Get maximum length for a field
   */
  getMaxLength(fieldName: string): number {
    const maxLengths: { [key: string]: number } = {
      title: 200,
      description: 500,
      summary: 300
    };
    return maxLengths[fieldName] || 0;
  }

  /**
   * Get current user display name
   */
  getUserDisplayName(): string {
    if (this.currentUser?.first_name && this.currentUser?.last_name) {
      return `${this.currentUser.first_name} ${this.currentUser.last_name}`;
    }
    return this.currentUser?.email || this.currentUser?.user_id || 'Unknown User';
  }

  /**
   * Get current date formatted
   */
  getCurrentDate(): string {
    return new Date().toLocaleDateString();
  }

  /**
   * Get preview title or placeholder
   */
  getPreviewTitle(): string {
    return this.articleForm.get('title')?.value || 'Untitled Article';
  }

  /**
   * Get preview tags as array
   */
  getPreviewTags(): string[] {
    const tags = this.articleForm.get('tags')?.value;
    if (!tags) return [];
    return tags.split(',').map((tag: string) => tag.trim()).filter((tag: string) => tag);
  }

  /**
   * Check if user can edit this article
   */
  canEditArticle(): boolean {
    if (!this.currentUser || !this.currentArticle) return false;
    
    // Admin can edit any article
    if (this.currentUser.role === 'admin') return true;
    
    // Owner can edit their own article
    return this.currentUser.id === this.currentArticle.author_id;
  }

  /**
   * Get article creation date
   */
  getArticleCreatedDate(): string {
    if (!this.currentArticle?.created_date) return '';
    return new Date(this.currentArticle.created_date).toLocaleDateString();
  }

  /**
   * Get article last updated date
   */
  getArticleUpdatedDate(): string {
    if (!this.currentArticle?.updated_date) return '';
    return new Date(this.currentArticle.updated_date).toLocaleDateString();
  }
}

// Local interface for catalog types with descriptions
interface EditArticleCatalogType {
  value: string;
  label: string;
  icon: any;
  color: string;
  background: string;
  description: string;
}
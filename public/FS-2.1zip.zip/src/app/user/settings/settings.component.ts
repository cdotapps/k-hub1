import { Component, OnInit, OnDestroy } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { UserService } from '../../shared/services/user.service';
import { AuthService } from '../../shared/services/auth.service';
import { DateUtilityService } from '../../shared/services/date-utility.service';
import { CatalogService } from '../../shared/services/catalog.service';
import { User, Catalog } from '../../shared/models/user.interface';
import { Subscription } from 'rxjs';
import { 
  faUser, faEdit, faKey, faCog, faQuestionCircle, faBuilding,
  faShieldAlt, faClock, faCheckCircle, faExclamationTriangle,
  faTimes, faSpinner, faEnvelope, faInfoCircle
} from '@fortawesome/free-solid-svg-icons';
import { BreadcrumbItem } from '../../shared/components/breadcrumb/breadcrumb.component';
import { IconDefinition } from '@fortawesome/fontawesome-svg-core';

@Component({
  selector: 'app-user-dashboard',
  templateUrl: './settings.component.html',
  styleUrls: ['./settings.component.css']
})
export class SettingsComponent implements OnInit, OnDestroy {
  currentUser: User | null = null;
  
  // UI State
  isLoading = false;
  showPasswordModal = false;
  isChangingPassword = false;
  
  // Messages
  successMessage = '';
  errorMessage = '';
  
  // Forms
  passwordForm: FormGroup;
  
  // Font Awesome icons
  faUser = faUser;
  faEdit = faEdit;
  faKey = faKey;
  faCog = faCog;
  faQuestionCircle = faQuestionCircle;
  faBuilding = faBuilding;
  faShieldAlt = faShieldAlt;
  faClock = faClock;
  faCheckCircle = faCheckCircle;
  faExclamationTriangle = faExclamationTriangle;
  faTimes = faTimes;
  faSpinner = faSpinner;
  faEnvelope = faEnvelope;
  faInfoCircle = faInfoCircle;

  // Metrics for page-hero component
  dashboardMetrics: {
    icon: IconDefinition;
    number?: number | string;
    label: string;
    status?: string;
    isActive?: boolean;
    isClickable?: boolean;
  }[] = [];

  // Notifications panel state
  notifications: Catalog[] = [];
  showNotifications = false;
  isRefreshingNotifications = false;
  
  // Recent news items
  recentNews: Catalog[] = [];
  isRefreshingNews = false;

  private subscription = new Subscription();
  private lastNotificationsRefresh = 0;
  private lastNewsRefresh = 0;

  // Breadcrumb navigation
  breadcrumbItems: BreadcrumbItem[] = [
    { label: 'Dashboard', active: true }
  ];

  constructor(
    private userService: UserService,
    private authService: AuthService,
    private formBuilder: FormBuilder,
    private dateUtilityService: DateUtilityService,
    private catalogService: CatalogService,
    private router: Router
  ) {
    this.passwordForm = this.createPasswordForm();
  }

  ngOnInit(): void {
    this.loadCurrentUser();
    this.loadRecentNotifications();
    this.loadRecentNews();
    
    // Subscribe to catalog refresh events to auto-update content
    this.subscription.add(
      this.catalogService.catalogRefresh$.subscribe(shouldRefresh => {
        if (shouldRefresh) {
          const now = Date.now();
          
          // Refresh notifications if it's been more than 1 minute
          if (now - this.lastNotificationsRefresh > 60000) {
            this.silentRefreshNotifications();
          }
          
          // Refresh news if it's been more than 2 minutes
          if (now - this.lastNewsRefresh > 120000) {
            this.silentRefreshNews();
          }
        }
      })
    );
  }

  ngOnDestroy(): void {
    this.subscription.unsubscribe();
  }

  // Initialize metrics for page-hero component
  initializeDashboardMetrics(): void {
    this.dashboardMetrics = [
      {
        icon: faUser,
        number: this.getAccountAge(),
        label: 'Days Active',
        isActive: false,
        isClickable: false
      },
      {
        icon: faEnvelope,
        status: this.currentUser?.email_verified ? 'Verified' : 'Unverified',
        label: 'Email Status',
        isActive: this.currentUser?.email_verified || false,
        isClickable: false
      },
      {
        icon: faCheckCircle,
        status: this.currentUser?.is_active ? 'Active' : 'Inactive',
        label: 'Account Status',
        isActive: this.currentUser?.is_active || false,
        isClickable: false
      },
      {
        icon: faClock,
        status: this.getLastLoginDisplay(),
        label: 'Last Login',
        isActive: false,
        isClickable: true
      }
    ];
  }

  // Handle metric click events from page-hero
  onMetricClick(index: number): void {
    if (index === 3) { // Last Login metric
      this.viewLastLogin();
    }
  }

  // Form creation methods
  private createPasswordForm(): FormGroup {
    return this.formBuilder.group({
      current_password: ['', [Validators.required]],
      new_password: ['', [Validators.required, Validators.minLength(6)]],
      confirm_password: ['', [Validators.required]]
    }, {
      validators: this.passwordMatchValidator
    });
  }

  private passwordMatchValidator(form: FormGroup) {
    const newPassword = form.get('new_password');
    const confirmPassword = form.get('confirm_password');
    
    if (newPassword && confirmPassword && newPassword.value !== confirmPassword.value) {
      confirmPassword.setErrors({ passwordMismatch: true });
    } else if (confirmPassword?.errors?.['passwordMismatch']) {
      delete confirmPassword.errors['passwordMismatch'];
      if (Object.keys(confirmPassword.errors).length === 0) {
        confirmPassword.setErrors(null);
      }
    }
    
    return null;
  }

  loadCurrentUser(): void {
    this.subscription.add(
      this.authService.currentUser$.subscribe((user: User | null) => {
        this.currentUser = user;
        this.initializeDashboardMetrics(); // Initialize metrics when user data is loaded
      })
    );
  }
  
  /**
   * Load recent notifications
   */
  loadRecentNotifications(): void {
    this.isRefreshingNotifications = true;
    
    this.subscription.add(
      this.catalogService.getNotifications({ limit: 5 }).subscribe({
        next: (notifications) => {
          this.notifications = notifications;
          this.lastNotificationsRefresh = Date.now();
          this.isRefreshingNotifications = false;
        },
        error: (error) => {
          console.error('Failed to load notifications:', error);
          this.isRefreshingNotifications = false;
        }
      })
    );
  }
  
  /**
   * Load recent news
   */
  loadRecentNews(): void {
    this.isRefreshingNews = true;
    
    this.subscription.add(
      this.catalogService.getRecentNews(3).subscribe({
        next: (news) => {
          this.recentNews = news;
          this.lastNewsRefresh = Date.now();
          this.isRefreshingNews = false;
        },
        error: (error) => {
          console.error('Failed to load news:', error);
          this.isRefreshingNews = false;
        }
      })
    );
  }
  
  /**
   * Silently refresh notifications without visual indicators
   */
  silentRefreshNotifications(): void {
    if (this.isRefreshingNotifications) return;
    
    this.isRefreshingNotifications = true;
    
    this.subscription.add(
      this.catalogService.getNotifications({ limit: 5 }).subscribe({
        next: (notifications) => {
          // Only update if there are changes
          if (this.hasNewItems(this.notifications, notifications)) {
            this.notifications = notifications;
          }
          this.lastNotificationsRefresh = Date.now();
          this.isRefreshingNotifications = false;
        },
        error: (error) => {
          console.error('Failed to refresh notifications:', error);
          this.isRefreshingNotifications = false;
        }
      })
    );
  }
  
  /**
   * Silently refresh news without visual indicators
   */
  silentRefreshNews(): void {
    if (this.isRefreshingNews) return;
    
    this.isRefreshingNews = true;
    
    this.subscription.add(
      this.catalogService.getRecentNews(3).subscribe({
        next: (news) => {
          // Only update if there are changes
          if (this.hasNewItems(this.recentNews, news)) {
            this.recentNews = news;
          }
          this.lastNewsRefresh = Date.now();
          this.isRefreshingNews = false;
        },
        error: (error) => {
          console.error('Failed to refresh news:', error);
          this.isRefreshingNews = false;
        }
      })
    );
  }
  
  /**
   * Check if there are new items in the new array compared to the current array
   */
  private hasNewItems(currentItems: Catalog[], newItems: Catalog[]): boolean {
    if (currentItems.length !== newItems.length) return true;
    
    const currentIds = new Set(currentItems.map(item => item.id));
    return newItems.some(item => !currentIds.has(item.id));
  }

  /**
   * Toggle notifications panel
   */
  toggleNotifications(): void {
    this.showNotifications = !this.showNotifications;
    
    // If opening, refresh notifications
    if (this.showNotifications) {
      this.loadRecentNotifications();
    }
  }
  
  /**
   * Handle notification click
   */
  onNotificationClicked(notification: Catalog): void {
    console.log('Notification clicked:', notification);
    
    // Handle specific notification actions based on type
    // This could navigate to specific views or trigger other actions
  }

  // Date formatting helper methods
  formatTime(dateString: string | undefined): string {
    return this.dateUtilityService.formatTime(dateString);
  }

  formatDate(dateString: string | undefined): string {
    return this.dateUtilityService.formatDate(dateString);
  }

  formatDateTime(dateString: string | undefined): string {
    return this.dateUtilityService.formatDateTime(dateString);
  }

  formatDateLong(date: Date | string): string {
    return this.dateUtilityService.formatDateLong(date);
  }

  formatRelativeTime(dateString: string): string {
    return this.dateUtilityService.formatRelativeTime(dateString);
  }

  // User display methods
  getUserInitials(): string {
    if (!this.currentUser) return 'U';
    return this.userService.getUserInitials(this.currentUser);
  }

  getUserDisplayName(): string {
    if (!this.currentUser) return 'User';
    return this.userService.getUserDisplayName(this.currentUser);
  }

  getManagerDisplayValue(): string {
    if (!this.currentUser?.manager_id) return 'No manager assigned';
    // In a real app, you would fetch manager details
    return 'Manager information not available';
  }

  // Account metrics methods
  getAccountAge(): number {
    if (!this.currentUser?.created_date) return 0;
    
    const createdDate = new Date(this.currentUser.created_date);
    const now = new Date();
    const diffTime = Math.abs(now.getTime() - createdDate.getTime());
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    return diffDays;
  }

  getLastLoginDisplay(): string {
    if (!this.currentUser?.last_login) return 'Never';
    return this.formatRelativeTime(this.currentUser.last_login);
  }

  getSessionDuration(): string {
    // This would typically come from session management
    return 'Active session';
  }

  getProfileCompletion(): number {
    if (!this.currentUser) return 0;
    
    let completed = 0;
    let total = 8;
    
    if (this.currentUser.first_name) completed++;
    if (this.currentUser.last_name) completed++;
    if (this.currentUser.email) completed++;
    if (this.currentUser.user_id) completed++;
    if (this.currentUser.designation) completed++;
    if (this.currentUser.user_type) completed++;
    if (this.currentUser.organization_id) completed++;
    if (this.currentUser.email_verified) completed++;
    
    return Math.round((completed / total) * 100);
  }

  // Navigation methods
  navigateToProfile(): void {
    this.router.navigate(['/profile']);
  }

  navigateToSettings(): void {
    // Implement settings navigation
    this.showMessage('Settings page coming soon!', 'info');
  }

  openSupport(): void {
    // Implement support functionality
    this.showMessage('Support system coming soon!', 'info');
  }

  viewLastLogin(): void {
    if (this.currentUser?.last_login) {
      const lastLogin = this.formatDateTime(this.currentUser.last_login);
      this.showMessage(`Last login: ${lastLogin}`, 'info');
    } else {
      this.showMessage('No previous login recorded', 'info');
    }
  }

  // Password management
  closePasswordModal(): void {
    this.showPasswordModal = false;
    this.passwordForm.reset();
    this.clearMessages();
  }

  changePassword(): void {
    if (this.passwordForm.invalid) {
      this.markFormGroupTouched(this.passwordForm);
      return;
    }

    this.isChangingPassword = true;
    this.clearMessages();

    const { current_password, new_password } = this.passwordForm.value;

    this.subscription.add(
      this.userService.changePassword(current_password, new_password).subscribe({
        next: () => {
          this.successMessage = 'Password changed successfully!';
          this.closePasswordModal();
          this.isChangingPassword = false;
        },
        error: (error) => {
          console.error('Failed to change password:', error);
          this.errorMessage = error.message || 'Failed to change password. Please try again.';
          this.isChangingPassword = false;
        }
      })
    );
  }

  // Form validation helpers
  hasPasswordFieldError(fieldName: string): boolean {
    const field = this.passwordForm.get(fieldName);
    return !!(field && field.invalid && (field.dirty || field.touched));
  }

  getPasswordFieldError(fieldName: string): string {
    const field = this.passwordForm.get(fieldName);
    if (field && field.errors) {
      if (field.errors['required']) return `${fieldName.replace('_', ' ')} is required`;
      if (field.errors['minlength']) return `Password must be at least 6 characters`;
      if (field.errors['passwordMismatch']) return 'Passwords do not match';
    }
    return '';
  }

  private markFormGroupTouched(formGroup: FormGroup): void {
    Object.keys(formGroup.controls).forEach(key => {
      const control = formGroup.get(key);
      control?.markAsTouched();
      
      if (control instanceof FormGroup) {
        this.markFormGroupTouched(control);
      }
    });
  }

  // Message management
  private showMessage(message: string, type: 'success' | 'error' | 'info'): void {
    if (type === 'success') {
      this.successMessage = message;
      this.errorMessage = '';
    } else {
      this.errorMessage = message;
      this.successMessage = '';
    }

    // Auto-clear messages after 5 seconds
    setTimeout(() => {
      this.clearMessages();
    }, 5000);
  }

  clearMessages(): void {
    this.successMessage = '';
    this.errorMessage = '';
  }
}
import { Component, OnInit, OnDestroy } from '@angular/core';
import { Router } from '@angular/router';
import { faHome, faChartLine, faFolder, faFileAlt, faLightbulb, faHandshake, faRocket, faUsers, faCog, faShieldAlt, faDatabase } from '@fortawesome/free-solid-svg-icons';
import { CatalogService } from '../../shared/services/catalog.service';
import { UserService } from '../../shared/services/user.service';
import { AuthService } from '../../shared/services/auth.service';
import { User } from '../../shared/models/user.interface';
import { Subscription } from 'rxjs';
import { forkJoin } from 'rxjs';

@Component({
  selector: 'app-admin-home',
  template: `
    <div class="home-container">
      <section class="hero-section">
        <app-container>
          <div class="hero-content">
            <h1 class="hero-title">Admin Control Center</h1>
            <p class="hero-subtitle">Manage your organization, monitor system performance, and oversee user activities</p>
            <app-button variant="primary" size="lg" (click)="navigateTo('admin/dashboard')">Go to Dashboard</app-button>
          </div>
        </app-container>
      </section>
      
      <!-- Overlapping Container -->
      <div class="overlap-container">
        <app-container>
          <div class="overlap-content">
            <div class="overlap-card">
              <div class="overlap-grid">
                <div class="overlap-item" (click)="navigateTo('admin/dashboard')">
                  <div class="badge-container">
                    <app-icon [faIcon]="faHome" size="lg" variant="primary"></app-icon>
                    <span class="overlap-badge" *ngIf="dashboardCount > 0">{{ dashboardCount }}</span>
                  </div>
                  <span class="overlap-text">Dashboard</span>
                </div>
                <div class="overlap-item" (click)="navigateTo('admin/users')">
                  <div class="badge-container">
                    <app-icon [faIcon]="faUsers" size="lg" variant="secondary"></app-icon>
                    <span class="overlap-badge" *ngIf="usersCount > 0">{{ usersCount }}</span>
                  </div>
                  <span class="overlap-text">Users</span>
                </div>
                <div class="overlap-item" (click)="navigateTo('admin/analytics')">
                  <div class="badge-container">
                    <app-icon [faIcon]="faChartLine" size="lg" variant="primary"></app-icon>
                    <span class="overlap-badge" *ngIf="analyticsCount > 0">{{ analyticsCount }}</span>
                  </div>
                  <span class="overlap-text">Analytics</span>
                </div>
                <div class="overlap-item" (click)="navigateTo('admin/settings')">
                  <div class="badge-container">
                    <app-icon [faIcon]="faCog" size="lg" variant="secondary"></app-icon>
                    <span class="overlap-badge" *ngIf="settingsCount > 0">{{ settingsCount }}</span>
                  </div>
                  <span class="overlap-text">Settings</span>
                </div>
              </div>
            </div>
          </div>
        </app-container>
      </div>
      
      <section class="features-section">
        <app-container>
          <h2>Administrative Tools</h2>
          <div class="features-grid">
            <app-card variant="feature" size="lg" [clickable]="true" (click)="navigateTo('admin/users')">
              <app-icon [faIcon]="faUsers" size="xl" variant="primary"></app-icon>
              <h3>User Management</h3>
              <p>Manage user accounts, roles, permissions, and organizational structure</p>
            </app-card>
            <app-card variant="feature" size="lg" [clickable]="true" (click)="navigateTo('admin/analytics')">
              <app-icon [faIcon]="faChartLine" size="xl" variant="secondary"></app-icon>
              <h3>System Analytics</h3>
              <p>Monitor system performance, user activity, and generate comprehensive reports</p>
            </app-card>
            <app-card variant="feature" size="lg" [clickable]="true" (click)="navigateTo('admin/settings')">
              <app-icon [faIcon]="faShieldAlt" size="xl" variant="success"></app-icon>
              <h3>Security & Settings</h3>
              <p>Configure system settings, security policies, and administrative preferences</p>
            </app-card>
          </div>
        </app-container>
      </section>
      
      <section class="stats-section">
        <app-container>
          <h2>System Overview</h2>
          <div class="stats-grid">
            <div class="stat-card">
              <div class="stat-icon">
                <app-icon [faIcon]="faUsers" size="xl" variant="primary"></app-icon>
              </div>
              <div class="stat-content">
                <div class="stat-number">{{ usersCount }}</div>
                <div class="stat-label">Total Users</div>
              </div>
            </div>
            <div class="stat-card">
              <div class="stat-icon">
                <app-icon [faIcon]="faFolder" size="xl" variant="secondary"></app-icon>
              </div>
              <div class="stat-content">
                <div class="stat-number">{{ projectsCount }}</div>
                <div class="stat-label">Active Projects</div>
              </div>
            </div>
            <div class="stat-card">
              <div class="stat-icon">
                <app-icon [faIcon]="faDatabase" size="xl" variant="success"></app-icon>
              </div>
              <div class="stat-content">
                <div class="stat-number">{{ resourcesCount }}</div>
                <div class="stat-label">Resources</div>
              </div>
            </div>
            <div class="stat-card">
              <div class="stat-icon">
                <app-icon [faIcon]="faChartLine" size="xl" variant="warning"></app-icon>
              </div>
              <div class="stat-content">
                <div class="stat-number">{{ analyticsCount }}</div>
                <div class="stat-label">Reports</div>
              </div>
            </div>
          </div>
        </app-container>
      </section>
    </div>
  `,
  styles: [`
    .home-container {
      width: 100%;
      position: relative;
    }
    
    .hero-section {
      background: linear-gradient(135deg, var(--fm-primary-hero) 0%, var(--fm-secondary-hero) 100%);
      color: var(--fm-white);
      padding: 4rem 0;
      text-align: center;
      min-height: 400px;
      display: flex;
      align-items: center;
      justify-content: center;
      position: relative;
      z-index: 1;
    }
    
    .hero-content {
      max-width: 700px;
      margin: 0 auto;
    }
    
    .hero-title {
      font-size: 3rem;
      font-weight: 700;
      margin-bottom: 1rem;
      line-height: 1.2;
      color: var(--fm-white);
    }
    
    .hero-subtitle {
      font-size: 1.25rem;
      margin-bottom: 2rem;
      opacity: 0.85;
      line-height: 1.5;
      color: var(--fm-white);
    }
    
    /* Overlapping Container Styles */
    .overlap-container {
      position: relative;
      z-index: 10;
      max-height: 100px;
      margin-top: -50px;
      margin-bottom: 50px;
    }
    
    .overlap-content {
      display: flex;
      justify-content: center;
      align-items: center;
    }
    
    .overlap-card {
      background: var(--fm-white);
      border-radius: 50px 0px 50px 0px;
      box-shadow: 0 20px 60px rgba(0, 0, 0, 0.1);
      padding: 1rem 2rem;
      width: 100%;
      max-width: 700px;
      border: 1px solid rgba(0, 0, 0, 0.05);
    }
    
    .overlap-grid {
      display: flex;
      flex-direction: row;
      justify-content: space-between;
      align-items: center;
      gap: 1rem;
      flex-wrap: nowrap;
      overflow-x: auto;
    }
    
    .overlap-item {
      margin-top: 10px;
      text-align: center;
      padding: 0.5rem;
      display: flex;
      flex-direction: column;
      justify-content: center;
      align-items: center;
      flex-shrink: 0;
      width: 90px;
      height: 90px;
      cursor: pointer;
      border-radius: 12px;
      transition: all 0.3s ease;
      position: relative;
      overflow: hidden;
      border: 0px solid rgba(0, 0, 0, 0.1);
    }
    
    .badge-container {
      position: relative;
      display: inline-block;
      margin-bottom: 0.5rem;
    }
    
    .overlap-badge {
      position: absolute;
      top: -5px;
      right: -20px;
      background: var(--fm-red);
      color: white;
      border-radius: 50%;
      width: 30px;
      height: 30px;
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 0.8rem;
      font-weight: 700;
      border: 2px solid white;
      box-shadow: 0 2px 4px rgba(0, 0, 0, 0.2);
      transition: all 0.3s ease;
      z-index: 10;
    }
    
    .overlap-item:hover .overlap-badge {
      background: var(--fm-orange);
      transform: scale(1.1);
    }
    
    .overlap-item::before {
      content: '';
      position: absolute;
      top: 0;
      left: -100%;
      width: 100%;
      height: 100%;
      background: linear-gradient(90deg, transparent, rgba(255,255,255,0.2), transparent);
      transition: left 0.5s;
    }
    
    .overlap-item:hover::before {
      left: 100%;
    }
    
    .overlap-item:hover {
      background: linear-gradient(135deg, var(--fm-primary-blue), var(--fm-secondary-blue));
      color: white;
      transform: translateY(-5px);
      box-shadow: 0 8px 25px rgba(0, 63, 127, 0.3);
    }
    
    .overlap-item:hover .overlap-text {
      color: white;
    }
    
    .overlap-item:active {
      transform: translateY(-2px);
      transition: transform 0.1s ease;
    }
    
    .overlap-text {
      font-size: 0.875rem;
      font-weight: 600;
      color: var(--fm-text-primary);
      padding: 0 0.5rem;
      line-height: 1.2;
      transition: color 0.3s ease;
    }
    
    .features-section {
      padding: 3rem 0;
      background: var(--fm-bg-light);
    }
    
    .features-section h2 {
      text-align: center;
      font-size: 2.5rem;
      font-weight: 700;
      margin-bottom: 3rem;
      color: var(--fm-text-primary);
    }
    
    .features-grid {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
      gap: 2rem;
      margin-top: 2rem;
    }
    
    .stats-section {
      padding: 3rem 0;
      background: var(--fm-white);
    }
    
    .stats-section h2 {
      text-align: center;
      font-size: 2.5rem;
      font-weight: 700;
      margin-bottom: 3rem;
      color: var(--fm-text-primary);
    }
    
    .stats-grid {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
      gap: 2rem;
      margin-top: 2rem;
    }
    
    .stat-card {
      background: var(--fm-white);
      border-radius: 12px;
      padding: 2rem;
      text-align: center;
      box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
      border: 1px solid #e9ecef;
      transition: all 0.3s ease;
    }
    
    .stat-card:hover {
      transform: translateY(-5px);
      box-shadow: 0 8px 25px rgba(0, 0, 0, 0.15);
    }
    
    .stat-icon {
      margin-bottom: 1rem;
    }
    
    .stat-number {
      font-size: 2.5rem;
      font-weight: 700;
      color: var(--fm-text-primary);
      margin-bottom: 0.5rem;
    }
    
    .stat-label {
      font-size: 1rem;
      color: var(--fm-text-secondary);
      font-weight: 500;
    }
    
    /* Responsive Design */
    @media (max-width: 768px) {
      .hero-title {
        font-size: 2rem;
      }
      
      .hero-subtitle {
        font-size: 1rem;
      }
      
      .overlap-container {
        margin-top: -80px;
        margin-bottom: 80px;
      }
      
      .overlap-card {
        padding: 1.25rem 0.75rem;
        border-radius: 15px;
        max-width: 500px;
      }
      
      .overlap-grid {
        gap: 0.5rem;
        justify-content: space-around;
        padding: 0 0.25rem;
      }
      
      .overlap-item {
        min-width: 70px;
        padding: 0.5rem 0.25rem;
      }
      
      .overlap-text {
        font-size: 0.75rem;
      }
      
      .features-section h2,
      .stats-section h2 {
        font-size: 2rem;
      }
      
      .stats-grid {
        grid-template-columns: repeat(auto-fit, minmax(150px, 1fr));
        gap: 1rem;
      }
      
      .stat-card {
        padding: 1.5rem;
      }
      
      .stat-number {
        font-size: 2rem;
      }
    }
  `]
})
export class AdminHomeComponent implements OnInit, OnDestroy {
  // Font Awesome icons
  faHome = faHome;
  faChartLine = faChartLine;
  faFolder = faFolder;
  faFileAlt = faFileAlt;
  faLightbulb = faLightbulb;
  faHandshake = faHandshake;
  faRocket = faRocket;
  faUsers = faUsers;
  faCog = faCog;
  faShieldAlt = faShieldAlt;
  faDatabase = faDatabase;

  // Badge counts from API
  dashboardCount = 0;
  usersCount = 0;
  projectsCount = 0;
  analyticsCount = 0;
  resourcesCount = 0;
  settingsCount = 0;
  
  private subscription = new Subscription();

  constructor(
    private router: Router,
    private catalogService: CatalogService,
    private userService: UserService,
    private authService: AuthService
  ) { }

  ngOnInit(): void {
    this.loadAdminCounts();
  }

  ngOnDestroy(): void {
    this.subscription.unsubscribe();
  }

  /**
   * Load admin dashboard counts from API
   */
  private loadAdminCounts(): void {
    this.subscription.add(
      forkJoin({
        projects: this.catalogService.getCatalogItems({ type: 'project', limit: 1 }),
        analytics: this.catalogService.getCatalogItems({ type: 'analytics', limit: 1 }),
        resources: this.catalogService.getCatalogItems({ type: 'document', limit: 1 }),
        users: this.userService.getUsers({ limit: 1 })
      }).subscribe({
        next: (results) => {
          this.projectsCount = results.projects.total || 0;
          this.analyticsCount = results.analytics.total || 0;
          this.resourcesCount = results.resources.total || 0;
          this.usersCount = Array.isArray(results.users) ? results.users.length : 0;
          
          // Set admin-specific counts
          this.dashboardCount = this.calculateAdminDashboardItems();
          this.settingsCount = this.calculateSettingsItems();
        },
        error: (error) => {
          console.error('Failed to load admin counts:', error);
          // Set fallback values
          this.dashboardCount = 0;
          this.usersCount = 0;
          this.projectsCount = 0;
          this.analyticsCount = 0;
          this.resourcesCount = 0;
          this.settingsCount = 0;
        }
      })
    );
  }

  /**
   * Calculate admin dashboard items count
   */
  private calculateAdminDashboardItems(): number {
    // Admin dashboard could show pending approvals, alerts, etc.
    return Math.min(this.usersCount + this.projectsCount, 99);
  }

  /**
   * Calculate settings items count
   */
  private calculateSettingsItems(): number {
    // Could represent pending configurations, alerts, etc.
    return Math.floor(Math.random() * 5); // Placeholder
  }
  
  navigateTo(section: string): void {
    console.log(`Admin navigating to: ${section}`);
    this.router.navigate([section]);
  }
}
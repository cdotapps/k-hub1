import { Component, OnInit, OnDestroy } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { UserService } from '../../shared/services/user.service';
import { AuthService } from '../../shared/services/auth.service';
import { DateUtilityService } from '../../shared/services/date-utility.service';
import { User, UserCreate, UserDesignation } from '../../shared/models/user.interface';
import { SearchSuggestion, SearchOptions } from '../../shared/components/search/search.component';
import { Subscription } from 'rxjs';
import { Chart, ChartConfiguration, ChartData, ChartEvent, ChartType } from 'chart.js';
import { 
  faUsers, faUserPlus, faEdit, faTrash, faSearch, 
  faFilter, faSort, faEye, faUserShield, faUserCheck,
  faSpinner, faExclamationTriangle, faCheckCircle,
  faTimes, faSave, faUserCog, faChartBar, faChartLine,
  faSync, faShieldAlt, faClock, faUser, faCheck,
  faArrowTrendUp, faCalendarAlt, faGlobe, faPause, faPlay,
  faDownload, faKey, faBan, faToggleOn, faToggleOff, faBuilding
} from '@fortawesome/free-solid-svg-icons';
import { BreadcrumbItem } from '../../shared/components/breadcrumb/breadcrumb.component';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit, OnDestroy {
  users: User[] = [];
  filteredUsers: User[] = [];
  currentUser: User | null = null;
  
  // Manager selection for dropdown
  availableManagers: User[] = [];
  
  // Designation options
  designationOptions = Object.values(UserDesignation);
  
  // UI State
  isLoading = false;
  isCreatingUser = false;
  isEditingUser = false;
  editingUserId: string | null = null;
  showUserModal = false;
  
  // Messages
  successMessage = '';
  errorMessage = '';
  
  // Track original form values for change detection
  private originalFormValues: any = {};
  
  // Search and Filter
  searchTerm = '';
  selectedRole = '';
  selectedStatus = '';
  sortBy = 'created_date';
  sortDirection: 'asc' | 'desc' = 'desc';
  
  // Modern Search Component Properties
  isSearching = false;
  searchSuggestions: SearchSuggestion[] = [];
  searchOptions: SearchOptions = {
    showSuggestions: true,
    showHistory: true,
    maxHistoryItems: 5,
    maxSuggestions: 8,
    debounceTime: 300,
    minSearchLength: 1,
    caseSensitive: false
  };
  
  // Forms
  userForm: FormGroup;
  editForm: FormGroup;
  passwordForm: FormGroup;
  
  // Form control states
  private isFormDisabled = false;

  // Statistics
  totalUsers = 0;
  activeUsers = 0;
  adminUsers = 0;
  recentLogins = 0;
  inactiveUsers = 0;
  unverifiedUsers = 0;
  pendingRequests = 0;
  
  // Chart Data
  userActivityChartData: ChartData<'line'> = {
    labels: [],
    datasets: []
  };
  
  userRoleChartData: ChartData<'doughnut'> = {
    labels: [],
    datasets: []
  };
  
  userGrowthChartData: ChartData<'bar'> = {
    labels: [],
    datasets: []
  };

  // Chart Options
  lineChartOptions: ChartConfiguration['options'] = {
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
      legend: {
        display: true,
        position: 'top'
      }
    },
    scales: {
      y: {
        beginAtZero: true,
        grid: {
          color: 'rgba(0, 0, 0, 0.05)'
        }
      },
      x: {
        grid: {
          color: 'rgba(0, 0, 0, 0.05)'
        }
      }
    }
  };

  doughnutChartOptions: ChartConfiguration['options'] = {
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
      legend: {
        position: 'bottom'
      }
    }
  };

  barChartOptions: ChartConfiguration['options'] = {
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
      legend: {
        display: false
      }
    },
    scales: {
      y: {
        beginAtZero: true,
        grid: {
          color: 'rgba(0, 0, 0, 0.05)'
        }
      },
      x: {
        grid: {
          display: false
        }
      }
    }
  };
  
  // Font Awesome icons
  faUsers = faUsers;
  faUserPlus = faUserPlus;
  faEdit = faEdit;
  faTrash = faTrash;
  faSearch = faSearch;
  faFilter = faFilter;
  faSort = faSort;
  faEye = faEye;
  faUserShield = faUserShield;
  faUserCheck = faUserCheck;
  faSpinner = faSpinner;
  faExclamationTriangle = faExclamationTriangle;
  faCheckCircle = faCheckCircle;
  faTimes = faTimes;
  faSave = faSave;
  faUserCog = faUserCog;
  faChartBar = faChartBar;
  faChartLine = faChartLine;
  faSync = faSync;
  faShieldAlt = faShieldAlt;
  faClock = faClock;
  faUser = faUser;
  faCheck = faCheck;
  faArrowTrendUp = faArrowTrendUp;
  faCalendarAlt = faCalendarAlt;
  faGlobe = faGlobe;
  faPause = faPause;
  faPlay = faPlay;
  faDownload = faDownload;
  faKey = faKey;
  faBan = faBan;
  faToggleOn = faToggleOn;
  faToggleOff = faToggleOff;
  faBuilding = faBuilding;

  private subscription = new Subscription();

  // Breadcrumb navigation
  breadcrumbItems: BreadcrumbItem[] = [
    { label: 'Admin', url: '/admin' },
    { label: 'User Management', active: true }
  ];

  // Modal states
  selectedUser: User | null = null;
  modalTitle = '';
  isEditing = false;
  showPasswordModal = false;

  constructor(
    private userService: UserService,
    private authService: AuthService,
    private formBuilder: FormBuilder,
    private dateUtilityService: DateUtilityService
  ) {
    this.userForm = this.createUserForm();
    this.editForm = this.createUserForm();
    this.passwordForm = this.createPasswordForm();
  }

  ngOnInit(): void {
    this.loadCurrentUser();
    this.loadUsers();
    this.initializeCharts();
  }

  ngOnDestroy(): void {
    this.subscription.unsubscribe();
  }

  // Date formatting helper methods
  formatTime(dateString: string | undefined): string {
    return this.dateUtilityService.formatTime(dateString);
  }

  formatDate(dateString: string | undefined): string {
    return this.dateUtilityService.formatDate(dateString);
  }

  formatDateTime(dateString: string | undefined): string {
    return this.dateUtilityService.formatDateTime(dateString);
  }

  formatDateLong(date: Date | string): string {
    return this.dateUtilityService.formatDateLong(date);
  }

  formatShortDate(dateString: string): string {
    return this.dateUtilityService.formatShortDate(dateString);
  }

  formatRelativeTime(dateString: string): string {
    return this.dateUtilityService.formatRelativeTime(dateString);
  }

  formatTimeAgo(dateString: string): string {
    return this.dateUtilityService.formatTimeAgo(dateString);
  }

  formatMonthYear(dateString: string): string {
    return this.dateUtilityService.formatMonthYear(dateString);
  }

  // Form creation methods
  private createUserForm(): FormGroup {
    return this.formBuilder.group({
      user_id: ['', [Validators.required, Validators.minLength(3)]],
      email: ['', [Validators.email]],
      first_name: ['', [Validators.required, Validators.minLength(1)]],
      last_name: ['', [Validators.required, Validators.minLength(1)]],
      password: ['', [Validators.required, Validators.minLength(6)]],
      role: ['user', [Validators.required]],
      is_active: [true],
      is_superuser: [false],
      email_verified: [false],
      manager_id: [''],
      portfolio_id: [''],
      organization_id: [''],
      costcenter_id: [''],
      user_type: [''],
      designation: [''],
      status: ['']
    });
  }

  private createPasswordForm(): FormGroup {
    return this.formBuilder.group({
      current_password: ['', [Validators.required]],
      new_password: ['', [Validators.required, Validators.minLength(6)]],
      confirm_password: ['', [Validators.required]]
    }, {
      validators: this.passwordMatchValidator
    });
  }

  private passwordMatchValidator(form: FormGroup) {
    const newPassword = form.get('new_password');
    const confirmPassword = form.get('confirm_password');
    
    if (newPassword && confirmPassword && newPassword.value !== confirmPassword.value) {
      confirmPassword.setErrors({ passwordMismatch: true });
    } else if (confirmPassword?.errors?.['passwordMismatch']) {
      delete confirmPassword.errors['passwordMismatch'];
      if (Object.keys(confirmPassword.errors).length === 0) {
        confirmPassword.setErrors(null);
      }
    }
    
    return null;
  }

  loadCurrentUser(): void {
    this.subscription.add(
      this.authService.currentUser$.subscribe((user: User | null) => {
        this.currentUser = user;
      })
    );
  }

  loadUsers(): void {
    this.isLoading = true;
    this.clearMessages();
    
    this.subscription.add(
      this.userService.getAllUsers({ page: 1, page_size: 100 }).subscribe({
        next: (users) => {
          this.users = users;
          this.filteredUsers = users;
          this.updateAvailableManagers();
          this.calculateStats();
          this.applyFilters();
          this.updateChartsWithRealData();
          this.isLoading = false;
          
          if (users.length === 0) {
            this.errorMessage = 'No users found. The system may be empty or there may be a connection issue.';
          }
        },
        error: (error) => {
          console.error('Failed to load users:', error);
          this.errorMessage = `Failed to load users: ${error.message || 'Please check your connection and try again.'}`;
          this.isLoading = false;
          this.users = [];
          this.filteredUsers = [];
          this.calculateStats();
        }
      })
    );
  }

  // Manager selection methods
  updateAvailableManagers(): void {
    // Filter users who can be managers (exclude the user being edited)
    this.availableManagers = this.users.filter(user => {
      if (this.editingUserId && user.id === this.editingUserId) {
        return false; // Can't be their own manager
      }
      return true;
    }).sort((a, b) => {
      const nameA = this.getUserDisplayName(a).toLowerCase();
      const nameB = this.getUserDisplayName(b).toLowerCase();
      return nameA.localeCompare(nameB);
    });
  }

  onManagerSelectionChange(event: any): void {
    const selectedManagerId = event.target.value;
    const form = this.isCreatingUser ? this.userForm : this.editForm;
    form.get('manager_id')?.setValue(selectedManagerId || '');
  }

  onManagerSelected(user: User | null): void {
    const form = this.isCreatingUser ? this.userForm : this.editForm;
    form.get('manager_id')?.setValue(user?.id || '');
  }

  getSelectedManagerName(managerId: string | undefined): string {
    if (!managerId) return 'No manager assigned';
    const manager = this.users.find(user => user.id === managerId);
    return manager ? this.getUserDisplayName(manager) : 'Manager not found';
  }

  calculateStats(): void {
    this.totalUsers = this.users.length;
    this.activeUsers = this.users.filter(user => user.is_active).length;
    this.inactiveUsers = this.users.filter(user => !user.is_active).length;
    this.adminUsers = this.users.filter(user => user.role === 'admin' || user.is_superuser).length;
    this.unverifiedUsers = this.users.filter(user => !user.email_verified).length;
    this.recentLogins = this.users.filter(user => {
      if (!user.last_login) return false;
      const lastLogin = new Date(user.last_login);
      const thirtyDaysAgo = new Date();
      thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 30);
      return lastLogin > thirtyDaysAgo;
    }).length;
  }

  applyFilters(): void {
    let filtered = [...this.users];

    // Search filter
    if (this.searchTerm) {
      const term = this.searchTerm.toLowerCase();
      filtered = filtered.filter(user => 
        user.first_name?.toLowerCase().includes(term) ||
        user.last_name?.toLowerCase().includes(term) ||
        user.email?.toLowerCase().includes(term) ||
        user.user_id?.toLowerCase().includes(term) ||
        this.userService.getUserDisplayName(user).toLowerCase().includes(term)
      );
    }

    // Role filter
    if (this.selectedRole) {
      filtered = filtered.filter(user => user.role === this.selectedRole);
    }

    // Status filter - simplified to only Active/Inactive
    if (this.selectedStatus) {
      switch (this.selectedStatus) {
        case 'active':
          filtered = filtered.filter(user => user.is_active);
          break;
        case 'inactive':
          filtered = filtered.filter(user => !user.is_active);
          break;
      }
    }

    // Sort
    filtered.sort((a, b) => {
      let aValue: any = a[this.sortBy as keyof User];
      let bValue: any = b[this.sortBy as keyof User];

      if (typeof aValue === 'string') aValue = aValue.toLowerCase();
      if (typeof bValue === 'string') bValue = bValue.toLowerCase();

      if (this.sortDirection === 'asc') {
        return aValue > bValue ? 1 : -1;
      } else {
        return aValue < bValue ? 1 : -1;
      }
    });

    this.filteredUsers = filtered;
  }

  onFilterChange(): void {
    this.applyFilters();
  }

  onSortChange(): void {
    this.applyFilters();
  }

  toggleSortDirection(): void {
    this.sortDirection = this.sortDirection === 'asc' ? 'desc' : 'asc';
    this.applyFilters();
  }

  // User CRUD Operations
  showCreateUserModal(): void {
    this.isCreatingUser = true;
    this.showUserModal = true;
    this.updateAvailableManagers();
    this.userForm.reset();
    this.userForm.patchValue({
      role: 'user',
      is_active: true,
      is_superuser: false,
      email_verified: false
    });
    this.clearMessages();
  }

  showEditUserModal(user: User): void {
    this.isEditingUser = true;
    this.editingUserId = user.id;
    this.updateAvailableManagers();
    this.showUserModal = true;
    
    const formValues = {
      user_id: user.user_id,
      email: user.email,
      first_name: user.first_name,
      last_name: user.last_name,
      role: user.role,
      is_active: user.is_active,
      is_superuser: user.is_superuser,
      email_verified: user.email_verified,
      manager_id: user.manager_id,
      portfolio_id: user.portfolio_id,
      organization_id: user.organization_id,
      costcenter_id: user.costcenter_id,
      user_type: user.user_type,
      designation: user.designation,
      status: user.status
    };
    
    this.editForm.patchValue(formValues);
    this.originalFormValues = { ...formValues };
    
    // Remove password requirement for editing
    this.editForm.get('password')?.clearValidators();
    this.editForm.get('password')?.updateValueAndValidity();
    this.clearMessages();
  }

  closeModal(): void {
    this.showUserModal = false;
    this.showPasswordModal = false;
    this.isCreatingUser = false;
    this.isEditingUser = false;
    this.editingUserId = null;
    this.selectedUser = null;
    this.userForm.reset();
    this.editForm.reset();
    this.passwordForm.reset();
    this.clearMessages();
  }

  createUser(): void {
    if (this.userForm.invalid) {
      this.markFormGroupTouched(this.userForm);
      return;
    }

    this.isLoading = true;
    this.clearMessages();

    const userData: UserCreate = this.userForm.value;

    this.subscription.add(
      this.userService.createUser(userData).subscribe({
        next: (newUser) => {
          this.users.push(newUser);
          this.applyFilters();
          this.calculateStats();
          this.updateChartsWithRealData();
          this.closeModal();
          this.successMessage = `User "${this.userService.getUserDisplayName(newUser)}" created successfully!`;
          this.isLoading = false;
        },
        error: (error) => {
          console.error('Failed to create user:', error);
          this.errorMessage = error.message || 'Failed to create user. Please try again.';
          this.isLoading = false;
        }
      })
    );
  }

  updateUser(): void {
    if (this.editForm.invalid || !this.editingUserId) {
      this.markFormGroupTouched(this.editForm);
      return;
    }

    this.isLoading = true;
    this.clearMessages();

    const formData = { ...this.editForm.value };
    delete formData.password; // Remove password field for updates

    this.subscription.add(
      this.userService.updateUserById(this.editingUserId, formData).subscribe({
        next: (updatedUser) => {
          const index = this.users.findIndex(u => u.id === this.editingUserId);
          if (index !== -1) {
            this.users[index] = updatedUser;
            this.applyFilters();
            this.calculateStats();
            this.updateChartsWithRealData();
          }
          this.closeModal();
          this.successMessage = `User "${this.userService.getUserDisplayName(updatedUser)}" updated successfully!`;
          this.isLoading = false;
        },
        error: (error) => {
          console.error('Failed to update user:', error);
          this.errorMessage = error.message || 'Failed to update user. Please try again.';
          this.isLoading = false;
        }
      })
    );
  }

  deleteUser(user: User): void {
    const displayName = this.userService.getUserDisplayName(user);
    if (!confirm(`Are you sure you want to delete user "${displayName}"? This action cannot be undone.`)) {
      return;
    }

    this.isLoading = true;
    this.clearMessages();

    this.subscription.add(
      this.userService.deleteUser(user.id).subscribe({
        next: () => {
          this.users = this.users.filter(u => u.id !== user.id);
          this.applyFilters();
          this.calculateStats();
          this.updateChartsWithRealData();
          this.successMessage = `User "${displayName}" deleted successfully!`;
          this.isLoading = false;
        },
        error: (error) => {
          console.error('Failed to delete user:', error);
          this.errorMessage = error.message || 'Failed to delete user. Please try again.';
          this.isLoading = false;
        }
      })
    );
  }

  // User status and role management
  toggleUserStatus(user: User): void {
    this.isLoading = true;
    this.clearMessages();

    this.subscription.add(
      this.userService.toggleUserStatus(user.id).subscribe({
        next: (updatedUser) => {
          const index = this.users.findIndex(u => u.id === user.id);
          if (index !== -1) {
            this.users[index] = updatedUser;
            this.applyFilters();
            this.calculateStats();
            this.updateChartsWithRealData();
          }
          const statusText = updatedUser.is_active ? 'activated' : 'deactivated';
          this.successMessage = `User "${this.userService.getUserDisplayName(updatedUser)}" ${statusText} successfully!`;
          this.isLoading = false;
        },
        error: (error) => {
          console.error('Failed to toggle user status:', error);
          this.errorMessage = error.message || 'Failed to update user status. Please try again.';
          this.isLoading = false;
        }
      })
    );
  }

  updateUserRole(user: User, newRole: 'user' | 'admin'): void {
    if (!confirm(`Are you sure you want to change ${this.userService.getUserDisplayName(user)}'s role to ${newRole}?`)) {
      return;
    }

    this.isLoading = true;
    this.clearMessages();

    this.subscription.add(
      this.userService.updateUserRole(user.id, newRole).subscribe({
        next: (updatedUser) => {
          const index = this.users.findIndex(u => u.id === user.id);
          if (index !== -1) {
            this.users[index] = updatedUser;
            this.applyFilters();
            this.calculateStats();
            this.updateChartsWithRealData();
          }
          this.successMessage = `User role updated to ${newRole} successfully!`;
          this.isLoading = false;
        },
        error: (error) => {
          console.error('Failed to update user role:', error);
          this.errorMessage = error.message || 'Failed to update user role. Please try again.';
          this.isLoading = false;
        }
      })
    );
  }

  // Password management
  showChangePasswordModal(user: User): void {
    this.selectedUser = user;
    this.showPasswordModal = true;
    this.passwordForm.reset();
    this.clearMessages();
  }

  changeUserPassword(): void {
    if (this.passwordForm.invalid || !this.selectedUser) {
      this.markFormGroupTouched(this.passwordForm);
      return;
    }

    this.isLoading = true;
    this.clearMessages();

    const { current_password, new_password } = this.passwordForm.value;

    this.subscription.add(
      this.userService.changePassword(current_password, new_password).subscribe({
        next: () => {
          this.successMessage = 'Password changed successfully!';
          this.closeModal();
          this.isLoading = false;
        },
        error: (error) => {
          console.error('Failed to change password:', error);
          this.errorMessage = error.message || 'Failed to change password. Please try again.';
          this.isLoading = false;
        }
      })
    );
  }

  // Additional methods needed by the template
  refreshUsers(): void {
    this.loadUsers();
  }

  getUserInitials(user: User): string {
    return this.userService.getUserInitials(user);
  }

  getUserDisplayName(user: User): string {
    return this.userService.getUserDisplayName(user);
  }

  getStatusDisplay(user: User): string {
    if (!user.is_active) return 'Inactive';
    if (user.email_verified === false) return 'Unverified';
    return 'Active';
  }

  getStatusClass(user: User): string {
    if (!user.is_active) return 'inactive';
    if (user.email_verified === false) return 'pending';
    return 'active';
  }

  canToggleStatus(user: User): boolean {
    // Only admins can toggle status, and can't toggle their own status
    return this.currentUser?.role === 'admin' && this.currentUser?.id !== user.id;
  }

  canEditUser(user: User): boolean {
    // Admins can edit any user except themselves, users can't edit anyone
    if (this.currentUser?.role === 'admin') {
      return this.currentUser?.id !== user.id;
    }
    return false;
  }

  canDeleteUser(user: User): boolean {
    // Only admins can delete users, and can't delete themselves
    return this.currentUser?.role === 'admin' && this.currentUser?.id !== user.id;
  }

  quickToggleStatus(user: User): void {
    this.toggleUserStatus(user);
  }

  approveUser(user: User): void {
    if (!confirm(`Are you sure you want to approve user "${this.getUserDisplayName(user)}"?`)) {
      return;
    }

    this.isLoading = true;
    this.clearMessages();

    // Update user to active status
    this.subscription.add(
      this.userService.updateUserById(user.id, { is_active: true }).subscribe({
        next: (updatedUser) => {
          const index = this.users.findIndex(u => u.id === user.id);
          if (index !== -1) {
            this.users[index] = updatedUser;
            this.applyFilters();
            this.calculateStats();
          }
          this.successMessage = `User "${this.getUserDisplayName(updatedUser)}" approved successfully!`;
          this.isLoading = false;
          this.closeModal();
        },
        error: (error) => {
          console.error('Failed to approve user:', error);
          this.errorMessage = error.message || 'Failed to approve user. Please try again.';
          this.isLoading = false;
        }
      })
    );
  }

  rejectUser(user: User): void {
    if (!confirm(`Are you sure you want to reject user "${this.getUserDisplayName(user)}"? This will delete their account.`)) {
      return;
    }

    this.deleteUser(user);
  }

  editUser(user: User): void {
    this.showEditUserModal(user);
  }

  viewUserDetails(user: User): void {
    this.selectedUser = user;
    this.modalTitle = `User Details - ${this.getUserDisplayName(user)}`;
    this.isCreatingUser = false;
    this.isEditing = false;
    this.showUserModal = true;
    this.clearMessages();
  }

  startEditing(): void {
    if (this.selectedUser) {
      this.isEditing = true;
      this.isEditingUser = true; // Set both flags for consistency
      this.editingUserId = this.selectedUser.id;
      this.updateAvailableManagers();
      
      const formValues = {
        user_id: this.selectedUser.user_id,
        email: this.selectedUser.email,
        first_name: this.selectedUser.first_name,
        last_name: this.selectedUser.last_name,
        role: this.selectedUser.role,
        is_active: this.selectedUser.is_active,
        is_superuser: this.selectedUser.is_superuser,
        email_verified: this.selectedUser.email_verified,
        manager_id: this.selectedUser.manager_id,
        portfolio_id: this.selectedUser.portfolio_id,
        organization_id: this.selectedUser.organization_id,
        costcenter_id: this.selectedUser.costcenter_id,
        user_type: this.selectedUser.user_type,
        designation: this.selectedUser.designation,
        status: this.selectedUser.status
      };
      
      // Use editForm and ensure password validation is cleared
      this.editForm.patchValue(formValues);
      this.originalFormValues = { ...formValues };
      
      // Remove password requirement for editing
      this.editForm.get('password')?.clearValidators();
      this.editForm.get('password')?.updateValueAndValidity();
    }
  }

  // Quick action methods for admin users
  quickToggleUserStatus(user: User): void {
    if (!this.userService.canChangeUserStatus(user)) {
      this.errorMessage = 'You do not have permission to change this user\'s status.';
      return;
    }

    const action = user.is_active ? 'disable' : 'enable';
    const displayName = this.getUserDisplayName(user);
    
    if (!confirm(`Are you sure you want to ${action} user "${displayName}"?`)) {
      return;
    }

    this.isLoading = true;
    this.clearMessages();

    this.subscription.add(
      this.userService.updateUserStatus(user.id, !user.is_active).subscribe({
        next: (updatedUser) => {
          const index = this.users.findIndex(u => u.id === user.id);
          if (index !== -1) {
            this.users[index] = updatedUser;
            this.applyFilters();
            this.calculateStats();
            this.updateChartsWithRealData();
          }
          const statusText = updatedUser.is_active ? 'enabled' : 'disabled';
          this.successMessage = `User "${this.getUserDisplayName(updatedUser)}" ${statusText} successfully!`;
          this.isLoading = false;
        },
        error: (error) => {
          console.error('Failed to update user status:', error);
          this.errorMessage = error.message || 'Failed to update user status. Please try again.';
          this.isLoading = false;
        }
      })
    );
  }

  quickToggleUserRole(user: User): void {
    if (!this.userService.canChangeUserRole(user)) {
      this.errorMessage = 'You do not have permission to change this user\'s role.';
      return;
    }

    const newRole = user.role === 'admin' ? 'user' : 'admin';
    const displayName = this.getUserDisplayName(user);
    
    if (!confirm(`Are you sure you want to change "${displayName}"'s role to ${newRole}?`)) {
      return;
    }

    this.isLoading = true;
    this.clearMessages();

    this.subscription.add(
      this.userService.updateUserRole(user.id, newRole).subscribe({
        next: (updatedUser) => {
          const index = this.users.findIndex(u => u.id === user.id);
          if (index !== -1) {
            this.users[index] = updatedUser;
            this.applyFilters();
            this.calculateStats();
            this.updateChartsWithRealData();
          }
          this.successMessage = `User "${this.getUserDisplayName(updatedUser)}" role updated to ${newRole} successfully!`;
          this.isLoading = false;
        },
        error: (error) => {
          console.error('Failed to update user role:', error);
          this.errorMessage = error.message || 'Failed to update user role. Please try again.';
          this.isLoading = false;
        }
      })
    );
  }

  // Add permission check methods using UserService
  canChangeUserStatus(user: User): boolean {
    return this.userService.canChangeUserStatus(user);
  }

  canChangeUserRole(user: User): boolean {
    return this.userService.canChangeUserRole(user);
  }

  // Form validation helpers
  hasFieldError(fieldName: string): boolean {
    const form = this.isCreatingUser ? this.userForm : this.editForm;
    const field = form.get(fieldName);
    return !!(field && field.invalid && (field.dirty || field.touched));
  }

  getFieldError(fieldName: string): string {
    const form = this.isCreatingUser ? this.userForm : this.editForm;
    const field = form.get(fieldName);
    if (field && field.errors) {
      if (field.errors['required']) return `${fieldName.replace('_', ' ')} is required`;
      if (field.errors['email']) return 'Please enter a valid email address';
      if (field.errors['minlength']) return `${fieldName.replace('_', ' ')} is too short`;
      if (field.errors['maxlength']) return `${fieldName.replace('_', ' ')} is too long`;
    }
    return '';
  }

  // Helper method to get the current form based on the operation
  getCurrentForm(): FormGroup {
    return this.isCreatingUser ? this.userForm : this.editForm;
  }

  // Check if form has changes
  hasFormChanges(): boolean {
    if (!this.originalFormValues || this.isCreatingUser) return true;
    
    const currentForm = this.editForm;
    const currentValues = currentForm.value;
    
    // Compare each field to detect changes
    return Object.keys(this.originalFormValues).some(key => {
      const originalValue = this.originalFormValues[key];
      const currentValue = currentValues[key];
      
      // Handle null/undefined/empty string comparisons
      const normalizeValue = (val: any) => {
        if (val === null || val === undefined || val === '') return '';
        return String(val);
      };
      
      return normalizeValue(originalValue) !== normalizeValue(currentValue);
    });
  }

  // Check if save button should be enabled
  isSaveButtonEnabled(): boolean {
    const currentForm = this.isCreatingUser ? this.userForm : this.editForm;
    
    if (this.isCreatingUser) {
      // For creating users, check if form is valid and not loading
      return !this.isLoading && currentForm.valid;
    } else {
      // For editing users, check if form is valid, not loading, and in editing mode
      const isValid = currentForm.valid;
      const isInEditingMode = this.isEditingUser || this.isEditing;
      const hasEditingId = !!this.editingUserId;
      
      return !this.isLoading && isValid && isInEditingMode && hasEditingId;
    }
  }

  saveUser(): void {
    // Use the same logic as updateUser() but determine which form to use
    const currentForm = this.isCreatingUser ? this.userForm : this.editForm;
    
    if (currentForm.invalid || (!this.isCreatingUser && !this.editingUserId)) {
      this.markFormGroupTouched(currentForm);
      return;
    }

    this.isLoading = true;
    this.clearMessages();

    if (this.isCreatingUser) {
      const userData: UserCreate = this.userForm.value;
      this.subscription.add(
        this.userService.createUser(userData).subscribe({
          next: (newUser) => {
            this.users.push(newUser);
            this.applyFilters();
            this.calculateStats();
            this.updateChartsWithRealData();
            this.closeModal();
            this.successMessage = `User "${this.userService.getUserDisplayName(newUser)}" created successfully!`;
            this.isLoading = false;
          },
          error: (error) => {
            console.error('Failed to create user:', error);
            this.errorMessage = error.message || 'Failed to create user. Please try again.';
            this.isLoading = false;
          }
        })
      );
    } else {
      // Update existing user
      const formData = { ...this.editForm.value };
      delete formData.password; // Remove password field for updates

      this.subscription.add(
        this.userService.updateUserById(this.editingUserId!, formData).subscribe({
          next: (updatedUser) => {
            const index = this.users.findIndex(u => u.id === this.editingUserId);
            if (index !== -1) {
              this.users[index] = updatedUser;
              this.applyFilters();
              this.calculateStats();
              this.updateChartsWithRealData();
            }
            this.closeModal();
            this.successMessage = `User "${this.userService.getUserDisplayName(updatedUser)}" updated successfully!`;
            this.isLoading = false;
          },
          error: (error) => {
            console.error('Failed to update user:', error);
            this.errorMessage = error.message || 'Failed to update user. Please try again.';
            this.isLoading = false;
          }
        })
      );
    }
  }

  // Missing method implementations
  initializeCharts(): void {
    // Initialize charts - placeholder for now
    this.updateChartsWithRealData();
  }

  updateChartsWithRealData(): void {
    // Chart updates are already implemented above
  }

  reviewPendingRequests(): void {
    if (this.pendingRequests === 0) return;
    
    // Filter to show only pending users
    this.selectedStatus = 'pending';
    this.applyFilters();
    
    // Scroll to table
    const tableElement = document.querySelector('.table-container');
    if (tableElement) {
      tableElement.scrollIntoView({ behavior: 'smooth' });
    }
  }

  clearFilters(): void {
    this.searchTerm = '';
    this.selectedRole = '';
    this.selectedStatus = '';
    this.sortBy = 'created_date';
    this.sortDirection = 'desc';
    this.applyFilters();
  }

  // Check if clear filters button should be disabled
  get isFiltersClearDisabled(): boolean {
    return !this.searchTerm && !this.selectedRole && !this.selectedStatus;
  }

  // Export functionality
  exportUserData(): void {
    const exportData = this.filteredUsers.map(user => ({
      'User ID': user.user_id,
      'Name': this.getUserDisplayName(user),
      'Email': user.email || 'Not provided',
      'Role': user.role,
      'Status': this.getStatusDisplay(user),
      'Email Verified': user.email_verified ? 'Yes' : 'No',
      'Last Login': user.last_login ? this.formatDateTime(user.last_login) : 'Never',
      'Created': this.formatDateTime(user.created_date),
      'Manager': this.getSelectedManagerName(user.manager_id)
    }));

    const csvContent = this.convertToCSV(exportData);
    this.downloadCSV(csvContent, `users-export-${new Date().toISOString().split('T')[0]}.csv`);
  }

  private convertToCSV(data: any[]): string {
    if (data.length === 0) return '';
    
    const headers = Object.keys(data[0]);
    const csvRows = [
      headers.join(','),
      ...data.map(row => 
        headers.map(header => {
          const value = row[header] || '';
          return `"${value.toString().replace(/"/g, '""')}"`;
        }).join(',')
      )
    ];
    
    return csvRows.join('\n');
  }

  private downloadCSV(content: string, filename: string): void {
    const blob = new Blob([content], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    const url = URL.createObjectURL(blob);
    
    link.setAttribute('href', url);
    link.setAttribute('download', filename);
    link.style.visibility = 'hidden';
    
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  }

  // Utility methods
  private markFormGroupTouched(formGroup: FormGroup): void {
    Object.keys(formGroup.controls).forEach(key => {
      const control = formGroup.get(key);
      control?.markAsTouched();
      
      if (control instanceof FormGroup) {
        this.markFormGroupTouched(control);
      }
    });
  }

  // Additional action methods for table
  editUserFromTable(user: User): void {
    this.showEditUserModal(user);
  }

  // Search functionality for the main search component
  onSearchChange(searchTerm: string): void {
    this.searchTerm = searchTerm;
    this.applyFilters();
    
    // Generate suggestions based on current users
    if (searchTerm.length >= (this.searchOptions.minSearchLength || 1)) {
      this.generateSearchSuggestions(searchTerm);
    } else {
      this.searchSuggestions = [];
    }
  }

  onSearchSelect(suggestion: SearchSuggestion): void {
    this.searchTerm = suggestion.label;
    this.applyFilters();
  }

  onSearchClear(): void {
    this.searchTerm = '';
    this.searchSuggestions = [];
    this.applyFilters();
  }

  private generateSearchSuggestions(searchTerm: string): void {
    const term = searchTerm.toLowerCase();
    const suggestions: SearchSuggestion[] = [];
    
    // Generate suggestions from user data
    this.users.forEach(user => {
      const displayName = this.getUserDisplayName(user);
      const email = user.email || '';
      const userId = user.user_id || '';
      
      if (displayName.toLowerCase().includes(term) || 
          email.toLowerCase().includes(term) || 
          userId.toLowerCase().includes(term)) {
        
        suggestions.push({
          id: user.id,
          label: displayName,
          category: 'Users',
          icon: user.role === 'admin' ? 'user-shield' : 'user',
          data: { email: email, role: user.role }
        });
      }
    });
    
    // Limit suggestions
    this.searchSuggestions = suggestions.slice(0, (this.searchOptions.maxSuggestions || 8));
  }

  // Clear messages helper
  clearMessages(): void {
    this.successMessage = '';
    this.errorMessage = '';
  }
}

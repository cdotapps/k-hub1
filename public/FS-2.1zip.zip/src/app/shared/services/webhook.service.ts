import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { BaseApiService } from './base-api.service';
import { Webhook, WebhookCreate, WebhookUpdate, WebhookResponse, WebhookTestResult, WebhookEvent } from '../models/user.interface';

@Injectable({
  providedIn: 'root'
})
export class WebhookService extends BaseApiService {

  /**
   * Create a new webhook
   */
  createWebhook(webhook: WebhookCreate): Observable<Webhook> {
    return this.post<Webhook>('/webhooks/', webhook);
  }

  /**
   * Get all webhooks with optional pagination
   */
  getWebhooks(params?: { 
    page?: number; 
    page_size?: number;
    limit?: number;
    sort?: string;
    order?: 'asc' | 'desc';
  }): Observable<WebhookResponse> {
    const sortedParams = this.addSortParams(params, 'created_date', 'desc');
    return this.get<WebhookResponse>('/webhooks/', sortedParams);
  }

  /**
   * Get a specific webhook by ID
   */
  getWebhook(id: string): Observable<Webhook> {
    return this.get<Webhook>(`/webhooks/${id}`);
  }

  /**
   * Update a webhook
   */
  updateWebhook(id: string, webhook: WebhookUpdate): Observable<Webhook> {
    return this.put<Webhook>(`/webhooks/${id}`, webhook);
  }

  /**
   * Delete a webhook
   */
  deleteWebhook(id: string): Observable<void> {
    return this.delete<void>(`/webhooks/${id}`);
  }

  /**
   * Test a webhook by sending a test event
   */
  testWebhook(id: string): Observable<WebhookTestResult> {
    return this.post<WebhookTestResult>(`/webhooks/${id}/test`, {});
  }

  /**
   * Toggle webhook enabled/disabled status
   */
  toggleWebhook(id: string): Observable<Webhook> {
    return this.patch<Webhook>(`/webhooks/${id}/toggle`, {});
  }

  /**
   * Get webhook delivery history
   */
  getWebhookDeliveries(id: string, params?: { 
    page?: number; 
    page_size?: number;
    limit?: number;
    sort?: string;
    order?: 'asc' | 'desc';
  }): Observable<any> {
    const sortedParams = this.addSortParams(params, 'created_date', 'desc');
    return this.get<any>(`/webhooks/${id}/deliveries`, sortedParams);
  }

  /**
   * Get available webhook events
   */
  getAvailableWebhookEvents(): Observable<WebhookEvent[]> {
    return this.get<WebhookEvent[]>('/webhooks/events/available');
  }
}
import { Injectable } from '@angular/core';
import { Observable, of } from 'rxjs';
import { map, catchError } from 'rxjs/operators';
import { CatalogService } from './catalog.service';
import { Catalog } from '../models/user.interface';

// Generic Catalog Type interfaces
export interface CatalogTypeItem {
  id: string;
  title: string;
  content: string;
  description: string;
  message: string;
  type: string;
  category: string;
  priority: string;
  isRead: boolean;
  isBookmarked: boolean;
  timestamp: string;
  author?: string;
  authorId?: string;
  relatedItem?: {
    id: string;
    type: string;
    title: string;
  };
  actions?: CatalogTypeAction[];
}

export interface CatalogTypeAction {
  label: string;
  action: string;
  variant: 'primary' | 'secondary' | 'danger';
  icon?: any;
}

export interface CatalogTypeResponse {
  items: CatalogTypeItem[];
  totalCount: number;
  currentPage: number;
  totalPages: number;
  pageSize: number;
}

interface CatalogTypeFilters {
  type: string;
  search?: string;
  category?: string;
  item_type?: string;
  priority_level?: string;
  is_read?: boolean;
  date_from?: string;
  date_to?: string;
  page?: number;
  page_size?: number;
  sort?: string;
  order?: 'asc' | 'desc';
}

@Injectable({
  providedIn: 'root'
})
export class CatalogTypeService {
  constructor(private catalogService: CatalogService) {}

  /**
   * Get catalog items of any type with filters and pagination
   */
  getCatalogTypeItems(filters: CatalogTypeFilters): Observable<CatalogTypeResponse> {
    const catalogParams = {
      type: filters.type,
      page: filters.page || 1,
      page_size: filters.page_size || 12,
      sort: filters.sort || 'created_at',
      order: filters.order || 'desc',
      search: filters.search,
      query: filters.search, // Add query parameter as alias for search
      category: filters.category,
      priority_level: filters.priority_level,
      is_read: filters.is_read,
      date_from: filters.date_from,
      date_to: filters.date_to
    };

    // Remove undefined values to avoid sending empty parameters
    Object.keys(catalogParams).forEach(key => {
      if (catalogParams[key as keyof typeof catalogParams] === undefined) {
        delete catalogParams[key as keyof typeof catalogParams];
      }
    });

    console.log('🔍 getCatalogTypeItems - sending params:', catalogParams);

    return this.catalogService.getCatalogItems(catalogParams)
      .pipe(
        map(response => this.transformCatalogTypeResponse(response, filters)),
        catchError(error => {
          console.error('Error fetching catalog type items:', error);
          return of({
            items: [],
            totalCount: 0,
            currentPage: 1,
            totalPages: 1,
            pageSize: filters.page_size || 12
          });
        })
      );
  }

  markAsRead(itemId: string): Observable<CatalogTypeItem> {
    return this.catalogService.getCatalogItem(itemId)
      .pipe(
        map(catalog => {
          const updatedCustom = {
            ...catalog.custom,
            is_read: true
          };
          this.catalogService.updateCustomAttributes(itemId, updatedCustom).subscribe();
          return this.transformCatalogToItem(catalog);
        })
      );
  }

  toggleBookmark(itemId: string, isBookmarked: boolean): Observable<CatalogTypeItem> {
    return this.catalogService.getCatalogItem(itemId)
      .pipe(
        map(catalog => {
          const updatedCustom = {
            ...catalog.custom,
            is_bookmarked: isBookmarked
          };
          this.catalogService.updateCustomAttributes(itemId, updatedCustom).subscribe();
          return this.transformCatalogToItem(catalog);
        })
      );
  }

  deleteCatalogTypeItem(itemId: string): Observable<void> {
    return this.catalogService.deleteCatalogItem(itemId);
  }

  getCatalogTypeStats(type: string): Observable<{
    total: number;
    unread: number;
    categories: { [key: string]: number };
  }> {
    return this.catalogService.getCatalogItems({
      type,
      status: 'published',
      page_size: 100
    }).pipe(
      map(response => {
        const items = (response.items || []).map((item: Catalog) => this.transformCatalogToItem(item));
        const stats = {
          total: response.total || items.length,
          unread: items.filter(n => !n.isRead).length,
          categories: {} as { [key: string]: number }
        };
        items.forEach(item => {
          const category = item.category;
          stats.categories[category] = (stats.categories[category] || 0) + 1;
        });
        return stats;
      }),
      catchError(error => {
        console.warn('Error getting catalog type stats:', error);
        return of({
          total: 0,
          unread: 0,
          categories: {}
        });
      })
    );
  }

  markAllAsRead(filters: any = {}): Observable<{ success: boolean; updated_count: number }> {
    // This would require a bulk update API in the catalog service
    // For now, return a success response
    return of({ success: true, updated_count: 0 });
  }

  private transformCatalogTypeResponse(response: any, filters: CatalogTypeFilters): CatalogTypeResponse {
    const items = (response.items || [])
      .map((item: Catalog) => this.transformCatalogToItem(item));
    return {
      items,
      totalCount: response.total || items.length,
      currentPage: response.page || filters.page || 1,
      totalPages: response.total_pages || Math.ceil((response.total || items.length) / (filters.page_size || 12)),
      pageSize: filters.page_size || 12
    };
  }

  private transformCatalogToItem(catalog: Catalog): CatalogTypeItem {
    return {
      id: catalog.id,
      title: catalog.title,
      content: catalog.content || '',
      description: catalog.description || '',
      message: catalog.description || catalog.content || '',
      type: catalog.type || catalog.custom?.['type'] || '',
      category: catalog.category || catalog.custom?.['category'] || '',
      priority: catalog.priority || catalog.custom?.['priority_level'] || '',
      isRead: catalog.custom?.['is_read'] || false,
      isBookmarked: catalog.custom?.['is_bookmarked'] || false,
      timestamp: catalog.created_date || catalog.updated_date || new Date().toISOString(),
      author: catalog.author,
      authorId: catalog.author_id,
      relatedItem: catalog.custom?.['related_item'] ? {
        id: catalog.custom['related_item'].id,
        type: catalog.custom['related_item'].type || 'unknown',
        title: catalog.custom['related_item'].title || 'Related Item'
      } : undefined,
      actions: this.extractActionsFromCatalog(catalog)
    };
  }

  private extractActionsFromCatalog(catalog: Catalog): CatalogTypeAction[] {
    if (catalog.custom?.['actions'] && Array.isArray(catalog.custom['actions'])) {
      return catalog.custom['actions'].map((action: any) => ({
        label: action.label,
        action: action.action,
        variant: action.variant || 'secondary',
        icon: action.icon
      }));
    }
    return [];
  }
}

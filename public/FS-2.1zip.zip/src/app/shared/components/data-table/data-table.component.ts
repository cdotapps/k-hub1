import { Component, Input, Output, EventEmitter, OnInit, OnChanges, TemplateRef } from '@angular/core';
import { 
  faSort, faSortUp, faSortDown, faChevronDown, faSpinner, faInbox, faChevronLeft, faChevronRight, faChevronUp, faEye, faFileAlt, faInfoCircle, faCheckCircle, faCalendar, faCog, faShare, faTrash, faBookmark, faBell, faTimes 
} from '@fortawesome/free-solid-svg-icons';
import { CatalogService } from '../../services/catalog.service';

export interface DataTableColumn {
  key: string;
  label: string;
  type?: 'text' | 'badge' | 'actions' | 'date' | 'icon' | 'custom';
  sortable?: boolean;
  width?: string;
  align?: 'left' | 'center' | 'right';
  render?: (value: any, row: any) => string;
  // Data mapping properties
  sourceKey?: string; // Key from raw data to map to this column
  transform?: (value: any, rawRow: any) => any; // Transform function for mapping
}

export interface DataTableAction {
  label: string;
  icon?: any;
  variant?: 'primary' | 'secondary' | 'success' | 'warning' | 'danger' | 'muted';
  action: string;
  disabled?: (row: any) => boolean;
  visible?: (row: any) => boolean;
}

export interface DataTableBadge {
  text: string;
  variant: 'primary' | 'secondary' | 'success' | 'warning' | 'danger' | 'muted' | 'light' | 'dark';
  icon?: any;
}

// New interface for data mapping configuration
export interface DataMapping {
  [displayKey: string]: {
    sourceKey: string;
    transform?: (value: any, rawRow: any) => any;
  };
}

@Component({
  selector: 'app-data-table',
  template: `
    <div class="data-table-container" [class.loading]="loading">
      <!-- Loading State -->
      <div *ngIf="loading" class="loading-overlay">
        <div class="loading-content">
          <app-icon [faIcon]="loadingIcon" class="loading-spinner"></app-icon>
          <span>{{ loadingText }}</span>
        </div>
      </div>

      <!-- Proper HTML Table -->
      <table class="table table-striped table-hover">
        <!-- Header -->
        <thead class="table-head">
          <tr class="table-header-row">
            <!-- Remove Expand Column Header -->
            <th *ngIf="selectable" class="select-column" scope="col">
              <input 
                type="checkbox" 
                [checked]="isAllSelected()" 
                [indeterminate]="isSomeSelected()"
                (change)="toggleSelectAll()"
                class="select-all-checkbox">
            </th>
            <th *ngFor="let column of columns" 
              [style.width]="column.width"
              [class.sortable]="column.sortable"
              [class.sorted]="sortColumn === column.key"
              [class.sort-asc]="sortColumn === column.key && sortDirection === 'asc'"
              [class.sort-desc]="sortColumn === column.key && sortDirection === 'desc'"
              [style.text-align]="column.align || 'left'"
              (click)="onSort(column)"
              scope="col">
              <div class="header-content">
                <span class="header-label">{{ column.label }}</span>
                <app-icon *ngIf="column.sortable" 
                  [faIcon]="getSortIcon(column.key)" 
                  class="sort-icon" 
                  size="sm"></app-icon>
              </div>
            </th>
          </tr>
        </thead>

        <!-- Body -->
        <tbody class="table-body">
          <ng-container *ngFor="let row of data; trackBy: trackByFn; let i = index">
            <!-- Main Row -->
            <tr class="data-row"
              [class.selected]="isRowSelected(row)"
              [class.clickable]="rowClickable"
              [class.expanded]="isRowExpanded(i)"
              (click)="onRowClick(row, i)">
              
              <!-- Remove View Details Column -->
              <td *ngIf="selectable" class="select-column">
                <input 
                  type="checkbox" 
                  [checked]="isRowSelected(row)"
                  (change)="toggleRowSelection(row, $event)"
                  (click)="$event.stopPropagation()"
                  class="row-checkbox">
              </td>

              <!-- Data Columns -->
              <td *ngFor="let column of columns" 
                class="data-cell"
                [style.text-align]="column.align || 'left'"
                [class]="'column-' + column.type">
                
                <!-- Text Column -->
                <span *ngIf="column.type === 'text' || !column.type" class="cell-text">
                  {{ getCellValue(row, column) }}
                </span>

                <!-- Badge Column -->
                <span *ngIf="column.type === 'badge'" 
                  class="cell-badge badge"
                  [ngClass]="'badge-' + getBadgeVariant(row, column)">
                  <app-icon *ngIf="getBadgeIcon(row, column)" 
                    [faIcon]="getBadgeIcon(row, column)" 
                    size="xs"></app-icon>
                  {{ getBadgeText(row, column) }}
                </span>

                <!-- Date Column -->
                <span *ngIf="column.type === 'date'" class="cell-date">
                  {{ formatDate(getCellValue(row, column)) }}
                </span>

                <!-- Icon Column -->
                <span *ngIf="column.type === 'icon'" class="cell-icon">
                  <app-icon [faIcon]="getCellValue(row, column)" size="sm"></app-icon>
                </span>

                <!-- Actions Column -->
                <div *ngIf="column.type === 'actions'" class="cell-actions">
                  <button *ngFor="let action of getRowActions(row)"
                    type="button"
                    class="action-btn"
                    [ngClass]="'btn-' + (action.variant || 'secondary')"
                    [disabled]="isActionDisabled(action, row)"
                    [title]="action.label"
                    (click)="onActionClick(action, row, $event)">
                    <app-icon *ngIf="action.icon" [faIcon]="action.icon" size="sm"></app-icon>
                  </button>
                </div>

                <!-- Custom Column -->
                <div *ngIf="column.type === 'custom'" class="cell-custom">
                  <ng-container [ngSwitch]="column.key">
                    <ng-content 
                      select="[slot='custom-cell']" 
                      *ngSwitchDefault>
                    </ng-content>
                  </ng-container>
                </div>
              </td>
            </tr>
            
            <!-- Expandable Row Content - Now properly spans full width -->
            <tr *ngIf="isRowExpanded(i) && expandedCatalogIndex === i" class="expandable-row">
              <td [attr.colspan]="getColumnCount()" class="expandable-cell">
                <div class="expandable-row-container">
                  <div class="expandable-row-content">
                    <div class="expandable-header">
                      <div class="expandable-header-left">
                        <h3 class="expandable-title">{{ expandedCatalogDetails?.title || getRawValue(row, 'title') }}</h3>
                      </div>
                      <div class="expandable-header-right">
              
                        <button type="button" 
                                class="close-expandable-btn"
                                (click)="collapseRow(i, $event)"
                                title="Close Details">
                          <app-icon [faIcon]="faTimes" size="sm"></app-icon>
                        </button>
                      </div>
                    </div>
                    
                    <div class="expandable-body">
                      <div *ngIf="expandedCatalogDetails && !expandedCatalogLoading && !expandedCatalogError" class="expandable-toolbar">
                        <div class="tab-nav">
                        <button [class.active]="expandedCatalogTab === 'content'" (click)="expandedCatalogTab = 'content'">Content</button>
                          <button [class.active]="expandedCatalogTab === 'standard'" (click)="expandedCatalogTab = 'standard'">Details</button>
                          <button [class.active]="expandedCatalogTab === 'custom'" (click)="expandedCatalogTab = 'custom'">Attributes</button>
                        </div>
                        <div class="toolbar-actions expandable-body">
                          <button *ngFor="let action of getRowActions(row)"
                            type="button"
                            class="action-btn"
                            [ngClass]="'btn-' + (action.variant || 'primary')"
                            [disabled]="isActionDisabled(action, row)"
                            [title]="action.label"
                            (click)="onActionClick(action, row, $event)">
                            <app-icon *ngIf="action.icon" [faIcon]="action.icon" size="sm"></app-icon>
                            {{ action.label }}
                          </button>
                    </div> 
                      </div>
                      <div *ngIf="expandedCatalogLoading" class="loading-overlay">
                        <div class="loading-content">
                          <app-icon [faIcon]="loadingIcon" class="loading-spinner"></app-icon>
                          <span>Loading details...</span>
                        </div>
                      </div>
                      <div *ngIf="expandedCatalogError" class="error-message">
                        {{ expandedCatalogError }}
                      </div>
                      <ng-container *ngIf="expandedCatalogDetails && !expandedCatalogLoading && !expandedCatalogError">
                      <div class="tab-content" *ngIf="expandedCatalogTab === 'content'">
                          <div class="tab-section">
                              <div class="catalog-message-note">
                                <div class="catalog-message-title">
                                  {{ expandedCatalogDetails["title"] }}
                                </div>
                                <div class="catalog-message-description">
                                  {{ expandedCatalogDetails["descritpion"] }}
                                </div>
                                <div class="catalog-message-content">
                                  {{ expandedCatalogDetails["content"] }}
                                </div>
                              </div>
                          </div>
                        </div>
                        <div class="tab-content" *ngIf="expandedCatalogTab === 'standard'">
                          <div class="tab-section tab-grid">
                            <div *ngFor="let field of getStandardFields(expandedCatalogDetails)" class="tab-grid-item">
                              <dt class="metadata-label">{{ field.key }}</dt>
                              <dd class="metadata-value">{{ field.value }}</dd>
                            </div>
                          </div>
                        </div>
                        <div class="tab-content" *ngIf="expandedCatalogTab === 'custom'">
                          <div class="tab-section tab-grid">
                            <div *ngFor="let attr of getCustomFields(expandedCatalogDetails)" class="tab-grid-item">
                              <dt class="custom-attr-label">{{ attr.description || attr.key }}</dt>
                              <dd class="custom-attr-value">{{ attr.value }}</dd>
                            </div>
                          </div>
                        </div>
                      </ng-container>
                    </div>
                  </div>
                </div>
              </td>
            </tr>
          </ng-container>

          <!-- Empty State Row -->
          <tr *ngIf="!loading && (!data || data.length === 0)" class="empty-row">
            <td [attr.colspan]="getColumnCount()" class="empty-cell">
              <div class="empty-state">
                <app-icon [faIcon]="emptyIcon" class="empty-icon" size="xl"></app-icon>
                <h4 class="empty-title">{{ emptyTitle }}</h4>
                <p class="empty-message">{{ emptyMessage }}</p>
                <button *ngIf="emptyActionLabel" 
                  type="button" 
                  class="empty-action-btn"
                  (click)="onEmptyAction()">
                  {{ emptyActionLabel }}
                </button>
              </div>
            </td>
          </tr>
        </tbody>
      </table>

      <!-- Simple Item Count (outside the table) -->
      <div *ngIf="showRowCount && data && data.length > 0" class="item-count-container">
        <span class="item-count">
          Showing {{ getStartIndex() + 1 }}-{{ getEndIndex() }} of {{ totalRows || data.length || 0 }} items
        </span>
      </div>
    </div>
  `,
  styleUrls: ['./data-table.component.css']
})
export class DataTableComponent implements OnInit, OnChanges {
  @Input() data: any[] = [];
  @Input() rawData: any[] = []; // New: Raw data input
  @Input() dataMapping?: DataMapping; // New: Data mapping configuration
  @Input() columns: DataTableColumn[] = [];
  @Input() actions: DataTableAction[] = [];
  
  // Appearance
  @Input() striped = true;
  @Input() bordered = true;
  @Input() hover = true;
  @Input() selectable = false;
  @Input() rowClickable = true;
  
  // Expandable Rows
  @Input() expandable = false;
  @Input() expandedRowTemplate?: TemplateRef<any>;
  @Input() expandedFields: string[] = []; // Fields to show in default expanded view
  @Input() expandedFieldLabels: { [key: string]: string } = {}; // Custom labels for fields
  @Input() initiallyExpanded: number[] = []; // Initially expanded row indices
  @Input() expandedRowIndex: number | null = null; // Single expanded row index
  
  // Loading
  @Input() loading = false;
  @Input() loadingText = 'Loading...';
  @Input() loadingIcon: any;
  
  // Sorting
  @Input() sortColumn = '';
  @Input() sortDirection: 'asc' | 'desc' = 'asc';
  
  // Pagination
  @Input() pagination = false;
  @Input() currentPage = 1;
  @Input() totalPages = 1;
  @Input() totalRows?: number;
  @Input() itemsPerPage = 25;

  // Footer
  @Input() showFooter = true;
  @Input() showRowCount = true;
  @Input() showItemsPerPage = true;
  
  // Empty State
  @Input() emptyTitle = 'No data available';
  @Input() emptyMessage = 'There are no items to display.';
  @Input() emptyActionLabel = '';
  @Input() emptyIcon: any;
  
  // Selection
  @Input() selectedRows: any[] = [];
  @Input() selectionKey = 'id';
  
  // Track by function
  @Input() trackByFn = (index: number, item: any) => item.id || index;
  
  // Events
  @Output() rowClick = new EventEmitter<{row: any, index: number}>();
  @Output() actionClick = new EventEmitter<{action: DataTableAction, row: any}>();
  @Output() sort = new EventEmitter<{column: string, direction: 'asc' | 'desc'}>();
  @Output() pageChange = new EventEmitter<number>();
  @Output() itemsPerPageChange = new EventEmitter<number>();
  @Output() selectionChange = new EventEmitter<any[]>();
  @Output() emptyAction = new EventEmitter<void>();
  @Output() viewDetails = new EventEmitter<{row: any, index: number}>();

  // Icons
  faChevronLeft = faChevronLeft;
  faChevronRight = faChevronRight;
  faChevronDown = faChevronDown;
  faChevronUp = faChevronUp;
  faEye = faEye;
  faFileAlt = faFileAlt;
  faInfoCircle = faInfoCircle;
  faCheckCircle = faCheckCircle;
  faCalendar = faCalendar;
  faCog = faCog;
  faShare = faShare;
  faTrash = faTrash;
  faBookmark = faBookmark;
  faBell = faBell;
  faTimes = faTimes;

  // Expanded rows state
  private expandedRows = new Set<number>();

  // State for expanded catalog details and loading
  expandedCatalogDetails: any = null;
  expandedCatalogLoading: boolean = false;
  expandedCatalogError: string | null = null;
  expandedCatalogIndex: number | null = null;
  expandedCatalogTab: 'content' | 'standard' | 'custom' = 'content';

  // Math functions for template
  Math = Math;

  constructor(private catalogService: CatalogService) {}

  ngOnInit(): void {
    // Set default icons if not provided
    if (!this.loadingIcon) {
      this.loadingIcon = 'faSpinner'; // You'll need to import this
    }
    if (!this.emptyIcon) {
      this.emptyIcon = 'faInbox'; // You'll need to import this
    }

    // Initialize expanded rows
    this.initiallyExpanded.forEach(index => {
      this.expandedRows.add(index);
    });

    // Process data mapping on initialization
    this.processDataMapping();
  }

  ngOnChanges(): void {
    // Re-process data mapping when inputs change
    this.processDataMapping();
  }

  /**
   * Process raw data with mapping configuration
   * If no dataMapping is provided, data equals rawData
   */
  private processDataMapping(): void {
    if (!this.rawData || this.rawData.length === 0) {
      // If no raw data, keep existing data as is
      return;
    }

    if (!this.dataMapping) {
      // No mapping provided, use raw data directly
      this.data = this.rawData;
      return;
    }

    // Apply data mapping transformation
    this.data = this.rawData.map(rawRow => {
      const mappedRow: any = {};
      
      // Apply mapping for each configured key
      Object.entries(this.dataMapping!).forEach(([displayKey, mapping]) => {
        const sourceValue = this.getNestedValue(rawRow, mapping.sourceKey);
        
        if (mapping.transform) {
          mappedRow[displayKey] = mapping.transform(sourceValue, rawRow);
        } else {
          mappedRow[displayKey] = sourceValue;
        }
      });

      // Also apply column-level mapping if defined
      this.columns.forEach(column => {
        if (column.sourceKey && !mappedRow.hasOwnProperty(column.key)) {
          const sourceValue = this.getNestedValue(rawRow, column.sourceKey);
          
          if (column.transform) {
            mappedRow[column.key] = column.transform(sourceValue, rawRow);
          } else {
            mappedRow[column.key] = sourceValue;
          }
        }
      });

      // Include any unmapped properties for backward compatibility
      Object.keys(rawRow).forEach(key => {
        if (!mappedRow.hasOwnProperty(key)) {
          mappedRow[key] = rawRow[key];
        }
      });

      return mappedRow;
    });
  }

  /**
   * Get nested value from object using dot notation
   */
  private getNestedValue(obj: any, path: string): any {
    return path.split('.').reduce((current, key) => current?.[key], obj);
  }

  getCellValue(row: any, column: DataTableColumn): any {
    const keys = column.key.split('.');
    let value = row;
    
    for (const key of keys) {
      value = value?.[key];
    }
    
    if (column.render) {
      return column.render(value, row);
    }
    
    return value;
  }

  /**
   * Helper method to get raw value from row by key path
   * Used in templates where we don't need full column configuration
   */
  getRawValue(row: any, keyPath: string): any {
    const keys = keyPath.split('.');
    let value = row;
    
    for (const key of keys) {
      value = value?.[key];
    }
    
    return value;
  }

  getBadgeVariant(row: any, column: DataTableColumn): string {
    const value = this.getCellValue(row, column);
    if (typeof value === 'object' && value.variant) {
      return value.variant;
    }
    return 'secondary';
  }

  getBadgeText(row: any, column: DataTableColumn): string {
    const value = this.getCellValue(row, column);
    if (typeof value === 'object' && value.text) {
      return value.text;
    }
    return value;
  }

  getBadgeIcon(row: any, column: DataTableColumn): any {
    const value = this.getCellValue(row, column);
    if (typeof value === 'object' && value.icon) {
      return value.icon;
    }
    return null;
  }

  formatDate(value: any): string {
    if (!value) return '';
    
    const date = new Date(value);
    if (isNaN(date.getTime())) return value;
    
    const now = new Date();
    const diffInMs = now.getTime() - date.getTime();
    const diffInMinutes = Math.floor(diffInMs / (1000 * 60));
    const diffInHours = Math.floor(diffInMinutes / 60);
    const diffInDays = Math.floor(diffInHours / 24);

    if (diffInMinutes < 1) {
      return 'Just now';
    } else if (diffInMinutes < 60) {
      return `${diffInMinutes}m ago`;
    } else if (diffInHours < 24) {
      return `${diffInHours}h ago`;
    } else if (diffInDays < 7) {
      return `${diffInDays}d ago`;
    } else {
      return date.toLocaleDateString();
    }
  }

  onSort(column: DataTableColumn): void {
    if (!column.sortable) return;
    
    let direction: 'asc' | 'desc' = 'asc';
    
    if (this.sortColumn === column.key) {
      direction = this.sortDirection === 'asc' ? 'desc' : 'asc';
    }
    
    this.sortColumn = column.key;
    this.sortDirection = direction;
    
    this.sort.emit({ column: column.key, direction });
  }

  getSortIcon(columnKey: string): any {
    if (this.sortColumn !== columnKey) {
      return faSort;
    }
    return this.sortDirection === 'asc' ? faSortUp : faSortDown;
  }

  onRowClick(row: any, index: number): void {
    if (!this.rowClickable) return;

    if (this.expandable) {
      // Collapse all other rows
      this.expandedRows.clear();
      this.toggleRowExpansion(index, new Event('click'));
      this.fetchCatalogDetails(row, index);
    } else {
      // Normal row click behavior
      this.rowClick.emit({ row, index });
    }
  }

  fetchCatalogDetails(row: any, index: number): void {
    const id = row.id;
    if (!id) return;
    this.expandedCatalogLoading = true;
    this.expandedCatalogError = null;
    this.expandedCatalogIndex = index;
    this.expandedCatalogDetails = null;
    this.catalogService.getCatalogItem(id).subscribe({
      next: (data: any) => {
        this.expandedCatalogDetails = data;
        this.expandedCatalogLoading = false;
      },
      error: (err: any) => {
        this.expandedCatalogError = 'Failed to load catalog details.';
        this.expandedCatalogLoading = false;
      }
    });
  }

  // Helper to get standard fields (excluding custom/default)
  getStandardFields(catalog: any): { key: string, value: any }[] {
    if (!catalog) return [];
    const exclude = ['custom', 'default'];
    return Object.keys(catalog)
      .filter(key => !exclude.includes(key))
      .map(key => ({ key, value: catalog[key] }))
      .filter(field => field.value !== null && field.value !== undefined && field.value !== '');
  }

  // Helper to get custom attributes from custom.default
  getCustomFields(catalog: any): { key: string, value: any, description?: string }[] {
    if (catalog && catalog.custom && Array.isArray(catalog.custom.default)) {
      return catalog.custom.default
        .map((attr: any) => ({
          key: attr.column,
          value: attr.value,
          description: attr.description
        }))
        .filter((attr: any) => attr.value !== null && attr.value !== undefined && attr.value !== '');
    }
    return [];
  }

  
  /**
   * Toggle row expansion
   */
  toggleRowExpansion(index: number, event?: Event): void {
    if (event) {
      event.stopPropagation();
    }
    
    if (this.expandedRows.has(index)) {
      this.expandedRows.delete(index);
    } else {
      this.expandedRows.add(index);
    }
  }

  /**
   * Check if row is expanded
   */
  isRowExpanded(index: number): boolean {
    return this.expandedRows.has(index);
  }

  /**
   * Collapse a specific row
   */
  collapseRow(index: number, event?: Event): void {
    if (event) {
      event.stopPropagation();
    }
    this.expandedRows.delete(index);
  }

  /**
   * Selection methods
   */
  isRowSelected(row: any): boolean {
    const rowId = row[this.selectionKey];
    return this.selectedRows.some(selected => selected[this.selectionKey] === rowId);
  }

  toggleRowSelection(row: any, event: any): void {
    const rowId = row[this.selectionKey];
    const isSelected = this.isRowSelected(row);
    
    if (isSelected) {
      this.selectedRows = this.selectedRows.filter(selected => selected[this.selectionKey] !== rowId);
    } else {
      this.selectedRows = [...this.selectedRows, row];
    }
    
    this.selectionChange.emit(this.selectedRows);
  }

  isAllSelected(): boolean {
    return this.data.length > 0 && this.selectedRows.length === this.data.length;
  }

  isSomeSelected(): boolean {
    return this.selectedRows.length > 0 && this.selectedRows.length < this.data.length;
  }

  toggleSelectAll(): void {
    if (this.isAllSelected()) {
      this.selectedRows = [];
    } else {
      this.selectedRows = [...this.data];
    }
    this.selectionChange.emit(this.selectedRows);
  }

  /**
   * Action methods
   */
  getRowActions(row: any): DataTableAction[] {
    return this.actions.filter(action => 
      !action.visible || action.visible(row)
    );
  }

  isActionDisabled(action: DataTableAction, row: any): boolean {
    return action.disabled ? action.disabled(row) : false;
  }

  onActionClick(action: DataTableAction, row: any, event: Event): void {
    event.stopPropagation();
    this.actionClick.emit({ action, row });
  }

  onInlineAction(actionType: string, row: any, event: Event): void {
    event.stopPropagation();
    
    const action: DataTableAction = {
      label: actionType,
      action: actionType
    };
    
    this.actionClick.emit({ action, row });
  }

  /**
   * Returns custom attributes for the Custom Attributes tab.
   * Excludes known fields shown in other tabs.
   */
  getCustomAttributes(row: any): { key: string, value: any, description?: string }[] {
    // Handle custom.default array if present
    if (row.custom && Array.isArray(row.custom.default)) {
      return row.custom.default.map((attr: any) => ({
        key: attr.column,
        value: attr.value,
        description: attr.description
      }));
    }
    // Fallback: show any other custom fields
    if (row.custom && typeof row.custom === 'object') {
      return Object.keys(row.custom).map(key => ({
        key,
        value: row.custom[key]
      }));
    }
    return [];
  }

  /**
   * Utility methods
   */
  getColumnCount(): number {
    let count = this.columns.length;
    if (this.expandable) count++;
    if (this.selectable) count++;
    return count;
  }

  getStartIndex(): number {
    if (!this.pagination) return 0;
    return (this.currentPage - 1) * this.itemsPerPage;
  }

  getEndIndex(): number {
    if (!this.pagination) return this.data.length;
    const start = this.getStartIndex();
    return Math.min(start + this.itemsPerPage, this.totalRows || this.data.length);
  }

  onEmptyAction(): void {
    this.emptyAction.emit();
  }
}
import { Component, Input, Output, EventEmitter, ElementRef, ViewChild, forwardRef } from '@angular/core';
import { ControlValueAccessor, NG_VALUE_ACCESSOR } from '@angular/forms';
import { faSearch } from '@fortawesome/free-solid-svg-icons';

// Search-related interfaces
export interface SearchSuggestion {
  id: string;
  label: string;
  category?: string;
  icon?: any;
  data?: any;
}

export interface SearchOptions {
  showSuggestions?: boolean;
  showHistory?: boolean;
  maxHistoryItems?: number;
  maxSuggestions?: number;
  debounceTime?: number;
  minSearchLength?: number;
  caseSensitive?: boolean;
}

@Component({
  selector: 'app-search',
  templateUrl: './search.component.html',
  styleUrls: ['./search.component.css'],
  providers: [
    {
      provide: NG_VALUE_ACCESSOR,
      useExisting: forwardRef(() => SearchComponent),
      multi: true
    }
  ]
})
export class SearchComponent implements ControlValueAccessor {
  @ViewChild('searchInput', { static: true }) searchInput!: ElementRef<HTMLInputElement>;

  // FontAwesome icons
  faSearch = faSearch;

  // Basic Inputs
  @Input() placeholder = 'Search...';
  @Input() size: 'small' | 'medium' | 'large' = 'medium';
  @Input() variant: 'default' | 'outline' | 'filled' = 'default';
  @Input() disabled = false;
  @Input() showClearButton = true;
  @Input() showSearchButton = false;
  @Input() showActionButton = false; // Added missing property
  @Input() searchButtonText = 'Search';
  @Input() isLoading = false; // Added missing property
  @Input() suggestions: SearchSuggestion[] = []; // Added missing property
  @Input() options: SearchOptions = {}; // Added missing property

  // Events
  @Output() search = new EventEmitter<string>();
  @Output() clear = new EventEmitter<void>();
  @Output() focus = new EventEmitter<FocusEvent>();
  @Output() blur = new EventEmitter<FocusEvent>();
  @Output() select = new EventEmitter<SearchSuggestion>(); // Added missing event

  // Component State
  value = '';
  isFocused = false;

  // ControlValueAccessor
  private onChange = (value: string) => {};
  private onTouched = () => {};

  // ControlValueAccessor Implementation
  writeValue(value: string): void {
    this.value = value || '';
    if (this.searchInput) {
      this.searchInput.nativeElement.value = this.value;
    }
  }

  registerOnChange(fn: (value: string) => void): void {
    this.onChange = fn;
  }

  registerOnTouched(fn: () => void): void {
    this.onTouched = fn;
  }

  setDisabledState(isDisabled: boolean): void {
    this.disabled = isDisabled;
  }

  // Event Handlers
  onInput(event: Event): void {
    const target = event.target as HTMLInputElement;
    this.value = target.value;
    this.onChange(this.value);
    this.search.emit(this.value);
  }

  onFocus(event: FocusEvent): void {
    this.isFocused = true;
    this.onTouched();
    this.focus.emit(event);
  }

  onBlur(event: FocusEvent): void {
    this.isFocused = false;
    this.blur.emit(event);
  }

  onKeyDown(event: KeyboardEvent): void {
    if (event.key === 'Enter') {
      event.preventDefault();
      this.performSearch();
    } else if (event.key === 'Escape') {
      this.searchInput.nativeElement.blur();
    }
  }

  // Action Methods
  clearSearch(): void {
    this.value = '';
    this.onChange('');
    this.searchInput.nativeElement.value = '';
    this.searchInput.nativeElement.focus();
    this.clear.emit();
  }

  performSearch(): void {
    if (this.value.trim()) {
      this.search.emit(this.value.trim());
    }
  }

  // Utility Methods
  getComponentClasses(): string[] {
    const classes = [
      'search-component',
      `search-${this.size}`
    ];

    if (this.disabled) classes.push('search-disabled');
    if (this.isFocused) classes.push('search-focused');

    return classes;
  }
}
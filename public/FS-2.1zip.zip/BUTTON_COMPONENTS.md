# Reusable Button Components

This project now includes 3 reusable button components that provide consistent styling and behavior across the application.

## Components Overview

### 1. ActionButtonComponent (`app-action-button`)
Primary buttons for main actions like submit, save, create, etc.

**Features:**
- 7 variants: primary, secondary, success, warning, danger, outline, ghost
- 3 sizes: small, medium, large
- Loading state with spinner
- Icon support
- Full width option
- Icon-only mode

**Usage:**
```html
<app-action-button 
  variant="primary" 
  [icon]="faUserPlus" 
  (buttonClick)="createUser()">
  Add User
</app-action-button>

<app-action-button 
  variant="secondary" 
  [icon]="faSync" 
  [loading]="isLoading"
  [disabled]="isLoading">
  Refresh
</app-action-button>
```

### 2. ToolButtonComponent (`app-tool-button`)
Utility buttons for filters, sorting, and controls.

**Features:**
- 5 variants: default, active, clear, filter, sort
- 2 sizes: small, medium
- Badge support
- Tooltip support
- Icon-only mode

**Usage:**
```html
<app-tool-button 
  variant="clear" 
  [icon]="faTimes" 
  (buttonClick)="clearFilters()"
  tooltip="Clear all filters">
  Clear Filters
</app-tool-button>

<app-tool-button 
  variant="filter" 
  [icon]="faFilter" 
  [badge]="3"
  iconOnly="true">
</app-tool-button>
```

### 3. IconButtonComponent (`app-icon-button`)
Compact buttons for table actions and quick controls.

**Features:**
- 8 variants: default, view, edit, delete, approve, reject, toggle, info
- 3 sizes: small, medium, large
- Badge support
- Accessibility features (aria-label, tooltip)
- Active state for toggles

**Usage:**
```html
<app-icon-button 
  variant="edit" 
  [icon]="faEdit" 
  size="small"
  (buttonClick)="editUser(user)"
  tooltip="Edit User">
</app-icon-button>

<app-icon-button 
  variant="toggle" 
  [icon]="faToggleOn" 
  [active]="isActive"
  (buttonClick)="toggle()">
</app-icon-button>
```

## Implementation

All components are:
- Standalone Angular components
- TypeScript with proper type definitions
- Fully accessible with ARIA support
- Responsive and mobile-friendly
- Consistent with the application's design system

The components are exported from the SharedModule and can be used throughout the application by importing the SharedModule in your feature modules.

## Dashboard Integration

The dashboard now uses these reusable components for:
- Toolbar actions (Add User, Refresh, Export)
- Filter controls (Clear Filters, Sort Direction)
- Table row actions (View, Edit, Delete, Approve, Reject)
- Modal actions (Save, Cancel, Approve, Reject)

This provides a consistent user experience and makes the codebase more maintainable.
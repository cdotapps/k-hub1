import { Component, Input, Output, EventEmitter } from '@angular/core';

export interface TabItem {
  label: string;
  value: string;
  icon?: any;
}

@Component({
  selector: 'app-tabs',
  templateUrl: './tabs.component.html',
  styleUrls: ['./tabs.component.css']
})
export class TabsComponent {
  @Input() tabs: TabItem[] = [];
  @Input() activeTab: string = '';
  @Output() tabChange = new EventEmitter<string>();

  onTabClick(tab: TabItem) {
    if (tab.value !== this.activeTab) {
      this.tabChange.emit(tab.value);
    }
  }
}

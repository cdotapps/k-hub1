import { Component, Input, Output, EventEmitter, OnInit, OnDestroy } from '@angular/core';
import { 
  faRobot, faPaperPlane, faSpinner, faTimes, faUser, 
  faExpand, faCompress, faCopy, faThumbsUp, faThumbsDown
} from '@fortawesome/free-solid-svg-icons';
import { Catalog } from '../../models/user.interface';

interface ChatMessage {
  id: string;
  content: string;
  isUser: boolean;
  timestamp: Date;
  isLoading?: boolean;
}

@Component({
  selector: 'app-ai-chat',
  templateUrl: './ai-chat.component.html',
  styleUrls: ['./ai-chat.component.css']
})
export class AiChatComponent implements OnInit, OnDestroy {
  @Input() catalogItem: Catalog | null = null;
  @Input() isOpen: boolean = false;
  @Output() closeChat = new EventEmitter<void>();

  // FontAwesome icons
  faRobot = faRobot;
  faPaperPlane = faPaperPlane;
  faSpinner = faSpinner;
  faTimes = faTimes;
  faUser = faUser;
  faExpand = faExpand;
  faCompress = faCompress;
  faCopy = faCopy;
  faThumbsUp = faThumbsUp;
  faThumbsDown = faThumbsDown;

  // Chat state
  messages: ChatMessage[] = [];
  currentMessage: string = '';
  isLoading: boolean = false;
  isExpanded: boolean = false;

  // Sample conversation starters based on catalog content
  conversationStarters: string[] = [
    'Can you summarize this article?',
    'What are the key takeaways?',
    'Explain this in simpler terms',
    'What questions should I ask about this topic?'
  ];

  ngOnInit(): void {
    if (this.catalogItem && this.isOpen) {
      this.initializeChat();
    }
  }

  ngOnDestroy(): void {
    // Cleanup if needed
  }

  private initializeChat(): void {
    // Add welcome message
    const welcomeMessage: ChatMessage = {
      id: this.generateMessageId(),
      content: `Hello! I'm here to help you understand and explore "${this.catalogItem?.title}". What would you like to know?`,
      isUser: false,
      timestamp: new Date()
    };
    this.messages = [welcomeMessage];
  }

  sendMessage(): void {
    if (!this.currentMessage.trim() || this.isLoading) return;

    // Add user message
    const userMessage: ChatMessage = {
      id: this.generateMessageId(),
      content: this.currentMessage,
      isUser: true,
      timestamp: new Date()
    };
    this.messages.push(userMessage);

    // Clear input
    const messageToSend = this.currentMessage;
    this.currentMessage = '';

    // Add loading message
    const loadingMessage: ChatMessage = {
      id: this.generateMessageId(),
      content: '',
      isUser: false,
      timestamp: new Date(),
      isLoading: true
    };
    this.messages.push(loadingMessage);

    this.isLoading = true;

    // Simulate AI response (replace with actual AI service call)
    this.simulateAIResponse(messageToSend, loadingMessage.id);
  }

  private simulateAIResponse(userMessage: string, loadingMessageId: string): void {
    // Simulate API delay
    setTimeout(() => {
      // Remove loading message
      this.messages = this.messages.filter(msg => msg.id !== loadingMessageId);

      // Generate response based on user message and catalog content
      const response = this.generateAIResponse(userMessage);

      const aiMessage: ChatMessage = {
        id: this.generateMessageId(),
        content: response,
        isUser: false,
        timestamp: new Date()
      };

      this.messages.push(aiMessage);
      this.isLoading = false;
    }, 1500);
  }

  private generateAIResponse(userMessage: string): string {
    const lowerMessage = userMessage.toLowerCase();
    
    if (lowerMessage.includes('summarize') || lowerMessage.includes('summary')) {
      return this.catalogItem?.summary || 
        `Based on "${this.catalogItem?.title}", here are the key points I can extract from the content...`;
    }
    
    if (lowerMessage.includes('key takeaway') || lowerMessage.includes('main point')) {
      return `The main takeaways from "${this.catalogItem?.title}" include several important concepts that relate to ${this.catalogItem?.category}...`;
    }
    
    if (lowerMessage.includes('explain') || lowerMessage.includes('simpler')) {
      return `Let me break down "${this.catalogItem?.title}" in simpler terms. This article discusses...`;
    }
    
    if (lowerMessage.includes('question')) {
      return `Here are some thoughtful questions you might consider about "${this.catalogItem?.title}": 1) How does this relate to current industry trends? 2) What are the practical applications? 3) What might be the long-term implications?`;
    }
    
    // Default response
    return `That's an interesting question about "${this.catalogItem?.title}". Based on the content, I can help you explore this topic further. What specific aspect would you like me to focus on?`;
  }

  useConversationStarter(starter: string): void {
    this.currentMessage = starter;
    this.sendMessage();
  }

  toggleExpanded(): void {
    this.isExpanded = !this.isExpanded;
  }

  copyMessage(content: string): void {
    navigator.clipboard.writeText(content).then(() => {
      // Could add a toast notification here
      console.log('Message copied to clipboard');
    }).catch(console.error);
  }

  rateMessage(messageId: string, isPositive: boolean): void {
    // Handle message rating - could send to analytics service
    console.log(`Message ${messageId} rated as ${isPositive ? 'positive' : 'negative'}`);
  }

  onClose(): void {
    this.closeChat.emit();
  }

  onKeyPress(event: KeyboardEvent): void {
    if (event.key === 'Enter' && !event.shiftKey) {
      event.preventDefault();
      this.sendMessage();
    }
  }

  private generateMessageId(): string {
    return Date.now().toString() + Math.random().toString(36).substr(2, 9);
  }

  getMessageTime(timestamp: Date): string {
    return timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  }
}
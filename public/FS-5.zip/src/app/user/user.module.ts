import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { FontAwesomeModule } from '@fortawesome/angular-fontawesome';

// Import SharedModule to get access to all shared components
import { SharedModule } from '../shared/shared.module';
import { UserGuard } from '../shared/guards/auth.guard';

// User Components
import { UserHomeComponent } from './home/home.component';
import { SettingsComponent } from './settings/settings.component';
import { CatalogDetailComponent } from './catalog/catalog-detail.component';
import { CreateArticleComponent } from './catalog/create-article.component';
import { CatalogTypeService } from '../shared/services/catalog-type.service';

const userRoutes = [
  { 
    path: 'user/catalog/create', 
    component: CreateArticleComponent, 
    canActivate: [UserGuard] 
  },
  { 
    path: 'user/catalog/:id', 
    component: CatalogDetailComponent, 
    canActivate: [UserGuard] 
  }
];

@NgModule({
  declarations: [
    UserHomeComponent,
    SettingsComponent,
    CatalogDetailComponent,
    CreateArticleComponent
  ],
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    SharedModule,
    FontAwesomeModule,
    RouterModule.forChild(userRoutes)
  ],
  exports: [
    UserHomeComponent,
    SettingsComponent,
    CatalogDetailComponent,
    CreateArticleComponent
  ],
  providers: [
    CatalogTypeService
  ]
})
export class UserModule { }
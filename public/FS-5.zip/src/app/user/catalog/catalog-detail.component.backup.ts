import { Component, OnInit, OnDestroy } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Subscription } from 'rxjs';
import { DomSanitizer, SafeHtml } from '@angular/platform-browser';

// FontAwesome Icons
import {
  faNewspaper, faCalendar, faUser, faTag, faEye, faHeart, faShare, faEdit, faTrash,
  faArrowLeft, faExternalLinkAlt, faDownload, faBookmark, faClock,
  faThumbsUp, faComment, faFlag, faXmark, faSpinner, faExclamationTriangle,
  faCheckCircle, faTimes, faReply, faPaperPlane, faEllipsisV, faPlus,
  faEnvelope, faCopy, faExpand, faInfoCircle, faList, faSliders, faSave, faCheck,
  faLayerGroup, faLink, faArrowRight, faChevronRight,
  faRobot, // <-- Add this
  faRefresh // <-- Add this
} from '@fortawesome/free-solid-svg-icons';

// Services and Models
import { CatalogService } from '../../shared/services/catalog.service';
import { AuthService } from '../../shared/services/auth.service';
import { DateUtilityService } from '../../shared/services/date-utility.service';
import { TemplateService } from '../../shared/services/template.service';
import { Catalog, User, CatalogConversation, ConversationMessage, CatalogChildItem } from '../../shared/models/user.interface';

// Add interface for additional attributes
interface AdditionalAttribute {
  attribute: string;
  value: string;
  group: string;
}

@Component({
  selector: 'app-catalog-detail',
  templateUrl: './catalog-detail.component.html',
  styleUrls: ['./catalog-detail.component.css']
})
export class CatalogDetailComponent implements OnInit, OnDestroy {
  // FontAwesome Icons
  faNewspaper = faNewspaper;
  faCalendar = faCalendar;
  faUser = faUser;
  faTag = faTag;
  faEye = faEye;
  faHeart = faHeart;
  faShare = faShare;
  faEdit = faEdit;
  faTrash = faTrash;
  faArrowLeft = faArrowLeft;
  faExternalLinkAlt = faExternalLinkAlt;
  faDownload = faDownload;
  faBookmark = faBookmark;
  faClock = faClock;
  faThumbsUp = faThumbsUp;
  faComment = faComment;
  faFlag = faFlag;
  faXmark = faXmark;
  faSpinner = faSpinner;
  faExclamationTriangle = faExclamationTriangle;
  faCheckCircle = faCheckCircle;
  faTimes = faTimes;
  faReply = faReply;
  faPaperPlane = faPaperPlane;
  faEllipsisV = faEllipsisV;
  faPlus = faPlus;
  faEnvelope = faEnvelope;
  faCopy = faCopy;
  faExpand = faExpand;
  faInfoCircle = faInfoCircle;
  faList = faList;
  faSliders = faSliders;
  faSave = faSave;
  faCheck = faCheck;
  faLayerGroup = faLayerGroup;
  faLink = faLink;
  faArrowRight = faArrowRight;
  faChevronRight = faChevronRight;
  faRobot = faRobot; // <-- Add this
  faRefresh = faRefresh; // <-- Add this

  // Template reference for the "no comments" state
  noComments = null;

  // Data Properties
  catalogItem: Catalog | null = null;
  relatedItems: Catalog[] = [];
  currentUser: User | null = null;
  isLoading = false;
  showShareModal = false;
  showFullView = false;
  errorMessage = '';
  breadcrumbItems: any[] = [];

  // ===== CONVERSATION PROPERTIES =====
  conversations: ConversationMessage[] = [];
  conversationCount = 0; // Track conversation count separately
  isLoadingConversations = false;
  showConversations = false;
  newMessage = '';
  isPostingMessage = false;
  replyingTo: ConversationMessage | null = null;
  replyMessage = '';
  editingMessage: ConversationMessage | null = null;
  editMessageText = '';

  // Messages for chatbox
  messages: ConversationMessage[] = [];

  // Debug Properties
  showDebugInfo = false;

  // Additional attributes popup state
  showAdditionalAttributes = false;
  additionalAttributes: AdditionalAttribute[] = [];

  // Simplified inline editing state (replacing separate edit popup)
  isEditingAttributes = false;
  newAttributeForGroup = '';
  showFirstAttributeForm = false;

  // Edit attributes popup state
  showEditAttributes = false;
  editableAttributes: AdditionalAttribute[] = [];
  newAttributeGroup = 'General';
  newAttributeName = '';
  newAttributeValue = '';
  isSavingAttributes = false;

  // Group management state
  showAddGroupForm = false;
  newGroupName = '';
  isAddingGroup = false;

  // Full view content
  fullViewHTML = '';

  // Modal state for delete confirmation
  showDeleteConfirm = false;

  // Add this property to prevent multiple markAsRead calls
  private hasMarkedAsRead = false;

  private subscriptions = new Subscription();

  constructor(
    private route: ActivatedRoute,
    private router: Router,
    private catalogService: CatalogService,
    private authService: AuthService,
    private dateUtilityService: DateUtilityService,
    private templateService: TemplateService,
    private sanitizer: DomSanitizer
  ) { }

  ngOnInit(): void {
    // Initialize breadcrumbs
    this.initializeBreadcrumbs();

    window.addEventListener('scroll', this.onScroll, true);

    // Subscribe to authentication state
    this.subscriptions.add(
      this.authService.currentUser$.subscribe((user: User | null) => {
        this.currentUser = user;
      })
    );

    // Subscribe to route params
    this.subscriptions.add(
      this.route.params.subscribe(params => {
        const itemId = params['id'];
        if (itemId) {
          this.loadCatalogItem(itemId);
        }
      })
    );
  }

  ngOnDestroy(): void {
    this.subscriptions.unsubscribe();
    window.removeEventListener('scroll', this.onScroll, true);
  }

  /**
   * Scroll event handler to mark as read when user scrolls past 30% of the page
   */
  onScroll = (): void => {
    if (this.hasMarkedAsRead || !this.catalogItem) return;

    const scrollTop = window.scrollY || document.documentElement.scrollTop;
    const docHeight = document.documentElement.scrollHeight - document.documentElement.clientHeight;
    if (docHeight <= 0) return;

    const scrollPercent = scrollTop / docHeight;
    if (scrollPercent > 0.3) {
      this.markAsRead();
      this.hasMarkedAsRead = true;
    }
  };

  markAsRead(): void {
    if (!this.catalogItem) return;

    if (!this.catalogItem.read) {
      // Call service to mark as read
      this.catalogService.markAsRead(this.catalogItem.id).subscribe({
        next: (updatedItem) => {
         },
        error: (error) => {
          console.error('Failed to mark as read:', error);
        }
      });
    }
  }

  /**
   * Initialize breadcrumb items
   */
  private initializeBreadcrumbs(): void {
    this.breadcrumbItems = [
      { label: 'Dashboard', routerLink: '/user/dashboard' },
      { label: 'Catalog', routerLink: '/user/catalog' },
      { label: 'Article Details', routerLink: null } // Current page
    ];
  }

  /**
   * Update breadcrumbs with article title once loaded
   */
  private updateBreadcrumbs(): void {
    if (this.catalogItem) {
      this.breadcrumbItems = [
        { label: 'Dashboard', routerLink: '/user/dashboard' },
        { label: 'Catalog', routerLink: '/user/catalog' },
        { label: this.catalogItem.title, routerLink: null } // Current article title
      ];
    }
  }

  /**
   * Load catalog item details
   */
  loadCatalogItem(itemId: string): void {
    this.isLoading = true;

    this.catalogService.getCatalogItem(itemId).subscribe({
      next: (item) => {
        this.catalogItem = item;
        console.log('Loaded catalog item:', this.catalogItem);
        this.isLoading = false;

        // Update breadcrumbs with article title
        this.updateBreadcrumbs();

        // Update view count
        this.incrementViewCount();

        // Load related items
        this.loadRelatedItems();

        // Load comment count only (not the full conversations)
        this.loadCommentCount();

        // Load additional attributes from custom property
        this.loadAdditionalAttributes();
      },
      error: (error) => {
        console.error('Failed to load catalog item:', error);
        this.isLoading = false;
        // Navigate back to catalog on error
        this.router.navigate(['/user/catalog']);
      }
    });
  }

  /**
   * Increment view count
   */
  private incrementViewCount(): void {
    if (!this.catalogItem) return;

    this.catalogService.incrementViewCount(this.catalogItem.id).subscribe({
      next: (updatedItem) => {
        if (this.catalogItem) {
          this.catalogItem.views_count = updatedItem.views_count;
        }
      },
      error: (error) => {
        console.error('Failed to increment view count:', error);
      }
    });
  }

  /**
   * Load related items
   */
  private loadRelatedItems(): void {
    if (!this.catalogItem) return;

    const params = {
      category: this.catalogItem.category,
      limit: 4,
      exclude: this.catalogItem.id
    };

    this.catalogService.getCatalogItems(params).subscribe({
      next: (response) => {
        this.relatedItems = response.items || [];
      },
      error: (error) => {
        console.error('Failed to load related items:', error);
        this.relatedItems = [];
      }
    });
  }

  /**
   * Navigate back to catalog
   */
  goBack(): void {
    this.router.navigate(['/user/catalog']);
  }

  /**
   * Navigate to related item
   */
  goToRelatedItem(item: Catalog): void {
    this.router.navigate(['/user/catalog', item.id]);
  }

  /**
   * Toggle like status
   */
  toggleLike(): void {
    if (!this.catalogItem || !this.currentUser) return;

    const isLiked = this.catalogItem.user_has_liked;
    const action = isLiked ? 'unlike' : 'like';

    this.catalogService.toggleLike(this.catalogItem.id, action).subscribe({
      next: (response) => {
        if (this.catalogItem) {
          this.catalogItem.user_has_liked = !isLiked;
          this.catalogItem.likes_count = response.likes_count;
        }
      },
      error: (error) => {
        console.error('Failed to toggle like:', error);
      }
    });
  }

  /**
   * Share item
   */
  shareItem(): void {
    if (!this.catalogItem) return;

    if (navigator.share) {
      // Use native sharing if available
      navigator.share({
        title: this.catalogItem.title,
        text: this.catalogItem.description || this.getExcerpt(this.catalogItem.content || '', 100),
        url: window.location.href
      }).catch(console.error);
    } else {
      // Fallback to custom share modal
      this.showShareModal = true;
    }
  }

  /**
   * Close share modal
   */
  closeShareModal(): void {
    this.showShareModal = false;
  }

  /**
   * Copy link to clipboard
   */
  copyLink(): void {
    navigator.clipboard.writeText(window.location.href).then(() => {
      console.log('Link copied to clipboard');
      this.closeShareModal();
    }).catch(console.error);
  }

  /**
   * Email article
   */
  emailArticle(): void {
    if (!this.catalogItem) return;

    const subject = encodeURIComponent(`Article: ${this.catalogItem.title}`);

    // Convert HTML content to plain text and limit length
    const rawContent = this.catalogItem.content || this.catalogItem.description || '';
    const plainTextContent = this.stripHtmlTags(rawContent);
    const articleContent = plainTextContent.length > 1500
      ? plainTextContent.substring(0, 1500) + '...'
      : plainTextContent;

    const body = encodeURIComponent(`
Hi,

I thought you might be interested in this article:

Title: ${this.catalogItem.title}
Author: ${this.getAuthorDisplayName()}
Read Time: ${this.getReadingTime()}

${articleContent}

Read the full article here: ${window.location.href}

Best regards
    `);

    window.location.href = `mailto:?subject=${subject}&body=${body}`;
  }

  /**
   * Copy article link
   */
  copyArticleLink(): void {
    navigator.clipboard.writeText(window.location.href).then(() => {
      // Show success message (you could implement a toast service here)
      console.log('Article link copied to clipboard');
      // You could add a toast notification here
    }).catch(error => {
      console.error('Failed to copy link:', error);
    });
  }

  /**
   * Check if user can edit this item
   */
  canEdit(): boolean {
    // For testing purposes, always return true to see the edit options
    // You should remove this override after testing
    return true;

    // Original implementation:
    // if (!this.catalogItem || !this.currentUser) return false;
    // return this.currentUser?.user_id === this.catalogItem.author_id || 
    //       this.currentUser?.role === 'admin';
  }

  /**
   * Check if user can delete this item
   */
  canDelete(): boolean {
    if (!this.catalogItem || !this.currentUser) return false;
    return this.currentUser?.id === this.catalogItem.author_id ||
      this.currentUser?.role === 'admin';
  }

  /**
   * Edit item
   */
  editItem(): void {
    if (!this.catalogItem || !this.canEdit()) return;

    // Navigate to edit page using create-article component with the id parameter
    // This will load the item in edit mode
    this.router.navigate(['/user/catalog/edit', this.catalogItem.id]);
  }

  /**
   * Delete item
   */
  deleteItem(): void {
    if (!this.catalogItem || !this.canDelete()) return;

    if (confirm('Are you sure you want to delete this item?')) {
      this.catalogService.deleteCatalogItem(this.catalogItem.id).subscribe({
        next: () => {
          this.router.navigate(['/user/catalog']);
        },
        error: (error) => {
          console.error('Failed to delete item:', error);
        }
      });
    }
  }

  /**
   * Check if user can edit this item (alias for canEdit)
   */
  canEditItem(): boolean {
    return this.canEdit();
  }

  /**
   * Check if user can delete this item (alias for canDelete)
   */
  canDeleteItem(): boolean {
    return this.canDelete();
  }

  /**
   * Get formatted publish date
   */
  getFormattedPublishDate(): string {
    return this.catalogItem?.published_at
      ? this.formatDate(this.catalogItem.published_at)
      : this.formatDate(this.catalogItem?.created_date || '');
  }

  /**
   * Get reading time estimate
   */
  getReadingTime(): string {
    const content = this.catalogItem?.content || '';
    const wordsPerMinute = 200;
    const wordCount = content.split(' ').length;
    const minutes = Math.ceil(wordCount / wordsPerMinute);
    return `${minutes} min`;
  }

  /**
   * Format date for comments (similar to attachment format)
   */
  formatCommentDate(dateString: string | undefined): string {
    if (!dateString) return '';

    const date = new Date(dateString);
    const now = new Date();
    const diffInSeconds = Math.floor((now.getTime() - date.getTime()) / 1000);
    const diffInMinutes = Math.floor(diffInSeconds / 60);
    const diffInHours = Math.floor(diffInMinutes / 60);
    const diffInDays = Math.floor(diffInHours / 24);

    if (diffInSeconds < 60) {
      return 'Just now';
    } else if (diffInMinutes < 60) {
      return `${diffInMinutes} min${diffInMinutes > 1 ? 's' : ''} ago`;
    } else if (diffInHours < 24) {
      return `${diffInHours} hour${diffInHours > 1 ? 's' : ''} ago`;
    } else if (diffInDays < 7) {
      return `${diffInDays} day${diffInDays > 1 ? 's' : ''} ago`;
    } else {
      // For older comments, show the actual date
      const options: Intl.DateTimeFormatOptions = {
        year: 'numeric',
        month: 'short',
        day: 'numeric'
      };
      return date.toLocaleDateString('en-US', options);
    }
  }

  

  /**
   * Get publish date for meta tag
   */
  getPublishDateForMeta(): string {
    if (!this.catalogItem) return '';
    const publishDate = new Date(this.catalogItem?.published_at || this.catalogItem?.created_date || '');
    return publishDate.toISOString();
  }

  /**
   * Get last updated text
   */
  getLastUpdated(): string {
    if (!this.catalogItem?.updated_date) return '';

    const updatedDate = new Date(this.catalogItem.updated_date);
    const publishDate = new Date(this.catalogItem.published_at || this.catalogItem.created_date || '');

    // Only show "Last updated" if it was updated after initial publication
    if (updatedDate > publishDate) {
      return `Last updated ${this.formatRelativeTime(this.catalogItem.updated_date)}`;
    }

    return '';
  }

  /**
   * Format date
   */
  formatDate(dateString: string): string {
    if (!dateString) return '';
    return this.dateUtilityService.formatDate(dateString);
  }

  /**
   * Format relative time
   */
  formatRelativeTime(dateString: string | undefined): string {
    if (!dateString) return '';
    return this.dateUtilityService.getRelativeTime(dateString);
  }

  /**
   * Get excerpt from text
   */
  getExcerpt(text: string | undefined, maxLength: number = 150): string {
    if (!text) return '';
    if (text.length <= maxLength) return text;
    return text.substring(0, maxLength) + '...';
  }

  /**
   * Get category CSS class
   */
  getCategoryClass(category: string | undefined): string {
    if (!category) return '';
    const categoryMap: { [key: string]: string } = {
      'news': 'category-news',
      'article': 'category-article',
      'announcement': 'category-announcement',
      'guide': 'category-guide',
      'tutorial': 'category-tutorial',
      'documentation': 'category-documentation',
      'blog': 'category-blog',
      'research': 'category-research',
      'whitepaper': 'category-whitepaper',
      'case-study': 'category-case-study'
    };
    return categoryMap[category] || 'category-default';
  }

  /**
   * Get item status CSS class
   */
  getItemStatusClass(status: string | undefined): string {
    if (!status) return '';
    const statusMap: { [key: string]: string } = {
      'draft': 'status-draft',
      'published': 'status-published',
      'archived': 'status-archived',
      'pending': 'status-pending',
      'approved': 'status-approved',
      'rejected': 'status-rejected'
    };
    return statusMap[status] || 'status-default';
  }

  /**
   * Download article (if URL is available)
   */
  downloadArticle(): void {
    if (!this.catalogItem?.url) return;

    const link = document.createElement('a');
    link.href = this.catalogItem.url;
    link.download = this.catalogItem.title;
    link.click();
  }

  /**
   * Open external link
   */
  openExternalLink(): void {
    if (!this.catalogItem?.url) return;
    window.open(this.catalogItem.url, '_blank');
  }

  /**
   * Report content
   */
  reportContent(): void {
    if (!this.catalogItem) return;
    // Implement reporting functionality
    console.log('Report content:', this.catalogItem);
  }

  /**
   * Bookmark item
   */
  bookmarkItem(): void {
    if (!this.catalogItem) return;
    // Implement bookmark functionality
    console.log('Bookmark item:', this.catalogItem);
  }

  /**
   * Get author display name
   */
  getAuthorDisplayName(): string {
    return this.catalogItem?.author || 'Unknown Author';
  }

  /**
   * Get published date
   */
  getPublishedDate(): string {
    return this.catalogItem?.published_at
      ? this.formatDate(this.catalogItem.published_at)
      : this.formatDate(this.catalogItem?.created_date || '');
  }

  /**
   * Check if comment is recent (within last 24 hours) to show "Pending" status
   */
  isRecentComment(dateString: string | undefined): boolean {
    if (!dateString) return false;

    const commentDate = new Date(dateString);
    const oneDayAgo = new Date();
    oneDayAgo.setDate(oneDayAgo.getDate() - 1);

    return commentDate > oneDayAgo;
  }

  // ===== CONVERSATION METHODS =====

  /**
   * Get conversation count
   */
  getConversationCount(): number {
    // Return the separate conversation count if available, otherwise fall back to conversations length
    return this.conversationCount || this.conversations?.length || 0;
  }

  /**
   * Load conversation count only (without loading full conversations)
   */
  loadCommentCount(): void {
    if (!this.catalogItem) return;

    // Use the catalog's conversations property if available
    if (this.catalogItem.conversations && this.catalogItem.conversations.total_messages !== undefined) {
      this.conversationCount = this.catalogItem.conversations.total_messages;
      return;
    }

    // Load conversations count from API
    this.catalogService.getCatalogConversations(this.catalogItem.id).subscribe({
      next: (conversations) => {
        this.conversationCount = conversations.total_messages || 0;
        // Store the conversations data for later use
        if (this.catalogItem) {
          this.catalogItem.conversations = {
            messages: conversations.messages || [],
            total_messages: conversations.total_messages || 0,
            last_activity: conversations.last_activity || new Date().toISOString()
          };
        }
      },
      error: (error) => {
        console.error('Failed to load conversation count:', error);
        this.conversationCount = 0;

        // Initialize empty conversations structure
        if (this.catalogItem) {
          this.catalogItem.conversations = {
            messages: [],
            total_messages: 0,
            last_activity: new Date().toISOString()
          };
        }
      }
    });
  }

  /**
   * Load conversations for the catalog item
   */
  loadConversations(): void {
    if (!this.catalogItem) return;

    this.isLoadingConversations = true;

    // First check if catalog already has conversations loaded
    if (this.catalogItem.conversations &&
      this.catalogItem.conversations.messages &&
      this.catalogItem.conversations.messages.length > 0) {
      // Sort conversations by most recent first (newest at top)
      this.conversations = this.catalogItem.conversations.messages.sort((a, b) =>
        new Date(b.created_date).getTime() - new Date(a.created_date).getTime()
      );
      this.conversationCount = this.catalogItem.conversations.total_messages;
      this.isLoadingConversations = false;
      return;
    }

    // Load conversations from API
    this.catalogService.getCatalogConversations(this.catalogItem.id).subscribe({
      next: (conversations) => {
        // Sort conversations by most recent first (newest at top)
        this.conversations = (conversations.messages || []).sort((a, b) =>
          new Date(b.created_date).getTime() - new Date(a.created_date).getTime()
        );

        // Update conversation count
        this.conversationCount = conversations.total_messages || 0;

        // Update the catalog item's conversations property
        if (this.catalogItem) {
          this.catalogItem.conversations = {
            messages: this.conversations,
            total_messages: this.conversationCount,
            last_activity: conversations.last_activity || new Date().toISOString()
          };
        }

        this.isLoadingConversations = false;
      },
      error: (error) => {
        console.error('Failed to load conversations:', error);
        this.conversations = [];
        this.conversationCount = 0;

        // Initialize empty conversations structure
        if (this.catalogItem) {
          this.catalogItem.conversations = {
            messages: [],
            total_messages: 0,
            last_activity: new Date().toISOString()
          };
        }

        this.isLoadingConversations = false;
      }
    });
  }

  /**
   * Toggle conversations display
   */
  toggleConversations(): void {
    this.showConversations = !this.showConversations;
    if (this.showConversations && this.conversations.length === 0) {
      this.loadConversations();
    }
  }

  /**
   * Close conversations
   */
  closeConversations(): void {
    this.showConversations = false;
  }

  /**
   * Check if there are conversation messages
   */
  hasConversationMessages(): boolean {
    return this.conversations && this.conversations.length > 0;
  }

  /**
   * Track function for ngFor on messages
   */
  trackByMessageId(index: number, message: ConversationMessage): string {
    return message.id;
  }

  /**
   * Get user initials for avatar
   */
  getUserInitials(name: string): string {
    if (!name) return 'U';
    const names = name.split(' ');
    if (names.length === 1) {
      return names[0].charAt(0).toUpperCase();
    }
    return (names[0].charAt(0) + names[names.length - 1].charAt(0)).toUpperCase();
  }

  /**
   * Get message user display name
   */
  getMessageUserDisplayName(message: ConversationMessage): string {
    return message.user_name || 'Unknown User';
  }

  /**
   * Handle textarea keydown for posting messages
   */
  onTextareaKeydown(event: KeyboardEvent, type: 'post' | 'edit' | 'reply'): void {
    if (event.key === 'Enter' && (event.ctrlKey || event.metaKey)) {
      event.preventDefault();
      switch (type) {
        case 'post':
          this.postMessage();
          break;
        case 'edit':
          this.saveEdit();
          break;
        case 'reply':
          this.postReply();
          break;
      }
    }
  }

  /**
   * Post a new message - using stub implementation
   */
  postMessage(): void {
    if (!this.newMessage.trim() || !this.catalogItem || !this.currentUser) return;

    this.isPostingMessage = true;

    console.log('🔄 Posting message with current user:', {
      id: this.currentUser.id,
      user_id: this.currentUser.user_id,
      first_name: this.currentUser.first_name,
      last_name: this.currentUser.last_name,
      profile_image: this.currentUser.profile_image
    });

    // Use the API to post the message
    this.catalogService.addConversationMessage(this.catalogItem.id, this.newMessage.trim()).subscribe({
      next: (newMessage) => {
        console.log('📨 Received new message from API:', newMessage);

        // Ensure the message has proper user information
        const enrichedMessage: ConversationMessage = {
          ...newMessage,
          user_id: newMessage.user_id || this.currentUser!.id,
          user_name: newMessage.user_name || this.getUserDisplayName(this.currentUser!),
          user_profile_image: newMessage.user_profile_image || this.currentUser!.profile_image || undefined
        };

        console.log('✨ Enriched message:', enrichedMessage);

        // Add new message to the beginning (most recent first)
        this.conversations = [enrichedMessage, ...this.conversations];

        // Update conversation count
        this.conversationCount = this.conversations.length;

        // Initialize conversations structure if it doesn't exist
        if (!this.catalogItem!.conversations) {
          this.catalogItem!.conversations = {
            messages: [],
            total_messages: 0,
            last_activity: new Date().toISOString()
          };
        }

        // Update the catalog item's conversations property
        this.catalogItem!.conversations = {
          messages: this.conversations,
          total_messages: this.conversationCount,
          last_activity: new Date().toISOString()
        };

        this.newMessage = '';
        this.isPostingMessage = false;
      },
      error: (error) => {
        console.error('Failed to post message:', error);
        this.isPostingMessage = false;
        // TODO: Show error message to user
      }
    });
  }

  showJSON(): void {
    if (!this.catalogItem) return;
    const dataStr = JSON.stringify(this.catalogItem, null, 2);
    const html = `
      <html>
        <head>
          <title>${this.catalogItem.title || 'Catalog Item'} - JSON</title>
          <style>
            body { background: #222; color: #eee; margin: 0; padding: 0; }
            pre { background: #181818; color: #00e676; padding: 2rem; margin: 0; font-size: 1.1rem; overflow-x: auto; }
            .header { background: #111; color: #fff; padding: 1rem 2rem; font-size: 1.2rem; font-family: sans-serif; }
          </style>
        </head>
        <body>
          <div class="header">${this.catalogItem.title || 'Catalog Item'} JSON</div>
          <pre>${dataStr.replace(/</g, '&lt;').replace(/>/g, '&gt;')}</pre>
        </body>
      </html>
    `;
    const win = window.open('', '_blank');
    if (win) {
      win.document.open();
      win.document.write(html);
      win.document.close();
    }
  }

  cancelApprovalRequest(): void {
    if (!this.catalogItem) return;
    this.isLoading = true;
    this.catalogService.cancelApprovalRequest(this.catalogItem.id).subscribe({
      next: (updatedItem) => {
        this.catalogItem = updatedItem;
        this.isLoading = false;
      },
      error: (err) => {
        this.isLoading = false;
        // Optionally show an error message
        this.errorMessage = 'Failed to approve item. Please try again.';
        console.error('Approve error:', err);
      }
    });
  }

  approveItem(): void {
    if (!this.catalogItem) return;
    this.isLoading = true;
    this.catalogService.approveCatalogItem(this.catalogItem.id).subscribe({
      next: (updatedItem) => {
        this.catalogItem = updatedItem;
        this.isLoading = false;
      },
      error: (err) => {
        this.isLoading = false;
        // Optionally show an error message
        this.errorMessage = 'Failed to approve item. Please try again.';
        console.error('Approve error:', err);
      }
    });
  }
  reviseContent(): void {
    if (!this.catalogItem) return;
    this.isLoading = true;
    this.catalogService.reviseContent(this.catalogItem.id).subscribe({
      next: (updatedItem) => {
        this.catalogItem = updatedItem;
        this.isLoading = false;
      },
      error: (err) => {
        this.isLoading = false;
        // Optionally show an error message
        this.errorMessage = 'Failed to approve item. Please try again.';
        console.error('Revise error:', err);
      }
    });
  }


  /**
   * Get current user display name
   */
  getUserDisplayName(user: User): string {
    if (!user) return 'Unknown User';

    // Try to build full name from first and last name
    const firstName = (user.first_name || '').trim();
    const lastName = (user.last_name || '').trim();
    const fullName = `${firstName} ${lastName}`.trim();

    if (fullName) {
      return fullName;
    }

    // Fall back to user_id, email, or default
    return user.user_id || user.email || user.id || 'Unknown User';
  }

  /**
   * Like a message - using stub implementation
   */
  likeMessage(message: ConversationMessage): void {
    if (!this.catalogItem || !this.currentUser) return;

    // Stub implementation - replace with actual API call when available
    message.likes = (message.likes || 0) + 1;
  }

  /**
   * Start replying to a message
   */
  startReply(message: ConversationMessage): void {
    this.replyingTo = message;
    this.replyMessage = '';
  }

  /**
   * Cancel reply
   */
  cancelReply(): void {
    this.replyingTo = null;
    this.replyMessage = '';
  }

  /**
   * Post a reply - using stub implementation
   */
  postReply(): void {
    if (!this.replyMessage.trim() || !this.replyingTo || !this.catalogItem || !this.currentUser) return;

    // Stub implementation - replace with actual API call when available
    const newReply: ConversationMessage = {
      id: Date.now().toString(),
      user_id: this.currentUser.id,
      user_name: this.getUserDisplayName(this.currentUser),
      user_profile_image: this.currentUser.profile_image || undefined,
      message: this.replyMessage.trim(),
      created_date: new Date().toISOString(),
      parent_id: this.replyingTo.id,
      likes: 0,
      replies: []
    };

    if (this.replyingTo) {
      if (!this.replyingTo.replies) {
        this.replyingTo.replies = [];
      }
      this.replyingTo.replies.push(newReply);
    }
    this.cancelReply();
  }

  /**
   * Check if user can edit a message
   */
  canEditMessage(message: ConversationMessage): boolean {
    if (!this.currentUser) return false;
    return message.user_id === this.currentUser.id || this.currentUser.role === 'admin';
  }

  /**
   * Check if user can delete a message
   */
  canDeleteMessage(message: ConversationMessage): boolean {
    if (!this.currentUser) return false;
    return message.user_id === this.currentUser.id || this.currentUser.role === 'admin';
  }

  /**
   * Start editing a message
   */
  startEdit(message: ConversationMessage): void {
    this.editingMessage = message;
    this.editMessageText = message.message;
  }

  /**
   * Cancel edit
   */
  cancelEdit(): void {
    this.editingMessage = null;
    this.editMessageText = '';
  }

  /**
   * Save edit - using stub implementation
   */
  saveEdit(): void {
    if (!this.editMessageText.trim() || !this.editingMessage || !this.catalogItem) return;

    // Use the API to update the message
    this.catalogService.updateConversationMessage(
      this.catalogItem.id,
      this.editingMessage.id,
      this.editMessageText.trim()
    ).subscribe({
      next: (updatedMessage) => {
        // Update the message in the local array
        const index = this.conversations.findIndex(m => m.id === this.editingMessage!.id);
        if (index !== -1) {
          this.conversations[index] = updatedMessage;
        }

        // Initialize conversations structure if it doesn't exist
        if (!this.catalogItem!.conversations) {
          this.catalogItem!.conversations = {
            messages: [],
            total_messages: 0,
            last_activity: new Date().toISOString()
          };
        }

        // Update the catalog item's conversations property
        this.catalogItem!.conversations = {
          messages: this.conversations,
          total_messages: this.conversationCount,
          last_activity: new Date().toISOString()
        };

        this.cancelEdit();
      },
      error: (error) => {
        console.error('Failed to update message:', error);
        // TODO: Show error message to user
        this.cancelEdit();
      }
    });
  }

  /**
   * Delete a message
   */
  deleteMessage(message: ConversationMessage): void {
    if (!confirm('Are you sure you want to delete this message?')) return;
    if (!this.catalogItem) return;

    // Use the API to delete the message
    this.catalogService.deleteConversationMessage(this.catalogItem.id, message.id).subscribe({
      next: () => {
        // Remove message from local array
        this.conversations = this.conversations.filter(m => m.id !== message.id);

        // Update conversation count
        this.conversationCount = this.conversations.length;

        // Initialize conversations structure if it doesn't exist
        if (!this.catalogItem!.conversations) {
          this.catalogItem!.conversations = {
            messages: [],
            total_messages: 0,
            last_activity: new Date().toISOString()
          };
        }

        // Update the catalog item's conversations property
        this.catalogItem!.conversations = {
          messages: this.conversations,
          total_messages: this.conversationCount,
          last_activity: this.conversations.length > 0 ? this.conversations[0].created_date : new Date().toISOString()
        };
      },
      error: (error) => {
        console.error('Failed to delete message:', error);
        // TODO: Show error message to user
      }
    });
  }

  /**
   * Like the main item (alias for toggleLike)
   */
  likeItem(): void {
    this.toggleLike();
  }

  /**
   * View related item
   */
  viewRelatedItem(item: Catalog): void {
    this.router.navigate(['/user/catalog', item.id]);
  }

  /**
   * Go to catalog page
   */
  goToCatalog(): void {
    this.router.navigate(['/user/catalog']);
  }

  /**
   * Show delete confirmation
   */
  showDeleteConfirmation(): void {
    this.showDeleteConfirm = true;
  }

  /**
   * Cancel delete
   */
  cancelDelete(): void {
    this.showDeleteConfirm = false;
  }

  /**
   * Confirm delete
   */
  confirmDelete(): void {
    this.showDeleteConfirm = false;
    this.deleteItem();
  }

  /**
   * Get created date with full timestamp
   */
  getCreatedDateWithTime(): string {
    if (!this.catalogItem?.created_date) return 'Unknown';
    return this.dateUtilityService.formatDateWithTime(this.catalogItem.created_date);
  }

  /**
   * Get updated date with full timestamp
   */
  getUpdatedDateWithTime(): string {
    if (!this.catalogItem?.updated_date) return 'Unknown';
    return this.dateUtilityService.formatDateWithTime(this.catalogItem.updated_date);
  }

  /**
   * Check if the item has been updated (updated_date is different from created_date)
   */
  hasBeenUpdated(): boolean {
    if (!this.catalogItem?.updated_date || !this.catalogItem?.created_date) return false;

    const createdDate = new Date(this.catalogItem.created_date);
    const updatedDate = new Date(this.catalogItem.updated_date);

    // Consider it updated if the difference is more than 1 minute
    const diffInMinutes = Math.abs(updatedDate.getTime() - createdDate.getTime()) / (1000 * 60);
    return diffInMinutes > 1;
  }

  /**
   * Check if catalog item has tags
   */
  hasTags(): boolean {
    return !!(this.catalogItem?.tags && this.catalogItem.tags.length > 0);
  }

  /**
   * Get catalog item tags safely
   */
  getTags(): string[] {
    return this.catalogItem?.tags || [];
  }

  /**
   * Close chatbox
   */
  closeChatbox(): void {
    this.showConversations = false;
  }

  /**
   * Send a new message in chatbox
   */
  sendMessage(): void {
    if (this.newMessage.trim()) {
      const newMessage: ConversationMessage = {
        user_name: `${this.currentUser?.first_name || ''} ${this.currentUser?.last_name || 'Anonymous'}`.trim(),
        created_date: new Date().toISOString(),
        message: this.newMessage.trim(),
        id: Date.now().toString(),
        user_id: this.currentUser?.id || '0',
        likes: 0,
        replies: []
      };
      this.conversations.push(newMessage);
      this.newMessage = '';
    }
  }

  /**
   * Auto-resize textarea based on content
   */
  autoResizeTextarea(event: any): void {
    const textarea = event.target;
    textarea.style.height = 'auto';
    textarea.style.height = Math.min(textarea.scrollHeight, 120) + 'px'; // Max height of 120px
  }

  /**
   * Open full view modal for copy/paste
   */
  openFullView(): void {
    this.showFullView = true;
    this.generateFullViewHTML();
  }

  /**
   * Close full view modal
   */
  closeFullView(): void {
    this.showFullView = false;
    this.fullViewHTML = '';
  }

  /**
   * Copy full article HTML to clipboard
   */
  copyFullArticleHTML(): void {
    if (this.fullViewHTML) {
      navigator.clipboard.writeText(this.fullViewHTML).then(() => {
        console.log('Full article HTML copied to clipboard');
        // You could add a toast notification here
      }).catch(error => {
        console.error('Failed to copy full article HTML:', error);
      });
    } else {
      this.generateFullArticleHTML();
    }
  }

  /**
   * Generate full view HTML for display in modal
   */
  generateFullViewHTML(): void {
    if (!this.catalogItem) return;

    const templateData = {
      title: this.catalogItem.title,
      category: this.catalogItem.category || 'Article',
      author: this.getAuthorDisplayName(),
      publishedDate: this.getPublishedDate(),
      readingTime: this.getReadingTime(),
      description: this.catalogItem.description || '',
      content: this.catalogItem.content || '',
      originalUrl: window.location.href,
      generatedDate: new Date().toLocaleDateString()
    };

    this.templateService.loadTemplate('full-article', templateData).subscribe({
      next: (html) => {
        this.fullViewHTML = html;
      },
      error: (error) => {
        console.error('Failed to load template:', error);
        // Fallback to the old method if template loading fails
        this.fullViewHTML = this.generateFallbackHTMLString();
      }
    });
  }

  /**
   * Generate full article HTML for copy/paste using template service
   */
  generateFullArticleHTML(): void {
    if (!this.catalogItem) return;

    const templateData = {
      title: this.catalogItem.title,
      category: this.catalogItem.category || 'Article',
      author: this.getAuthorDisplayName(),
      publishedDate: this.getPublishedDate(),
      readingTime: this.getReadingTime(),
      description: this.catalogItem.description || '',
      content: this.catalogItem.content || '',
      originalUrl: window.location.href,
      generatedDate: new Date().toLocaleDateString()
    };

    this.templateService.loadTemplate('full-article', templateData).subscribe({
      next: (html) => {
        navigator.clipboard.writeText(html).then(() => {
          console.log('Full article HTML copied to clipboard');
          // You could add a toast notification here
        }).catch(error => {
          console.error('Failed to copy full article HTML:', error);
        });
      },
      error: (error) => {
        console.error('Failed to load template:', error);
        // Fallback to the old method if template loading fails
        const fallbackHTML = this.generateFallbackHTMLString();
        navigator.clipboard.writeText(fallbackHTML).then(() => {
          console.log('Fallback article HTML copied to clipboard');
        }).catch(error => {
          console.error('Failed to copy fallback HTML:', error);
        });
      }
    });
  }

  /**
   * Fallback method for generating HTML if template fails - returns string
   */
  private generateFallbackHTMLString(): string {
    if (!this.catalogItem) return '';

    return `
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>${this.catalogItem.title}</title>
    <style>
        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
            line-height: 1.6;
            max-width: 800px;
            margin: 0 auto;
            padding: 40px 20px;
            color: #333;
        }
        .article-header { border-bottom: 2px solid #e9ecef; padding-bottom: 20px; margin-bottom: 30px; }
        .article-title { font-size: 1.5rem; font-weight: 700; color: #1a1a1a; margin: 20px 0; }
        .article-meta { display: flex; gap: 20px; font-size: 0.95rem; color: #666; margin-bottom: 15px; }
        .article-content { margin: 30px 0; }
        .article-footer { border-top: 1px solid #e9ecef; padding-top: 20px; margin-top: 40px; }
    </style>
</head>
<body>
    <article>
        <header class="article-header">
            <h1 class="article-title">${this.catalogItem.title}</h1>
            <div class="meta">
              By ${this.getAuthorDisplayName()} | ${this.getPublishedDate()} | ${this.getReadingTime()} read
            </div>
        </header>
        <div class="article-content">${this.catalogItem.content || this.catalogItem.description || ''}</div>
        <footer class="article-footer">
            <p>Originally published at: ${window.location.href}</p>
            <p>Generated on: ${new Date().toLocaleDateString()}</p>
        </footer>
    </article>
</body>
</html>`;
  }

  /**
   * Open additional attributes popup
   */
  openAdditionalAttributes(): void {
    console.log('🔍 Opening additional attributes popup');
    console.log('📊 Catalog item:', this.catalogItem);
    console.log('🎯 Custom property:', this.catalogItem?.custom);

    this.showAdditionalAttributes = true;
    this.loadAdditionalAttributes();

    console.log('✅ Additional attributes loaded:', this.additionalAttributes);
  }

  /**
   * Close additional attributes popup
   */
  closeAdditionalAttributes(): void {
    this.showAdditionalAttributes = false;
  }

  /**
   * Load additional attributes from custom attribute API endpoint
   */
  private loadAdditionalAttributes(): void {
    this.additionalAttributes = [];

    if (!this.catalogItem?.id) {
      console.log('❌ No catalog item ID found');
      return;
    }

    console.log('🔍 Loading additional attributes from API for catalog:', this.catalogItem.id);

    // Call the new custom attributes API endpoint
    this.catalogService.getCustomAttributes(this.catalogItem.id).subscribe({
      next: (customData) => {
        console.log('✅ Custom attributes loaded from API:', customData);

        // Process the dynamic data in the expected format:
        // {
        //   "default": [{"column": "name1", "value": true}],
        //   "group1": [{"column": "name2", "value": true}],
        //   "group2": [{"column": "name3", "value": true}]
        // }

        if (customData && typeof customData === 'object') {
          Object.keys(customData).forEach(groupName => {
            const groupData = customData[groupName];

            console.log(`📋 Processing API group "${groupName}":`, groupData);

            if (Array.isArray(groupData)) {
              groupData.forEach((item: any, index: number) => {
                console.log(`📋 Processing API item ${index} in group "${groupName}":`, item);

                if (item && typeof item === 'object' && 'column' in item && 'value' in item) {
                  const formattedAttribute = this.formatCustomAttributeFromGroup(item, groupName);
                  if (formattedAttribute) {
                    this.additionalAttributes.push(formattedAttribute);
                  }
                }
              });
            }
          });

          // Sort attributes by group name and then by attribute name within each group
          this.additionalAttributes.sort((a, b) => {
            if (a.group !== b.group) {
              return a.group.localeCompare(b.group);
            }
            return a.attribute.localeCompare(b.attribute);
          });

          console.log('✅ Final processed API attributes:', this.additionalAttributes);

          // Update the catalog item's custom property with the fresh data
          if (this.catalogItem) {
            this.catalogItem.custom = customData;
          }
        }
      },
      error: (error) => {
        console.error('❌ Failed to load custom attributes from API:', error);

        // Fallback to existing custom property if API call fails
        this.loadAdditionalAttributesFromLocal();
      }
    });
  }

  /**
   * Fallback method to load additional attributes from local catalog item's custom property
   */
  private loadAdditionalAttributesFromLocal(): void {
    console.log('🔄 Falling back to local custom property loading');

    this.additionalAttributes = [];

    if (!this.catalogItem?.custom) {
      console.log('❌ No custom property found in local catalog item');
      return;
    }

    console.log('🎯 Processing local custom property:', this.catalogItem.custom);

    // Handle the dynamic groups structure: custom[groupName] arrays
    Object.keys(this.catalogItem.custom).forEach(groupName => {
      const groupData = this.catalogItem?.custom?.[groupName];

      console.log(`📋 Processing local group "${groupName}":`, groupData);

      if (Array.isArray(groupData)) {
        groupData.forEach((item: any, index: number) => {
          console.log(`📋 Processing local item ${index} in group "${groupName}":`, item);

          if (item && typeof item === 'object' && 'column' in item && 'value' in item) {
            const formattedAttribute = this.formatCustomAttributeFromGroup(item, groupName);
            if (formattedAttribute) {
              this.additionalAttributes.push(formattedAttribute);
            }
          }
        });
      }
    });

    // Sort attributes by group name and then by attribute name within each group
    this.additionalAttributes.sort((a, b) => {
      if (a.group !== b.group) {
        return a.group.localeCompare(b.group);
      }
      return a.attribute.localeCompare(b.attribute);
    });

    console.log('✅ Final processed local attributes:', this.additionalAttributes);
  }

  /**
   * Format a custom attribute from the new group-based structure
   */
  private formatCustomAttributeFromGroup(item: any, groupName: string): AdditionalAttribute | null {
    // Skip if value is empty
    if (!item || item.value === null || item.value === undefined || item.value === '') {
      return null;
    }

    // Use the group name from the object key
    const group = this.formatGroupName(groupName);

    // Use the column name as the attribute name
    const attributeName = item.column;

    // Format the attribute label from the column name
    const formattedLabel = this.formatAttributeLabel(attributeName);

    // Format the value based on its type and content
    const formattedValue = this.formatAttributeValue(attributeName, item.value);

    return {
      attribute: formattedLabel,
      value: formattedValue,
      group: group
    };
  }

  /**
   * Format a custom attribute from the legacy array-based structure
   */
  private formatCustomAttributeFromArray(customAttr: any): AdditionalAttribute | null {
    // Skip if value is empty
    if (!customAttr || customAttr.value === null || customAttr.value === undefined || customAttr.value === '') {
      return null;
    }

    // Format group name with intelligent capitalization
    const group = this.formatGroupName(customAttr.group || 'General');

    // Format the attribute label
    const formattedLabel = this.formatAttributeLabel(customAttr.attribute);

    // Format the value based on its type and content
    const formattedValue = this.formatAttributeValue(customAttr.attribute, customAttr.value);

    return {
      attribute: formattedLabel,
      value: formattedValue,
      group: group
    };
  }

  /**
   * Format group name from key with intelligent capitalization
   */
  private formatGroupName(groupName: string): string {
    // Handle common group names with special formatting
    const specialGroups: { [key: string]: string } = {
      'default': 'General',
      'stats': 'Statistics',
      'asset': 'Asset Information',
      'financial': 'Financial',
      'technical': 'Technical',
      'metadata': 'Metadata',
      'content': 'Content',
      'business': 'Business'
    };

    const lowerGroupName = groupName.toLowerCase();
    if (specialGroups[lowerGroupName]) {
      return specialGroups[lowerGroupName];
    }

    // Use the same formatting logic as attribute labels
    return this.formatAttributeLabel(groupName);
  }

  /**
   * Format attribute label with intelligent capitalization and spacing
   */
  private formatAttributeLabel(label: string): string {
    if (!label) return 'Unknown Attribute';

    // Handle common attribute names with special formatting
    const specialAttributes: { [key: string]: string } = {
      'asset_id': 'Asset ID',
      'asset_type': 'Asset Type',
      'asset_value': 'Asset Value',
      'cost_savings': 'Cost Savings',
      'roi': 'ROI',
      'kpi': 'KPI',
      'sla': 'SLA',
      'sku': 'SKU',
      'upc': 'UPC',
      'isbn': 'ISBN',
      'posted': 'Posted Status',
      'quantity': 'Quantity',
      'quality': 'Quality Score',
      'savings': 'Savings Amount'
    };

    const lowerLabel = label.toLowerCase().replace(/[^a-z0-9]/g, '_');
    if (specialAttributes[lowerLabel]) {
      return specialAttributes[lowerLabel];
    }

    // Convert camelCase or snake_case to Title Case
    return label
      .replace(/([a-z])([A-Z])/g, '$1 $2') // Split camelCase
      .replace(/[_-]/g, ' ') // Replace underscores and hyphens with spaces
      .replace(/\b\w/g, char => char.toUpperCase()) // Capitalize first letter of each word
      .trim();
  }

  /**
   * Format attribute value based on type and content with intelligent formatting
   */
  private formatAttributeValue(attributeName: string, value: any): string {
    if (value === null || value === undefined) return 'N/A';

    const lowerAttributeName = attributeName.toLowerCase();

    // Handle boolean values
    if (typeof value === 'boolean') {
      return value ? 'Yes' : 'No';
    }

    // Handle string boolean values
    if (typeof value === 'string') {
      const lowerValue = value.toLowerCase();
      if (lowerValue === 'true' || lowerValue === 'yes' || lowerValue === '1') {
        return 'Yes';
      }
      if (lowerValue === 'false' || lowerValue === 'no' || lowerValue === '0') {
        return 'No';
      }
    }

    // Handle numeric values
    if (typeof value === 'number') {
      // Format currency values
      if (lowerAttributeName.includes('cost') ||
        lowerAttributeName.includes('price') ||
        lowerAttributeName.includes('savings') ||
        lowerAttributeName.includes('value') ||
        lowerAttributeName.includes('amount')) {
        return new Intl.NumberFormat('en-US', {
          style: 'currency',
          currency: 'USD',
          minimumFractionDigits: 0,
          maximumFractionDigits: 2
        }).format(value);
      }

      // Format percentage values
      if (lowerAttributeName.includes('percent') ||
        lowerAttributeName.includes('rate') ||
        lowerAttributeName.includes('ratio') ||
        lowerAttributeName.includes('roi')) {
        return `${value.toFixed(1)}%`;
      }

      // Format quantity or count values
      if (lowerAttributeName.includes('quantity') ||
        lowerAttributeName.includes('count') ||
        lowerAttributeName.includes('number')) {
        return value.toLocaleString();
      }

      // Default number formatting
      if (Number.isInteger(value)) {
        return value.toLocaleString();
      } else {
        return value.toFixed(2);
      }
    }

    // Handle date values
    if (typeof value === 'string' && this.isDateString(value)) {
      try {
        const date = new Date(value);
        return date.toLocaleDateString('en-US', {
          year: 'numeric',
          month: 'short',
          day: 'numeric'
        });
      } catch (error) {
        return value;
      }
    }

    // Default string formatting
    return String(value);
  }

  /**
   * Check if a string represents a date
   */
  private isDateString(value: string): boolean {
    // Check for common date patterns
    const datePatterns = [
      /^\d{4}-\d{2}-\d{2}/, // YYYY-MM-DD
      /^\d{2}\/\d{2}\/\d{4}/, // MM/DD/YYYY
      /^\d{4}\/\d{2}\/\d{2}/, // YYYY/MM/DD
      /^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}/, // ISO datetime
    ];

    return datePatterns.some(pattern => pattern.test(value)) && !isNaN(Date.parse(value));
  }

  /**
   * Get unique groups from additional attributes
   */
  getUniqueGroups(): string[] {
    const groups = this.additionalAttributes.map(attr => attr.group);
    return [...new Set(groups)].sort();
  }

  /**
   * Get attributes for a specific group
   */
  getAttributesForGroup(groupName: string): AdditionalAttribute[] {
    return this.additionalAttributes.filter(attr => attr.group === groupName);
  }

  /**
   * Check if there are additional attributes to show
   */
  hasAdditionalAttributes(): boolean {
    return this.additionalAttributes && this.additionalAttributes.length > 0;
  }

  /**
   * Open edit attributes popup
   */
  openEditAttributes(): void {
    this.showEditAttributes = true;
    this.loadEditableAttributes();
  }

  /**
   * Close edit attributes popup
   */
  closeEditAttributes(): void {
    this.showEditAttributes = false;
    this.resetEditForm();
  }

  /**
   * Load editable attributes
   */
  private loadEditableAttributes(): void {
    // Create a copy of current attributes for editing
    this.editableAttributes = [...this.additionalAttributes];
  }

  /**
   * Reset edit form
   */
  private resetEditForm(): void {
    this.newAttributeGroup = 'General';
    this.newAttributeName = '';
    this.newAttributeValue = '';
    this.showAddGroupForm = false;
    this.newGroupName = '';
  }

  /**
   * Add new attribute
   */
  addNewAttribute(): void {
    if (!this.newAttributeName.trim() || !this.newAttributeValue.trim()) {
      return;
    }

    const newAttribute: AdditionalAttribute = {
      group: this.newAttributeGroup,
      attribute: this.newAttributeName.trim(),
      value: this.newAttributeValue.trim()
    };

    this.editableAttributes.push(newAttribute);

    // Reset form
    this.newAttributeName = '';
    this.newAttributeValue = '';
  }

  /**
   * Remove attribute
   */
  removeAttribute(index: number): void {
    if (confirm('Are you sure you want to remove this attribute?')) {
      this.editableAttributes.splice(index, 1);
    }
  }

  /**
   * Save attributes changes using the correct catalog update API
   */
  saveAttributes(): void {
    if (!this.catalogItem?.id) {
      console.error('No catalog item ID available for saving attributes');
      return;
    }

    this.isSavingAttributes = true;

    // Convert attributes back to the grouped format for the custom field
    const groupedAttributes: { [key: string]: any[] } = {};

    this.editableAttributes.forEach(attr => {
      // Use the original group name or convert it to a suitable key
      let groupKey = attr.group.toLowerCase();

      // Handle special group name mappings
      const groupMappings: { [key: string]: string } = {
        'general': 'default',
        'statistics': 'stats',
        'asset information': 'asset',
        'financial': 'financial',
        'technical': 'technical',
        'metadata': 'metadata',
        'content': 'content',
        'business': 'business'
      };

      groupKey = groupMappings[groupKey] || groupKey.replace(/\s+/g, '_');

      if (!groupedAttributes[groupKey]) {
        groupedAttributes[groupKey] = [];
      }

      groupedAttributes[groupKey].push({
        column: attr.attribute,
        value: attr.value
      });
    });

    console.log('📤 Saving custom attributes:', { catalogId: this.catalogItem.id, customData: groupedAttributes });

    // Call the updated custom attributes API that uses the main catalog endpoint
    this.catalogService.updateCustomAttributes(this.catalogItem.id, groupedAttributes).subscribe({
      next: (response) => {
        console.log('✅ Custom attributes saved successfully:', response);

        // Update the catalog item's custom property with the fresh data
        if (this.catalogItem) {
          this.catalogItem.custom = groupedAttributes;
        }

        this.isSavingAttributes = false;

        // Exit edit mode after successful save
        this.isEditingAttributes = false;

        // Clear any temporary form states
        this.resetEditForm();

        // Refresh the data from the server to ensure consistency
        console.log('🔄 Refreshing additional attributes from server...');
        this.loadAdditionalAttributes();

        console.log('✅ Custom attributes updated, edit mode exited, and data refreshed successfully');
      },
      error: (error) => {
        console.error('❌ Failed to save custom attributes:', error);
        this.isSavingAttributes = false;

        // Show specific error message to the user
        let errorMessage = 'Failed to save custom attributes. ';
        if (error.message.includes('Field required')) {
          errorMessage += 'Please ensure all required fields are filled.';
        } else if (error.message.includes('Validation')) {
          errorMessage += 'Please check the data format and try again.';
        } else {
          errorMessage += 'Please try again.';
        }

        alert(errorMessage);
      }
    });
  }

  /**
   * Toggle attribute editing mode
   */
  toggleAttributeEdit(): void {
    this.isEditingAttributes = !this.isEditingAttributes;
    if (this.isEditingAttributes) {
      this.loadEditableAttributes();
    } else {
      this.resetEditForm();
    }
  }

  /**
   * Get attribute groups for display
   */
  getAttributeGroups(): string[] {
    return this.getUniqueGroups();
  }

  /**
   * Get grouped attributes organized by group name
   */
  getGroupedAttributes(): { [key: string]: AdditionalAttribute[] } {
    const grouped: { [key: string]: AdditionalAttribute[] } = {};

    this.additionalAttributes.forEach(attr => {
      if (!grouped[attr.group]) {
        grouped[attr.group] = [];
      }
      grouped[attr.group].push(attr);
    });

    return grouped;
  }

  /**
   * Get count of attributes in a specific group
   */
  getGroupAttributeCount(groupName: string): number {
    return this.getAttributesForGroup(groupName).length;
  }

  /**
   * Add attribute to specific group
   */
  addAttributeToGroup(groupName: string): void {
    this.newAttributeForGroup = groupName;
    this.newAttributeName = '';
    this.newAttributeValue = '';
  }

  /**
   * Confirm adding attribute to group
   */
  confirmAddAttribute(groupName: string): void {
    if (!this.newAttributeName.trim() || !this.newAttributeValue.trim()) {
      return;
    }

    const newAttribute: AdditionalAttribute = {
      group: groupName,
      attribute: this.newAttributeName.trim(),
      value: this.newAttributeValue.trim()
    };

    // Add to editableAttributes for immediate display
    this.editableAttributes.push(newAttribute);

    // Also add to the main additionalAttributes for display
    this.additionalAttributes.push(newAttribute);

    this.cancelAddAttribute();
  }

  /**
   * Cancel adding attribute
   */
  cancelAddAttribute(): void {
    this.newAttributeForGroup = '';
    this.newAttributeName = '';
    this.newAttributeValue = '';
  }

  /**
   * Show add group form
   */
  showAddGroup(): void {
    this.showAddGroupForm = true;
    this.newGroupName = '';
  }

  /**
   * Cancel adding new group
   */
  cancelAddGroup(): void {
    this.showAddGroupForm = false;
    this.newGroupName = '';
  }

  /**
   * Add new group
   */
  addNewGroup(): void {
    if (!this.newGroupName.trim()) {
      return;
    }

    const trimmedGroupName = this.newGroupName.trim();

    // Check if group already exists (case-insensitive)
    const existingGroups = this.getAttributeGroups();
    const groupExists = existingGroups.some(group =>
      group.toLowerCase() === trimmedGroupName.toLowerCase()
    );

    if (groupExists) {
      alert('A group with this name already exists.');
      return;
    }

    // Add a placeholder attribute to create the group
    const placeholderAttribute: AdditionalAttribute = {
      group: trimmedGroupName,
      attribute: 'Group Created',
      value: `This group was created. You can add attributes here or remove this placeholder.`
    };

    // Add to both arrays for immediate display
    this.editableAttributes.push(placeholderAttribute);
    this.additionalAttributes.push(placeholderAttribute);

    // Update the group selection dropdown
    this.newAttributeGroup = trimmedGroupName;

    this.cancelAddGroup();
  }

  /**
   * Check if group can be deleted
   */
  canDeleteGroup(groupName: string): boolean {
    // Don't allow deleting if it's the only group or if it's a system group
    const systemGroups = ['General', 'Statistics', 'Asset Information'];
    return !systemGroups.includes(groupName) && this.getUniqueGroups().length > 1;
  }

  /**
   * Delete entire group
   */
  deleteGroup(groupName: string): void {
    if (!this.canDeleteGroup(groupName)) {
      return;
    }

    if (confirm(`Are you sure you want to delete the "${groupName}" group and all its attributes?`)) {
      // Remove all attributes in this group from editableAttributes
      this.editableAttributes = this.editableAttributes.filter(attr => attr.group !== groupName);

      // Also remove from additionalAttributes for immediate display update
      this.additionalAttributes = this.additionalAttributes.filter(attr => attr.group !== groupName);
    }
  }

  /**
   * Remove attribute from group
   */
  removeAttributeFromGroup(groupName: string, index: number): void {
    const groupAttributes = this.getAttributesForGroup(groupName);
    if (index >= 0 && index < groupAttributes.length) {
      const attributeToRemove = groupAttributes[index];

      // Remove from editableAttributes
      const editableIndex = this.editableAttributes.findIndex(attr =>
        attr.group === attributeToRemove.group &&
        attr.attribute === attributeToRemove.attribute &&
        attr.value === attributeToRemove.value
      );
      if (editableIndex !== -1) {
        this.editableAttributes.splice(editableIndex, 1);
      }

      // Remove from additionalAttributes for immediate display update
      const displayIndex = this.additionalAttributes.findIndex(attr =>
        attr.group === attributeToRemove.group &&
        attr.attribute === attributeToRemove.attribute &&
        attr.value === attributeToRemove.value
      );
      if (displayIndex !== -1) {
        this.additionalAttributes.splice(displayIndex, 1);
      }
    }
  }

  /**
   * Strip HTML tags from text and convert to plain text
   */
  private stripHtmlTags(html: string): string {
    if (!html) return '';

    // Create a temporary div element to parse HTML
    const tempDiv = document.createElement('div');
    tempDiv.innerHTML = html;

    // Get text content and clean up extra whitespace
    return tempDiv.textContent || tempDiv.innerText || '';
  }

  /**
   * Add first attribute when none exist
   */
  addFirstAttribute(): void {
    this.showFirstAttributeForm = true;
    this.newAttributeGroup = 'General';
    this.newAttributeName = '';
    this.newAttributeValue = '';
  }

  /**
   * Confirm adding first attribute
   */
  confirmAddFirstAttribute(): void {
    if (!this.newAttributeName.trim() || !this.newAttributeValue.trim()) {
      return;
    }

    const newAttribute: AdditionalAttribute = {
      group: this.newAttributeGroup,
      attribute: this.newAttributeName.trim(),
      value: this.newAttributeValue.trim()
    };

    this.additionalAttributes.push(newAttribute);
    this.cancelAddFirstAttribute();
  }

  /**
   * Cancel adding first attribute
   */
  cancelAddFirstAttribute(): void {
    this.showFirstAttributeForm = false;
    this.newAttributeGroup = 'General';
    this.newAttributeName = '';
    this.newAttributeValue = '';
  }

  /**
   * Get sanitized content that preserves inline styles for newsletter templates
   */
  getSanitizedContent(): SafeHtml {
    if (!this.catalogItem?.content) return '';

    // Check if the content contains inline styles (likely from newsletter templates)
    const hasInlineStyles = this.catalogItem.content.includes('style=');

    if (hasInlineStyles) {
      // For content with inline styles, sanitize but preserve styling
      return this.sanitizer.bypassSecurityTrustHtml(this.catalogItem.content);
    } else {
      // For regular content, use the original innerHTML binding (handled in template)
      return '';
    }
  }

  /**
   * Check if content has inline styles (used in template)
   */
  hasInlineStyles(): boolean {
    return !!(this.catalogItem?.content && this.catalogItem.content.includes('style='));
  }

  // ===== CHILD IDS FUNCTIONALITY =====

  /**
   * Check if catalog item has child IDs
   */
  hasChildIds(): boolean {
    return !!(this.catalogItem?.child_ids && this.catalogItem.child_ids.length > 0);
  }

  /**
   * Get child items count
   */
  getChildItemsCount(): number {
    if (!this.catalogItem?.child_ids) return 0;
    return this.catalogItem.child_ids.length;
  }

  /**
   * Get child items in proper format
   */
  getChildItems(): CatalogChildItem[] {
    if (!this.catalogItem?.child_ids) return [];

    // Check if child_ids contains objects (CatalogChildItem) or strings
    const firstChild = this.catalogItem.child_ids[0];
    const isObjectFormat = typeof firstChild === 'object' && firstChild !== null;

    if (isObjectFormat) {
      // Return sorted by index
      return (this.catalogItem.child_ids as CatalogChildItem[])
        .sort((a, b) => a.index - b.index);
    } else {
      // Convert string array to CatalogChildItem format for display
      return (this.catalogItem.child_ids as string[]).map((id, index) => ({
        id: id,
        index: index,
        title: `Child Item ${index + 1}`,
        description: `Catalog ID: ${id}`,
        author: 'Unknown'
      }));
    }
  }

  /**
   * Navigate to child catalog item
   */
  goToChildItem(childItem: CatalogChildItem): void {
    if (childItem.id) {
      this.router.navigate(['/user/catalog', childItem.id]);
    }
  }

  /**
   * Get child item display title
   */
  getChildItemDisplayTitle(childItem: CatalogChildItem): string {
    return childItem.title || `Item ${childItem.index + 1}`;
  }

  /**
   * Get child item display description
   */
  getChildItemDisplayDescription(childItem: CatalogChildItem): string {
    if (childItem.description) {
      return this.getExcerpt(childItem.description, 100);
    }
    return `Catalog ID: ${childItem.id}`;
  }

  /**
   * Get child item display author
   */
  getChildItemDisplayAuthor(childItem: CatalogChildItem): string {
    return childItem.author || 'Unknown Author';
  }

  /**
   * Check if child item has complete information (title, description, etc.)
   */
  isChildItemComplete(childItem: CatalogChildItem): boolean {
    return !!(childItem.title && childItem.description);
  }

  /**
   * Get child items grouped by completeness
   */
  getGroupedChildItems(): { complete: CatalogChildItem[], incomplete: CatalogChildItem[] } {
    const childItems = this.getChildItems();
    return {
      complete: childItems.filter(item => this.isChildItemComplete(item)),
      incomplete: childItems.filter(item => !this.isChildItemComplete(item))
    };
  }

  /**
   * Track function for ngFor on child items
   */
  trackByChildId(index: number, childItem: CatalogChildItem): string {
    return childItem.id + '_' + childItem.index;
  }

  // ===== AI SUMMARY ACTIONS =====
  regenerateSummary(): void {
    // TODO: Implement actual regeneration logic (API call)
    alert('Regenerate summary feature coming soon!');
  }

  copySummary(): void {
    if (this.catalogItem?.summary) {
      const el = document.createElement('textarea');
      el.value = this.stripHtmlTags(this.catalogItem.summary);
      document.body.appendChild(el);
      el.select();
      document.execCommand('copy');
      document.body.removeChild(el);
      // Optionally show a toast/notification
      alert('AI summary copied to clipboard!');
    }
  }
}
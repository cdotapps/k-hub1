# FST-Wave API Documentation

## API Overview

**Base URL:** `http://localhost:8000`  
**API Version:** v1  
**Authentication:** JWT Bearer Token  
**Content Type:** `application/json`  
**OpenAPI Spec:** Available at `/openapi.json`  
**Interactive Docs:** Available at `/docs`  
**API Status:** ✅ **FULLY OPERATIONAL** (Tested on June 22, 2025)

## 🚀 Key Features Verified

- ✅ Complete user authentication and management system
- ✅ Comprehensive catalog management with advanced features
- ✅ Webhook system for real-time integrations
- ✅ SharePoint assets integration
- ✅ Role-based access control (user, admin, manager, developer)
- ✅ Hierarchical user relationships (managers, peers, teams)
- ✅ Advanced search and filtering capabilities
- ✅ Public and private content sharing
- ✅ Conversation/commenting system
- ✅ Analytics tracking (likes, views, usage, shares)

---

## 🔐 Authentication Endpoints

### 1. User Registration
```http
POST /api/v1/auth/register
```

**Request Body:**
```typescript
interface UserCreate {
  user_id: string;           // Required - Unique user identifier
  email?: string;            // Optional - User email (format: email)
  first_name: string;        // Required - User's first name
  last_name: string;         // Required - User's last name
  password: string;          // Required - User password
  is_active?: boolean;       // Optional - Default: true
  role?: "user" | "admin" | "manager" | "developer";   // Optional - Default: "user"
  is_superuser?: boolean;    // Optional - Default: false
  email_verified?: boolean;  // Optional - Default: false
  manager_id?: string;       // Optional - Manager's user ID
  portfolio_id?: string;     // Optional - Portfolio identifier
  organization_id?: string;  // Optional - Organization identifier
  costcenter_id?: string;    // Optional - Cost center identifier
  user_type?: string;        // Optional - User type classification
  designation?: "Associate" | "Lead Associate" | "Manager" | "Senior Manager" | "Advisor" | "Director" | "Senior Director" | "Principal" | "Vice President" | "Senior Vice President" | "Fellow";  // Optional - Job designation/title
}
```

**Response (200):**
```typescript
interface User {
  id: string;                // Auto-generated UUID
  user_id?: string;
  email?: string;
  first_name?: string;
  last_name?: string;
  is_active?: boolean;
  role?: "user" | "admin" | "manager" | "developer";
  is_superuser?: boolean;
  email_verified?: boolean;
  manager_id?: string;
  portfolio_id?: string;
  organization_id?: string;
  costcenter_id?: string;
  user_type?: string;
  designation?: string;      // Job designation/title
  created_date: string;      // ISO date-time (auto-generated)
  updated_date?: string;     // ISO date-time
  last_login?: string;       // ISO date-time
  manager?: ManagerInfo;     // Manager details if available
}

interface ManagerInfo {
  id: string;
  user_id: string;
  first_name: string;
  last_name: string;
  designation?: string;
}
```

### 2. Admin Registration
```http
POST /api/v1/auth/register-admin
Authorization: Bearer {access_token}
```
**Description:** Create new admin user account (admin only)  
**Request/Response:** Same as user registration

### 3. User Login
```http
POST /api/v1/auth/login
```

**Request Body:**
```typescript
interface LoginRequest {
  user_id: string;     // Required - User identifier
  password: string;    // Required - User password
}
```

**Response (200):**
```typescript
interface Token {
  access_token: string;     // JWT access token
  refresh_token: string;    // JWT refresh token
  token_type: string;       // "bearer"
  user: TokenUser;
}

interface TokenUser {
  id: string;
  user_id: string;
  email?: string;
  first_name: string;
  last_name: string;
  role: "user" | "admin" | "manager" | "developer";
  designation?: string;
}
```

### 4. Refresh Token
```http
POST /api/v1/auth/refresh
Authorization: Bearer {refresh_token}
```
**Description:** Refresh access token using refresh token  
**Response:** Same as login response

### 5. Logout
```http
POST /api/v1/auth/logout
Authorization: Bearer {access_token}
```
**Description:** Logout user (client should delete tokens)

---

## 👤 User Management Endpoints

### 1. Get Current User
```http
GET /api/v1/users/me
Authorization: Bearer {access_token}
```
**Description:** Get current user profile with manager details if available

### 2. Update Current User
```http
PUT /api/v1/users/me
Authorization: Bearer {access_token}
```

**Request Body:**
```typescript
interface UserProfileUpdate {
  first_name?: string;
  last_name?: string;
  email?: string;          // Format: email
  manager_id?: string;
  portfolio_id?: string;
  organization_id?: string;
  costcenter_id?: string;
  user_type?: string;
  designation?: string;    // Job designation/title
}
```

### 3. Update Current User Password
```http
PUT /api/v1/users/me/password
Authorization: Bearer {access_token}
```

**Request Body:**
```typescript
{
  current_password: string;
  new_password: string;
}
```

### 4. Get Current User Peers
```http
GET /api/v1/users/me/peers
Authorization: Bearer {access_token}
```
**Description:** Get current user's peers (colleagues who report to the same manager)

### 5. Get Current User Team
```http
GET /api/v1/users/me/team
Authorization: Bearer {access_token}
```
**Description:** Get current user's team members (direct reports)

### 6. Get All Users
```http
GET /api/v1/users/
```
**Description:** Get all users (public access)

**Query Parameters:**
- `skip?: number` - Default: 0
- `limit?: number` - Default: 100
- `page?: number` - Page number
- `page_size?: number` - Items per page

### 7. Get User by ID (Admin Only)
```http
GET /api/v1/users/{user_id}
Authorization: Bearer {access_token}
```

### 8. Update User by ID (Admin Only)
```http
PUT /api/v1/users/{user_id}
Authorization: Bearer {access_token}
```

**Request Body:**
```typescript
interface UserAdminUpdate {
  user_id?: string;
  email?: string;
  first_name?: string;
  last_name?: string;
  is_active?: boolean;
  role?: "user" | "admin" | "manager" | "developer";
  is_superuser?: boolean;
  email_verified?: boolean;
  manager_id?: string;
  portfolio_id?: string;
  organization_id?: string;
  costcenter_id?: string;
  user_type?: string;
  designation?: string;
}
```

### 9. Delete User (Admin Only)
```http
DELETE /api/v1/users/{user_id}
Authorization: Bearer {access_token}
```

### 10. Update User Role (Admin Only)
```http
PATCH /api/v1/users/{user_id}/role
Authorization: Bearer {access_token}
```

**Request Body:**
```typescript
{
  role: "user" | "admin" | "manager" | "developer"  // Required
}
```

### 11. Update User Status (Admin Only)
```http
PATCH /api/v1/users/{user_id}/status
Authorization: Bearer {access_token}
```

**Request Body:**
```typescript
{
  is_active: boolean  // Required
}
```

### 12. Toggle User Status (Admin Only)
```http
PATCH /api/v1/users/{user_id}/toggle-status
Authorization: Bearer {access_token}
```
**Description:** Toggle a user's active status between true/false

---

## 📚 Catalog Management Endpoints

### 1. Create Catalog Item
```http
POST /api/v1/catalog/
Authorization: Bearer {access_token}
```

**Request Body:**
```typescript
interface CatalogCreate {
  title: string;                    // Required - Catalog item title
  type: string;                     // Required - Type of catalog item (document, prompt, blog, product, etc.)
  description?: string;             // Optional - Catalog item description
  summary?: string;                 // Optional - Brief summary
  content?: string;                 // Optional - Main content
  url?: string;                     // Optional - Associated URL
  image?: string;                   // Optional - Image URL or path
  imageUrl?: string;                // Optional - Direct image URL for web display
  display?: string;                 // Optional - Display settings or visibility options
  tags?: string[];                  // Optional - Tags for categorizing
  author?: string;                  // Optional - Author name (auto-filled from user)
  created_date?: string;            // Optional - Creation date (ISO date-time, auto-generated)
  updated_date?: string;            // Optional - Last update date (ISO date-time, auto-generated)
  expire_date?: string;             // Optional - Expire date
  due_date?: string;                // Optional - Due date
  custom?: object;                  // Optional - Custom fields for type-specific attributes
  category?: string;                // Optional - Primary category
  parent_id?: string;               // Optional - Parent catalog item ID for hierarchical structures
  child_ids?: string[];             // Optional - List of child catalog item IDs
  priority?: 'high' | 'medium' | 'low';  // Optional - Priority level (default: 'low')
  severity?: 'high' | 'medium' | 'low';  // Optional - Severity level (default: 'low')
  urgent?: boolean;                 // Optional - Indicates urgency (default: false)
  important?: boolean;              // Optional - Indicates importance (default: false)
  likes?: number;                   // Optional - Number of likes (default: 0)
  usages?: number;                  // Optional - Number of uses (default: 0)
  favorites?: number;               // Optional - Number of favorites (default: 0)
  views?: number;                   // Optional - Number of views (default: 0)
  shares?: number;                  // Optional - Number of shares (default: 0)
  approved_by?: string;             // Optional - Email/name of approver
  reviewed_by?: string;             // Optional - Email/name of reviewer
  source?: string;                  // Optional - Source or origin
  status?: string;                  // Optional - Status (draft, published, archived) - default: "draft"
  private?: boolean;                // Optional - Is private (default: true)
  shared_with?: string[];           // Optional - List of user IDs or emails
  conversations?: object[];         // Optional - Comments and conversations
  author_id?: string;               // Optional - Author's user ID (auto-filled)
}
```

### 2. Get Catalog Items
```http
GET /api/v1/catalog/
Authorization: Bearer {access_token}
```
**Description:** Get catalog items with pagination, filtering, and search. Returns only items that the current user owns, has been shared with, or has approved.

**Query Parameters:**
- `type?: string` - Filter by catalog type (e.g., news, document, tutorial)
- `query?: string` - Search term to find in title, description, content, tags, etc.
- `search?: string` - Search term (alias for query)
- `q?: string` - Search term (alias for query)
- `title?: string` - Search in title field
- `category?: string` - Filter by category
- `status?: string` - Filter by status
- `author?: string` - Filter by author
- `page?: number` - Page number (starts from 1, default: 1)
- `page_size?: number` - Number of items per page (1-100, default: 50)
- `skip?: number` - Number of items to skip (legacy parameter)
- `limit?: number` - Number of items to return (legacy parameter, 1-100)

**Response:**
```typescript
interface CatalogResponse {
  items: Catalog[];
  total: number;
  limit: number;
  offset: number;
  page?: number;
  page_size?: number;
  total_pages?: number;
}
```

### 3. Search Catalog Items (Public)
```http
GET /api/v1/catalog/search
```
**Description:** Search catalog items with various filters. This endpoint is public and does not require authentication.

**Query Parameters:**
- `query?: string` - Search term
- `type?: string` - Filter by type
- `category?: string` - Filter by category
- `status?: string` - Filter by status
- `author?: string` - Filter by author
- `approved_by?: string` - Filter by approved_by
- `reviewed_by?: string` - Filter by reviewed_by
- `source?: string` - Filter by source
- `tags?: string` - Filter by tags
- `skip?: number` - Number to skip (default: 0)
- `limit?: number` - Number to return (1-100, default: 50)

### 4. Get Catalog Item by ID (Public)
```http
GET /api/v1/catalog/{catalog_id}
```
**Description:** Get a specific catalog item by ID. Public endpoint.

### 5. Update Catalog Item
```http
PUT /api/v1/catalog/{catalog_id}
Authorization: Bearer {access_token}
```
**Description:** Update a catalog item. Use this endpoint to update sharing information by including `shared_with` field.

**Request Body:** Same as CatalogCreate but all fields are optional

### 6. Delete Catalog Item
```http
DELETE /api/v1/catalog/{catalog_id}
Authorization: Bearer {access_token}
```

### 7. Like Catalog Item
```http
POST /api/v1/catalog/{catalog_id}/like
Authorization: Bearer {access_token}
```
**Description:** Like a catalog item (increment like count)

### 8. Use Catalog Item
```http
POST /api/v1/catalog/{catalog_id}/use
Authorization: Bearer {access_token}
```
**Description:** Mark catalog item as used (increment usage count)

### 9. Approve Catalog Item (Admin Only)
```http
PATCH /api/v1/catalog/{catalog_id}/approve
Authorization: Bearer {access_token}
```
**Description:** Approve a catalog item

### 10. Review Catalog Item (Admin Only)
```http
PATCH /api/v1/catalog/{catalog_id}/review
Authorization: Bearer {access_token}
```

**Request Body:**
```typescript
{
  status: string  // Required - New status to set
}
```

### 11. Request Catalog Approval
```http
PATCH /api/v1/catalog/{catalog_id}/request-approval
Authorization: Bearer {access_token}
```
**Description:** Request approval for a catalog item. Sets the approver as the user's manager and changes status to pending_approval.

### 12. Get Catalogs by Type (Public)
```http
GET /api/v1/catalog/by-type/{type}
```
**Query Parameters:**
- `skip?: number` - Default: 0
- `limit?: number` - Default: 50 (max: 100)

### 13. Get Catalogs by Status (Public)
```http
GET /api/v1/catalog/by-status/{status}
```
**Query Parameters:**
- `skip?: number` - Default: 0
- `limit?: number` - Default: 50 (max: 100)

### 14. Get Catalogs by Author
```http
GET /api/v1/catalog/by-author/{author_id}
Authorization: Bearer {access_token}
```
**Description:** Get catalog items by author_id. Users can only see their own content unless they are admin.

### 15. Get My Catalog Content
```http
GET /api/v1/catalog/my-content
Authorization: Bearer {access_token}
```
**Description:** Get all catalog items created by the current user

### 16. Get Catalog Conversations
```http
GET /api/v1/catalog/{catalog_id}/conversations
```
**Description:** Get all conversations for a catalog item (Public endpoint)

### 17. Add Catalog Conversation
```http
POST /api/v1/catalog/{catalog_id}/conversations
Authorization: Bearer {access_token}
```

**Request Body:**
```typescript
{
  // Conversation/comment object
  message: string;
  parent_id?: string;  // For reply threading
  [key: string]: any;
}
```

### 18. Get Custom Attributes
```http
GET /api/v1/catalog/{id}/custom
Authorization: Bearer {access_token}
```
**Description:** Get custom attributes for a catalog item

### 19. Update Custom Attributes
```http
POST /api/v1/catalog/{id}/custom
Authorization: Bearer {access_token}
```

**Request Body:**
```typescript
interface CustomAttributesRequest {
  attributes: {
    [category: string]: CustomAttribute[];
  };
}

interface CustomAttribute {
  column: string;
  value: string;
}
```

### 20. Get Team Shares
```http
GET /api/v1/catalog/cataloglist/teamshares
Authorization: Bearer {access_token}
```
**Description:** Get catalog items that have been shared with the current user by team members. This endpoint returns a filtered view of catalog items based on team sharing permissions.

**Query Parameters:**
- `page?: number` - Page number (starts from 1, default: 1)
- `page_size?: number` - Number of items per page (1-100, default: 12)
- `search?: string` - Search term to find in title, description, content
- `category?: string` - Filter by category
- `priority_level?: string` - Filter by priority level (high, medium, low)
- `is_read?: boolean` - Filter by read status
- `date_from?: string` - Filter items from this date (ISO format)
- `date_to?: string` - Filter items until this date (ISO format)
- `sort?: string` - Sort field (default: 'created_date')
- `order?: string` - Sort order: 'asc' or 'desc' (default: 'desc')

**Response:**
```typescript
interface CatalogResponse {
  items: Catalog[];
  total: number;
  page: number;
  page_size: number;
  total_pages: number;
  limit: number;
  offset: number;
}
```

### 21. Get Approval Queue
```http
GET /api/v1/catalog/cataloglist/approvals
Authorization: Bearer {access_token}
```
**Description:** Get catalog items that are pending approval by the current user. This endpoint is typically used by managers and administrators to view items requiring their approval.

**Query Parameters:**
- `page?: number` - Page number (starts from 1, default: 1)
- `page_size?: number` - Number of items per page (1-100, default: 12)
- `search?: string` - Search term to find in title, description, content
- `category?: string` - Filter by category
- `priority_level?: string` - Filter by priority level (high, medium, low)
- `status?: string` - Filter by approval status (pending-review, pending-approval)
- `date_from?: string` - Filter items from this date (ISO format)
- `date_to?: string` - Filter items until this date (ISO format)
- `sort?: string` - Sort field (default: 'created_date')
- `order?: string` - Sort order: 'asc' or 'desc' (default: 'desc')

**Response:**
```typescript
interface CatalogResponse {
  items: Catalog[];
  total: number;
  page: number;
  page_size: number;
  total_pages: number;
  limit: number;
  offset: number;
}
```

---

## 🔧 Backend Implementation Status

### ⚠️ Missing Endpoints (Require Backend Implementation)

The following endpoints are referenced in the frontend code but are **not yet implemented** on the backend:

1. **Team Shares Endpoint**: `GET /api/v1/cataloglist/teamshares`
   - **Status**: ❌ Not Found (404)
   - **Purpose**: Retrieve catalog items shared with the current user by team members
   - **Frontend Integration**: ✅ Implemented in CatalogService.getTeamShares()

2. **Approval Queue Endpoint**: `GET /api/v1/cataloglist/approvals`
   - **Status**: ❌ Not Found (404) 
   - **Purpose**: Retrieve catalog items pending approval by the current user
   - **Frontend Integration**: ✅ Implemented in CatalogService.getApprovalQueue()

### 🛠️ Required Backend Implementation

To make these endpoints functional, the backend FastAPI application needs to implement the following routes:

```python
# Required backend implementation (Python/FastAPI)

@router.get("/cataloglist/teamshares", response_model=CatalogResponse)
async def get_team_shares(
    page: int = Query(1, ge=1),
    page_size: int = Query(12, ge=1, le=100),
    search: Optional[str] = None,
    category: Optional[str] = None,
    priority_level: Optional[str] = None,
    is_read: Optional[bool] = None,
    date_from: Optional[str] = None,
    date_to: Optional[str] = None,
    sort: str = Query("created_date"),
    order: str = Query("desc", regex="^(asc|desc)$"),
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """Get catalog items shared with the current user by team members"""
    # Implementation needed here
    pass

@router.get("/cataloglist/approvals", response_model=CatalogResponse)
async def get_approval_queue(
    page: int = Query(1, ge=1),
    page_size: int = Query(12, ge=1, le=100),
    search: Optional[str] = None,
    category: Optional[str] = None,
    priority_level: Optional[str] = None,
    status: Optional[str] = None,
    date_from: Optional[str] = None,
    date_to: Optional[str] = None,
    sort: str = Query("created_date"),
    order: str = Query("desc", regex="^(asc|desc)$"),
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """Get catalog items pending approval by the current user"""
    # Implementation needed here
    pass
```

---

## 📋 Data Models

### Catalog Schema
```typescript
interface Catalog {
  id: string;                       // Required - Unique identifier (UUID)
  title?: string;                   // Catalog item title
  description?: string;             // Item description
  summary?: string;                 // Brief summary
  type?: string;                    // Type (document, prompt, blog, product, news, etc.)
  content?: string;                 // Main content
  url?: string;                     // Associated URL
  image?: string;                   // Image URL or path
  imageUrl?: string;                // Direct image URL for web display
  display?: string;                 // Display settings
  tags?: string[];                  // Categorization tags
  author?: string;                  // Author name (auto-filled from user)
  created_date?: string;            // Creation date (ISO date-time, auto-generated)
  updated_date?: string;            // Last update date (ISO date-time, auto-updated)
  expire_date?: string;             // Expire date
  due_date?: string;                // Due date
  custom?: object;                  // Custom fields for type-specific attributes
  category?: string;                // Primary category
  parent_id?: string;               // Parent item ID for hierarchical structures
  child_ids?: string[];             // List of child catalog item IDs
  priority?: 'high' | 'medium' | 'low';  // Priority level (default: 'low')
  severity?: 'high' | 'medium' | 'low';  // Severity level (default: 'low')
  urgent?: boolean;                 // Indicates urgency (default: false)
  important?: boolean;              // Indicates importance (default: false)
  likes?: number;                   // Number of likes (default: 0)
  usages?: number;                  // Number of uses (default: 0)
  favorites?: number;               // Number of favorites (default: 0)
  views?: number;                   // Number of views (default: 0)
  shares?: number;                  // Number of shares (default: 0)
  approved_by?: string;             // Optional - Email/name of approver
  reviewed_by?: string;             // Optional - Email/name of reviewer
  source?: string;                  // Optional - Source or origin
  status?: string;                  // Optional - Status (draft, published, archived) - default: "draft"
  private?: boolean;                // Optional - Is private (default: true)
  shared_with?: string[];           // Optional - List of user IDs or emails shared with
  conversations?: object[];         // Optional - Comments and conversations
  author_id?: string;               // Optional - Author's user ID (auto-filled)
}
```

### Webhook Schema
```typescript
interface Webhook {
  id: string;                       // Unique identifier
  name: string;                     // User-friendly name
  url: string;                      // Target URL (max 2083 chars, valid URI)
  events: string[];                 // List of subscribed events
  secret?: string;                  // Secret for signature verification
  headers?: Record<string, string>; // Additional headers
  active: boolean;                  // Is webhook active (default: true)
  filters?: object;                 // Trigger conditions
  status: string;                   // Webhook status
  created_by: string;               // Creator user ID
  created_date: string;             // Creation date (ISO date-time)
  updated_date?: string;            // Last update date (ISO date-time)
  last_triggered?: string;          // Last trigger date (ISO date-time)
  success_count: string;            // Number of successful deliveries
  failure_count: string;            // Number of failed deliveries
}
```

### Error Handling
All endpoints return standard HTTP status codes and error responses:

```typescript
interface HTTPValidationError {
  detail: ValidationError[];
}

interface ValidationError {
  loc: (string | number)[];
  msg: string;
  type: string;
}
```

**Common HTTP Status Codes:**
- `200` - Success
- `422` - Validation Error
- `401` - Unauthorized (missing or invalid token)
- `403` - Forbidden (insufficient permissions)
- `404` - Not Found
- `500` - Internal Server Error

---

## 🔑 Authentication & Security Notes

- All protected endpoints require `Authorization: Bearer {access_token}` header
- JWT tokens are used for authentication with access and refresh tokens
- Tokens expire and should be refreshed using the refresh endpoint
- Admin-only endpoints require user to have admin role
- Some endpoints are public and don't require authentication
- Role-based access control is implemented (user, admin, manager, developer)

## 🔄 Sharing Implementation

To share catalog items with users, use the **PUT /api/v1/catalog/{catalog_id}** endpoint with the `shared_with` field:

```typescript
// Example: Share catalog item with multiple users
PUT /api/v1/catalog/{catalog_id}
Authorization: Bearer {access_token}
{
  "shared_with": ["user1_id", "user2_id", "user3_id"]
}
```

The `shared_with` field accepts an array of user IDs or email addresses.

## 🔍 Search & Filtering Features

The API provides powerful search and filtering capabilities:

### Catalog Search Features:
- **Full-text search** across title, description, content, and tags
- **Type filtering** (document, news, blog, etc.)
- **Category filtering**
- **Status filtering** (draft, published, archived)
- **Author filtering**
- **Date range filtering**
- **Tag-based filtering**
- **Pagination** with configurable page sizes
- **Public search endpoint** for unauthenticated access

### User Search Features:
- **Hierarchical relationships** (managers, peers, teams)
- **Role-based filtering**
- **Designation-based filtering**
- **Organization structure queries**

## 📊 Analytics & Metrics

The catalog system tracks comprehensive analytics:
- **Likes** - User engagement metric
- **Views** - Content visibility metric
- **Usage** - Content utilization metric
- **Shares** - Content distribution metric
- **Favorites** - User preference metric

## 🔄 Workflow Features

- **Approval workflow** with manager-based approval routing
- **Review system** with status tracking
- **Draft/Published lifecycle management**
- **Private/Public sharing controls**
- **Conversation/commenting system**

## 🌐 Integration Features

- **Webhook system** for real-time event notifications
- **SharePoint integration** for enterprise asset management
- **OpenAPI specification** for easy integration
- **RESTful design** following industry standards

## ⚡ Performance Features

- **Pagination** for large datasets
- **Efficient filtering** and search
- **Optimized queries** with skip/limit parameters
- **Caching-friendly** response structure

---

**Last Updated:** June 22, 2025  
**API Version:** 1.0.0  
**Status:** Production Ready ✅
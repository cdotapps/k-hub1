import { Component, OnInit, OnDestroy } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { DomSanitizer, SafeHtml } from '@angular/platform-browser';
import { Subscription } from 'rxjs';
import { 
  faArrowLeft, faUser, faCalendar, faClock, faEye, faTag, 
  faHeart, faShare, faEdit, faTrash, faFileText,
  faCopy, faCheck, faInfoCircle, faExclamationTriangle, faSpinner, faRobot, faComments,
  faLayerGroup, faLink, faChevronRight
} from '@fortawesome/free-solid-svg-icons';

// Services and Models
import { CatalogService } from '../../shared/services/catalog.service';
import { AuthService } from '../../shared/services/auth.service';
import { DateUtilityService } from '../../shared/services/date-utility.service';
import { Catalog, User, CatalogChildItem } from '../../shared/models/user.interface';

@Component({
  selector: 'app-catalog-detail',
  templateUrl: './catalog-detail.component.html',
  styleUrls: ['./catalog-detail.component.css']
})
export class CatalogDetailComponent implements OnInit, OnDestroy {
  // FontAwesome icons
  faArrowLeft = faArrowLeft;
  faUser = faUser;
  faCalendar = faCalendar;
  faClock = faClock;
  faEye = faEye;
  faTag = faTag;
  faHeart = faHeart;
  faShare = faShare;
  faEdit = faEdit;
  faCheck= faCheck;
  faTrash = faTrash;
  faFileText = faFileText;
  faCopy = faCopy;
  faInfoCircle = faInfoCircle;
  faExclamationTriangle = faExclamationTriangle;
  faSpinner = faSpinner;
  faRobot = faRobot;
  faComments = faComments;
  faLayerGroup = faLayerGroup;
  faLink = faLink;
  faChevronRight = faChevronRight;
  
  // Core data
  catalogItem: Catalog | null = null;
  relatedItems: Catalog[] = [];
  currentUser: User | null = null;
  
  // Add this property to prevent multiple markAsRead calls
  private hasMarkedAsRead = false;

  // State management
  isLoading = false;
  errorMessage = '';
  isLiked = false;
  showShareModal = false;
  showAiChat = false;
  showConversations = false;
  
  // Tab configuration
  dynamicTabItems = [
    { key: 'content', value: 'content', label: 'Content', count: 0 },
    { key: 'summary', value: 'summary', label: 'AI Summary', count: 0 },
    { key: 'details', value: 'details', label: 'Details', count: 0 }
  ];
  activeTab = 'content';
  
  // Navigation
  breadcrumbItems = [
    { label: 'Dashboard', routerLink: '/user/dashboard' },
    { label: 'Catalog', routerLink: '/user/catalog' },
    { label: 'Article Details', routerLink: null }
  ];

  private subscriptions = new Subscription();

  constructor(
    private route: ActivatedRoute,
    private router: Router,
    private catalogService: CatalogService,
    private authService: AuthService,
    private dateUtilityService: DateUtilityService,
    private sanitizer: DomSanitizer
  ) {}

  ngOnInit(): void {
    this.initializeComponent();

    window.addEventListener('scroll', this.onScroll, true);
  }

  ngOnDestroy(): void {
    this.subscriptions.unsubscribe();

    window.removeEventListener('scroll', this.onScroll, true);
  }

  /**
   * Scroll event handler to mark as read when user scrolls past 30% of the page
   */
  onScroll = (): void => {
    if (this.hasMarkedAsRead || !this.catalogItem) return;

    const scrollTop = window.scrollY || document.documentElement.scrollTop;
    const docHeight = document.documentElement.scrollHeight - document.documentElement.clientHeight;
    if (docHeight <= 0) return;

    const scrollPercent = scrollTop / docHeight;
    if (scrollPercent > 0.3) {
      this.markAsRead();
      this.hasMarkedAsRead = true;
    }
  };

  approveItem(): void {
    if (!this.catalogItem) return;
    this.isLoading = true;
    this.catalogService.approveCatalogItem(this.catalogItem.id).subscribe({
      next: (updatedItem) => {
        this.catalogItem = updatedItem;
        this.isLoading = false;
      },
      error: (err) => {
        this.isLoading = false;
        // Optionally show an error message
        this.errorMessage = 'Failed to approve item. Please try again.';
        console.error('Approve error:', err);
      }
    });
  }

  // ===== INITIALIZATION METHODS =====

  private initializeComponent(): void {
    this.initializeBreadcrumbs();
    this.subscribeToAuthState();
    this.subscribeToRouteParams();
  }

  private initializeBreadcrumbs(): void {
    this.breadcrumbItems = [
      { label: 'Dashboard', routerLink: '/user/dashboard' },
      { label: 'Catalog', routerLink: '/user/catalog' },
      { label: 'Article Details', routerLink: null }
    ];
  }

  private subscribeToAuthState(): void {
    this.subscriptions.add(
      this.authService.currentUser$.subscribe((user: User | null) => {
        this.currentUser = user;
      })
    );
  }

  /**
   * Subscribe to route parameter changes
   */
  private subscribeToRouteParams(): void {
    this.subscriptions.add(
      this.route.params.subscribe(params => {
        const itemId = params['id'];
        
        // Handle special reserved route keywords that should not be treated as catalog item IDs
        const reservedKeywords = ['create', 'create-article', 'create-newsletter', 'edit'];
        if (reservedKeywords.includes(itemId)) {
          console.log(`Detected reserved keyword "${itemId}" in catalog detail route, redirecting...`);
          // Redirect to the proper create route
          if (itemId === 'create') {
            this.router.navigate(['/user/catalog/create-article']);
          } else {
            this.router.navigate(['/user/catalog', itemId]);
          }
          return;
        }
        
        if (itemId && itemId !== this.catalogItem?.id) {
          this.loadCatalogItem(itemId);
        }
      })
    );
  }

  private updateBreadcrumbs(): void {
    if (this.catalogItem) {
      this.breadcrumbItems = [
        { label: 'Dashboard', routerLink: '/user/dashboard' },
        { label: 'Catalog', routerLink: '/user/catalog' },
        { label: this.catalogItem.title, routerLink: null }
      ];
    }
  }

  // ===== DATA LOADING METHODS =====

  loadCatalogItem(itemId: string): void {
    this.isLoading = true;
    this.errorMessage = '';

    this.catalogService.getCatalogItem(itemId).subscribe({
      next: (item) => {
        this.catalogItem = {
          ...item,
          read: item.read === true ? true : false
        };
        
        this.isLoading = false;
        this.updateBreadcrumbs();
        this.loadRelatedItems();
        this.initializeUserInteractions();
      },
      error: (error) => {
        console.error('Failed to load catalog item:', error);
        this.errorMessage = 'Failed to load article. Please try again.';
        this.isLoading = false;
      }
    });
  }

  private initializeUserInteractions(): void {
    if (this.catalogItem) {
      this.isLiked = this.catalogItem.user_has_liked || false;
    }
  }

  private loadRelatedItems(): void {
    if (!this.catalogItem) return;

    const params = {
      category: this.catalogItem.category,
      limit: 3,
      exclude: this.catalogItem.id
    };

    this.catalogService.getCatalogItems(params).subscribe({
      next: (response) => {
        this.relatedItems = response.items || [];
      },
      error: (error) => {
        console.error('Failed to load related items:', error);
        this.relatedItems = [];
      }
    });
  }

  // ===== NAVIGATION METHODS =====

  goBack(): void {
    this.router.navigate(['/user/catalog']);
  }

  goToRelatedItem(item: Catalog): void {
    this.router.navigate(['/user/catalog', item.id]);
  }

  // ===== USER INTERACTION METHODS =====

  toggleLike(): void {
    if (!this.catalogItem || !this.currentUser) return;

    const action = this.isLiked ? 'unlike' : 'like';

    this.catalogService.toggleLike(this.catalogItem.id, action).subscribe({
      next: (response) => {
        this.isLiked = !this.isLiked;
        if (this.catalogItem) {
          this.catalogItem.likes_count = response.likes_count;
          this.catalogItem.user_has_liked = this.isLiked;
        }
      },
      error: (error) => {
        console.error('Failed to toggle like:', error);
      }
    });
  }

  shareArticle(): void {
    if (!this.catalogItem) return;

    if (navigator.share) {
      navigator.share({
        title: this.catalogItem.title,
        text: this.catalogItem.description || this.getExcerpt(this.catalogItem.content || '', 100),
        url: window.location.href
      }).catch(console.error);
    } else {
      this.showShareModal = true;
    }
  }

  closeShareModal(): void {
    this.showShareModal = false;
  }

  copyLink(): void {
    navigator.clipboard.writeText(window.location.href).then(() => {
      console.log('Link copied to clipboard');
      this.closeShareModal();
    }).catch(console.error);
  }

  emailArticle(): void {
    if (!this.catalogItem) return;

    const subject = encodeURIComponent(`Article: ${this.catalogItem.title}`);
    const body = encodeURIComponent(`
I thought you might be interested in this article:

${this.catalogItem.title}

${this.catalogItem.description || ''}

Read the full article here: ${window.location.href}
    `);

    window.location.href = `mailto:?subject=${subject}&body=${body}`;
  }

  markAsRead(): void {
    if (!this.catalogItem || this.catalogItem.read) return;

    this.catalogService.markAsRead(this.catalogItem.id).subscribe({
      next: (updatedItem) => {
        if (this.catalogItem) {
          this.catalogItem.read = true;
          this.catalogItem = { ...this.catalogItem, ...updatedItem };
        }
      },
      error: (error) => {
        console.error('Failed to mark as read:', error);
      }
    });
  }

  // ===== AI CHAT METHODS =====

  openAiChat(): void {
    this.showAiChat = true;
  }

  closeAiChat(): void {
    this.showAiChat = false;
  }

  // ===== CONVERSATIONS METHODS =====

  openConversations(): void {
    this.showConversations = true;
  }

  closeConversations(): void {
    this.showConversations = false;
  }

  // ===== CONTENT MANAGEMENT METHODS =====

  editItem(): void {
    if (!this.catalogItem || !this.canEdit()) return;
    this.router.navigate(['/user/catalog/edit', this.catalogItem.id]);
  }

  deleteItem(): void {
    if (!this.catalogItem || !this.canDelete()) return;

    if (confirm('Are you sure you want to delete this article?')) {
      this.catalogService.deleteCatalogItem(this.catalogItem.id).subscribe({
        next: () => {
          this.router.navigate(['/user/catalog']);
        },
        error: (error) => {
          console.error('Failed to delete item:', error);
        }
      });
    }
  }

  // ===== TAB MANAGEMENT =====

  changeTab(tabValue: string): void {
    this.activeTab = tabValue;
  }

  // ===== PERMISSION CHECKS =====

  canEdit(): boolean {
    if (!this.catalogItem || !this.currentUser) return false;
    return this.currentUser.id === this.catalogItem.author_id || this.currentUser.role === 'admin';
  }

  canDelete(): boolean {
    if (!this.catalogItem || !this.currentUser) return false;
    return this.currentUser.id === this.catalogItem.author_id || this.currentUser.role === 'admin';
  }

  // ===== UTILITY METHODS =====

  getFormattedPublishDate(): string {
    if (!this.catalogItem) return '';
    return this.catalogItem.published_at
      ? this.formatDate(this.catalogItem.published_at)
      : this.formatDate(this.catalogItem.created_date || '');
  }

  getReadingTime(): string {
    if (!this.catalogItem?.content) return '1 min';
    const wordsPerMinute = 200;
    const wordCount = this.catalogItem.content.split(' ').length;
    const minutes = Math.ceil(wordCount / wordsPerMinute);
    return `${minutes} min`;
  }

  getAuthorDisplayName(): string {
    return this.catalogItem?.author || 'Unknown Author';
  }

  formatDate(dateString: string): string {
    if (!dateString) return '';
    return this.dateUtilityService.formatDate(dateString);
  }

  getExcerpt(text: string | undefined, maxLength: number = 150): string {
    if (!text) return '';
    if (text.length <= maxLength) return text;
    return text.substring(0, maxLength) + '...';
  }

  // ===== STYLING METHODS =====

  getCategoryClass(category: string | undefined): string {
    if (!category) return 'status-badge';
    const categoryMap: { [key: string]: string } = {
      'technology': 'status-badge status-info',
      'business': 'status-badge status-success',
      'news': 'status-badge status-warning',
      'research': 'status-badge status-primary',
      'announcement': 'status-badge status-announcement'
    };
    return categoryMap[category] || 'status-badge';
  }

  getStatusClass(status: string | undefined): string {
    if (!status) return 'status-badge status-published';
    const statusMap: { [key: string]: string } = {
      'published': 'status-badge status-success',
      'draft': 'status-badge status-medium',
      'pending': 'status-badge status-warning'
    };
    return statusMap[status] || 'status-badge status-published';
  }

  // ===== CONTENT CHECKS =====

  /**
   * Enhanced newsletter detection - checks for various newsletter indicators
   */
  hasInlineStyles(): boolean {
    if (!this.catalogItem?.content && !this.catalogItem?.contentHTML) return false;
    
    const content = this.catalogItem.contentHTML || this.catalogItem.content || '';
    
    // Check for multiple newsletter indicators
    const newsletterIndicators = [
      'style=',                           // Inline styles
      'table',                           // Table-based layouts common in newsletters
      'cellpadding',                     // Table formatting
      'cellspacing',                     // Table formatting
      'background-color',                // Background styling
      'font-family',                     // Font styling
      'text-align',                      // Text alignment
      'border-collapse',                 // Table styling
      'mso-',                           // Microsoft Outlook specific styles
      'webkit-',                        // Webkit specific styles
      'data-module',                    // Newsletter builder modules
      'data-block',                     // Newsletter builder blocks
      'newsletter',                     // Explicit newsletter indicator
      'email-template',                 // Email template indicator
      'campaign',                       // Email campaign indicator
    ];

    return newsletterIndicators.some(indicator => 
      content.toLowerCase().includes(indicator.toLowerCase())
    );
  }

  /**
   * Check if content is from a newsletter template
   */
  isNewsletterContent(): boolean {
    if (!this.catalogItem) return false;
    
    // Check type/category indicators
    const type = this.catalogItem.type?.toLowerCase() || '';
    const category = this.catalogItem.category?.toLowerCase() || '';
    const title = this.catalogItem.title?.toLowerCase() || '';
    
    const newsletterTypes = ['newsletter', 'email', 'campaign', 'announcement'];
    const isNewsletterType = newsletterTypes.some(newsletterType => 
      type.includes(newsletterType) || 
      category.includes(newsletterType) || 
      title.includes(newsletterType)
    );

    // Check content structure
    const hasNewsletterStructure = this.hasInlineStyles();
    
    return isNewsletterType || hasNewsletterStructure;
  }

  /**
   * Get content with preserved newsletter formatting
   */
  getNewsletterSafeContent(): string {
    if (!this.catalogItem) return '';
    
    // Prefer contentHTML for newsletters as it preserves formatting better
    let content = this.catalogItem.contentHTML || this.catalogItem.content || '';
    
    if (this.isNewsletterContent()) {
      // For newsletter content, ensure we preserve all inline styles and structure
      // Add a wrapper div to contain the newsletter styling
      content = `<div class="newsletter-wrapper">${content}</div>`;
    }
    
    return content;
  }

  // ===== DEVELOPMENT UTILITIES =====

  showJSON(): void {
    if (!this.catalogItem) return;
    const dataStr = JSON.stringify(this.catalogItem, null, 2);
    const html = `
      <html>
        <head>
          <title>${this.catalogItem.title || 'Catalog Item'} - JSON</title>
          <style>
            body { background: #222; color: #eee; margin: 0; padding: 0; }
            pre { background: #181818; color: #00e676; padding: 2rem; margin: 0; font-size: 1.1rem; overflow-x: auto; }
            .header { background: #111; color: #fff; padding: 1rem 2rem; font-size: 1.2rem; font-family: sans-serif; }
          </style>
        </head>
        <body>
          <div class="header">${this.catalogItem.title || 'Catalog Item'} JSON</div>
          <pre>${dataStr.replace(/</g, '&lt;').replace(/>/g, '&gt;')}</pre>
        </body>
      </html>
    `;
    const win = window.open('', '_blank');
    if (win) {
      win.document.open();
      win.document.write(html);
      win.document.close();
    }
  }

  // ===== CHILD IDS FUNCTIONALITY =====

  /**
   * Get child items in proper format
   */
  getChildItems(): CatalogChildItem[] {
    if (!this.catalogItem?.child_ids) return [];

    // Check if child_ids contains objects (CatalogChildItem) or strings
    const firstChild = this.catalogItem.child_ids[0];
    const isObjectFormat = typeof firstChild === 'object' && firstChild !== null;

    if (isObjectFormat) {
      // Return sorted by index
      return (this.catalogItem.child_ids as CatalogChildItem[])
        .sort((a, b) => a.index - b.index);
    } else {
      // Convert string array to CatalogChildItem format for display
      return (this.catalogItem.child_ids as string[]).map((id, index) => ({
        id: id,
        index: index,
        title: `Child Item ${index + 1}`,
        description: `Catalog ID: ${id}`,
        author: 'Unknown'
      }));
    }
  }

  /**
   * Navigate to child catalog item
   */
  goToChildItem(childItem: CatalogChildItem): void {
    if (childItem.id) {
      this.router.navigate(['/user/catalog', childItem.id]);
    }
  }

  /**
   * Get child item display title
   */
  getChildItemDisplayTitle(childItem: CatalogChildItem): string {
    return childItem.title || `Item ${childItem.index + 1}`;
  }

  /**
   * Get child item display description
   */
  getChildItemDisplayDescription(childItem: CatalogChildItem): string {
    if (childItem.description) {
      return this.getExcerpt(childItem.description, 100);
    }
    return `Catalog ID: ${childItem.id}`;
  }

  /**
   * Get child item display author
   */
  getChildItemDisplayAuthor(childItem: CatalogChildItem): string {
    return childItem.author || 'Unknown Author';
  }

  /**
   * Check if child item has complete information (title, description, etc.)
   */
  isChildItemComplete(childItem: CatalogChildItem): boolean {
    return !!(childItem.title && childItem.description);
  }

  /**
   * Get child items grouped by completeness
   */
  getGroupedChildItems(): { complete: CatalogChildItem[], incomplete: CatalogChildItem[] } {
    const childItems = this.getChildItems();
    return {
      complete: childItems.filter(item => this.isChildItemComplete(item)),
      incomplete: childItems.filter(item => !this.isChildItemComplete(item))
    };
  }

  /**
   * Track function for ngFor on child items
   */
  trackByChildId(index: number, childItem: CatalogChildItem): string {
    return childItem.id + '_' + childItem.index;
  }

  /**
   * Get sanitized content that preserves inline styles for newsletter templates
   */
  getSanitizedContent(): SafeHtml {
    if (!this.catalogItem?.content) return '';

    // Check if the content contains inline styles (likely from newsletter templates)
    const hasInlineStylesContent = this.catalogItem.content.includes('style=');

    if (hasInlineStylesContent) {
      // For content with inline styles, sanitize but preserve styling
      return this.sanitizer.bypassSecurityTrustHtml(this.catalogItem.content);
    } else {
      // For regular content, use the original innerHTML binding (handled in template)
      return '';
    }
  }

  // ===== AI SUMMARY ACTIONS =====
  regenerateSummary(): void {
    // TODO: Implement actual regeneration logic (API call)
    alert('Regenerate summary feature coming soon!');
  }

  copySummary(): void {
    if (this.catalogItem?.summary) {
      const el = document.createElement('textarea');
      el.value = this.stripHtmlTags(this.catalogItem.summary);
      document.body.appendChild(el);
      el.select();
      document.execCommand('copy');
      document.body.removeChild(el);
      // Optionally show a toast/notification
      alert('AI summary copied to clipboard!');
    }
  }

  /**
   * Strip HTML tags from text and convert to plain text
   */
  private stripHtmlTags(html: string): string {
    if (!html) return '';

    // Create a temporary div element to parse HTML
    const tempDiv = document.createElement('div');
    tempDiv.innerHTML = html;

    // Get text content and clean up extra whitespace
    return tempDiv.textContent || tempDiv.innerText || '';
  }

  hasTags(): boolean {
    return !!(this.catalogItem?.tags && this.catalogItem.tags.length > 0);
  }

  getTags(): string[] {
    return this.catalogItem?.tags || [];
  }

  hasSummary(): boolean {
    return !!(this.catalogItem?.summary && this.catalogItem.summary.trim());
  }

  hasChildIds(): boolean {
    return !!(this.catalogItem?.child_ids && this.catalogItem.child_ids.length > 0);
  }

  getChildItemsCount(): number {
    if (!this.catalogItem?.child_ids) return 0;
    return this.catalogItem.child_ids.length;
  }
}
import { Component, Input, TemplateRef, Output, EventEmitter } from '@angular/core';
import { IconDefinition } from '@fortawesome/fontawesome-svg-core';
import { CommonModule } from '@angular/common';
import { FontAwesomeModule } from '@fortawesome/angular-fontawesome';
import { faEdit, faTimes, faEye, faFileAlt } from '@fortawesome/free-solid-svg-icons';

@Component({
  selector: 'app-recent-item',
  standalone: true,
  imports: [CommonModule, FontAwesomeModule],
  template: `
    <div class="recent-item-card" 
         [class.clickable]="clickable" 
         (click)="onItemClick()"
         [title]="getTooltipText()">
      
      <!-- Main Icon -->
      <div class="item-icon-container">
        <fa-icon [icon]="icon || faFileAlt" class="main-icon"></fa-icon>
      </div>
      
      <!-- Title -->
      <div class="item-title">{{ getTruncatedTitle() }}</div>
      
      <!-- Type Badge -->
      <div class="item-type" *ngIf="type">{{ type }}</div>
      
      <!-- Action Buttons (on hover) -->
      <div class="item-actions" *ngIf="showActions" (click)="$event.stopPropagation()">
        <!-- <fa-icon 
          [icon]="faEdit" 
          class="action-icon edit-icon"
          (click)="onEditClick()"
          title="Edit"></fa-icon> -->
        <fa-icon 
          [icon]="faTimes" 
          class="action-icon delete-icon"
          (click)="onDeleteClick()"
          title="Delete"></fa-icon>
      </div>
    </div>
  `,
  styles: [`
    .recent-item-card {
      background: var(--fm-white, #fff);
      border: 1px solid var(--fm-border-light, #e3e6f0);
      border-radius: 12px;
      padding: 0.75rem;
      transition: all 0.2s ease;
      position: relative;
      height: 140px;
      width: 120px;
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      text-align: center;
      gap: 0.5rem;
      box-sizing: border-box;
      overflow: hidden;
    }
    
    .recent-item-card.clickable {
      cursor: pointer;
    }
    
    .recent-item-card:hover {
      border-color: var(--fm-primary-blue, #007bff);
      box-shadow: 0 4px 12px rgba(0, 123, 255, 0.15);
      transform: translateY(-1px);
    }
    
    .item-icon-container {
      display: flex;
      align-items: center;
      justify-content: center;
      margin-bottom: 0.25rem;
    }
    
    .main-icon {
      font-size: 2rem;
      padding:0px;
      color: var(--fm-primary-blue, #007bff);
      transition: all 0.2s ease;
    }
    
    .recent-item-card:hover .main-icon {
      transform: scale(1.1);
      color: var(--fm-primary-blue-dark, #0056b3);
    }
    
    .item-title {
      font-weight: 600;
      color: var(--fm-text-primary, #222);
      font-size: 0.75rem;
      line-height: 1.2;
      text-align: center;
      word-break: break-word;
      overflow: hidden;
      display: -webkit-box;
      -webkit-line-clamp: 2;
      -webkit-box-orient: vertical;
      max-height: 2.4rem;
      margin-bottom: 0.25rem;
    }
    
    .item-type {
      font-size: 0.65rem;
      color: var(--fm-text-muted, #6c757d);
      text-transform: uppercase;
      font-weight: 500;
      letter-spacing: 0.5px;
      background: var(--fm-gray-100, #f8f9fa);
      padding: 0.125rem 0.375rem;
      border-radius: 8px;
      max-width: 100%;
      overflow: hidden;
      text-overflow: ellipsis;
      white-space: nowrap;
    }
    
    .item-actions {
      position: absolute;
      top: 0.25rem;
      right: 0.25rem;
      display: flex;
      gap: 0.125rem;
      opacity: 0;
      transition: all 0.2s ease;
      z-index: 2;
    }
    
    .recent-item-card:hover .item-actions {
      opacity: 1;
    }
    
    .action-icon {
      cursor: pointer;
      padding: 0.25rem;
      border-radius: 4px;
      transition: all 0.2s ease;
      font-size: 0.7rem;
      background: rgba(255, 255, 255, 0.9);
      backdrop-filter: blur(4px);
    }
    
    .edit-icon {
      color: var(--fm-warning, #ffc107);
    }
    
    .edit-icon:hover {
      background: var(--fm-warning, #ffc107);
      color: white;
    }
    
    .delete-icon {
      color: var(--fm-danger, #dc3545);
    }
    
    .delete-icon:hover {
      background: var(--fm-danger, #dc3545);
      color: white;
    }
    
    /* Responsive adjustments for smaller sizes */
    @media (max-width: 768px) {
      .recent-item-card {
        height: 110px;
        width: 110px;
        padding: 0.5rem;
      }
      
      .main-icon {
        font-size: 1.75rem;
      }
      
      .item-title {
        font-size: 0.7rem;
      }
      
      .item-type {
        font-size: 0.6rem;
        padding: 0.1rem 0.3rem;
      }
    }
  `]
})
export class RecentItemComponent {
  @Input() icon?: IconDefinition;
  @Input() title: string = '';
  @Input() description?: string;
  @Input() category?: string;
  @Input() type?: string;
  @Input() time?: string;
  @Input() value?: string | number;
  @Input() graphic?: string | TemplateRef<any>;
  @Input() showActions: boolean = false;
  @Input() clickable: boolean = true;
  @Input() itemId?: string;

  @Output() itemClick = new EventEmitter<any>();
  @Output() viewClick = new EventEmitter<any>();
  @Output() editClick = new EventEmitter<any>();
  @Output() deleteClick = new EventEmitter<any>();

  // Font Awesome icons
  faEdit = faEdit;
  faTimes = faTimes;
  faEye = faEye;
  faFileAlt = faFileAlt;

  onItemClick(): void {
    if (this.clickable) {
      this.itemClick.emit({
        id: this.itemId,
        title: this.title,
        description: this.description,
        category: this.category,
        type: this.type,
        time: this.time
      });
    }
  }

  onViewClick(): void {
    this.viewClick.emit({
      id: this.itemId,
      title: this.title,
      action: 'view'
    });
  }

  onEditClick(): void {
    this.editClick.emit({
      id: this.itemId,
      title: this.title,
      action: 'edit'
    });
  }

  onDeleteClick(): void {
    this.deleteClick.emit({
      id: this.itemId,
      title: this.title,
      action: 'delete'
    });
  }

  get graphicImg(): string | null {
    return typeof this.graphic === 'string' ? this.graphic : null;
  }

  get graphicTpl(): TemplateRef<any> | null {
    return this.graphic instanceof TemplateRef ? this.graphic : null;
  }

  /**
   * Get truncated title that fits within the card
   */
  getTruncatedTitle(): string {
    if (!this.title) return '';
    
    // For 120px card, limit to about 20 characters to ensure good fit
    const maxLength = 20;
    if (this.title.length <= maxLength) {
      return this.title;
    }
    
    return this.title.substring(0, maxLength - 3) + '...';
  }

  /**
   * Get tooltip text with full title and additional info
   */
  getTooltipText(): string {
    let tooltip = this.title || '';
    
    if (this.description) {
      tooltip += `\n\n${this.description}`;
    }
    
    if (this.type) {
      tooltip += `\nType: ${this.type}`;
    }
    
    if (this.time) {
      tooltip += `\nLast updated: ${this.time}`;
    }
    
    return tooltip;
  }
}
import { Component, Input, Output, EventEmitter } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FontAwesomeModule } from '@fortawesome/angular-fontawesome';
import { faExclamationTriangle, faTimes, faTrash } from '@fortawesome/free-solid-svg-icons';
import { ActionButtonComponent } from '../button/action-button.component';
import { IconButtonComponent } from '../button/icon-button.component';

export interface DeleteConfirmationData {
  id: string;
  title: string;
  type?: string;
  description?: string;
}

@Component({
  selector: 'app-delete-confirmation',
  standalone: true,
  imports: [CommonModule, FontAwesomeModule, ActionButtonComponent, IconButtonComponent],
  template: `
    <div *ngIf="show && itemToDelete" class="modal-overlay" (click)="onCancel()">
      <div class="modal-container" (click)="$event.stopPropagation()">
        <div class="modal-header">
          <h2>Delete {{ itemType }}</h2>
          <app-icon-button 
            variant="default" 
            [icon]="faTimes" 
            size="medium" 
            (buttonClick)="onCancel()"
            tooltip="Close modal">
          </app-icon-button>
        </div>

        <div class="modal-content">
          <div class="confirmation-content">
            <fa-icon [icon]="faExclamationTriangle" class="warning-icon"></fa-icon>
            <h3>Are you sure you want to delete this {{ itemType.toLowerCase() }}?</h3>
            <p>
              The {{ itemType.toLowerCase() }} "{{ itemToDelete.title }}" will be permanently deleted. 
              This action cannot be undone.
            </p>
            <p *ngIf="itemToDelete.description" class="item-description">
              {{ itemToDelete.description }}
            </p>
          </div>

          <div class="modal-actions">
            <app-action-button 
              type="button" 
              variant="secondary" 
              (buttonClick)="onCancel()">
              Cancel
            </app-action-button>
            <app-action-button 
              type="button" 
              variant="danger" 
              [icon]="faTrash" 
              [disabled]="isDeleting"
              (buttonClick)="onConfirm()">
              {{ isDeleting ? 'Deleting...' : 'Delete ' + itemType }}
            </app-action-button>
          </div>
        </div>
      </div>
    </div>
  `,
  styles: [`
    .modal-overlay {
      position: fixed;
      top: 0;
      left: 0;
      right: 0;
      bottom: 0;
      background: rgba(0, 0, 0, 0.6);
      display: flex;
      align-items: center;
      justify-content: center;
      z-index: 1000;
      animation: fadeIn 0.2s ease-out;
    }

    .modal-container {
      background: var(--fm-white);
      border-radius: 12px;
      box-shadow: 0 8px 32px rgba(0, 0, 0, 0.2);
      max-width: 500px;
      width: 90%;
      max-height: 90vh;
      overflow: hidden;
      animation: slideIn 0.3s ease-out;
    }

    .modal-header {
      display: flex;
      align-items: center;
      justify-content: space-between;
      padding: 1.5rem 2rem 1rem 2rem;
      border-bottom: 1px solid var(--fm-border-light, #e3e6f0);
      background: var(--fm-gray-lighter, #f8f9fa);
    }

    .modal-header h2 {
      margin: 0;
      font-size: 1.5rem;
      font-weight: 600;
      color: var(--fm-text-primary, #222);
    }

    .modal-content {
      padding: 2rem;
    }

    .confirmation-content {
      text-align: center;
      margin-bottom: 2rem;
    }

    .warning-icon {
      font-size: 3rem;
      color: var(--fm-warning, #ffc107);
      margin-bottom: 1rem;
      animation: pulse 2s ease-in-out infinite;
    }

    .confirmation-content h3 {
      margin: 0 0 1rem 0;
      font-size: 1.25rem;
      font-weight: 600;
      color: var(--fm-text-primary, #222);
    }

    .confirmation-content p {
      margin: 0 0 0.5rem 0;
      color: var(--fm-text-secondary, #6c757d);
      line-height: 1.5;
    }

    .item-description {
      font-style: italic;
      background: var(--fm-gray-100, #f8f9fa);
      padding: 0.75rem;
      border-radius: 6px;
      border-left: 3px solid var(--fm-warning, #ffc107);
      margin-top: 1rem !important;
    }

    .modal-actions {
      display: flex;
      gap: 1rem;
      justify-content: flex-end;
    }

    @keyframes fadeIn {
      from {
        opacity: 0;
      }
      to {
        opacity: 1;
      }
    }

    @keyframes slideIn {
      from {
        opacity: 0;
        transform: translateY(-20px) scale(0.95);
      }
      to {
        opacity: 1;
        transform: translateY(0) scale(1);
      }
    }

    @keyframes pulse {
      0%, 100% {
        opacity: 1;
        transform: scale(1);
      }
      50% {
        opacity: 0.8;
        transform: scale(1.05);
      }
    }

    /* Responsive design */
    @media (max-width: 768px) {
      .modal-container {
        width: 95%;
        margin: 1rem;
      }

      .modal-header {
        padding: 1rem 1.5rem 0.75rem 1.5rem;
      }

      .modal-header h2 {
        font-size: 1.25rem;
      }

      .modal-content {
        padding: 1.5rem;
      }

      .confirmation-content h3 {
        font-size: 1.1rem;
      }

      .modal-actions {
        flex-direction: column;
      }
    }
  `]
})
export class DeleteConfirmationComponent {
  @Input() show: boolean = false;
  @Input() itemToDelete: DeleteConfirmationData | null = null;
  @Input() itemType: string = 'Item';
  @Input() isDeleting: boolean = false;

  @Output() confirm = new EventEmitter<DeleteConfirmationData>();
  @Output() cancel = new EventEmitter<void>();

  // FontAwesome icons
  faExclamationTriangle = faExclamationTriangle;
  faTimes = faTimes;
  faTrash = faTrash;

  onConfirm(): void {
    if (this.itemToDelete && !this.isDeleting) {
      this.confirm.emit(this.itemToDelete);
    }
  }

  onCancel(): void {
    if (!this.isDeleting) {
      this.cancel.emit();
    }
  }
}
import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, BehaviorSubject, forkJoin, of } from 'rxjs';
import { map, switchMap, catchError } from 'rxjs/operators';
import { Catalog, CatalogResponse, CatalogCreate, CatalogUpdate, CatalogChildItem } from '../models/user.interface';
import { filterCatalogTypesByRole } from '../config/site-config';
import { AuthService } from './auth.service';
import { BaseApiService } from './base-api.service';
import { CacheService } from './cache.service';
import { ConversationService } from './conversation.service';

export interface CatalogQueryParams {
  type?: string;
  query?: string;
  search?: string;
  q?: string;
  title?: string;
  category?: string;
  status?: string;
  author?: string;
  key?: string; // Added key parameter for searching by key
  priority?: 'high' | 'medium' | 'low';
  severity?: 'high' | 'medium' | 'low';
  urgent?: boolean;
  important?: boolean;
  page?: number;
  page_size?: number;
  skip?: number;
  limit?: number;
  sort?: string;
  order?: 'asc' | 'desc';
  date_range?: string;
  useCache?: boolean;
}

@Injectable({
  providedIn: 'root'
})
export class CatalogService extends BaseApiService {
  // Observable streams for reactive data
  private notificationsSubject = new BehaviorSubject<Catalog[]>([]);
  private newsSubject = new BehaviorSubject<Catalog[]>([]);
  
  // Expose observables for components
  public notifications$ = this.notificationsSubject.asObservable();
  public news$ = this.newsSubject.asObservable();
  public catalogRefresh$: Observable<boolean>;

  constructor(
    http: HttpClient,
    private authService: AuthService,
    private cacheService: CacheService,
    private conversationService: ConversationService
  ) {
    super(http);
    this.catalogRefresh$ = this.cacheService.catalogRefresh$;
  }

  // Core CRUD Operations
  
  /**
   * Get catalog items with optional filters and caching
   */
  getCatalogItems(params?: CatalogQueryParams): Observable<CatalogResponse> {
    const useCache = params?.useCache !== false;
    const apiParams = { ...params };
    delete apiParams.useCache;
    
    const sortedParams = this.addSortParams(apiParams);
    const cacheKey = this.cacheService.createKey('catalog-items', sortedParams);
    
    if (useCache) {
      const cached = this.cacheService.get<CatalogResponse>(cacheKey);
      if (cached && (!params?.page || params.page > 1)) {
        return new Observable(observer => {
          observer.next(cached);
          observer.complete();
        });
      }
    }

    return this.get<CatalogResponse>('/catalog/', sortedParams).pipe(
      map(response => {
        this.cacheService.set(cacheKey, response);
        return response;
      })
    );
  }

  /**
   * Search catalog items
   */
  searchCatalogItems(params?: Omit<CatalogQueryParams, 'useCache'>): Observable<CatalogResponse> {
    const sortedParams = this.addSortParams(params);
    return this.get<CatalogResponse>('/catalog/search', sortedParams);
  }

  /**
   * Mark catalog item as read
   */
  markAsRead(catalogId: string): Observable<Catalog> {
    // POST /api/v1/catalog/{catalog_id}/read
    return this.post<Catalog>(`/catalog/${catalogId}/read`, {});
  }

  /**
   * Get catalog item by ID with enhanced content processing
   * Fetches all attributes for each child_id and replaces variables in content
   * using the pattern @catalog[index].property
   */
  getCatalogItem(id: string): Observable<Catalog> {
    console.log('🔍 getCatalogItem called for ID:', id);
    return this.get<Catalog>(`/catalog/${id}`).pipe(
      map(catalog => {
        console.log('📦 Raw catalog item received:', catalog);
        console.log('📦 Catalog child_ids:', catalog.child_ids);
        return catalog;
      }),
      switchMap(catalog => {
        // Check if catalog has child_ids and needs content processing
        if (catalog.child_ids && catalog.child_ids.length > 0) {
          console.log('🔄 Processing content with child items for catalog:', id);
          return this.fetchAllChildAttributesAndReplaceContent(catalog);
        } else {
          console.log('⚠️ No child_ids found or empty array for catalog:', id);
          return of(catalog);
        }
      }),
      map(processedCatalog => {
        console.log('✅ Final processed catalog:', processedCatalog);
        return processedCatalog;
      })
    );
  }

  /**
   * Get catalog item by ID for editing purposes
   * Returns the raw catalog item without processing child content variables
   * This preserves the original content with @catalog[index].property patterns intact
   */
  getCatalogItemForEdit(id: string): Observable<Catalog> {
    console.log('🔍 getCatalogItemForEdit called for ID:', id);
    return this.get<Catalog>(`/catalog/${id}`).pipe(
      map(catalog => {
        console.log('📦 Raw catalog item for editing:', catalog);
        console.log('📦 Preserving original content patterns for editing');
        return catalog;
      })
    );
  }

  /**
   * Fetch all attributes for each child ID and replace content variables
   * Supports both child_ids formats:
   * 1. String array: ["catalogId1", "catalogId2", "catalogId3"] 
   * 2. Object array: [{id: "catalogId1", index: 0, title: "...", description: "..."}, ...]
   * Enhanced to prevent HTML content duplication
   */
  private fetchAllChildAttributesAndReplaceContent(catalog: Catalog): Observable<Catalog> {
    console.log('🔄 fetchAllChildAttributesAndReplaceContent called with catalog:', catalog.id);
    console.log('📦 Child IDs:', catalog.child_ids);
    console.log('📦 Original content length:', catalog.content?.length || 0);
    console.log('📦 Original contentHTML length:', catalog.contentHTML?.length || 0);
    
    if (!catalog.child_ids || catalog.child_ids.length === 0) {
      console.log('⚠️ No child_ids found, returning original catalog');
      return of(catalog);
    }

    // Check if content has already been processed (contains replaced values instead of @catalog patterns)
    const hasVariablePatterns = this.hasUnprocessedVariablePatterns(catalog);
    if (!hasVariablePatterns) {
      console.log('✅ Content appears to already be processed (no @catalog patterns found), returning as-is');
      return of(catalog);
    }

    // Determine if child_ids contains strings (catalogIDs) or objects (CatalogChildItem)
    const firstChild = catalog.child_ids[0];
    const isObjectFormat = typeof firstChild === 'object' && firstChild !== null;
    console.log('🔍 Detection result - isObjectFormat:', isObjectFormat);

    if (isObjectFormat) {
      console.log('📦 Object format detected - fetching full attributes for each child ID');
      // Even for object format, fetch complete attributes from API to ensure we have ALL data
      const childObjects = catalog.child_ids as CatalogChildItem[];
      const catalogIds = childObjects.map(child => String(child.id));
      
      return this.fetchCompleteChildItems(catalogIds).pipe(
        map(completeChildItems => {
          // Merge with existing index information and sort by index
          const indexedChildItems = completeChildItems.map(item => {
            const childObj = childObjects.find(child => String(child.id) === item.id);
            return {
              ...item, // All attributes from API
              index: childObj?.index || 0 // Preserve original index
            };
          }).sort((a, b) => a.index - b.index);
          
          console.log('📦 Complete indexed child items:', indexedChildItems.length);
          return this.replaceContentVariablesSafely(catalog, indexedChildItems);
        })
      );
    } else {
      console.log('📦 String format detected - fetching complete attributes for each catalog ID');
      // Handle string format - fetch ALL attributes for each child catalog ID
      const catalogIds = catalog.child_ids as string[];
      
      return this.fetchCompleteChildItems(catalogIds).pipe(
        map(completeChildItems => {
          console.log('📦 Complete child items fetched:', completeChildItems.length);
          return this.replaceContentVariablesSafely(catalog, completeChildItems);
        })
      );
    }
  }

  /**
   * Check if catalog content contains unprocessed variable patterns (@catalog[x].property)
   * This helps prevent reprocessing already processed content
   */
  private hasUnprocessedVariablePatterns(catalog: Catalog): boolean {
    const variablePattern = /@catalog\[(\d+)\]\.(\w+(?:\.\w+)*)/;
    
    const fieldsToCheck = [
      catalog.content,
      catalog.contentHTML,
      catalog.description,
      catalog.summary,
      catalog.title
    ].filter(field => field && typeof field === 'string') as string[];

    // Check custom fields
    if (catalog.custom) {
      fieldsToCheck.push(...this.extractStringValuesFromObject(catalog.custom));
    }

    const hasPatterns = fieldsToCheck.some(field => variablePattern.test(field));
    console.log('🔍 Variable pattern check result:', hasPatterns);
    
    return hasPatterns;
  }

  /**
   * Extract all string values from a nested object (for checking custom fields)
   */
  private extractStringValuesFromObject(obj: any): string[] {
    const stringValues: string[] = [];
    
    const extract = (current: any) => {
      if (typeof current === 'string') {
        stringValues.push(current);
      } else if (typeof current === 'object' && current !== null) {
        if (Array.isArray(current)) {
          current.forEach(item => extract(item));
        } else {
          Object.values(current).forEach(value => extract(value));
        }
      }
    };
    
    extract(obj);
    return stringValues;
  }

  /**
   * Replace content variables with child data (enhanced to prevent duplication)
   */
  private replaceContentVariablesSafely(catalog: Catalog, childItems: Catalog[]): Catalog {
    console.log('🔄 replaceContentVariablesSafely called with:', {
      catalogId: catalog.id,
      childItemsCount: childItems.length
    });
    
    // Create a deep copy to prevent mutation of original catalog
    const processedCatalog = JSON.parse(JSON.stringify(catalog));
    
    // Process content field
    if (processedCatalog.content && typeof processedCatalog.content === 'string') {
      console.log('🔄 Processing content field...');
      const originalLength = processedCatalog.content.length;
      processedCatalog.content = this.replaceVariablesInText(
        processedCatalog.content, 
        childItems
      );
      const newLength = processedCatalog.content.length;
      console.log(`📏 Content length: ${originalLength} -> ${newLength}`);
    }

    // Process contentHTML field (separate from content to prevent duplication)
    if (processedCatalog.contentHTML && typeof processedCatalog.contentHTML === 'string') {
      console.log('🔄 Processing contentHTML field...');
      const originalLength = processedCatalog.contentHTML.length;
      processedCatalog.contentHTML = this.replaceVariablesInText(
        processedCatalog.contentHTML, 
        childItems
      );
      const newLength = processedCatalog.contentHTML.length;
      console.log(`📏 ContentHTML length: ${originalLength} -> ${newLength}`);
    }
    
    // Process description field
    if (processedCatalog.description && typeof processedCatalog.description === 'string') {
      console.log('🔄 Processing description field...');
      processedCatalog.description = this.replaceVariablesInText(
        processedCatalog.description, 
        childItems
      );
    }
    
    // Process summary field
    if (processedCatalog.summary && typeof processedCatalog.summary === 'string') {
      console.log('🔄 Processing summary field...');
      processedCatalog.summary = this.replaceVariablesInText(
        processedCatalog.summary, 
        childItems
      );
    }

    // Process title field (in case it also contains variables)
    if (processedCatalog.title && typeof processedCatalog.title === 'string') {
      console.log('🔄 Processing title field...');
      processedCatalog.title = this.replaceVariablesInText(
        processedCatalog.title, 
        childItems
      );
    }

    // Process custom fields that might contain variables
    if (processedCatalog.custom) {
      console.log('🔄 Processing custom fields...');
      processedCatalog.custom = this.replaceVariablesInCustomFields(
        processedCatalog.custom, 
        childItems
      );
    }

    console.log('✅ Content variable replacement completed safely');
    return processedCatalog;
  }

  /**
   * Fetch complete catalog items with ALL attributes for given catalog IDs
   */
  private fetchCompleteChildItems(catalogIds: string[]): Observable<Catalog[]> {
    console.log('📡 Fetching complete child items for IDs:', catalogIds);
    
    if (!catalogIds || catalogIds.length === 0) {
      return of([]);
    }

    const childRequests = catalogIds.map(catalogId => 
      this.get<Catalog>(`/catalog/${catalogId}`).pipe(
        map(item => {
          console.log(`📦 Fetched complete item ${catalogId}:`, {
            id: item.id,
            title: item.title,
            hasContent: !!item.content,
            hasDescription: !!item.description,
            hasAllAttributes: Object.keys(item).length
          });
          return item;
        }),
        catchError(error => {
          console.warn(`Failed to fetch child catalog item with ID ${catalogId}:`, error);
          return of(null);
        })
      )
    );

    return forkJoin(childRequests).pipe(
      map(childItems => {
        // Filter out null items (failed requests) and maintain array order
        const validChildItems = childItems.filter(item => item !== null) as Catalog[];
        console.log('📦 Valid complete child items:', validChildItems.map(item => ({
          id: item.id,
          title: item.title,
          attributeCount: Object.keys(item).length
        })));
        return validChildItems;
      })
    );
  }

  /**
   * Replace variables in text content with child catalog item data
   * Supports patterns like @catalog[0].title, @catalog[1].description, @catalog[1].content, etc.
   * Now handles ALL attributes fetched from child catalog items
   */
  private replaceVariablesInText(text: string, childItems: Catalog[]): string {
    console.log('🔄 replaceVariablesInText called with:', { 
      text: text?.substring(0, 200) + (text?.length > 200 ? '...' : ''), 
      childItemsCount: childItems.length 
    });
    
    if (!text || childItems.length === 0) {
      console.log('⚠️ Early return: no text or no child items');
      return text;
    }

    // Enhanced regex pattern to match @catalog\[(\d+)\]\.(\w+(?:\.\w+)*)
    // This supports nested properties like @catalog[0].custom.fieldName
    const variablePattern = /@catalog\[(\d+)\]\.(\w+(?:\.\w+)*)/g;
    
    console.log('🔍 Looking for pattern matches in text...');
    const matches = [...text.matchAll(variablePattern)];
    console.log('📝 Found matches:', matches.map(m => m[0]));
    
    return text.replace(variablePattern, (match, indexStr, property) => {
      const index = parseInt(indexStr, 10) - 1;
      console.log(`🎯 Processing variable: ${match} (index: ${index}, property: ${property})`);
      
      // Check if index is valid
      if (index < 0 || index >= childItems.length) {
        console.warn(`Invalid catalog index ${index} in variable ${match}. Available indexes: 0-${childItems.length - 1}`);
        console.log('📦 Available child items:', childItems.map((item, i) => ({ 
          index: i, 
          id: item.id, 
          title: item.title,
          availableProperties: Object.keys(item)
        })));
        return match; // Return original text if index is invalid
      }

      const childItem = childItems[index];
      console.log(`📦 Child item at index ${index}:`, { 
        id: childItem.id, 
        title: childItem.title,
        hasContent: !!childItem.content,
        hasDescription: !!childItem.description,
        allProperties: Object.keys(childItem)
      });
      
      // Get the property value from the child item (supports nested properties)
      const propertyValue = this.getPropertyValue(childItem, property);
      console.log(`🎯 Property '${property}' value:`, propertyValue);
      
      if (propertyValue !== undefined && propertyValue !== null) {
        const result = String(propertyValue);
        console.log(`✅ Replacing ${match} with: ${result.substring(0, 100)}${result.length > 100 ? '...' : ''}`);
        return result;
      } else {
        console.warn(`Property '${property}' not found in catalog item at index ${index}`);
        console.log('📦 Available properties:', Object.keys(childItem));
        return match; // Return original text if property not found
      }
    });
  }

  /**
   * Replace variables in custom fields (recursive for nested objects)
   */
  private replaceVariablesInCustomFields(customFields: Record<string, any>, childItems: Catalog[]): Record<string, any> {
    const processedCustom = { ...customFields };
    
    for (const [key, value] of Object.entries(processedCustom)) {
      if (typeof value === 'string') {
        processedCustom[key] = this.replaceVariablesInText(value, childItems);
      } else if (typeof value === 'object' && value !== null && !Array.isArray(value)) {
        // Recursively process nested objects
        processedCustom[key] = this.replaceVariablesInCustomFields(value, childItems);
      } else if (Array.isArray(value)) {
        // Process arrays that might contain strings
        processedCustom[key] = value.map(item => 
          typeof item === 'string' ? this.replaceVariablesInText(item, childItems) : item
        );
      }
    }
    
    return processedCustom;
  }

  /**
   * Get property value from catalog item, supporting ALL attributes and nested properties
   * Enhanced to handle any property that exists on the fetched catalog item
   */
  private getPropertyValue(catalog: Catalog, property: string): any {
    console.log(`🔍 Getting property '${property}' from catalog:`, catalog.id);
    
    // Handle nested properties (e.g., 'custom.user.name', 'metadata.author.email')
    if (property.includes('.')) {
      return this.getNestedProperty(catalog, property);
    }
    
    // Handle direct properties - check if property exists directly on catalog object
    if (catalog.hasOwnProperty(property)) {
      const value = (catalog as any)[property];
      console.log(`✅ Found direct property '${property}':`, value);
      return value;
    }

    // Handle special cases for array/object formatting
    if (property === 'tags' && catalog.tags) {
      return Array.isArray(catalog.tags) ? catalog.tags.join(', ') : catalog.tags;
    }

    // Handle custom properties with 'custom.' prefix
    if (property.startsWith('custom.') && catalog.custom) {
      const customProperty = property.substring(7); // Remove 'custom.' prefix
      return this.getNestedProperty(catalog.custom, customProperty);
    }

    // Handle custom field directly if property matches a custom field key
    if (catalog.custom && catalog.custom.hasOwnProperty(property)) {
      return catalog.custom[property];
    }

    // Handle date formatting
    if (property.endsWith('_date') || property.endsWith('_at')) {
      const dateValue = (catalog as any)[property];
      if (dateValue) {
        try {
          return new Date(dateValue).toLocaleDateString();
        } catch (e) {
          return dateValue;
        }
      }
    }

    // Handle boolean properties
    if (typeof (catalog as any)[property] === 'boolean') {
      return (catalog as any)[property] ? 'Yes' : 'No';
    }

    // Handle array properties
    if (Array.isArray((catalog as any)[property])) {
      const arrayValue = (catalog as any)[property];
      return arrayValue.length > 0 ? arrayValue.join(', ') : '';
    }

    // Handle object properties (convert to JSON string for display)
    if (typeof (catalog as any)[property] === 'object' && (catalog as any)[property] !== null) {
      try {
        return JSON.stringify((catalog as any)[property]);
      } catch (e) {
        return String((catalog as any)[property]);
      }
    }

    console.warn(`Property '${property}' not found in catalog item`);
    console.log('Available properties:', Object.keys(catalog));
    return undefined;
  }

  /**
   * Get nested property value using dot notation (e.g., 'custom.user.name', 'metadata.author.email')
   * Enhanced to handle any level of nesting
   */
  private getNestedProperty(obj: any, path: string): any {
    console.log(`🔍 Getting nested property '${path}' from object`);
    
    if (!obj || !path) {
      return undefined;
    }
    
    const result = path.split('.').reduce((current, key) => {
      if (current === null || current === undefined) {
        return undefined;
      }
      
      const value = current[key];
      console.log(`  -> Accessing '${key}':`, value);
      return value;
    }, obj);
    
    console.log(`✅ Nested property '${path}' result:`, result);
    return result;
  }

  /**
   * Fetch multiple catalog items by IDs
   */
  private fetchCatalogItemsByIds(ids: string[]): Observable<Catalog[]> {
    if (!ids || ids.length === 0) {
      return of([]);
    }

    const requests = ids.map(id => 
      this.get<Catalog>(`/catalog/${id}`).pipe(
        catchError(error => {
          console.warn(`Failed to fetch catalog item ${id}:`, error);
          return of(null);
        })
      )
    );

    return forkJoin(requests).pipe(
      map(items => items.filter(item => item !== null) as Catalog[])
    );
  }

  /**
   * Create new catalog item
   */
  createCatalogItem(item: CatalogCreate): Observable<Catalog> {
    return this.post<Catalog>('/catalog/', item).pipe(
      map(result => {
        this.cacheService.triggerRefresh();
        return result;
      })
    );
  }

  /**
   * Create new catalog item (alias for backward compatibility)
   */
  createArticle(item: CatalogCreate): Observable<Catalog> {
    return this.createCatalogItem(item);
  }

  /**
   * Update catalog item
   */
  updateCatalogItem(id: string, item: CatalogUpdate): Observable<Catalog> {
    return this.put<Catalog>(`/catalog/${id}`, item).pipe(
      map(result => {
        this.cacheService.triggerRefresh();
        return result;
      })
    );
  }

  /**
   * Delete catalog item
   */
  deleteCatalogItem(id: string): Observable<void> {
    return this.delete<void>(`/catalog/${id}`).pipe(
      map(result => {
        this.cacheService.triggerRefresh();
        return result;
      })
    );
  }

  // Catalog Actions

  /**
   * Like catalog item
   */
  likeCatalogItem(id: string): Observable<Catalog> {
    return this.post<Catalog>(`/catalog/${id}/like`, {});
  }

  /**
   * Mark catalog item as used
   */
  useCatalogItem(id: string): Observable<Catalog> {
    return this.post<Catalog>(`/catalog/${id}/use`, {});
  }

  /**
   * Approve catalog item (admin only)
   */
  approveCatalogItem(id: string): Observable<Catalog> {
    return this.patch<Catalog>(`/catalog/${id}/approve`, {});
  }

  /**
   * Request approval for catalog item
   */
  requestApprovalForItem(id: string): Observable<Catalog> {
    return this.patch<Catalog>(`/catalog/${id}/request_approval`, {});
  }

  cancelApprovalRequest(id: string): Observable<Catalog> {
    return this.patch<Catalog>(`/catalog/${id}/draft`, {});
  }

  reviseContent(id: string): Observable<Catalog> {
    return this.patch<Catalog>(`/catalog/${id}/revise`, {});
  }
  /**
   * Review catalog item (admin only)
   */
  reviewCatalogItem(id: string, status: string): Observable<Catalog> {
    return this.patch<Catalog>(`/catalog/${id}/review`, { status });
  }

  /**
   * Request review for catalog item - sets status to pending-review and approved_by to manager ID
   */
  requestReviewForItem(id: string): Observable<Catalog> {
    return this.patch<Catalog>(`/catalog/${id}/request-approval`, {}).pipe(
      map(result => {
        this.cacheService.triggerRefresh();
        return result;
      })
    );
  }

  // Specialized Queries

  /**
   * Get catalogs by type
   */
  getCatalogsByType(type: string, params?: Omit<CatalogQueryParams, 'type'>): Observable<Catalog[]> {
    const sortedParams = this.addSortParams(params);
    return this.get<Catalog[]>(`/catalog/by-type/${type}`, sortedParams);
  }

  /**
   * Get catalogs by status
   */
  getCatalogsByStatus(status: string, params?: Omit<CatalogQueryParams, 'status'>): Observable<Catalog[]> {
    const sortedParams = this.addSortParams(params);
    return this.get<Catalog[]>(`/catalog/by-status/${status}`, sortedParams);
  }

  // Content Type Shortcuts

  /**
   * Get news items (shortcut for news type catalog items)
   */
  getNews(params?: Pick<CatalogQueryParams, 'page' | 'page_size' | 'query'>): Observable<CatalogResponse> {
    return this.getCatalogItems({ 
      type: 'news', 
      status: 'published',
      ...params 
    });
  }

  /**
   * Get notifications (shortcut for notification type catalog items)
   */
  getNotifications(params?: Pick<CatalogQueryParams, 'page' | 'page_size' | 'limit'>): Observable<Catalog[]> {
    return this.getCatalogItems({ 
      type: 'notifications', 
      status: 'published',
      page_size: params?.limit || 10,
      ...params 
    }).pipe(
      map(response => response.items || [])
    );
  }

  /**
   * Get documents (shortcut for document type catalog items)
   */
  getDocuments(params?: Pick<CatalogQueryParams, 'page' | 'page_size' | 'query'>): Observable<CatalogResponse> {
    return this.getCatalogItems({ 
      type: 'document', 
      status: 'published',
      ...params 
    });
  }

  /**
   * Get recent notifications with limit
   */
  getRecentNotifications(limit: number = 5): Observable<Catalog[]> {
    return this.getNotifications({ limit }).pipe(
      map(notifications => {
        this.notificationsSubject.next(notifications);
        return notifications;
      })
    );
  }

  /**
   * Get recent news with limit
   */
  getRecentNews(limit: number = 6): Observable<Catalog[]> {
    return this.getCatalogItems({ 
      type: 'news', 
      status: 'published',
      limit 
    }).pipe(
      map(response => {
        const news = response.items || [];
        this.newsSubject.next(news);
        return news;
      })
    );
  }

  // Utility Methods

  /**
   * Check if there are unread news items
   */
  hasUnreadNews(): Observable<boolean> {
    return this.getCatalogItems({ 
      type: 'news', 
      status: 'published',
      limit: 1 
    }).pipe(
      map(response => (response.items || []).length > 0)
    );
  }

  /**
   * Mark news as read (placeholder implementation)
   */
  markNewsAsRead(): Observable<any> {
    return new Observable(observer => {
      observer.next({ success: true });
      observer.complete();
    });
  }

  /**
   * Get available catalog types for filter dropdown
   */
  getCatalogTypes(): Observable<string[]> {
    return new Observable<string[]>(observer => {
      this.authService.currentUser$.subscribe(currentUser => {
        if (currentUser) {
          const userRole = currentUser.role;
          const allowedTypes = filterCatalogTypesByRole(userRole);
          const typeValues = allowedTypes.map(type => type.value).sort();
          
          observer.next(typeValues);
          observer.complete();
        } else {
          observer.next([]);
          observer.complete();
        }
      });
    });
  }

  /**
   * Get available catalog types with full metadata based on user role
   */
  getCatalogTypesWithMetadata() {
    return new Observable(observer => {
      this.authService.currentUser$.subscribe(currentUser => {
        if (currentUser) {
          const userRole = currentUser.role;
          const allowedTypes = filterCatalogTypesByRole(userRole);
          
          observer.next(allowedTypes);
          observer.complete();
        } else {
          observer.next([]);
          observer.complete();
        }
      });
    });
  }

  /**
   * Get authors for filter dropdown
   */
  getAuthors(): Observable<string[]> {
    return this.getCatalogItems({ limit: 100 }).pipe(
      map(response => {
        const authors = response.items
          .map(item => item.author)
          .filter((author, index, self) => author && self.indexOf(author) === index) as string[];
        return authors.sort();
      })
    );
  }

  // Legacy/Placeholder Methods

  /**
   * Increment view count for a catalog item
   */
  incrementViewCount(id: string): Observable<any> {
    return new Observable(observer => {
      observer.next({ success: true, message: 'View count incremented' });
      observer.complete();
    });
  }

  /**
   * Toggle like status for a catalog item
   */
  toggleLike(id: string, action: string): Observable<any> {
    if (action === 'like') {
      return this.likeCatalogItem(id);
    } else {
      return new Observable(observer => {
        observer.next({ success: true, message: 'Item unliked' });
        observer.complete();
      });
    }
  }

  // Sharing Functionality

  /**
   * Share catalog item with users
   */
  shareCatalogItem(catalogId: string, userIds: string[], message?: string): Observable<any> {
    const payload = {
      user_ids: userIds,
      message: message
    };
    
    console.log('📤 Sharing catalog item:', { catalogId, payload });
    
    return this.post<any>(`/catalog/${catalogId}/share`, payload).pipe(
      map((response: any) => {
        console.log('✅ Share catalog API response:', response);
        return response;
      })
    );
  }

  /**
   * Update catalog sharing information
   */
  updateCatalogSharing(catalogId: string, sharedUsers: any[]): Observable<any> {
    const payload = {
      shared_with: sharedUsers.map(user => user.id || user.user_id || user)
    };
    
    console.log('📤 Updating catalog sharing:', { catalogId, payload });
    
    return this.put<any>(`/catalog/${catalogId}`, payload).pipe(
      map((response: any) => {
        console.log('✅ Update catalog sharing API response:', response);
        return response;
      })
    );
  }

  // Custom Attributes

  /**
   * Get custom attributes for a catalog item
   */
  getCustomAttributes(catalogId: string): Observable<any> {
    console.log('🔍 Getting custom attributes for catalog:', catalogId);
    
    return this.getCatalogItem(catalogId).pipe(
      map((catalog: Catalog) => {
        console.log('✅ Catalog item loaded, extracting custom attributes:', catalog.custom);
        return catalog.custom || {};
      })
    );
  }

  /**
   * Update custom attributes for a catalog item
   */
  updateCustomAttributes(catalogId: string, customData: any): Observable<any> {
    console.log('📤 Updating custom attributes for catalog:', { catalogId, customData });
    
    const updatePayload = {
      custom: customData
    };
    
    return this.put<any>(`/catalog/${catalogId}`, updatePayload).pipe(
      map((response: any) => {
        console.log('✅ Update custom attributes API response:', response);
        return response;
      })
    );
  }

  // Conversation Methods (delegated to ConversationService)

  /**
   * Get conversations for a catalog item
   */
  getCatalogConversations(catalogId: string) {
    return this.conversationService.getCatalogConversations(catalogId);
  }

  /**
   * Add a message to catalog conversations
   */
  addConversationMessage(catalogId: string, message: string, parentId?: string) {
    return this.conversationService.addConversationMessage(catalogId, message, parentId);
  }

  /**
   * Update a conversation message
   */
  updateConversationMessage(catalogId: string, messageId: string, message: string) {
    return this.conversationService.updateConversationMessage(catalogId, messageId, message);
  }

  /**
   * Delete a conversation message
   */
  deleteConversationMessage(catalogId: string, messageId: string) {
    return this.conversationService.deleteConversationMessage(catalogId, messageId);
  }

  /**
   * Like a conversation message
   */
  likeConversationMessage(catalogId: string, messageId: string) {
    return this.conversationService.likeConversationMessage(catalogId, messageId);
  }

  // Cache Management

  /**
   * Start polling for catalog updates
   */
  startPollingForUpdates(intervalMs?: number): void {
    this.cacheService.startPollingForUpdates(intervalMs);
  }

  /**
   * Stop polling for catalog updates
   */
  stopPollingForUpdates(): void {
    this.cacheService.stopPollingForUpdates();
  }

  /**
   * Manually trigger a refresh of catalog data
   */
  triggerRefresh(): void {
    this.cacheService.triggerRefresh();
  }

  // New Team Shares and Approval Queue Endpoints

  /**
   * Get team shares items using the new dedicated endpoint
   */
  getTeamShares(params?: CatalogQueryParams): Observable<CatalogResponse> {
    const useCache = params?.useCache !== false;
    const apiParams = { ...params };
    delete apiParams.useCache;
    
    const sortedParams = this.addSortParams(apiParams);
    const cacheKey = this.cacheService.createKey('catalog-teamshares', sortedParams);
    
    if (useCache) {
      const cached = this.cacheService.get<CatalogResponse>(cacheKey);
      if (cached && (!params?.page || params.page > 1)) {
        return new Observable(observer => {
          observer.next(cached);
          observer.complete();
        });
      }
    }

    console.log('🔍 getTeamShares - sending params:', sortedParams);

    return this.get<any>('/catalog/cataloglist/teamshares', sortedParams).pipe(
      map(response => {
        console.log('✅ Team shares response:', response);
        
        // Handle both array and object response formats
        let catalogResponse: CatalogResponse;
        if (Array.isArray(response)) {
          // If response is an array, wrap it in CatalogResponse format
          catalogResponse = {
            items: response,
            total: response.length,
            page: params?.page || 1,
            page_size: params?.page_size || 12,
            total_pages: 1,
            limit: params?.limit || params?.page_size || 12,
            offset: ((params?.page || 1) - 1) * (params?.page_size || 12)
          };
        } else {
          // If response is already in CatalogResponse format
          catalogResponse = response;
        }
        
        this.cacheService.set(cacheKey, catalogResponse);
        console.log('🔍 [FIXED] Normalized team shares response:', catalogResponse);
        return catalogResponse;
      }),
      catchError(error => {
        console.error('Error fetching team shares:', error);
        return of({
          items: [],
          total: 0,
          page: 1,
          total_pages: 1,
          page_size: params?.page_size || 12,
          limit: params?.limit || params?.page_size || 12,
          offset: ((params?.page || 1) - 1) * (params?.page_size || 12)
        });
      })
    );
  }

  /**
   * Get approval queue items using the new dedicated endpoint
   */
  getApprovalQueue(params?: CatalogQueryParams): Observable<CatalogResponse> {
    const useCache = params?.useCache !== false;
    const apiParams = { ...params };
    delete apiParams.useCache;
    
    const sortedParams = this.addSortParams(apiParams);
    const cacheKey = this.cacheService.createKey('catalog-approvals', sortedParams);
    
    if (useCache) {
      const cached = this.cacheService.get<CatalogResponse>(cacheKey);
      if (cached && (!params?.page || params.page > 1)) {
        return new Observable(observer => {
          observer.next(cached);
          observer.complete();
        });
      }
    }

    console.log('🔍 getApprovalQueue - sending params:', sortedParams);

    return this.get<any>('/catalog/cataloglist/approvals', sortedParams).pipe(
      map(response => {
        console.log('✅ Approval queue response:', response);
        
        // Handle both array and object response formats
        let catalogResponse: CatalogResponse;
        if (Array.isArray(response)) {
          // If response is an array, wrap it in CatalogResponse format
          catalogResponse = {
            items: response,
            total: response.length,
            page: params?.page || 1,
            page_size: params?.page_size || 12,
            total_pages: 1,
            limit: params?.limit || params?.page_size || 12,
            offset: ((params?.page || 1) - 1) * (params?.page_size || 12)
          };
        } else {
          // If response is already in CatalogResponse format
          catalogResponse = response;
        }
        
        this.cacheService.set(cacheKey, catalogResponse);
        console.log('🔍 [FIXED] Normalized approval queue response:', catalogResponse);
        return catalogResponse;
      }),
      catchError(error => {
        console.error('Error fetching approval queue:', error);
        return of({
          items: [],
          total: 0,
          page: 1,
          total_pages: 1,
          page_size: params?.page_size || 12,
          limit: params?.limit || params?.page_size || 12,
          offset: ((params?.page || 1) - 1) * (params?.page_size || 12)
        });
      })
    );
  }

  /**
   * Get team shares stats
   */
  getTeamSharesStats(): Observable<{
    total: number;
    unread: number;
    categories: { [key: string]: number };
  }> {
    return this.getTeamShares({
      page_size: 100,
      useCache: false
    }).pipe(
      map(response => {
        const items = response.items || [];
        const stats = {
          total: response.total || items.length,
          unread: items.filter(item => !item.custom?.['is_read']).length,
          categories: {} as { [key: string]: number }
        };
        items.forEach(item => {
          const category = item.category || 'Uncategorized';
          stats.categories[category] = (stats.categories[category] || 0) + 1;
        });
        return stats;
      }),
      catchError(error => {
        console.warn('Error getting team shares stats:', error);
        return of({
          total: 0,
          unread: 0,
          categories: {}
        });
      })
    );
  }

  /**
   * Get approval queue stats
   */
  getApprovalQueueStats(): Observable<{
    total: number;
    pending: number;
    categories: { [key: string]: number };
  }> {
    return this.getApprovalQueue({
      page_size: 100,
      useCache: false
    }).pipe(
      map(response => {
        const items = response.items || [];
        const stats = {
          total: response.total || items.length,
          pending: items.filter(item => 
            item.status === 'pending-review' || 
            item.status === 'pending-approval'
          ).length,
          categories: {} as { [key: string]: number }
        };
        items.forEach(item => {
          const category = item.category || 'Uncategorized';
          stats.categories[category] = (stats.categories[category] || 0) + 1;
        });
        return stats;
      }),
      catchError(error => {
        console.warn('Error getting approval queue stats:', error);
        return of({
          total: 0,
          pending: 0,
          categories: {}
        });
      })
    );
  }
}
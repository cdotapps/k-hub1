export const environment = {
  production: false,
  siteUrl: 'http://localhost:4200',
  apiUrl: 'http://localhost:8000',
  apiVersion: '/api/v1',
  enableWebSockets: false,  // Disable WebSockets by default in dev until server is ready
  wsUrl: 'ws://localhost:8000',  // Proper WebSocket protocol
  wsEndpoint: '/api/v1/webhooks'  // WebSocket endpoint path
};
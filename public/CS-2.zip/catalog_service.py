from sqlalchemy import create_engine, Column, String, Text, Integer, JSON, Boolean
from sqlalchemy.orm import sessionmaker, declarative_base
import uuid
import requests
import json
import random
import time
import pandas as pd
import os
from datetime import datetime
import ast

Base = declarative_base()
sleep=5  # Sleep time in milliseconds

class Catalog(Base):
    __tablename__ = "catalogs"

    id = Column(String, primary_key=True, index=True, default=lambda: str(uuid.uuid4()))
    title = Column(String, nullable=True, index=True)  # Changed to nullable=True to match CatalogBase
    description = Column(Text, nullable=True)
    summary = Column(String, nullable=True, index=True)
    type = Column(String, nullable=True, index=True)  # Changed to nullable=True to match CatalogBase
    content = Column(Text, nullable=True)
    url = Column(String, nullable=True)
    image = Column(String, nullable=True)
    imageUrl = Column(String, nullable=True)
    display = Column(String, nullable=True)
    tags = Column(JSON, nullable=True)
    author = Column(String, nullable=True, index=True)
    created_date = Column(String, nullable=True)
    updated_date = Column(String, nullable=True)
    expire_date = Column(String, nullable=True)
    due_date = Column(String, nullable=True)
    custom = Column(JSON, nullable=True)
    category = Column(String, nullable=True, index=True)
    parent_id = Column(String, nullable=True, index=True)
    likes = Column(Integer, default=0, nullable=False)
    usages = Column(Integer, default=0, nullable=False)
    favorites = Column(Integer, default=0, nullable=False)
    views = Column(Integer, default=0, nullable=False)
    shares = Column(Integer, default=0, nullable=False)
    approved_by = Column(String, nullable=True, index=True)
    reviewed_by = Column(String, nullable=True, index=True)
    source = Column(String, nullable=True, index=True)
    status = Column(String, nullable=False, default="draft", index=True)
    private = Column(Boolean, default=True, nullable=False)
    shared_with = Column(JSON, nullable=True)
    conversations = Column(JSON, nullable=True)
    author_id = Column(String, nullable=True, index=True)  # Added author_id field

def post_catalog_item(data, headers):
    url = "http://localhost:8000/api/v1/catalog/"
    response = requests.post(url, json=data, headers=headers)
    try:
        response_json = response.json()
    except Exception:
        response_json = response.text
    if response.status_code != 200:
        print(f"API error {response.status_code}: {response_json}")
    return response_json

def authenticate():
    url = "http://localhost:8000/api/v1/auth/login"
    headers = {
        "accept": "application/json",
        "Content-Type": "application/json"
    }
    user_ids = ["suresh"]  # List of user IDs
    selected_user_id = random.choice(user_ids)  # Randomly select a user ID
    data = {
        "user_id": selected_user_id,
        "password": f"{selected_user_id}_123"  # Dynamically generate password based on user_id
    }

    response = requests.post(url, json=data, headers=headers)
    if response.status_code == 200:
        return response.json().get("access_token")
    else:
        raise Exception("Authentication failed: " + response.text)

def load_posted_items(file_path):
    if os.path.exists(file_path):
        with open(file_path, 'r') as file:
            return set(json.load(file))
    return set()

def save_posted_items(file_path, posted_items):
    with open(file_path, 'w') as file:
        json.dump(list(posted_items), file)

def post_items_from_excel(file_path, headers, posted_file):
    df = pd.read_excel(file_path)
    posted_items = load_posted_items(posted_file)

    # Ensure 'id' column exists and fill missing ids with UUIDs
    if "id" not in df.columns:
        df["id"] = [str(uuid.uuid4()) for _ in range(len(df))]
    else:
        df["id"] = df["id"].apply(lambda x: str(uuid.uuid4()) if pd.isna(x) or not x else x)

    # Filter unposted items
    unposted_items = df[~df["id"].isin(posted_items)]

    if unposted_items.empty:
        print("No new items to post.")
        return

    # Select one random item
    random_item = unposted_items.sample(n=1).iloc[0]
    item = random_item.to_dict()

    # Replace NaN values with None
    item = {key: (None if pd.isna(value) else value) for key, value in item.items()}

    # Catalog model fields (snake_case)
    valid_columns = {
        'id', 'title', 'description', 'summary', 'type', 'content', 'url', 'image', 'imageurl', 'display', 'tags',
        'author', 'created_date', 'updated_date', 'expire_date', 'due_date', 'custom', 'category', 'parent_id',
        'child_ids', 'priority', 'severity', 'urgent', 'important', 'likes', 'usages', 'favorites', 'views', 'shares',
        'owner_id', 'author_id', 'approved_by', 'reviewed_by', 'source', 'status', 'private', 'shared_with', 'conversations'
    }

    # Mapping from catalog attributes to Excel columns (can be a list for concatenation)

    catalog_type = file_path.replace(".xlsx", "").lower() 
    if catalog_type == "assets":
        valid_attributes = {
            'title': ['Asset ID', '-', 'title'],  # Concatenate 'Name' and 'Subject' columns for title
            'description': 'Details',      # Map 'Details' column to description
            'summary': 'Summary',
            'type': 'Type',
            'content': 'Content',
            'url': 'URL',
            'image': 'Image',
            'imageUrl': 'Image URL',
            'display': 'Display',
            'tags': ['Tags'],
            'author': ['Author Name'],
            # Add more mappings as needed
        }
    else:
        # Default mapping for other catalog types
        valid_attributes = {
        }


    import re
    def to_snake_case(name):
        s1 = re.sub(r'(.)([A-Z][a-z]+)', r'\1_\2', name)
        s2 = re.sub(r'([a-z0-9])([A-Z])', r'\1_\2', s1)
        s3 = s2.replace(" ", "_").replace("-", "_").lower()
        s4 = re.sub(r'_+', '_', s3)  # Replace multiple underscores with one
        return s4.strip('_')

    new_item = {}
    custom_default = []
    # First, use valid_attributes mapping if present
    for attr, excel_cols in valid_attributes.items():
        if isinstance(excel_cols, list):
            values = []
            for col in excel_cols:
                if col in item and item.get(col) is not None:
                    values.append(str(item.get(col)))
                elif col not in item:
                    # Treat as literal if not a column
                    values.append(str(col))
            if values:
                new_item[attr] = ' '.join(values).strip()
        else:
            val = item.get(excel_cols)
            if val is not None:
                new_item[attr] = val
    # Then, process remaining columns as before
    for key, value in list(item.items()):
        snake_key = to_snake_case(key)
        if snake_key in valid_columns and snake_key not in new_item:
            new_item[snake_key] = value
        elif snake_key not in new_item:
            custom_default.append({
                "column": snake_key,
                "value": value,
                "type": "text",
                "description": key
            })
    if custom_default:
        new_item["custom"] = {"default": custom_default}
    else:
        new_item["custom"] = {}
    item = new_item

    c_type = file_path.replace(".xlsx", "")
    # Fill required fields if missing
    if not item.get('title'):
        # Use first custom field as fallback
        if item["custom"].get("default"):
            item['title'] = item["custom"]["default"][0]["value"]
    if not item.get('description'):
        if item["custom"].get("default"):
            item['description'] = item["custom"]["default"][1]["value"]
    if not item.get('content'):
        if item["custom"].get("default"):
            item['content'] = item["custom"]["default"][2]["value"]
    if not item.get('type'):
        item['type'] = c_type
    if not item.get('status'):
        item['status'] = 'draft'
    if not item.get('priority'):
        item['priority'] = 'low'
    if not item.get('severity'):
        item['severity'] = 'low'
    if item.get('urgent') is None:
        item['urgent'] = False
    if item.get('important') is None:
        item['important'] = False
    if item.get('private') is None:
        item['private'] = True
    for field in ['child_ids', 'shared_with', 'conversations', 'tags']:
        if not item.get(field):
            item[field] = []
    for field in ['likes', 'usages', 'favorites', 'views', 'shares']:
        if not item.get(field):
            item[field] = 0

    # Remove 'id' from the payload before posting
    post_id = item["id"]
    item_to_post = item.copy()
    item_to_post.pop("id", None)
    # Remove created_date and updated_date before posting
    item_to_post.pop('created_date', None)
    item_to_post.pop('updated_date', None)

    # Convert all datetime objects to ISO strings before posting
    def convert_datetime(obj):
        if isinstance(obj, dict):
            return {k: convert_datetime(v) for k, v in obj.items()}
        elif isinstance(obj, list):
            return [convert_datetime(v) for v in obj]
        elif isinstance(obj, datetime):
            return obj.isoformat()
        else:
            return obj
    item_to_post = convert_datetime(item_to_post)

    # Parse tags, shared_with, and conversations fields from string to list using ast.literal_eval
    for field in ['tags', 'shared_with', 'conversations']:
        val = item_to_post.get(field)
        if isinstance(val, str):
            try:
                item_to_post[field] = ast.literal_eval(val)
                if not isinstance(item_to_post[field], list):
                    item_to_post[field] = []
            except Exception:
                item_to_post[field] = []
        elif not isinstance(val, list):
            item_to_post[field] = []

    response = post_catalog_item(item_to_post, headers)

    posted_items.add(post_id)
    save_posted_items(posted_file, posted_items)

    print(f"Posted item: {post_id}, Response: {response}")

def run_service():
    file_path = "assets.xlsx"
    file_path = "catalog_data.xlsx"
    posted_file = "posted_items.json"

    while True:
        try:
            print("Authenticating...")
            access_token = authenticate()
            headers = {
                "accept": "application/json",
                "Content-Type": "application/json",
                "Authorization": f"Bearer {access_token}"
            }

            post_items_from_excel(file_path, headers, posted_file)
            print("Next article will be posted in "+ str(sleep/60) +" minutes.")
        except Exception as e:
            print(f"Error occurred: {e}")

        time.sleep(sleep)  # Wait for 3 minutes
if __name__ == "__main__":
    run_service()
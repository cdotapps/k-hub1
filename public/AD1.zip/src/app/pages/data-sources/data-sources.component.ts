import { Component } from '@angular/core';

@Component({
  selector: 'app-data-sources',
  templateUrl: './data-sources.component.html',
  styleUrls: ['./data-sources.component.css']
})
export class DataSourcesComponent {
  dataSources = [
    {
      category: 'Databases',
      sources: [
        { name: 'PostgreSQL', icon: 'M4 7v10c0 2.21 3.582 4 8 4s8-1.79 8-4V7' },
        { name: 'MySQL', icon: 'M4 7v10c0 2.21 3.582 4 8 4s8-1.79 8-4V7' },
        { name: 'MongoDB', icon: 'M4 7v10c0 2.21 3.582 4 8 4s8-1.79 8-4V7' },
        { name: 'Snowflake', icon: 'M4 7v10c0 2.21 3.582 4 8 4s8-1.79 8-4V7' }
      ]
    },
    {
      category: 'Cloud Storage',
      sources: [
        { name: 'AWS S3', icon: 'M3 15v4c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2v-4M17 9l-5 5-5-5M12 12.8V2.5' },
        { name: 'Google Cloud', icon: 'M3 15v4c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2v-4M17 9l-5 5-5-5M12 12.8V2.5' },
        { name: 'Azure Blob', icon: 'M3 15v4c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2v-4M17 9l-5 5-5-5M12 12.8V2.5' }
      ]
    },
    {
      category: 'Business Tools',
      sources: [
        { name: 'Salesforce', icon: 'M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z' },
        { name: 'HubSpot', icon: 'M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z' },
        { name: 'Stripe', icon: 'M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z' },
        { name: 'Shopify', icon: 'M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z' }
      ]
    },
    {
      category: 'Files & Spreadsheets',
      sources: [
        { name: 'Excel', icon: 'M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z' },
        { name: 'Google Sheets', icon: 'M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z' },
        { name: 'CSV Files', icon: 'M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z' }
      ]
    }
  ];

  constructor() {}
}
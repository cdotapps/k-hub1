import { Component, OnInit, OnDestroy } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-queries',
  templateUrl: './queries.component.html',
  styleUrls: ['./queries.component.css']
})
export class QueriesComponent implements OnInit, OnDestroy {
  queryText: string = '';
  isProcessing: boolean = false;
  showResults: boolean = false;
  processingTime: number = 0;
  timer: any;
  
  // Mock data for the results
  chainOfThoughts: string[] = [];
  widgets: any[] = [];
  showProcessingDetails: boolean = false;
  summarizedAnswer: string = '';
  
  // Feedback properties
  summaryFeedback: 'like' | 'dislike' | null = null;
  showFeedbackContext: boolean = false;
  
  constructor(private router: Router) {}

  ngOnInit() {
    // Dashboard page after login
  }

  ngOnDestroy() {
    if (this.timer) {
      clearInterval(this.timer);
    }
  }

  onSubmitQuery() {
    console.log('Submit query called with text:', this.queryText);
    
    if (this.queryText.trim()) {
      console.log('Starting processing...');
      // Reset states
      this.showResults = false;
      this.chainOfThoughts = [];
      this.widgets = [];
      
      // Start processing
      this.isProcessing = true;
      this.processingTime = 0;
      
      // Start timer
      this.timer = setInterval(() => {
        this.processingTime += 0.1;
      }, 100);
      
      // Simulate processing with chain of thoughts
      this.simulateProcessing();
    } else {
      console.log('No query text provided');
    }
  }

  onKeyDown(event: KeyboardEvent) {
    if (event.key === 'Enter' && !event.shiftKey) {
      event.preventDefault();
      this.onSubmitQuery();
    }
  }

  onFollowUpKeyDown(event: KeyboardEvent, value: string) {
    if (event.key === 'Enter' && !event.shiftKey) {
      event.preventDefault();
      if (value.trim()) {
        this.onNewQuery(value);
        // Clear the input
        const target = event.target as HTMLTextAreaElement;
        target.value = '';
      }
    }
  }

  onFollowUpInput(event: Event) {
    // Optional: Handle input changes if needed
    const target = event.target as HTMLTextAreaElement;
    // You can add any logic here for handling input changes
  }

  private simulateProcessing() {
    const thoughts = [
      'Analyzing your query...',
      'Connecting to data sources...',
      'Processing data patterns...',
      'Generating insights...',
      'Creating visualizations...',
      'Finalizing results...'
    ];
    
    this.chainOfThoughts = [];
    
    thoughts.forEach((thought, index) => {
      setTimeout(() => {
        this.chainOfThoughts.push(thought);
        
        // Complete processing after all thoughts
        if (index === thoughts.length - 1) {
          setTimeout(() => {
            this.completeProcessing();
          }, 800);
        }
      }, (index + 1) * 800);
    });
  }

  private completeProcessing() {
    clearInterval(this.timer);
    this.isProcessing = false;
    this.showResults = true;
    
    // Generate summarized answer based on query
    this.generateSummarizedAnswer();
    
    // Mock widgets data
    this.widgets = [
      {
        type: 'chart',
        title: 'Revenue Trends',
        data: { value: '$2.4M', change: '+12%' }
      },
      {
        type: 'metric',
        title: 'Customer Growth',
        data: { value: '1,234', change: '+8%' }
      },
      {
        type: 'table',
        title: 'Top Products',
        data: { rows: 5, columns: 3 }
      }
    ];
  }

  private generateSummarizedAnswer() {
    // Generate a contextual answer based on the query
    const query = this.queryText.toLowerCase();
    
    if (query.includes('revenue') || query.includes('sales')) {
      this.summarizedAnswer = `Based on the latest data analysis, your revenue has shown a positive growth trend of 12% compared to the previous quarter. The total revenue reached $2.4M, with Product A being the top performer contributing 35% of the total sales. Key growth drivers include improved marketing efficiency and customer retention strategies.`;
    } else if (query.includes('customer') || query.includes('user')) {
      this.summarizedAnswer = `Customer analysis reveals a healthy growth pattern with 1,234 new customers acquired this period, representing an 8% increase. Customer satisfaction scores have improved by 15%, and retention rates are at an all-time high of 92%. The main acquisition channels are organic search (40%) and referrals (30%).`;
    } else if (query.includes('product') || query.includes('performance')) {
      this.summarizedAnswer = `Product performance analysis shows strong market positioning across all categories. Product A leads with $120K in sales and 15% growth, followed by Product B with $95K and 8% growth. Market share has increased by 5% overall, with particularly strong performance in the enterprise segment.`;
    } else {
      this.summarizedAnswer = `Analysis complete. The data shows positive trends across key metrics with notable improvements in performance indicators. Detailed insights and visualizations are available below to help you make informed decisions. Key recommendations include focusing on high-performing segments and optimizing underperforming areas.`;
    }
  }

  toggleProcessingDetails() {
    this.showProcessingDetails = !this.showProcessingDetails;
  }

  onNewQuery(query: string) {
    this.queryText = query;
    this.onSubmitQuery();
  }

  onBackToInput() {
    this.showResults = false;
    this.isProcessing = false;
    this.chainOfThoughts = [];
    this.widgets = [];
    this.processingTime = 0;
    this.queryText = '';
    // Reset feedback when going back
    this.summaryFeedback = null;
    this.showFeedbackContext = false;
  }

  // Method to format summary text with bold numbers/percentages/amounts
  getFormattedSummary(): string {
    return this.formatNumbersInText(this.summarizedAnswer);
  }

  private formatNumbersInText(text: string): string {
    // Regular expression to match:
    // - Currency amounts (e.g., $2.4M, $120K, €1,234.56)
    // - Percentages (e.g., 12%, +8%, -5.2%)
    // - Numbers with commas (e.g., 1,234, 10,000)
    // - Decimal numbers (e.g., 15.5, 92.3)
    // - Numbers with K/M/B suffixes (e.g., 2.4M, 120K)
    const numberPattern = /(\$[0-9,]+\.?[0-9]*[KMB]?|€[0-9,]+\.?[0-9]*[KMB]?|£[0-9,]+\.?[0-9]*[KMB]?|[+\-]?[0-9,]+\.?[0-9]*%|[0-9,]+\.?[0-9]*[KMB]?(?!\w)|[0-9,]+\.?[0-9]*(?=\s|$|[^\w]))/g;
    
    return text.replace(numberPattern, '<strong>$1</strong>');
  }

  onSummaryFeedback(feedbackType: 'like' | 'dislike') {
    if (this.summaryFeedback === feedbackType) {
      // If clicking the same button, remove feedback
      this.summaryFeedback = null;
      this.showFeedbackContext = false;
    } else {
      // Set new feedback
      this.summaryFeedback = feedbackType;
      this.showFeedbackContext = true;
      
      // Auto-hide feedback context after 5 seconds
      setTimeout(() => {
        this.showFeedbackContext = false;
      }, 5000);
      
      // Log feedback for analytics (in real app, send to backend)
      console.log(`Summary feedback: ${feedbackType}`, {
        query: this.queryText,
        summary: this.summarizedAnswer,
        timestamp: new Date().toISOString()
      });
    }
  }

  closeFeedbackContext() {
    this.showFeedbackContext = false;
  }

  onGoToDashboard() {
    this.router.navigate(['/dashboard']);
  }
}
import { Component } from '@angular/core';

@Component({
  selector: 'app-design',
  templateUrl: './design.component.html',
  styleUrls: ['./design.component.css']
})
export class DesignComponent {
  designPrinciples = [
    {
      title: 'User-Centric Interface',
      description: 'Intuitive design that puts user experience at the forefront',
      icon: 'M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z',
      details: ['Natural language processing', 'Conversational AI interface', 'Context-aware responses']
    },
    {
      title: 'Intelligent Data Processing',
      description: 'Advanced algorithms that understand and process your data efficiently',
      icon: 'M9.663 17h4.673M12 3v1m6.364 1.636l-.707.707M21 12h-1M4 12H3m3.343-5.657l-.707-.707m2.828 9.9a5 5 0 117.072 0l-.548.547A3.374 3.374 0 0014 18.469V19a2 2 0 11-4 0v-.531c0-.895-.356-1.754-.988-2.386l-.548-.547z',
      details: ['Machine learning algorithms', 'Pattern recognition', 'Predictive analytics']
    },
    {
      title: 'Scalable Architecture',
      description: 'Built to handle enterprise-level data volumes and concurrent users',
      icon: 'M19 11H5m14 0a2 2 0 012 2v6a2 2 0 01-2 2H5a2 2 0 01-2-2v-6a2 2 0 012-2m14 0V9a2 2 0 00-2-2M5 11V9a2 2 0 012-2m0 0V5a2 2 0 012-2h6a2 2 0 012 2v2M7 7h10',
      details: ['Cloud-native infrastructure', 'Auto-scaling capabilities', 'High availability design']
    },
    {
      title: 'Security & Privacy',
      description: 'Enterprise-grade security with zero data retention policies',
      icon: 'M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z',
      details: ['End-to-end encryption', 'Zero data retention', 'Compliance ready']
    }
  ];

  designFlow = [
    {
      step: 1,
      title: 'Data Input',
      description: 'Connect your data sources securely'
    },
    {
      step: 2,
      title: 'Natural Language Query',
      description: 'Ask questions in plain English'
    },
    {
      step: 3,
      title: 'AI Processing',
      description: 'Our AI analyzes and interprets your request'
    },
    {
      step: 4,
      title: 'Intelligent Response',
      description: 'Get insights, charts, and actionable results'
    }
  ];

  constructor() {}
}
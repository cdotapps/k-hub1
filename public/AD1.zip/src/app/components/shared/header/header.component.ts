import { Component, Input, OnInit, OnDestroy } from '@angular/core';
import { Router } from '@angular/router';
import { AuthService } from '../../../services/auth.service';
import { Subscription } from 'rxjs';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit, OnDestroy {
  @Input() showNavigation: boolean = true;
  @Input() brandName: string = 'AskData';
  @Input() ctaText: string = 'Integrate';
  @Input() onCtaClick: () => void = () => {};

  showUserMenu = false;
  isLoggedIn = false;
  currentUser: any = null;
  
  private subscriptions = new Subscription();

  constructor(
    public authService: AuthService,
    private router: Router
  ) {}

  ngOnInit() {
    // Subscribe to authentication state changes
    this.subscriptions.add(
      this.authService.authState$.subscribe(isAuthenticated => {
        this.isLoggedIn = isAuthenticated;
      })
    );

    this.subscriptions.add(
      this.authService.currentUser$.subscribe(user => {
        this.currentUser = user;
      })
    );
  }

  ngOnDestroy() {
    this.subscriptions.unsubscribe();
  }

  toggleUserMenu() {
    this.showUserMenu = !this.showUserMenu;
  }

  onLogin() {
    this.router.navigate(['/login']);
  }

  onLogout() {
    this.authService.logout();
    this.showUserMenu = false;
    this.router.navigate(['/login']);
  }

  navigateToHome() {
    this.router.navigate(['/home']);
  }
}
import { Component, Input, Output, EventEmitter } from '@angular/core';

@Component({
  selector: 'app-button',
  templateUrl: './button.component.html',
  styleUrls: ['./button.component.css']
})
export class ButtonComponent {
  @Input() variant: 'primary' | 'secondary' | 'ghost' | 'play' = 'primary';
  @Input() size: 'sm' | 'md' | 'lg' = 'md';
  @Input() disabled: boolean = false;
  @Input() loading: boolean = false;
  @Input() fullWidth: boolean = false;
  @Input() icon: string = '';
  @Input() iconPosition: 'left' | 'right' = 'left';
  @Output() clicked = new EventEmitter<void>();

  constructor() {}

  get buttonClasses() {
    return {
      'btn': true,
      [`btn-${this.variant}`]: true,
      [`btn-${this.size}`]: true,
      'btn-disabled': this.disabled,
      'btn-loading': this.loading,
      'btn-full-width': this.fullWidth
    };
  }

  onClick() {
    if (!this.disabled && !this.loading) {
      this.clicked.emit();
    }
  }
}
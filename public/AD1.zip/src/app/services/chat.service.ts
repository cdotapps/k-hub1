import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable, of } from 'rxjs';
import { delay, map } from 'rxjs/operators';
import { ChatMessage, ChatSession, ApiResponse } from '../models';

@Injectable({
  providedIn: 'root'
})
export class ChatService {
  private chatSessionsSubject = new BehaviorSubject<ChatSession[]>([]);
  public chatSessions$ = this.chatSessionsSubject.asObservable();

  private currentSessionSubject = new BehaviorSubject<ChatSession | null>(null);
  public currentSession$ = this.currentSessionSubject.asObservable();

  private isLoadingSubject = new BehaviorSubject<boolean>(false);
  public isLoading$ = this.isLoadingSubject.asObservable();

  constructor() {
    this.loadSessions();
  }

  private loadSessions(): void {
    const stored = localStorage.getItem('chatSessions');
    if (stored) {
      try {
        const sessions = JSON.parse(stored);
        this.chatSessionsSubject.next(sessions);
      } catch (error) {
        console.error('Error loading chat sessions:', error);
      }
    }
  }

  private saveSessions(): void {
    localStorage.setItem('chatSessions', JSON.stringify(this.chatSessionsSubject.value));
  }

  createNewSession(): ChatSession {
    const newSession: ChatSession = {
      id: this.generateId(),
      title: 'New Chat',
      messages: [],
      createdAt: new Date(),
      updatedAt: new Date()
    };

    const sessions = [...this.chatSessionsSubject.value, newSession];
    this.chatSessionsSubject.next(sessions);
    this.currentSessionSubject.next(newSession);
    this.saveSessions();

    return newSession;
  }

  selectSession(sessionId: string): void {
    const session = this.chatSessionsSubject.value.find(s => s.id === sessionId);
    if (session) {
      this.currentSessionSubject.next(session);
    }
  }

  sendMessage(content: string): Observable<ChatMessage> {
    let currentSession = this.currentSessionSubject.value;
    
    if (!currentSession) {
      currentSession = this.createNewSession();
    }

    // Add user message
    const userMessage: ChatMessage = {
      id: this.generateId(),
      content,
      type: 'user',
      timestamp: new Date()
    };

    currentSession.messages.push(userMessage);
    this.updateSession(currentSession);

    // Set loading state
    this.isLoadingSubject.next(true);

    // Simulate AI response
    return this.generateAIResponse(content).pipe(
      delay(1500),
      map(response => {
        const aiMessage: ChatMessage = {
          id: this.generateId(),
          content: response,
          type: 'assistant',
          timestamp: new Date(),
          metadata: {
            suggestions: this.generateSuggestions(content)
          }
        };

        currentSession!.messages.push(aiMessage);
        currentSession!.updatedAt = new Date();
        
        // Update title if it's the first exchange
        if (currentSession!.messages.length === 2) {
          currentSession!.title = this.generateTitle(content);
        }

        this.updateSession(currentSession!);
        this.isLoadingSubject.next(false);

        return aiMessage;
      })
    );
  }

  private updateSession(session: ChatSession): void {
    const sessions = this.chatSessionsSubject.value.map(s => 
      s.id === session.id ? session : s
    );
    this.chatSessionsSubject.next(sessions);
    this.currentSessionSubject.next(session);
    this.saveSessions();
  }

  private generateAIResponse(userInput: string): Observable<string> {
    // Mock AI responses based on input patterns
    const responses = {
      analytics: "I can help you analyze your data! Here are some insights I've gathered from your dataset. Would you like me to create visualizations for sales trends, customer segments, or performance metrics?",
      chart: "I'll create a chart for you. Based on your data, I can generate bar charts, line graphs, pie charts, or scatter plots. What type of visualization would work best for your analysis?",
      data: "I've analyzed your data and found some interesting patterns. The key metrics show a 15% increase over the last quarter. Would you like me to dive deeper into specific segments?",
      insights: "Here are the key insights from your data: \n\n• Revenue growth of 23% YoY\n• Customer retention rate at 87%\n• Top performing product category: Technology\n• Recommended action: Focus on mobile optimization",
      default: "I'm here to help you analyze your data and provide insights. You can ask me about trends, create visualizations, generate reports, or explore specific metrics. What would you like to know?"
    };

    const input = userInput.toLowerCase();
    let response = responses.default;

    if (input.includes('analytic') || input.includes('analyze')) {
      response = responses.analytics;
    } else if (input.includes('chart') || input.includes('graph') || input.includes('visual')) {
      response = responses.chart;
    } else if (input.includes('data') || input.includes('metric')) {
      response = responses.data;
    } else if (input.includes('insight') || input.includes('trend')) {
      response = responses.insights;
    }

    return of(response);
  }

  private generateSuggestions(userInput: string): string[] {
    const suggestions = [
      "Show me sales trends for Q4",
      "Create a customer segmentation analysis",
      "Generate a revenue dashboard",
      "Analyze user behavior patterns",
      "Compare performance metrics"
    ];

    return suggestions.slice(0, 3);
  }

  private generateTitle(firstMessage: string): string {
    const words = firstMessage.split(' ').slice(0, 4);
    return words.join(' ') + '...';
  }

  private generateId(): string {
    return Math.random().toString(36).substr(2, 9);
  }

  deleteSession(sessionId: string): void {
    const sessions = this.chatSessionsSubject.value.filter(s => s.id !== sessionId);
    this.chatSessionsSubject.next(sessions);
    
    if (this.currentSessionSubject.value?.id === sessionId) {
      this.currentSessionSubject.next(null);
    }
    
    this.saveSessions();
  }

  clearAllSessions(): void {
    this.chatSessionsSubject.next([]);
    this.currentSessionSubject.next(null);
    localStorage.removeItem('chatSessions');
  }
}
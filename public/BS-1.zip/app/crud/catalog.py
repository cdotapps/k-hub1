from sqlalchemy.orm import Session

from app.models import Catalog


def create_catalog(db: Session, catalog_data: dict) -> Catalog:
    catalog = Catalog(
        name=catalog_data["name"],
        description=catalog_data["description"],
        type=catalog_data["type"],
        source=catalog_data["source"],
        owner=catalog_data["owner"],
        status=catalog_data["status"],
        created_by=catalog_data["created_by"],
        updated_by=catalog_data["updated_by"],
        created_at=catalog_data["created_at"],
        updated_at=catalog_data["updated_at"],
        category=catalog_data.get("category"),
        parent_id=catalog_data.get("parent_id"),
        child_ids=catalog_data.get("child_ids"),
        priority=catalog_data.get("priority"),
        severity=catalog_data.get("severity"),
        urgent=catalog_data.get("urgent", False),
        important=catalog_data.get("important", False),
    )
    db.add(catalog)
    db.commit()
    db.refresh(catalog)
    return catalog


def update_catalog(db: Session, catalog_id: int, catalog_data: dict) -> Catalog:
    catalog = db.query(Catalog).filter(Catalog.id == catalog_id).first()
    if not catalog:
        return None
    for key, value in catalog_data.items():
        setattr(catalog, key, value)
    db.commit()
    db.refresh(catalog)
    return catalog
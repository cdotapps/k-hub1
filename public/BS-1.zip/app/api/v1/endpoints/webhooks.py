from typing import Any, List
from fastapi import APIRouter, Depends, HTTPException, status, Query, Path, BackgroundTasks
from sqlalchemy.ext.asyncio import AsyncSession

from app import crud, models
from app.schemas import webhook as schemas
from app.api import deps
from app.db.session import get_db
from app.services.webhook_service import webhook_service

router = APIRouter()

@router.post("/", response_model=schemas.Webhook)
async def create_webhook(
    *,
    db: AsyncSession = Depends(get_db),
    webhook_in: schemas.WebhookCreate,
    current_user: models.User = Depends(deps.get_current_user),
) -> Any:
    """
    Create a new webhook subscription.
    """
    # Validate event types
    valid_events = [
        "catalog.created",
        "catalog.updated", 
        "catalog.deleted",
        "catalog.approved",
        "catalog.rejected"
    ]
    
    invalid_events = [event for event in webhook_in.events if event not in valid_events]
    if invalid_events:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Invalid event types: {invalid_events}. Valid events: {valid_events}"
        )
    
    webhook = await crud.webhook.create(
        db, obj_in=webhook_in, created_by=current_user.id
    )
    return webhook

@router.get("/", response_model=List[schemas.Webhook])
async def get_webhooks(
    db: AsyncSession = Depends(get_db),
    current_user: models.User = Depends(deps.get_current_user),
    skip: int = Query(0, ge=0),
    limit: int = Query(100, ge=1, le=100),
    show_all: bool = Query(False, description="Show all webhooks (admin only)")
) -> Any:
    """
    Get webhooks. Users see only their own webhooks, admins can see all.
    """
    created_by = None
    if not show_all or not crud.user.is_admin(current_user):
        created_by = current_user.id
    
    webhooks = await crud.webhook.get_multi(
        db, skip=skip, limit=limit, created_by=created_by
    )
    return webhooks

@router.get("/{webhook_id}", response_model=schemas.Webhook)
async def get_webhook(
    webhook_id: str = Path(...),
    db: AsyncSession = Depends(get_db),
    current_user: models.User = Depends(deps.get_current_user),
) -> Any:
    """
    Get a specific webhook by ID.
    """
    webhook = await crud.webhook.get(db, id=webhook_id)
    if not webhook:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Webhook not found"
        )
    
    # Check permissions
    if webhook.created_by != current_user.id and not crud.user.is_admin(current_user):
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Not enough permissions to access this webhook"
        )
    
    return webhook

@router.put("/{webhook_id}", response_model=schemas.Webhook)
async def update_webhook(
    *,
    db: AsyncSession = Depends(get_db),
    webhook_id: str = Path(...),
    webhook_in: schemas.WebhookUpdate,
    current_user: models.User = Depends(deps.get_current_user),
) -> Any:
    """
    Update a webhook.
    """
    webhook = await crud.webhook.get(db, id=webhook_id)
    if not webhook:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Webhook not found"
        )
    
    # Check permissions
    if webhook.created_by != current_user.id and not crud.user.is_admin(current_user):
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Not enough permissions to update this webhook"
        )
    
    # Validate event types if provided
    if webhook_in.events:
        valid_events = [
            "catalog.created",
            "catalog.updated", 
            "catalog.deleted",
            "catalog.approved",
            "catalog.rejected"
        ]
        invalid_events = [event for event in webhook_in.events if event not in valid_events]
        if invalid_events:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail=f"Invalid event types: {invalid_events}. Valid events: {valid_events}"
            )
    
    webhook = await crud.webhook.update(db, db_obj=webhook, obj_in=webhook_in)
    return webhook

@router.delete("/{webhook_id}")
async def delete_webhook(
    *,
    db: AsyncSession = Depends(get_db),
    webhook_id: str = Path(...),
    current_user: models.User = Depends(deps.get_current_user),
) -> Any:
    """
    Delete a webhook.
    """
    webhook = await crud.webhook.get(db, id=webhook_id)
    if not webhook:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Webhook not found"
        )
    
    # Check permissions
    if webhook.created_by != current_user.id and not crud.user.is_admin(current_user):
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Not enough permissions to delete this webhook"
        )
    
    await crud.webhook.remove(db, id=webhook_id)
    return {"status": "success", "msg": "Webhook deleted successfully"}

@router.post("/{webhook_id}/test")
async def test_webhook(
    webhook_id: str = Path(...),
    background_tasks: BackgroundTasks = BackgroundTasks(),
    db: AsyncSession = Depends(get_db),
    current_user: models.User = Depends(deps.get_current_user),
) -> Any:
    """
    Send a test payload to a webhook.
    """
    webhook = await crud.webhook.get(db, id=webhook_id)
    if not webhook:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Webhook not found"
        )
    
    # Check permissions
    if webhook.created_by != current_user.id and not crud.user.is_admin(current_user):
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Not enough permissions to test this webhook"
        )
    
    # Test webhook in background
    result = await webhook_service.test_webhook(db, webhook_id)
    return result

@router.patch("/{webhook_id}/toggle")
async def toggle_webhook(
    webhook_id: str = Path(...),
    db: AsyncSession = Depends(get_db),
    current_user: models.User = Depends(deps.get_current_user),
) -> Any:
    """
    Toggle webhook active status.
    """
    webhook = await crud.webhook.get(db, id=webhook_id)
    if not webhook:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Webhook not found"
        )
    
    # Check permissions
    if webhook.created_by != current_user.id and not crud.user.is_admin(current_user):
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Not enough permissions to modify this webhook"
        )
    
    # Toggle active status
    webhook_update = schemas.WebhookUpdate(active=not webhook.active)
    webhook = await crud.webhook.update(db, db_obj=webhook, obj_in=webhook_update)
    
    return {
        "id": webhook.id,
        "active": webhook.active,
        "msg": f"Webhook {'activated' if webhook.active else 'deactivated'}"
    }

@router.get("/{webhook_id}/deliveries", response_model=List[schemas.WebhookDelivery])
async def get_webhook_deliveries(
    webhook_id: str = Path(...),
    db: AsyncSession = Depends(get_db),
    current_user: models.User = Depends(deps.get_current_user),
    skip: int = Query(0, ge=0),
    limit: int = Query(100, ge=1, le=100),
) -> Any:
    """
    Get delivery history for a webhook.
    """
    webhook = await crud.webhook.get(db, id=webhook_id)
    if not webhook:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Webhook not found"
        )
    
    # Check permissions
    if webhook.created_by != current_user.id and not crud.user.is_admin(current_user):
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Not enough permissions to access this webhook's deliveries"
        )
    
    deliveries = await crud.webhook_delivery.get_by_webhook(
        db, webhook_id=webhook_id, skip=skip, limit=limit
    )
    return deliveries

@router.get("/events/available")
async def get_available_events() -> Any:
    """
    Get list of available webhook event types.
    """
    return {
        "events": [
            {
                "type": "catalog.created",
                "description": "Triggered when a new catalog item is created"
            },
            {
                "type": "catalog.updated", 
                "description": "Triggered when a catalog item is updated"
            },
            {
                "type": "catalog.deleted",
                "description": "Triggered when a catalog item is deleted"
            },
            {
                "type": "catalog.approved",
                "description": "Triggered when a catalog item is approved by an admin"
            },
            {
                "type": "catalog.rejected",
                "description": "Triggered when a catalog item is rejected by an admin"
            }
        ]
    }
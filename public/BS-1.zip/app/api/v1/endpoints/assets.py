from typing import Any, List, Dict
from fastapi import APIRouter, Body, Depends, HTTPException, status, Query, Path, BackgroundTasks
from sqlalchemy.ext.asyncio import AsyncSession

from app import models
from app.api import deps
from app.services.sharepoint_asset_service import sharepoint_asset_service, SharePointAsset

router = APIRouter()


def check_sharepoint_configured():
    """Dependency to check if SharePoint is configured"""
    if not sharepoint_asset_service.is_configured():
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail="SharePoint is not configured. Please check your environment variables."
        )
    return True

@router.get("/", response_model=List[SharePointAsset])
async def get_all_assets(
    current_user: models.User = Depends(deps.get_current_user),
    _: bool = Depends(check_sharepoint_configured),
) -> Any:
    """
    Get all assets from SharePoint list.
    """
    try:
        assets = await sharepoint_asset_service.get_all_assets()
        return assets
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Error fetching assets: {str(e)}"
        )

@router.get("/asset-id/{asset_id}", response_model=SharePointAsset)
async def get_asset_by_id(
    *,
    asset_id: str = Path(..., description="Business Asset ID"),
    current_user: models.User = Depends(deps.get_current_user),
    _: bool = Depends(check_sharepoint_configured),
) -> Any:
    """
    Get asset by business Asset ID.
    """
    try:
        asset = await sharepoint_asset_service.get_asset(asset_id)
        if not asset:
            raise HTTPException(status_code=404, detail="Asset not found")
        return asset
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Error fetching asset: {str(e)}"
        )

@router.get("/sp-id/{sp_id}", response_model=SharePointAsset)
async def get_asset_by_sharepoint_id(
    *,
    sp_id: int = Path(..., description="SharePoint Item ID"),
    current_user: models.User = Depends(deps.get_current_user),
    _: bool = Depends(check_sharepoint_configured),
) -> Any:
    """
    Get asset by SharePoint item ID.
    """
    try:
        asset = await sharepoint_asset_service.get_asset_by_sp_id(sp_id)
        if not asset:
            raise HTTPException(status_code=404, detail="Asset not found")
        return asset
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Error fetching asset: {str(e)}"
        )

@router.post("/", response_model=SharePointAsset)
async def create_asset(
    *,
    asset: SharePointAsset,
    current_user: models.User = Depends(deps.get_current_user),
    _: bool = Depends(check_sharepoint_configured),
) -> Any:
    """
    Create new asset in SharePoint list.
    """
    try:
        # Check if asset ID already exists
        existing_asset = await sharepoint_asset_service.get_asset(asset.AssetID)
        if existing_asset:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Asset with this ID already exists"
            )
        
        created_asset = await sharepoint_asset_service.create_asset(asset)
        return created_asset
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Error creating asset: {str(e)}"
        )

@router.put("/sp-id/{sp_id}", response_model=SharePointAsset)
async def update_asset(
    *,
    sp_id: int = Path(..., description="SharePoint Item ID"),
    asset: SharePointAsset,
    current_user: models.User = Depends(deps.get_current_user),
    _: bool = Depends(check_sharepoint_configured),
) -> Any:
    """
    Update asset in SharePoint list.
    """
    try:
        # Check if asset exists
        existing_asset = await sharepoint_asset_service.get_asset_by_sp_id(sp_id)
        if not existing_asset:
            raise HTTPException(status_code=404, detail="Asset not found")
        
        # If AssetID is being changed, check for duplicates
        if asset.AssetID != existing_asset.AssetID:
            duplicate = await sharepoint_asset_service.get_asset(asset.AssetID)
            if duplicate and duplicate.Id != sp_id:
                raise HTTPException(
                    status_code=status.HTTP_400_BAD_REQUEST,
                    detail="Asset with this ID already exists"
                )
        
        updated_asset = await sharepoint_asset_service.update_asset(sp_id, asset)
        return updated_asset
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Error updating asset: {str(e)}"
        )

@router.delete("/sp-id/{sp_id}", response_model=Dict[str, str])
async def delete_asset(
    *,
    sp_id: int = Path(..., description="SharePoint Item ID"),
    current_user: models.User = Depends(deps.get_current_user),
    _: bool = Depends(check_sharepoint_configured),
) -> Any:
    """
    Delete asset from SharePoint list.
    """
    try:
        # Check if asset exists
        existing_asset = await sharepoint_asset_service.get_asset_by_sp_id(sp_id)
        if not existing_asset:
            raise HTTPException(status_code=404, detail="Asset not found")
        
        await sharepoint_asset_service.delete_asset(sp_id)
        return {"message": f"Asset {existing_asset.AssetID} deleted successfully"}
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Error deleting asset: {str(e)}"
        )

@router.get("/search", response_model=List[SharePointAsset])
async def search_assets(
    *,
    business: str = Query(None, description="Filter by business"),
    asset_type: str = Query(None, description="Filter by asset type"),
    asset_status: str = Query(None, description="Filter by asset status"),
    owner: str = Query(None, description="Filter by owner"),
    search_term: str = Query(None, description="General search term"),
    current_user: models.User = Depends(deps.get_current_user),
    _: bool = Depends(check_sharepoint_configured),
) -> Any:
    """
    Search assets in SharePoint list.
    """
    try:
        filters = {}
        if business:
            filters['business'] = business
        if asset_type:
            filters['asset_type'] = asset_type
        if asset_status:
            filters['asset_status'] = asset_status
        if owner:
            filters['owner'] = owner
        if search_term:
            filters['search_term'] = search_term
        
        assets = await sharepoint_asset_service.search_assets(filters)
        return assets
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Error searching assets: {str(e)}"
        )

@router.get("/statistics", response_model=Dict[str, Any])
async def get_asset_statistics(
    current_user: models.User = Depends(deps.get_current_user),
    _: bool = Depends(check_sharepoint_configured),
) -> Any:
    """
    Get asset statistics from SharePoint list.
    """
    try:
        stats = await sharepoint_asset_service.get_statistics()
        return stats
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Error getting statistics: {str(e)}"
        )

@router.post("/test-connection", response_model=Dict[str, Any])
async def test_sharepoint_connection(
    current_user: models.User = Depends(deps.get_current_user),
    _: bool = Depends(check_sharepoint_configured),
) -> Any:
    """
    Test SharePoint connection and list access.
    """
    try:
        # Try to get access token
        token = await sharepoint_asset_service.get_access_token()
        
        # Try to fetch assets (just count them)
        assets = await sharepoint_asset_service.get_all_assets()
        
        return {
            "status": "success",
            "message": f"Successfully connected to SharePoint. Found {len(assets)} assets in the list.",
            "asset_count": len(assets)
        }
    except Exception as e:
        return {
            "status": "error",
            "message": f"Failed to connect to SharePoint: {str(e)}",
            "asset_count": 0
        }

@router.get("/config-info", response_model=Dict[str, Any])
async def get_sharepoint_config_info(
    current_user: models.User = Depends(deps.get_current_user),
) -> Any:
    """
    Get SharePoint configuration information and status.
    """
    try:
        from app.core.config import sharepoint_settings
        
        if not sharepoint_settings:
            return {
                "configured": False,
                "message": "SharePoint is not configured. Please set environment variables.",
                "required_variables": [
                    "SHAREPOINT_SITE_URL",
                    "SHAREPOINT_LIST_NAME",
                    "SHAREPOINT_CLIENT_ID",
                    "SHAREPOINT_CLIENT_SECRET",
                    "SHAREPOINT_TENANT_ID"
                ]
            }
        
        # Don't expose sensitive information
        return {
            "configured": True,
            "site_url": sharepoint_settings.site_url,
            "list_name": sharepoint_settings.list_name,
            "tenant_id": sharepoint_settings.tenant_id,
            "message": "SharePoint is properly configured"
        }
    except Exception as e:
        return {
            "configured": False,
            "message": f"Error checking configuration: {str(e)}"
        }

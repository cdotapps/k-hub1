#!/usr/bin/env python3
"""
Migration script to populate author_id field in existing catalog entries
This script will match author names to user records and populate the author_id field
"""

import asyncio
import sys
sys.path.append('.')

from app.db.session import async_session
from app import crud
from sqlalchemy import text

async def migrate_catalog_author_ids():
    """Migrate existing catalog entries to populate author_id field"""
    print("🔄 Starting catalog author_id migration...")
    print("=" * 60)
    
    async with async_session() as db:
        # Get all catalog entries that don't have author_id set
        result = await db.execute(
            text("SELECT id, author FROM catalogs WHERE author_id IS NULL AND author IS NOT NULL")
        )
        catalog_entries = result.fetchall()
        
        if not catalog_entries:
            print("✅ No catalog entries need migration")
            return
        
        print(f"📊 Found {len(catalog_entries)} catalog entries to migrate")
        print("=" * 60)
        
        updated_count = 0
        failed_count = 0
        
        for catalog_id, author_name in catalog_entries:
            try:
                if not author_name:
                    continue
                
                # Try to find user by matching first_name + last_name
                parts = author_name.strip().split()
                if len(parts) >= 2:
                    first_name = parts[0]
                    last_name = ' '.join(parts[1:])  # Handle multi-word last names
                    
                    # Find user by name
                    users_result = await db.execute(
                        text("SELECT id FROM users WHERE first_name = :first_name AND last_name = :last_name"),
                        {"first_name": first_name, "last_name": last_name}
                    )
                    user_record = users_result.fetchone()
                    
                    if user_record:
                        user_id = user_record[0]
                        
                        # Update catalog entry with author_id
                        await db.execute(
                            text("UPDATE catalogs SET author_id = :author_id WHERE id = :catalog_id"),
                            {"author_id": user_id, "catalog_id": catalog_id}
                        )
                        
                        print(f"✅ Updated catalog '{catalog_id[:8]}...' -> author_id: {user_id} ({author_name})")
                        updated_count += 1
                    else:
                        print(f"⚠️  No user found for author: '{author_name}' (catalog: {catalog_id[:8]}...)")
                        failed_count += 1
                else:
                    print(f"⚠️  Invalid author name format: '{author_name}' (catalog: {catalog_id[:8]}...)")
                    failed_count += 1
                    
            except Exception as e:
                print(f"❌ Error processing catalog {catalog_id}: {e}")
                failed_count += 1
        
        # Commit all changes
        await db.commit()
        
        print("=" * 60)
        print(f"📊 Migration Summary:")
        print(f"   ✅ Successfully updated: {updated_count} entries")
        print(f"   ⚠️  Failed to update: {failed_count} entries")
        print(f"   📈 Success rate: {(updated_count/(updated_count+failed_count)*100):.1f}%" if (updated_count+failed_count) > 0 else "N/A")
        print("=" * 60)

async def main():
    """Main migration function"""
    print("🗄️  Catalog Author ID Migration Script")
    print("=" * 60)
    print("This script will populate the author_id field for existing catalog entries")
    print("by matching author names with user records in the database.")
    print("")
    
    try:
        await migrate_catalog_author_ids()
        print("🎉 Migration completed successfully!")
    except Exception as e:
        print(f"❌ Migration failed: {e}")
        sys.exit(1)

if __name__ == "__main__":
    asyncio.run(main())
from typing import Optional, List, Dict, Any, Literal
from pydantic import BaseModel, Field
from uuid import UUID, uuid4
from datetime import datetime
import random


def genKey(item_type: str, username: str, item_id: UUID) -> str:
    A = (item_type[0] if item_type else "X").upper()
    # Pick two random letters from username
    letters = [c for c in username if c.isalpha()]
    if len(letters) >= 2:
        XX = ''.join(random.sample(letters, 2)).upper()
    elif len(letters) == 1:
        XX = (letters[0]*2).upper()
    else:
        XX = str(item_id)[-2:].upper()
    YYYY = str(random.randint(0000, 9999)).zfill(4)
    ZZZZ = str(item_id)[-4:].upper()
    return f"{A}{XX}-{YYYY}-{ZZZZ}"


class MsgPayload(BaseModel):
    msg_id: Optional[int]
    msg_name: str


class User(BaseModel):
    username: str
    password: str  # In production, store hashed passwords only
    name: Optional[str] = None
    role: Literal["admin", "officer", "analyst"]


class CatalogItem(BaseModel):
    id: UUID = Field(default_factory=uuid4)
    key: Optional[str] = None
    name: str
    title: Optional[str] = None
    description: Optional[str] = None
    content: Optional[str] = None
    type: str
    category: Optional[str] = None
    status: Optional[str] = None
    priority: Optional[int] = None
    due_date: Optional[datetime] = None
    parent_id: Optional[UUID] = None
    child_id: List[UUID] = []
    ai_content: Optional[Dict[str, Any]] = None
    ai_summary: Optional[str] = None
    custom: Optional[Dict[str, Any]] = None
    private: bool = True
    # Audit fields
    created_at: datetime = Field(default_factory=datetime.utcnow)
    updated_at: Optional[datetime] = None
    created_by: Optional[str] = None
    updated_by: Optional[str] = None

    def __init__(self, **data):
        super().__init__(**data)
        if self.key is None:
            self.key = genKey(self.type, self.name, self.id)

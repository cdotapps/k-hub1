from fastapi import FastAPI, Depends, HTTPException, status, APIRouter, Request, Body, Query
from fastapi.security import OAuth2PasswordBearer, OAuth2PasswordRequestForm
from models import MsgPayload, CatalogItem
from typing import Dict, List
from uuid import UUID
from datetime import datetime, timedelta
import jwt
import os
from dotenv import load_dotenv
import json
from fastapi.middleware.cors import CORSMiddleware
import boto3
from ai_model import bedrock_infer_model
from ai_agent import ai_agent_router
from db import catalog_db, users_db, messages_list
from auth import get_current_user, User

load_dotenv()
STORAGE_BACKEND = os.getenv("STORAGE_BACKEND", "memory")
POSTGRES_URL = os.getenv("POSTGRES_URL")

if STORAGE_BACKEND == "postgres":
    import psycopg2
    from psycopg2.extras import Json
    conn = psycopg2.connect(POSTGRES_URL)
    cur = conn.cursor()
    # Ensure table exists
    cur.execute("""
        CREATE TABLE IF NOT EXISTS catalog (
            id UUID PRIMARY KEY,
            name TEXT,
            title TEXT,
            description TEXT,
            content TEXT,
            type TEXT,
            category TEXT,
            status TEXT,
            priority INT,
            due_date TIMESTAMP,
            custom JSONB,
            parent_id UUID,
            child_id UUID[],
            ai_content JSONB,
            ai_summary TEXT,
            private BOOLEAN DEFAULT TRUE,
            created_at TIMESTAMP,
            updated_at TIMESTAMP,
            created_by TEXT,
            updated_by TEXT
        )
    """)
    conn.commit()

SECRET_KEY = "your-secret-key"  # Change this in production
ALGORITHM = "HS256"
ACCESS_TOKEN_EXPIRE_MINUTES = 60

app = FastAPI()

# Allow CORS for localhost:4200
app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:4200"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Routers
health_router = APIRouter(tags=["Health"])
auth_router = APIRouter(prefix="/v1", tags=["Auth"])
catalog_router = APIRouter(prefix="/v1/catalog", tags=["Catalog"])

# Load users from users.json if using memory backend
if STORAGE_BACKEND == "memory":
    BASE_DIR = os.path.dirname(os.path.abspath(__file__))
    USERS_FILE = os.path.join(BASE_DIR, "users.json")
    if os.path.exists(USERS_FILE):
        with open(USERS_FILE, "r") as f:
            loaded_users = json.load(f)
            users_db = {u["username"]: User(**u) for u in loaded_users}
    else:
        users_db = {"admin": User(username="admin", password="admin")}

oauth2_scheme = OAuth2PasswordBearer(tokenUrl="/v1/login")

def authenticate_user(username: str, password: str):
    user = users_db.get(username)
    if user and user.password == password:
        return user
    return None

def create_access_token(data: dict, expires_delta: timedelta = None):
    to_encode = data.copy()
    expire = datetime.utcnow() + (expires_delta or timedelta(minutes=ACCESS_TOKEN_EXPIRE_MINUTES))
    to_encode.update({"exp": expire})
    return jwt.encode(to_encode, SECRET_KEY, algorithm=ALGORITHM)

@app.get("/")
def root() -> dict[str, str]:
    return {"message": "Hello"}

# Health endpoint
define_health = health_router.get("/health")
@define_health
def health() -> dict:
    return {"status": "ok"}

# Auth endpoints
@auth_router.post("/login")
def login(form_data: OAuth2PasswordRequestForm = Depends()):
    user = authenticate_user(form_data.username, form_data.password)
    if not user:
        raise HTTPException(status_code=400, detail="Incorrect username or password")
    access_token = create_access_token(data={"sub": user.username})
    return {"access_token": access_token, "token_type": "bearer"}

def catalog_create_postgres(item: CatalogItem):
    cur.execute(
        """
        INSERT INTO catalog (id, name, title, description, content, type, category, status, priority, due_date, custom, parent_id, child_id, ai_content, ai_summary, private, created_at, updated_at, created_by, updated_by)
        VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
        """,
        (
            str(item.id), item.name, item.title, item.description, item.content, item.type, item.category, item.status, item.priority, item.due_date,
            Json(item.custom) if item.custom else None, str(item.parent_id) if item.parent_id else None, [str(cid) for cid in item.child_id],
            Json(item.ai_content) if item.ai_content else None, item.ai_summary, item.private, item.created_at, item.updated_at, item.created_by, item.updated_by
        )
    )
    conn.commit()

def catalog_list_postgres(type: str = None):
    if type:
        cur.execute("SELECT * FROM catalog WHERE type=%s", (type,))
    else:
        cur.execute("SELECT * FROM catalog")
    rows = cur.fetchall()
    return [CatalogItem(**dict(zip([desc[0] for desc in cur.description], row))) for row in rows]

def catalog_get_postgres(item_id: UUID):
    cur.execute("SELECT * FROM catalog WHERE id=%s", (str(item_id),))
    row = cur.fetchone()
    if not row:
        return None
    return CatalogItem(**dict(zip([desc[0] for desc in cur.description], row)))

def catalog_update_postgres(item_id: UUID, item: CatalogItem):
    cur.execute(
        """
        UPDATE catalog SET name=%s, title=%s, description=%s, content=%s, type=%s, category=%s, status=%s, priority=%s, due_date=%s, custom=%s, parent_id=%s, child_id=%s, ai_content=%s, ai_summary=%s, private=%s, updated_at=%s, updated_by=%s WHERE id=%s
        """,
        (
            item.name, item.title, item.description, item.content, item.type, item.category, item.status, item.priority, item.due_date,
            Json(item.custom) if item.custom else None, str(item.parent_id) if item.parent_id else None, [str(cid) for cid in item.child_id],
            Json(item.ai_content) if item.ai_content else None, item.ai_summary, item.private, item.updated_at, item.updated_by, str(item_id)
        )
    )
    conn.commit()

def catalog_delete_postgres(item_id: UUID):
    cur.execute("DELETE FROM catalog WHERE id=%s", (str(item_id),))
    conn.commit()

# Catalog endpoints
@catalog_router.post("", response_model=CatalogItem)
def create_catalog_item(item: CatalogItem, current_user: User = Depends(get_current_user)):
    item.created_by = current_user.username
    item.created_at = datetime.utcnow()
    if STORAGE_BACKEND == "postgres":
        catalog_create_postgres(item)
    else:
        catalog_db[item.id] = item
    return item

@catalog_router.get("", response_model=List[CatalogItem])
def list_catalog_items(type: str = None, current_user: User = Depends(get_current_user)):
    if STORAGE_BACKEND == "postgres":
        query = "SELECT * FROM catalog WHERE (created_by=%s OR private=FALSE)"
        params = [current_user.username]
        if type:
            query += " AND type=%s"
            params.append(type)
        cur.execute(query, tuple(params))
        rows = cur.fetchall()
        return [CatalogItem(**dict(zip([desc[0] for desc in cur.description], row))) for row in rows]
    # In-memory filter
    results = [item for item in catalog_db.values() if item.created_by == current_user.username or item.private is False]
    if type:
        results = [item for item in results if item.type == type]
    return results

@catalog_router.get("/search", response_model=List[CatalogItem])
def search_catalog_items(
    name: str = None,
    title: str = None,
    type: str = None,
    category: str = None,
    status: str = None,
    priority: int = None,
    created_by: str = None,
    ai_summary: str = None,
    request: Request = None,
    current_user: User = Depends(get_current_user)
):
    print("Search request query params:", dict(request.query_params))
    try:
        if STORAGE_BACKEND == "postgres":
            query = "SELECT * FROM catalog WHERE (created_by=%s OR private=FALSE)"
            params = [current_user.username]
            if name:
                query += " AND name ILIKE %s"
                params.append(f"%{name}%")
            if title:
                query += " AND title ILIKE %s"
                params.append(f"%{title}%")
            if type:
                query += " AND type=%s"
                params.append(type)
            if category:
                query += " AND category=%s"
                params.append(category)
            if status:
                query += " AND status=%s"
                params.append(status)
            if priority is not None:
                query += " AND priority=%s"
                params.append(priority)
            if created_by:
                query += " AND created_by=%s"
                params.append(created_by)
            if ai_summary:
                query += " AND ai_summary ILIKE %s"
                params.append(f"%{ai_summary}%")
            cur.execute(query, tuple(params))
            rows = cur.fetchall()
            return [CatalogItem(**dict(zip([desc[0] for desc in cur.description], row))) for row in rows] if rows else []
        # In-memory search
        results = [item for item in catalog_db.values() if item.created_by == current_user.username or item.private is False]
        if name:
            results = [item for item in results if item.name and name.lower() in item.name.lower()]
        if title:
            results = [item for item in results if item.title and title.lower() in item.title.lower()]
        if type:
            results = [item for item in results if item.type == type]
        if category:
            results = [item for item in results if item.category == category]
        if status:
            results = [item for item in results if item.status == status]
        if priority is not None:
            results = [item for item in results if item.priority == priority]
        if created_by:
            results = [item for item in results if item.created_by == created_by]
        if ai_summary:
            results = [item for item in results if item.ai_summary and ai_summary.lower() in item.ai_summary.lower()]
        return results if results else []
    except Exception as e:
        print(f"Search error: {e}")
        return []

@catalog_router.get("/search/by-key", response_model=List[CatalogItem])
def search_catalog_by_key(key: str, current_user: User = Depends(get_current_user)):
    if STORAGE_BACKEND == "postgres":
        query = "SELECT * FROM catalog WHERE (created_by=%s OR private=FALSE) AND key ILIKE %s"
        params = [current_user.username, f"%{key}%"]
        cur.execute(query, tuple(params))
        rows = cur.fetchall()
        return [CatalogItem(**dict(zip([desc[0] for desc in cur.description], row))) for row in rows] if rows else []
    # In-memory search
    results = [item for item in catalog_db.values() if (item.created_by == current_user.username or item.private is False) and item.key and key.lower() in item.key.lower()]
    return results if results else []

@catalog_router.get("/{item_id}", response_model=CatalogItem)
def get_catalog_item(item_id: UUID, current_user: User = Depends(get_current_user)):
    if STORAGE_BACKEND == "postgres":
        item = catalog_get_postgres(item_id)
    else:
        item = catalog_db.get(item_id)
    if not item:
        raise HTTPException(status_code=404, detail="Item not found")
    return item

@catalog_router.put("/{item_id}", response_model=CatalogItem)
def update_catalog_item(item_id: UUID, item: CatalogItem, current_user: User = Depends(get_current_user)):
    item.updated_by = current_user.username
    item.updated_at = datetime.utcnow()
    if STORAGE_BACKEND == "postgres":
        if not catalog_get_postgres(item_id):
            raise HTTPException(status_code=404, detail="Item not found")
        catalog_update_postgres(item_id, item)
    else:
        if item_id not in catalog_db:
            raise HTTPException(status_code=404, detail="Item not found")
        catalog_db[item_id] = item
    return item

@catalog_router.delete("/{item_id}")
def delete_catalog_item(item_id: UUID, current_user: User = Depends(get_current_user)):
    if STORAGE_BACKEND == "postgres":
        if not catalog_get_postgres(item_id):
            raise HTTPException(status_code=404, detail="Item not found")
        catalog_delete_postgres(item_id)
    else:
        if item_id not in catalog_db:
            raise HTTPException(status_code=404, detail="Item not found")
        del catalog_db[item_id]
    return {"detail": "Item deleted"}

AWS_ACCESS_KEY_ID = os.getenv("AWS_ACCESS_KEY_ID")
AWS_SECRET_ACCESS_KEY = os.getenv("AWS_SECRET_ACCESS_KEY")
AWS_REGION = os.getenv("AWS_REGION")
S3_BUCKET_NAME = os.getenv("S3_BUCKET_NAME")

@app.post("/v1/s3/upload")
def upload_presigned_url(
    folder: str = Body(...),
    fileName: str = Body(...),
    fileType: str = Body(...),
    current_user: User = Depends(get_current_user)
):
    if current_user.role != "admin":
        raise HTTPException(status_code=403, detail="Admin access required")
    s3_client = boto3.client(
        "s3",
        aws_access_key_id=AWS_ACCESS_KEY_ID,
        aws_secret_access_key=AWS_SECRET_ACCESS_KEY,
        region_name=AWS_REGION
    )
    key = f"{folder}/{fileName}"
    try:
        url = s3_client.generate_presigned_url(
            ClientMethod="put_object",
            Params={
                "Bucket": S3_BUCKET_NAME,
                "Key": key,
                "ContentType": fileType
            },
            ExpiresIn=300
        )
        return {"uploadURL": url}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/v1/bedrock/model")
def bedrock_infer(
    prompt: str = Body(...),
    template_name: str = Body("default"),
    current_user: User = Depends(get_current_user)
):
    from ai_model import enhance_prompt_with_template
    enhanced_prompt = enhance_prompt_with_template(prompt, template_name)
    result = bedrock_infer_model(enhanced_prompt)
    return {"response": result}

# Register routers
app.include_router(health_router)
app.include_router(auth_router)
app.include_router(catalog_router)
app.include_router(ai_agent_router)

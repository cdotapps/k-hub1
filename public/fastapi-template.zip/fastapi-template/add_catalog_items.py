import requests
import json
import os
from dotenv import load_dotenv

load_dotenv()
API_URL = os.getenv("API_URL", "http://localhost:8000")

# Login as analyst
login_data = {"username": "analyst", "password": "analyst123"}
resp = requests.post(f"{API_URL}/v1/login", data=login_data)
resp.raise_for_status()
token = resp.json()["access_token"]
headers = {"Authorization": f"Bearer {token}"}

# Catalog items to add
catalog_items = [
    {
        "name": "Budget Planning Prompt",
        "type": "prompt",
        "category": "Finance Planning",
        "title": "Budget Planning",
        "description": "Prompt for annual budget planning.",
        "content": "What is the proposed budget for the next fiscal year?",
        "ai_summary": "User asks about next year's budget proposal."
    },
    {
        "name": "Forecast Accuracy Prompt",
        "type": "prompt",
        "category": "Analysis",
        "title": "Forecast Accuracy",
        "description": "Prompt for forecast accuracy review.",
        "content": "How accurate were our financial forecasts last quarter?",
        "ai_summary": "User asks about forecast accuracy."
    },
    {
        "name": "Expense Trend Message",
        "type": "message",
        "category": "Finance Planning",
        "title": "Expense Trend",
        "description": "Message about expense trends.",
        "content": "Expenses have increased by 10% compared to last year.",
        "ai_summary": "Expense trend notification."
    },
    {
        "name": "Variance Analysis Prompt",
        "type": "prompt",
        "category": "Analysis",
        "title": "Variance Analysis",
        "description": "Prompt for variance analysis.",
        "content": "Can you provide a variance analysis for Q3?",
        "ai_summary": "User requests Q3 variance analysis."
    },
    {
        "name": "Cash Flow Status Message",
        "type": "message",
        "category": "Finance Planning",
        "title": "Cash Flow Status",
        "description": "Message about current cash flow status.",
        "content": "Current cash flow is positive with a surplus of $50,000.",
        "ai_summary": "Cash flow status update."
    },
    {
        "name": "Scenario Planning Prompt",
        "type": "prompt",
        "category": "Finance Planning",
        "title": "Scenario Planning",
        "description": "Prompt for scenario planning.",
        "content": "What are the financial impacts of a 5% revenue drop?",
        "ai_summary": "User asks about scenario planning for revenue drop."
    },
    {
        "name": "KPI Review Prompt",
        "type": "prompt",
        "category": "Analysis",
        "title": "KPI Review",
        "description": "Prompt for reviewing financial KPIs.",
        "content": "Please review the financial KPIs for this month.",
        "ai_summary": "User requests monthly KPI review."
    },
    {
        "name": "Cost Optimization Message",
        "type": "message",
        "category": "Finance Planning",
        "title": "Cost Optimization",
        "description": "Message about cost optimization opportunities.",
        "content": "Consider renegotiating vendor contracts to reduce costs.",
        "ai_summary": "Cost optimization suggestion."
    },
    {
        "name": "Revenue Analysis Prompt",
        "type": "prompt",
        "category": "Analysis",
        "title": "Revenue Analysis",
        "description": "Prompt for revenue analysis.",
        "content": "Analyze the revenue growth for the last six months.",
        "ai_summary": "User requests revenue growth analysis."
    },
    {
        "name": "Financial Risk Message",
        "type": "message",
        "category": "Finance Planning",
        "title": "Financial Risk",
        "description": "Message about financial risks.",
        "content": "Monitor potential risks due to market volatility.",
        "ai_summary": "Financial risk alert."
    }
]

for item in catalog_items:
    resp = requests.post(f"{API_URL}/v1/catalog", json=item, headers=headers)
    print(f"Added: {item['name']} - Status: {resp.status_code}")
    print(resp.json())

from typing import Dict
from uuid import UUID
from models import MsgPayload, CatalogItem, User
import os
import json

messages_list: dict[int, MsgPayload] = {}
catalog_db: Dict[UUID, CatalogItem] = {}
users_db: Dict[str, User] = {}

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
USERS_FILE = os.path.join(BASE_DIR, "users.json")
if os.path.exists(USERS_FILE):
    with open(USERS_FILE, "r") as f:
        loaded_users = json.load(f)
        users_db.update({u["username"]: User(**u) for u in loaded_users})
if not users_db:
    users_db["admin"] = User(username="admin", password="admin")
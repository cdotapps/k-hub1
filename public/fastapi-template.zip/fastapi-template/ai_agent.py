from fastapi import APIRouter, Body, Depends
from fastapi.responses import StreamingResponse
import boto3
from models import CatalogItem
from uuid import uuid4
from datetime import datetime
from db import catalog_db
from auth import get_current_user, User
import json

ai_agent_router = APIRouter()

ai_data = {
    "key": '',
    "question": '',
    "answer": '',
    "summary": '',  
    "timestamp": datetime.utcnow().isoformat(),
    "charts": [
        {"type": "line", "title": "", "data": [{}]},
        {"type": "pie", "title": "", "data": [{}]}
    ],
    "data": {
        "table": [{}],
        "count": 0,
        "sum": 0,
        "average": 0,
        "min": 0,
        "max": 0,
        "top3": []
    }
}

# Dummy SQL execution function
def execute_sql_query(query: str):
    # Replace with actual DB logic
    return {"result": f"Executed SQL: {query}"}

# Dummy RAG retrieval function
def rag_retrieve_answer(question: str):
    # Replace with actual RAG/vector DB logic
    return f"RAG answer for: {question}"

# Tool for SQL generation and execution
def sql_gen_tool_func(question: str):
    # Here, you would use LLM to generate SQL, then execute
    sql_query = f"SELECT * FROM table WHERE question = '{question}'"  # Dummy
    return execute_sql_query(sql_query)

# Tool for SQL generation and execution
def sql_tool_func(question: str):
    # Here, you would use LLM to generate SQL, then execute
    sql_query = f"SELECT * FROM table WHERE question = '{question}'"  # Dummy
    return execute_sql_query(sql_query)

# Tool for RAG retrieval
def rag_tool_func(question: str):
    return rag_retrieve_answer(question)

def log_agent_step(key: str, step: str, question: str, agent_input: dict = None, response: str = None, created_by: str = "agent", custom: dict = None):
    log_item = CatalogItem(
        id=uuid4(),
        key=key,
        type="agent-log",
        name=f"Agent Step: {step}",
        description=question,
        content=json.dumps(agent_input) if agent_input else None,
        ai_content={"ai_response": response} if response else None,
        custom=custom,
        created_by=created_by,
        created_at=datetime.utcnow(),
        private=False
    )
    catalog_db[log_item.id] = log_item

def process_ai_response(key, question, answer, summary=None):
    from datetime import datetime
    ai_data = {
        "key": key,
        "question": question,
        "answer": answer,
        "summary": summary or "",
        "timestamp": datetime.utcnow().isoformat(),
        "charts": [
            {"type": "line", "title": "Monthly Expense Trends", "data": [{}]},
            {"type": "pie", "title": "Expense Breakdown by Category", "data": [{}]}
        ],
        "data": {
            "count": 0,
            "sum": 0,
            "average": 0,
            "min": 0,
            "max": 0,
            "top3": [],
            "table": [{}]
        }
    }
    return ai_data

@ai_agent_router.post("/v1/agentic-chat")
def agentic_chat_endpoint(
    key: str = Body(..., embed=True),
    question: str = Body(..., embed=True),
    current_user: User = Depends(get_current_user)
):
    ai_data = process_ai_response(key, question, question)
    log_agent_step(key, "Received Question", question, agent_input={"key": key, "question": question}, response=question, custom=ai_data)
    try:
        from langchain.agents import initialize_agent, AgentType
        from langchain.llms import BedrockLLM
        from langchain.tools import Tool
        sql_tool = Tool(
            name="SQLTool",
            func=sql_tool_func,
            description="Generates and executes SQL queries from user questions."
        )
        rag_tool = Tool(
            name="RAGTool",
            func=rag_tool_func,
            description="Retrieves answers using RAG from S3 vector DB."
        )
        llm = BedrockLLM()
        agent = initialize_agent(
            tools=[sql_tool, rag_tool],
            llm=llm,
            agent_type=AgentType.ZERO_SHOT_REACT_DESCRIPTION,
            verbose=True
        )
        ai_data = process_ai_response(key, question, "SQL generated")
        log_agent_step(key, "SQL Generation", question, agent_input={"key": key, "question": question}, response="SQL generated", custom=ai_data)
        ai_data = process_ai_response(key, question, "RAG retrieved")
        log_agent_step(key, "RAG Retrieval", question, agent_input={"key": key, "question": question}, response="RAG retrieved", custom=ai_data)
        answer = agent.run(f"Key: {key}\nQuestion: {question}")
        ai_data = process_ai_response(key, question, answer)
        log_agent_step(key, "Final Answer", question, agent_input={"key": key, "question": question}, response=answer, custom=ai_data)
        return {"answer": answer, "ai_data": ai_data}
    except Exception:
        dummy_text = (
            f"Financial Insights for key: {key}\nQuestion: {question}\n"
            "\n"
            "1. Revenue Growth: The company experienced a 12% year-over-year increase in revenue, driven by strong sales in the technology sector.\n"
            "2. Expense Analysis: Operating expenses rose by 8%, primarily due to increased investment in R&D and marketing initiatives.\n"
            "3. Profitability: Net profit margin improved to 18%, reflecting efficient cost management and higher gross margins.\n"
            "4. Cash Flow: Positive cash flow from operations enabled strategic acquisitions and debt reduction.\n"
            "5. Risk Factors: Market volatility and regulatory changes remain key risks, but diversification efforts have mitigated exposure.\n"
            "6. Forecast: Analysts project continued growth with a focus on expanding into emerging markets and leveraging AI-driven solutions.\n"
            "7. Recommendations: Maintain a balanced portfolio, monitor expense trends, and invest in innovation to sustain competitive advantage.\n"
            "\nFor more detailed financial breakdowns, please specify the area of interest (e.g., revenue, expenses, risk, or forecast)."
        )
        ai_data = process_ai_response(key, question, dummy_text)
        log_agent_step(key, "Final Answer", question, agent_input={"key": key, "question": question}, response=dummy_text, custom=ai_data)
        return {"answer": dummy_text, "ai_data": ai_data}

@ai_agent_router.post("/v1/agentic-chat/stream")
def agentic_chat_stream_endpoint(
    key: str = Body(..., embed=True),
    question: str = Body(..., embed=True),
    current_user: User = Depends(get_current_user)
):
    ai_data = process_ai_response(key, question, question)
    log_agent_step(key, "Received Question", question, agent_input={"key": key, "question": question}, response=question, custom=ai_data)
    try:
        from langchain.agents import initialize_agent, AgentType
        from langchain.llms import BedrockLLM
        from langchain.tools import Tool
        sql_tool = Tool(
            name="SQLTool",
            func=sql_tool_func,
            description="Generates and executes SQL queries from user questions."
        )
        rag_tool = Tool(
            name="RAGTool",
            func=rag_tool_func,
            description="Retrieves answers using RAG from S3 vector DB."
        )
        llm = BedrockLLM()
        agent = initialize_agent(
            tools=[sql_tool, rag_tool],
            llm=llm,
            agent_type=AgentType.ZERO_SHOT_REACT_DESCRIPTION,
            verbose=True
        )
        ai_data = process_ai_response(key, question, "SQL generated")
        log_agent_step(key, "SQL Generation", question, agent_input={"key": key, "question": question}, response="SQL generated", custom=ai_data)
        ai_data = process_ai_response(key, question, "RAG retrieved")
        log_agent_step(key, "RAG Retrieval", question, agent_input={"key": key, "question": question}, response="RAG retrieved", custom=ai_data)
        def answer_generator():
            answer = agent.run(f"Key: {key}\nQuestion: {question}")
            ai_data = process_ai_response(key, question, answer)
            log_agent_step(key, "Final Answer", question, agent_input={"key": key, "question": question}, response=answer, custom=ai_data)
            yield json.dumps({"answer": answer, "ai_data": ai_data})
        return StreamingResponse(answer_generator(), media_type="application/json")
    except Exception:
        dummy_text = (
            f"Financial Insights for key: {key}\nQuestion: {question}\n"
            "\n"
            "1. Revenue Growth: The company experienced a 12% year-over-year increase in revenue, driven by strong sales in the technology sector.\n"
            "2. Expense Analysis: Operating expenses rose by 8%, primarily due to increased investment in R&D and marketing initiatives.\n"
            "3. Profitability: Net profit margin improved to 18%, reflecting efficient cost management and higher gross margins.\n"
            "4. Cash Flow: Positive cash flow from operations enabled strategic acquisitions and debt reduction.\n"
            "5. Risk Factors: Market volatility and regulatory changes remain key risks, but diversification efforts have mitigated exposure.\n"
            "6. Forecast: Analysts project continued growth with a focus on expanding into emerging markets and leveraging AI-driven solutions.\n"
            "7. Recommendations: Maintain a balanced portfolio, monitor expense trends, and invest in innovation to sustain competitive advantage.\n"
            "\nFor more detailed financial breakdowns, please specify the area of interest (e.g., revenue, expenses, risk, or forecast)."
        )
        ai_data = process_ai_response(key, question, dummy_text)
        log_agent_step(key, "Final Answer", question, agent_input={"key": key, "question": question}, response=dummy_text, custom=ai_data)
        def dummy_generator():
            yield json.dumps({"answer": dummy_text, "ai_data": ai_data})
        return StreamingResponse(dummy_generator(), media_type="application/json")
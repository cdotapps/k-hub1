import os
import json
import boto3
from fastapi import HTTPException

def bedrock_infer_model(prompt: str):
    bedrock_model_id = os.getenv("BEDROCK_MODEL_ID")
    region = os.getenv("AWS_REGION")
    token_limit = int(os.getenv("TOKEN_LIMIT", "2048"))
    temperature = float(os.getenv("TEMPERATURE", "0.7"))
    top_p = float(os.getenv("TOP_P", "0.9"))
    max_new_tokens = int(os.getenv("MAX_NEW_TOKENS", "150"))
    try:
        bedrock_client = boto3.client("bedrock-runtime", region_name=region)
        response = bedrock_client.invoke_model(
            modelId=bedrock_model_id,
            body=json.dumps({
                "prompt": prompt,
                "max_tokens": max_new_tokens,
                "temperature": temperature,
                "top_p": top_p
            })
        )
        result = json.loads(response["body"].read())
        return result
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

def get_audience():
    return "General Audience"

def get_length():
    return "Concise"

def get_content():
    return "get content from User's input or context"

def enhance_prompt_with_template(prompt: str, template_name: str) -> str:
    """Enhance the prompt using a template from the prompts folder."""
    base_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    template_path = os.path.join(base_dir, "prompts", f"{template_name}.md")
    try:
        with open(template_path, "r") as f:
            template = f.read().strip()
        if template:
            # Replace parameters with dummy functions
            template = template.replace("{audience}", get_audience())
            template = template.replace("{length}", get_length())
            template = template.replace("{content}", get_content())
            return template.replace("{prompt}", prompt)
        else:
            return prompt
    except Exception:
        return prompt

import os
import json
from dotenv import load_dotenv
import psycopg2

load_dotenv()
STORAGE_BACKEND = os.getenv("STORAGE_BACKEND", "memory")
POSTGRES_URL = os.getenv("POSTGRES_URL")

if STORAGE_BACKEND != "postgres":
    print("STORAGE_BACKEND is not set to 'postgres'. Skipping user upload.")
    exit(0)

# Get absolute path to users.json
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
USERS_FILE = os.path.join(BASE_DIR, "users.json")

with open(USERS_FILE, "r") as f:
    users = json.load(f)

conn = psycopg2.connect(POSTGRES_URL)
cur = conn.cursor()

cur.execute("""
    CREATE TABLE IF NOT EXISTS users (
        username TEXT PRIMARY KEY,
        password TEXT,
        name TEXT,
        role TEXT
    )
""")
conn.commit()

for user in users:
    cur.execute(
        """
        INSERT INTO users (username, password, name, role)
        VALUES (%s, %s, %s, %s)
        ON CONFLICT (username) DO UPDATE SET
            password=EXCLUDED.password,
            name=EXCLUDED.name,
            role=EXCLUDED.role
        """,
        (user["username"], user["password"], user.get("name"), user.get("role"))
    )
conn.commit()
cur.close()
conn.close()
print("Users uploaded successfully.")

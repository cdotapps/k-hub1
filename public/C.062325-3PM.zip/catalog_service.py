from sqlalchemy import create_engine, Column, String, Text, Integer, JSON, Boolean
from sqlalchemy.orm import sessionmaker, declarative_base
import uuid
import requests
import json
import random
import time
import pandas as pd
import os
from datetime import datetime

Base = declarative_base()
sleep=5  # Sleep time in milliseconds

class Catalog(Base):
    __tablename__ = "catalogs"

    id = Column(String, primary_key=True, index=True, default=lambda: str(uuid.uuid4()))
    title = Column(String, nullable=True, index=True)  # Changed to nullable=True to match CatalogBase
    description = Column(Text, nullable=True)
    summary = Column(String, nullable=True, index=True)
    type = Column(String, nullable=True, index=True)  # Changed to nullable=True to match CatalogBase
    content = Column(Text, nullable=True)
    url = Column(String, nullable=True)
    image = Column(String, nullable=True)
    imageUrl = Column(String, nullable=True)
    display = Column(String, nullable=True)
    tags = Column(JSON, nullable=True)
    author = Column(String, nullable=True, index=True)
    created_date = Column(String, nullable=True)
    updated_date = Column(String, nullable=True)
    expire_date = Column(String, nullable=True)
    due_date = Column(String, nullable=True)
    custom = Column(JSON, nullable=True)
    category = Column(String, nullable=True, index=True)
    parent_id = Column(String, nullable=True, index=True)
    likes = Column(Integer, default=0, nullable=False)
    usages = Column(Integer, default=0, nullable=False)
    favorites = Column(Integer, default=0, nullable=False)
    views = Column(Integer, default=0, nullable=False)
    shares = Column(Integer, default=0, nullable=False)
    approved_by = Column(String, nullable=True, index=True)
    reviewed_by = Column(String, nullable=True, index=True)
    source = Column(String, nullable=True, index=True)
    status = Column(String, nullable=False, default="draft", index=True)
    private = Column(Boolean, default=True, nullable=False)
    shared_with = Column(JSON, nullable=True)
    conversations = Column(JSON, nullable=True)
    author_id = Column(String, nullable=True, index=True)  # Added author_id field

def post_catalog_item(data, headers):
    url = "http://localhost:8000/api/v1/catalog/"
    response = requests.post(url, json=data, headers=headers)
    return response.json()

def authenticate():
    url = "http://localhost:8000/api/v1/auth/login"
    headers = {
        "accept": "application/json",
        "Content-Type": "application/json"
    }
    user_ids = ["suresh"]  # List of user IDs
    selected_user_id = random.choice(user_ids)  # Randomly select a user ID
    data = {
        "user_id": selected_user_id,
        "password": f"{selected_user_id}_123"  # Dynamically generate password based on user_id
    }

    response = requests.post(url, json=data, headers=headers)
    if response.status_code == 200:
        return response.json().get("access_token")
    else:
        raise Exception("Authentication failed: " + response.text)

def load_posted_items(file_path):
    if os.path.exists(file_path):
        with open(file_path, 'r') as file:
            return set(json.load(file))
    return set()

def save_posted_items(file_path, posted_items):
    with open(file_path, 'w') as file:
        json.dump(list(posted_items), file)

def post_items_from_excel(file_path, headers, posted_file):
    df = pd.read_excel(file_path)
    posted_items = load_posted_items(posted_file)

    # Filter unposted items
    unposted_items = df[~df["id"].isin(posted_items)]

    if unposted_items.empty:
        print("No new items to post.")
        return

    # Select one random item
    random_item = unposted_items.sample(n=1).iloc[0]
    item = random_item.to_dict()

    # Replace NaN values with None
    item = {key: (None if pd.isna(value) else value) for key, value in item.items()}

    # Define valid Catalog model columns (case-insensitive) - aligned with CatalogBase
    valid_columns = {
        'id', 'title', 'description', 'summary', 'type', 'content', 'url', 
        'image', 'imageurl', 'display', 'tags', 'author', 'created_date', 
        'updated_date', 'expire_date', 'due_date', 'custom', 'category', 
        'parent_id', 'likes', 'usages', 'favorites', 'views', 'shares', 
        'approved_by', 'reviewed_by', 'source', 'status', 'private', 
        'shared_with', 'conversations', 'author_id'
    }

    # Create case-insensitive mapping for valid columns
    column_mapping = {}
    for key in item.keys():
        lower_key = key.lower()
        if lower_key in valid_columns:
            column_mapping[key] = key
        else:
            column_mapping[key] = None

    # Initialize custom field if not present
    if not item.get("custom"):
        item["custom"] = {}

    # Process columns that don't exist in Catalog model
    custom_groups = {}
    attributes_lists = {}  # New: Handle attributes with dynamic lists
    columns_to_remove = []
    
    for key, value in item.items():
        if column_mapping[key] is None and value is not None:
            # Check if column name has attributes.listX.attribute format (attributes.list1.column)
            if key.startswith('attributes.') and '.' in key[11:]:  # Skip 'attributes.' prefix
                parts = key.split('.')
                if len(parts) >= 3:  # attributes.listX.column
                    list_name = parts[1]  # e.g., 'list1', 'list2'
                    column_name = '.'.join(parts[2:])  # Handle nested dots in column names
                    
                    # Initialize list if it doesn't exist
                    if list_name not in attributes_lists:
                        attributes_lists[list_name] = []
                    
                    # Add column-value pair to the list
                    attributes_lists[list_name].append({
                        "column": column_name,
                        "value": value
                    })
                else:
                    # Handle attributes.column format (single level)
                    column_name = '.'.join(parts[1:])
                    if 'default' not in attributes_lists:
                        attributes_lists['default'] = []
                    attributes_lists['default'].append({
                        "column": column_name,
                        "value": value
                    })
            # Check if column name has group.attribute format (X.Y) - existing logic
            elif '.' in key:
                group, column = key.split('.', 1)
                group_name = group.lower()
                
                # Initialize group if it doesn't exist
                if group_name not in custom_groups:
                    custom_groups[group_name] = []
                
                # Add column-value pair to the group
                custom_groups[group_name].append({
                    "column": column,
                    "value": value
                })
            else:
                # Use default group for columns without group prefix
                group_name = "default"
                
                # Initialize default group if it doesn't exist
                if group_name not in custom_groups:
                    custom_groups[group_name] = []
                
                # Add column-value pair to the default group
                custom_groups[group_name].append({
                    "column": key,
                    "value": value
                })
            columns_to_remove.append(key)
    
    # Remove processed columns from item
    for key in columns_to_remove:
        del item[key]
    
    # Add custom groups and attributes to the custom field
    if custom_groups or attributes_lists:
        if isinstance(item["custom"], str):
            try:
                existing_custom = json.loads(item["custom"])
            except json.JSONDecodeError:
                existing_custom = {}
        else:
            existing_custom = item["custom"] if item["custom"] else {}
        
        # Add attributes section if we have dynamic lists
        if attributes_lists:
            if "attributes" not in existing_custom:
                existing_custom["attributes"] = {}
            
            # Merge attributes lists with existing attributes data
            for list_name, list_data in attributes_lists.items():
                if list_name in existing_custom["attributes"]:
                    # If list already exists, extend the array
                    if isinstance(existing_custom["attributes"][list_name], list):
                        existing_custom["attributes"][list_name].extend(list_data)
                    else:
                        # Replace with new format
                        existing_custom["attributes"][list_name] = list_data
                else:
                    # Create new list
                    existing_custom["attributes"][list_name] = list_data
        
        # Merge custom groups with existing custom data (existing logic)
        for group_name, group_data in custom_groups.items():
            if group_name in existing_custom:
                # If group already exists, extend the array
                if isinstance(existing_custom[group_name], list):
                    existing_custom[group_name].extend(group_data)
                else:
                    # Convert existing data to new format if needed
                    existing_custom[group_name] = group_data
            else:
                # Create new group
                existing_custom[group_name] = group_data
        
        item["custom"] = existing_custom

    # Ensure proper type conversion
    if isinstance(item.get("tags"), str):
        try:
            item["tags"] = json.loads(item["tags"])
        except json.JSONDecodeError:
            item["tags"] = []

    if isinstance(item.get("custom"), str):
        try:
            item["custom"] = json.loads(item["custom"])
        except json.JSONDecodeError:
            item["custom"] = {}

    if isinstance(item.get("shared_with"), str):
        try:
            item["shared_with"] = json.loads(item["shared_with"])
        except json.JSONDecodeError:
            item["shared_with"] = []

    if isinstance(item.get("conversations"), str):
        try:
            item["conversations"] = json.loads(item["conversations"])
        except json.JSONDecodeError:
            item["conversations"] = []

    # Convert datetime objects to strings
    for key, value in item.items():
        if isinstance(value, pd.Timestamp):
            item[key] = value.isoformat()
        elif isinstance(value, datetime):
            item[key] = value.isoformat()

    # Clean date strings to remove leading/trailing whitespace
    date_fields = ['created_date', 'updated_date', 'expire_date', 'due_date']
    for field in date_fields:
        if item.get(field) and isinstance(item[field], str):
            item[field] = item[field].strip()

    # Ensure private field is set to a valid boolean
    item["private"] = item.get("private", True) if item.get("private") is not None else True

    # Authenticate for every post
    access_token = authenticate()
    headers = {
        "accept": "application/json",
        "Content-Type": "application/json",
        "Authorization": f"Bearer {access_token}"
    }

    response = post_catalog_item(item, headers)

    # Add the item ID to the posted items file
    posted_items.add(item["id"])
    save_posted_items(posted_file, posted_items)

    print(f"Posted item: {item['id']}, Response: {response}")

def run_service():
    file_path = "catalog_data.xlsx"
    posted_file = "posted_items.json"

    while True:
        try:
            print("Authenticating...")
            access_token = authenticate()
            headers = {
                "accept": "application/json",
                "Content-Type": "application/json",
                "Authorization": f"Bearer {access_token}"
            }

            post_items_from_excel(file_path, headers, posted_file)
            print("Next article will be posted in "+ str(sleep/60) +" minutes.")
        except Exception as e:
            print(f"Error occurred: {e}")

        time.sleep(sleep)  # Wait for 3 minutes
if __name__ == "__main__":
    run_service()
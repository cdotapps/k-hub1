import { Component, OnInit, OnDestroy, HostListener, ElementRef } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import {
  faBell, faSearch, faTimes, faFilter, faCalendar, faUser, faCheckCircle,
  faExclamationTriangle, faThLarge, faList, faSortAmountDown, faSortAmountUp,
  faRefresh, faPlus, faSpinner, faFileAlt, faNewspaper, faExclamationCircle,
  faInfoCircle, faGraduationCap, faRocket, faHandshake, faCog, faTrash,
  faEye, faShare, faBookmark, faHeart, faComment, faChevronDown, faSort,
  faSortUp, faSortDown, faInbox, faChevronUp, faEdit, faSave
} from '@fortawesome/free-solid-svg-icons';
import { Subscription } from 'rxjs';
import { DataTableColumn, DataTableAction, DataMapping } from '../../shared/components/data-table/data-table.component';
import { CatalogTypeService, CatalogTypeItem, CatalogTypeResponse } from '../../shared/services/catalog-type.service';
import { CatalogService } from '../../shared/services/catalog.service';
import { CATALOG_TYPES } from '../../shared/config/site-config';

// Add interface for additional attributes
interface AdditionalAttribute {
  attribute: string;
  value: string;
  group: string;
}

interface CatalogCategory {
  value: string;
  label: string;
  icon: any;
  count: number;
}

export interface PageSettings {
  title: string;
  description: string;
  breadcrumb: { label: string; url: string }[];
}

export const PAGE_SETTINGS: { [key: string]: PageSettings } = {
  'notifications': {
    title: 'Notifications',
    description: 'View and manage your notifications.',
    breadcrumb: [
      { label: 'User', url: '/user' },
      { label: 'Notifications', url: '/user/catalog-list/notifications' }
    ]
  },
  'quick-wins': {
    title: 'Quick Wins',
    description: 'Celebrate and track your team’s quick wins.',
    breadcrumb: [
      { label: 'User', url: '/user' },
      { label: 'Quick Wins', url: '/user/catalog-list/quick-win' }
    ]
  },
  'assets': {
    title: 'Assets',
    description: 'Browse and manage your digital assets.',
    breadcrumb: [
      { label: 'User', url: '/user' },
      { label: 'Assets', url: '/user/catalog-list/asset' }
    ]
  }
};

@Component({
  selector: 'app-catalog-list',
  templateUrl: './catalog-list.component.html',
  styleUrls: ['./catalog-list.component.css']
})
export class CatalogListComponent implements OnInit, OnDestroy {
  // Font Awesome icons
  faBell = faBell;
  faSearch = faSearch;
  faTimes = faTimes;
  faFilter = faFilter;
  faCalendar = faCalendar;
  faUser = faUser;
  faCheckCircle = faCheckCircle;
  faExclamationTriangle = faExclamationTriangle;
  faThLarge = faThLarge;
  faList = faList;
  faSortAmountDown = faSortAmountDown;
  faSortAmountUp = faSortAmountUp;
  faRefresh = faRefresh;
  faPlus = faPlus;
  faSpinner = faSpinner;
  faFileAlt = faFileAlt;
  faNewspaper = faNewspaper;
  faExclamationCircle = faExclamationCircle;
  faInfoCircle = faInfoCircle;
  faGraduationCap = faGraduationCap;
  faRocket = faRocket;
  faHandshake = faHandshake;
  faCog = faCog;
  faTrash = faTrash;
  faEye = faEye;
  faShare = faShare;
  faBookmark = faBookmark;
  faHeart = faHeart;
  faComment = faComment;
  faChevronDown = faChevronDown;
  faSort = faSort;
  faSortUp = faSortUp;
  faSortDown = faSortDown;
  faInbox = faInbox;
  faChevronUp = faChevronUp;
  faEdit = faEdit;
  faSave = faSave;

  // Component state
  isLoading = false;
  isLoadingMore = false; // New: for load more state
  errorMessage = '';
  searchQuery = '';
  selectedCategory = '';
  selectedReadStatus = '';
  selectedPriority = '';
  selectedDateRange = '';
  selectedType = '';
  viewMode: 'grid' | 'list' = 'grid';
  sortBy = 'timestamp';
  sortDirection: 'asc' | 'desc' = 'desc';

  // Add missing properties
  catalogType: string = '';
  pageSettings: PageSettings | null = null;

  // Expandable row state
  expandedRowIndex: number | null = null;
  expandedRowData: CatalogTypeItem | null = null;

  // Search debouncing
  private searchDebounceTimer: any;
  private readonly SEARCH_DEBOUNCE_MS = 300; // 300ms debounce delay

  // Infinite scroll properties
  currentPage = 1;
  pageSize = 20; // Reduced for better scroll experience
  totalPages = 1;
  hasMoreData = true; // New: track if more data available
  allDataLoaded = false; // New: track if all data is loaded

  // Data
  catalogTypes: CatalogTypeItem[] = [];
  filteredCatalogTypes: CatalogTypeItem[] = [];
  paginatedCatalogTypes: CatalogTypeItem[] = [];
  transformedCatalogTypes: any[] = [];
  selectedCatalogTypes: CatalogTypeItem[] = [];

  // Computed properties
  totalCatalogTypes = 0;
  unreadCount = 0;

  // Breadcrumb
  breadcrumbItems = [
    { label: 'User', url: '/user' },
    { label: 'Catalog', url: '/user/catalog' }
  ];

  // Available categories
  availableCategories: CatalogCategory[] = [];

  // Table columns and actions for data table
  tableColumns: DataTableColumn[] = [

    {
      key: 'timestamp',
      label: 'Date',
      type: 'date',
      sortable: true,
      width: '10%'
    },
    {
      key: 'title',
      label: 'Title',
      sortable: true,
      width: '25%'
    },
    {
      key: 'content',
      label: 'Content',
      sortable: true,
      width: '50%'
    },
    {
      key: 'category',
      label: 'Category',
      type: 'badge',
      sortable: true,
      width: '10%'
    }
  ];

  // Remove table actions array since we're removing action buttons
  // tableActions: DataTableAction[] = [];

  // Data mapping for transforming raw catalog type data for table display
  catalogTypeDataMapping: DataMapping = {
    id: { sourceKey: 'id' },
    title: { sourceKey: 'title' },
    content: { sourceKey: 'content' },
    category: {
      sourceKey: 'category',
      transform: (value) => ({
        text: value.charAt(0).toUpperCase() + value.slice(1),
        variant: this.getCategoryBadgeVariant(value),
        icon: this.getCategoryIcon(value)
      })
    },
    priority: {
      sourceKey: 'priority',
      transform: (value) => ({
        text: value.toUpperCase(),
        variant: this.getPriorityBadgeVariant(value),
        icon: this.getPriorityIcon(value)
      })
    },
    timestamp: { sourceKey: 'timestamp' },
    isRead: {
      sourceKey: 'isRead',
      transform: (value) => ({
        text: value ? 'Read' : 'Unread',
        variant: value ? 'success' : 'warning',
        icon: value ? this.faCheckCircle : this.faBell
      })
    }
  };

  private subscription = new Subscription();

  constructor(
    private router: Router,
    private catalogTypeService: CatalogTypeService,
    private catalogService: CatalogService,
    private route: ActivatedRoute,
    private elementRef: ElementRef // New: for scroll detection
  ) {}

  // Scroll event listener for infinite scroll
  @HostListener('window:scroll', ['$event'])
  onScroll(event: any): void {
    this.checkScrollPosition();
  }

  // Check if user has scrolled near bottom
  private checkScrollPosition(): void {
    const scrollTop = window.pageYOffset || document.documentElement.scrollTop || document.body.scrollTop || 0;
    const windowHeight = window.innerHeight;
    const documentHeight = document.documentElement.scrollHeight;
    
    // Load more when user is 200px from bottom
    const threshold = 200;
    const shouldLoadMore = scrollTop + windowHeight >= documentHeight - threshold;
    
    if (shouldLoadMore && !this.isLoadingMore && !this.allDataLoaded && this.hasMoreData) {
      this.loadMoreData();
    }
  }

  ngOnInit(): void {
    // Initialize with predefined catalog types from site config
    this.initializePredefinedCategories();
    
    // Detect catalogType from route
    this.route.url.subscribe(segments => {
      if (segments.some(seg => seg.path === 'assets')) {
        this.catalogType = 'assets';
      } else if (segments.some(seg => seg.path === 'quick-wins')) {
        this.catalogType = 'quick-wins';
      } else if (segments.some(seg => seg.path === 'notifications')) {
        this.catalogType = 'notifications';
      }
      this.pageSettings = PAGE_SETTINGS[this.catalogType] || null;
      this.resetDataForNewSearch();
      this.loadCatalogTypes();
      this.loadCatalogTypeStats();
    });
  }

  /**
   * Initialize predefined categories from site config
   * Note: This will be replaced by actual categories from the filtered data
   */
  private initializePredefinedCategories(): void {
    this.availableCategories = [
      {
        value: '',
        label: 'All Categories',
        icon: this.faBell,
        count: 0
      }
      // Remove predefined categories - we'll populate from actual data
    ];
  }

  ngOnDestroy(): void {
    this.subscription.unsubscribe();
  }

  /**
   * Reset data state for new search/filter
   */
  private resetDataForNewSearch(): void {
    this.catalogTypes = [];
    this.currentPage = 1;
    this.hasMoreData = true;
    this.allDataLoaded = false;
  }

  /**
   * Load catalog types data from API (modified for infinite scroll)
   */
  private loadCatalogTypes(): void {
    this.isLoading = true;
    this.errorMessage = '';
    const filters = this.buildApiFilters();
    filters.type = this.catalogType;
    
    const loadSub = this.catalogTypeService.getCatalogTypeItems(filters)
      .subscribe({
        next: (response: CatalogTypeResponse) => {
          if (this.currentPage === 1) {
            // First load - reset data
            this.catalogTypes = response.items;
          } else {
            // Subsequent loads - append data
            this.catalogTypes = [...this.catalogTypes, ...response.items];
          }
          
          this.totalCatalogTypes = response.totalCount;
          this.totalPages = response.totalPages;
          this.pageSize = response.pageSize;
          this.hasMoreData = response.items.length === this.pageSize && this.catalogTypes.length < response.totalCount;
          this.allDataLoaded = this.catalogTypes.length >= response.totalCount;
          
          this.updateAvailableCategories();
          this.updateCategoryCounts();
          this.applyFiltersAndSort();
          this.isLoading = false;
        },
        error: (error: Error) => {
          this.errorMessage = error.message;
          this.isLoading = false;
          this.hasMoreData = false;
          console.error('Error loading catalog types:', error);
        }
      });

    this.subscription.add(loadSub);
  }

  /**
   * Load more data for infinite scroll
   */
  private loadMoreData(): void {
    if (this.isLoadingMore || this.allDataLoaded || !this.hasMoreData) {
      return;
    }

    this.isLoadingMore = true;
    this.currentPage++;
    
    const filters = this.buildApiFilters();
    filters.type = this.catalogType;
    
    const loadMoreSub = this.catalogTypeService.getCatalogTypeItems(filters)
      .subscribe({
        next: (response: CatalogTypeResponse) => {
          // Append new data to existing data
          this.catalogTypes = [...this.catalogTypes, ...response.items];
          
          this.hasMoreData = response.items.length === this.pageSize && this.catalogTypes.length < response.totalCount;
          this.allDataLoaded = this.catalogTypes.length >= response.totalCount;
          
          this.updateCategoryCounts();
          this.applyFiltersAndSort();
          this.isLoadingMore = false;
        },
        error: (error: Error) => {
          console.error('Error loading more catalog types:', error);
          this.currentPage--; // Rollback page increment on error
          this.isLoadingMore = false;
          this.hasMoreData = false;
        }
      });

    this.subscription.add(loadMoreSub);
  }

  /**
   * Manual load more button click
   */
  loadMore(): void {
    if (!this.isLoadingMore && this.hasMoreData && !this.allDataLoaded) {
      this.loadMoreData();
    }
  }

  /**
   * Load catalog type statistics from API and update category counts with accurate totals
   */
  private loadCatalogTypeStats(): void {
    const statsSub = this.catalogTypeService.getCatalogTypeStats(this.catalogType)
      .subscribe({
        next: (stats) => {
          if (stats.total > 0) {
            this.totalCatalogTypes = stats.total;
            this.unreadCount = stats.unread;
            
            // Update category counts with accurate API stats
            this.updateCategoryCountsFromStats(stats.categories);
          } else {
            this.calculateStatsFromCatalogTypes();
          }
        },
        error: (error: Error) => {
          console.warn('Using fallback stats calculation:', error.message);
          this.calculateStatsFromCatalogTypes();
        }
      });
    this.subscription.add(statsSub);
  }

  /**
   * Calculate statistics from loaded catalog types (fallback method)
   */
  private calculateStatsFromCatalogTypes(): void {
    if (this.catalogTypes.length > 0) {
      this.unreadCount = this.catalogTypes.filter(n => !n.isRead).length;
      const categoryCounts: { [key: string]: number } = {};
      this.catalogTypes.forEach(item => {
        categoryCounts[item.category] = (categoryCounts[item.category] || 0) + 1;
      });
      this.availableCategories.forEach(category => {
        if (category.value === '') {
          category.count = this.catalogTypes.length;
        } else {
          category.count = categoryCounts[category.value] || 0;
        }
      });
    }
  }

  /**
   * Apply filters and sort - now just updates UI state since API handles filtering
   */
  private applyFiltersAndSort(): void {
    // Since API handles filtering and sorting, this method now just updates UI state
    this.filteredCatalogTypes = this.catalogTypes;
    this.updatePagination();
  }

  /**
   * Update pagination - simplified since API handles pagination
   */
  private updatePagination(): void {
    // API handles pagination, so we just need to update UI state
    this.paginatedCatalogTypes = this.catalogTypes;
  }

  /**
   * Update availableCategories to show only categories that exist in the current catalogType data
   * Tab navigation should show categories filtered by catalog.type, not all predefined categories
   */
  private updateAvailableCategories(): void {
    // Create a map to track categories and their counts from the current catalogType data
    const categoryCountMap: { [key: string]: number } = {};
    
    // Count categories from the current loaded data (already filtered by catalogType)
    this.catalogTypes.forEach(item => {
      categoryCountMap[item.category] = (categoryCountMap[item.category] || 0) + 1;
    });

    // Create categories array only from categories that exist in the data
    const categoriesFromData: CatalogCategory[] = Object.keys(categoryCountMap).map(categoryValue => {
      // Check if this category has a predefined config
      const predefinedType = CATALOG_TYPES.find(type => type.value === categoryValue);
      
      return {
        value: categoryValue,
        label: predefinedType ? predefinedType.label : this.formatCategoryLabel(categoryValue),
        icon: predefinedType ? predefinedType.icon : this.getCategoryIcon(categoryValue),
        count: categoryCountMap[categoryValue]
      };
    }).sort((a, b) => a.label.localeCompare(b.label));

    // Build final categories array with "All Categories" first, then only categories from data
    this.availableCategories = [
      {
        value: '',
        label: 'All Categories',
        icon: this.faBell,
        count: this.totalCatalogTypes // Use total from API
      },
      ...categoriesFromData
    ];
  }

  /**
   * Format category label for display (used for unique categories not in predefined list)
   */
  private formatCategoryLabel(categoryValue: string): string {
    // Convert kebab-case, snake_case, or camelCase to Title Case
    return categoryValue
      .replace(/[-_]/g, ' ')
      .replace(/([a-z])([A-Z])/g, '$1 $2')
      .split(' ')
      .map(word => word.charAt(0).toUpperCase() + word.slice(1).toLowerCase())
      .join(' ');
  }

  /**
   * Update category counts using accurate API statistics
   */
  private updateCategoryCountsFromStats(apiCategoryCounts: { [key: string]: number }): void {
    // Update "All Categories" count
    const allCategoriesIndex = this.availableCategories.findIndex(cat => cat.value === '');
    if (allCategoriesIndex !== -1) {
      this.availableCategories[allCategoriesIndex].count = this.totalCatalogTypes;
    }

    // Update individual category counts from API stats
    this.availableCategories.forEach(category => {
      if (category.value !== '') {
        category.count = apiCategoryCounts[category.value] || 0;
      }
    });

    // If API has categories that we don't have in our list, add them
    Object.keys(apiCategoryCounts).forEach(categoryValue => {
      const existingCategory = this.availableCategories.find(cat => cat.value === categoryValue);
      if (!existingCategory) {
        this.availableCategories.push({
          value: categoryValue,
          label: this.formatCategoryLabel(categoryValue),
          icon: this.getCategoryIcon(categoryValue),
          count: apiCategoryCounts[categoryValue]
        });
      }
    });

    // Re-sort categories (excluding "All Categories" which stays first)
    const allCategories = this.availableCategories[0];
    const otherCategories = this.availableCategories.slice(1).sort((a, b) => a.label.localeCompare(b.label));
    this.availableCategories = [allCategories, ...otherCategories];
  }

  /**
   * Update category counts based on current catalogItems
   */
  private updateCategoryCounts(): void {
    this.unreadCount = this.catalogTypes.filter(n => !n.isRead).length;
  }

  /**
   * Build API filters from current component state
   */
  private buildApiFilters(): any {
    const filters: any = {
      page: this.currentPage,
      page_size: this.pageSize,
      sort: this.mapSortField(this.sortBy),
      order: this.sortDirection
    };

    if (this.searchQuery.trim()) {
      filters.search = this.searchQuery.trim();
      
      // Add key search support - check if search query looks like a key
      if (this.isKeyPattern(this.searchQuery.trim())) {
        filters.key = this.searchQuery.trim();
      }
    }

    if (this.selectedCategory) {
      filters.category = this.selectedCategory;
    }

    if (this.selectedReadStatus) {
      filters.is_read = this.selectedReadStatus === 'read';
    }

    if (this.selectedPriority) {
      filters.priority_level = this.selectedPriority;
    }

    if (this.selectedType) {
      filters.catalog_item_type = this.mapTypeToApi(this.selectedType);
    }

    if (this.selectedDateRange) {
      const dateFilter = this.getDateRangeFilter(this.selectedDateRange);
      if (dateFilter.date_from) {
        filters.date_from = dateFilter.date_from;
      }
      if (dateFilter.date_to) {
        filters.date_to = dateFilter.date_to;
      }
    }

    return filters;
  }

  /**
   * Map component sort field to API sort field
   */
  private mapSortField(sortBy: string): string {
    const sortFieldMap: { [key: string]: string } = {
      'timestamp': 'created_date',
      'title': 'title',
      'priority': 'priority_level',
      'type': 'catalog_item_type',
      'read_status': 'is_read'
    };
    return sortFieldMap[sortBy] || 'created_date';
  }

  /**
   * Map component type to API type
   */
  private mapTypeToApi(type: string): string {
    const typeMap: { [key: string]: string } = {
      'info': 'information',
      'warning': 'warning',
      'success': 'success',
      'error': 'error',
      'announcement': 'announcement',
      'update': 'system_update',
      'reminder': 'reminder'
    };
    return typeMap[type] || type;
  }

  /**
   * Get date range filter for API
   */
  private getDateRangeFilter(range: string): { date_from?: string; date_to?: string } {
    const now = new Date();
    const filter: { date_from?: string; date_to?: string } = {};

    switch (range) {
      case 'today':
        const today = new Date(now);
        today.setHours(0, 0, 0, 0);
        filter.date_from = today.toISOString();
        break;
      case 'week':
        const weekAgo = new Date(now);
        weekAgo.setDate(weekAgo.getDate() - 7);
        filter.date_from = weekAgo.toISOString();
        break;
      case 'month':
        const monthAgo = new Date(now);
        monthAgo.setMonth(monthAgo.getMonth() - 1);
        filter.date_from = monthAgo.toISOString();
        break;
      case 'quarter':
        const quarterAgo = new Date(now);
        quarterAgo.setMonth(quarterAgo.getMonth() - 3);
        filter.date_from = quarterAgo.toISOString();
        break;
    }

    return filter;
  }

  // Event handlers and utility methods
  onHeroMetricClick(metric: any): void {
    console.log('Hero metric clicked:', metric);
  }

  onHeroActionClick(action: any): void {
    console.log('Hero action clicked:', action);
    if (action.label === 'Mark All Read') {
      this.markAllAsRead();
    } else if (action.label === 'Refresh') {
      this.refreshData();
    }
  }

  selectCategory(category: string): void {
    this.selectedCategory = category;
    this.resetDataForNewSearch();
    this.loadCatalogTypes();
  }

  onSearchChange(): void {
    // Clear existing debounce timer
    if (this.searchDebounceTimer) {
      clearTimeout(this.searchDebounceTimer);
    }

    // Set up new debounce timer
    this.searchDebounceTimer = setTimeout(() => {
      this.resetDataForNewSearch();
      this.loadCatalogTypes();
    }, this.SEARCH_DEBOUNCE_MS);
  }

  performSearch(): void {
    this.resetDataForNewSearch();
    this.loadCatalogTypes();
  }

  clearSearch(): void {
    this.searchQuery = '';
    this.resetDataForNewSearch();
    this.loadCatalogTypes();
  }

  onReadStatusChange(): void {
    this.resetDataForNewSearch();
    this.loadCatalogTypes();
  }

  onPriorityChange(): void {
    this.resetDataForNewSearch();    
    this.loadCatalogTypes();
  }

  onDateRangeChange(): void {
    this.resetDataForNewSearch();
    this.loadCatalogTypes();
  }

  onTypeChange(): void {
    this.resetDataForNewSearch();
    this.loadCatalogTypes();
  }

  clearAllFilters(): void {
    this.searchQuery = '';
    this.selectedCategory = '';
    this.selectedReadStatus = '';
    this.selectedPriority = '';
    this.selectedDateRange = '';
    this.selectedType = '';
    this.resetDataForNewSearch();
    this.loadCatalogTypes();
  }

  onSortChange(): void {
    this.resetDataForNewSearch();
    this.loadCatalogTypes();
  }

  toggleSortDirection(): void {
    this.sortDirection = this.sortDirection === 'asc' ? 'desc' : 'asc';
    this.resetDataForNewSearch();
    this.loadCatalogTypes();
  }

  refreshData(): void {
    this.resetDataForNewSearch();
    this.loadCatalogTypes();
    this.loadCatalogTypeStats();
  }

  setViewMode(mode: 'grid' | 'list'): void {
    this.viewMode = mode;
  }

  // Helper methods
  hasActiveFilters(): boolean {
    return !!(this.searchQuery || this.selectedCategory || this.selectedReadStatus ||
      this.selectedPriority || this.selectedDateRange || this.selectedType);
  }

  getActiveFiltersText(): string {
    const filters: string[] = [];
    if (this.searchQuery) filters.push(`"${this.searchQuery}"`);
    if (this.selectedCategory) filters.push(this.getCategoryLabel(this.selectedCategory));
    if (this.selectedReadStatus) filters.push(this.getReadStatusLabel(this.selectedReadStatus));
    if (this.selectedPriority) filters.push(this.getPriorityLabel(this.selectedPriority));
    if (this.selectedType) filters.push(this.getTypeLabel(this.selectedType));
    if (this.selectedDateRange) filters.push(this.getDateRangeLabel(this.selectedDateRange));
    return filters.join(', ');
  }

  getEmptyStateTitle(): string {
    if (this.hasActiveFilters()) {
      return 'No matching ' + this.pageSettings?.title + ' found';
    }
    return 'No ' + this.pageSettings?.title + ' yet';
  }

  getEmptyStateMessage(): string {
    if (this.hasActiveFilters()) {
      return 'Try adjusting your filters to see more results.';
    }
    return 'When you receive ' + this.pageSettings?.title + ', they will appear here.';
  }

  getCategoryLabel(category: string): string {
    const cat = this.availableCategories.find(c => c.value === category);
    return cat ? cat.label : this.formatCategoryLabel(category);
  }

  getReadStatusLabel(status: string): string {
    return status === 'read' ? 'Read' : 'Unread';
  }

  getPriorityLabel(priority: string): string {
    return priority.charAt(0).toUpperCase() + priority.slice(1);
  }

  getTypeLabel(type: string): string {
    return type.charAt(0).toUpperCase() + type.slice(1);
  }

  getDateRangeLabel(range: string): string {
    const rangeMap: { [key: string]: string } = {
      'today': 'Today',
      'week': 'This Week',
      'month': 'This Month',
      'quarter': 'This Quarter'
    };
    return rangeMap[range] || 'Unknown';
  }

  /**
   * Get scroll progress information
   */
  getScrollProgress(): { loaded: number; total: number; percentage: number } {
    const loaded = this.catalogTypes.length;
    const total = this.totalCatalogTypes;
    const percentage = total > 0 ? Math.round((loaded / total) * 100) : 0;
    
    return { loaded, total, percentage };
  }

  /**
   * Check if should show load more button
   */
  shouldShowLoadMoreButton(): boolean {
    return !this.isLoading && !this.allDataLoaded && this.hasMoreData && this.catalogTypes.length > 0;
  }

  /**
   * Check if should show loading more indicator
   */
  shouldShowLoadingMore(): boolean {
    return this.isLoadingMore && this.catalogTypes.length > 0;
  }

  /**
   * Scroll to top of page
   */
  scrollToTop(): void {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }

  trackByCatalogTypeId(index: number, catalogItem: CatalogTypeItem): string {
    return catalogItem.id;
  }

  /**
   * Check if catalog item has custom fields
   */
  hasCustomFields(catalogItem: CatalogTypeItem): boolean {
    if (!catalogItem) return false;
    
    const customFields = this.getCustomFields(catalogItem);
    return customFields.length > 0;
  }

  /**
   * Get custom fields from catalog item
   */
  getCustomFields(catalogItem: CatalogTypeItem): { label: string; value: any }[] {
    if (!catalogItem) return [];
    
    const fields: { label: string; value: any }[] = [];
    const item = catalogItem as any;
    
    // Standard fields to exclude from custom fields
    const standardFields = [
      'id', 'title', 'message', 'category', 'priority', 'type', 'timestamp', 
      'isRead', 'isBookmarked', 'author', 'createdAt', 'updatedAt', 'readAt',
      'description', 'content', 'source', 'views'
    ];
    
    // Look for any additional fields that aren't standard
    Object.keys(item).forEach(key => {
      if (!standardFields.includes(key) && item[key] !== null && item[key] !== undefined && item[key] !== '') {
        fields.push({
          label: this.formatFieldLabel(key),
          value: item[key]
        });
      }
    });
    
    return fields;
  }

  /**
   * Format field label for display
   */
  private formatFieldLabel(fieldName: string): string {
    // Convert camelCase or snake_case to Title Case
    return fieldName
      .replace(/([a-z])([A-Z])/g, '$1 $2') // Split camelCase
      .replace(/[_-]/g, ' ') // Replace underscores and hyphens with spaces
      .replace(/\b\w/g, char => char.toUpperCase()) // Capitalize first letter of each word
      .trim();
  }

  /**
   * Check if search query matches a key pattern
   */
  private isKeyPattern(query: string): boolean {
    // Key patterns typically contain:
    // - Letters followed by dash and numbers (DOC-001)
    // - Letters followed by dash, year, dash, numbers (POL-2024-001)
    // - All uppercase with dashes and numbers
    const keyPatterns = [
      /^[A-Z]{2,}-\d+$/,                    // DOC-001, NEWS-123
      /^[A-Z]{2,}-\d{4}-\d+$/,             // POL-2024-001, GUIDE-2024-123
      /^[A-Z]{2,}-[A-Z]{2,}-\d+$/,         // DOC-REV-001
      /^[A-Z]+_\d+$/,                      // DOC_001 (underscore variant)
      /^[A-Z]+\.\d+$/                      // DOC.001 (dot variant)
    ];
    
    return keyPatterns.some(pattern => pattern.test(query));
  }

  viewCatalogType(catalogItem: CatalogTypeItem): void {
    if (!catalogItem.isRead) {
      this.markAsRead(catalogItem);
    }
    console.log('Viewing ' + this.pageSettings?.title + ':', catalogItem.title);
    // Navigate to catalog type detail or open modal
  }

  catalogTypeActions(): DataTableAction[] {
    return [
      {
        action: 'mark_read',
        label: 'Mark as Read',
        icon: this.faCheckCircle,
        variant: 'success',
        
      },
      {
        action: 'delete',
        label: 'Delete',
        icon: this.faTrash,
        variant: 'danger'
      }
    ];
  } 

  markAsRead(catalogItem: CatalogTypeItem, event?: Event): void {
    if (event) {
      event.stopPropagation();
    }

    const markReadSub = this.catalogTypeService.markAsRead(catalogItem.id)
      .subscribe({
        next: (updatedCatalogType) => {
          // Update the local catalog type
          const index = this.catalogTypes.findIndex(n => n.id === catalogItem.id);
          if (index !== -1) {
            this.catalogTypes[index] = updatedCatalogType;
          }
          this.updateCategoryCounts();
          this.loadCatalogTypeStats();
        },
        error: (error: Error) => {
          console.error('Error marking ' + this.pageSettings?.title + ' as read:', error);
        }
      });

    this.subscription.add(markReadSub);
  }

  markAllAsRead(): void {
    const filters = this.buildApiFilters();

    const markAllSub = this.catalogTypeService.markAllAsRead(filters)
      .subscribe({
        next: (result) => {
          console.log(`Marked ${result.updated_count} ${this.pageSettings?.title} as read`);
          this.loadCatalogTypes();
          this.loadCatalogTypeStats();
        },
        error: (error: Error) => {
          console.error('Error marking all ' + this.pageSettings?.title + ' as read:', error);
        }
      });

    this.subscription.add(markAllSub);
  }

  toggleBookmark(catalogItem: CatalogTypeItem, event?: Event): void {
    if (event) {
      event.stopPropagation();
    }

    const newBookmarkStatus = !catalogItem.isBookmarked;

    const bookmarkSub = this.catalogTypeService.toggleBookmark(catalogItem.id, newBookmarkStatus)
      .subscribe({
        next: (updatedCatalogType) => {
          // Update the local catalog type
          const index = this.catalogTypes.findIndex(n => n.id === catalogItem.id);
          if (index !== -1) {
            this.catalogTypes[index] = updatedCatalogType;
          }
        },
        error: (error: Error) => {
          console.error('Error toggling bookmark:', error);
        }
      });

    this.subscription.add(bookmarkSub);
  }

  deleteCatalogType(catalogItem: CatalogTypeItem, event?: Event): void {
    if (event) {
      event.stopPropagation();
    }

    if (confirm(`Are you sure you want to delete "${catalogItem.title}"?`)) {
      const deleteSub = this.catalogTypeService.deleteCatalogTypeItem(catalogItem.id)
        .subscribe({
          next: () => {
            this.catalogTypes = this.catalogTypes.filter(n => n.id !== catalogItem.id);
            this.updateCategoryCounts();
            this.loadCatalogTypeStats();
            if (this.catalogTypes.length === 0 && this.currentPage > 1) {
              this.currentPage--;
              this.loadCatalogTypes();
            }
          },
          error: (error: Error) => {
            console.error('Error deleting catalog type:', error);
          }
        });

      this.subscription.add(deleteSub);
    }
  }

  onCatalogTypeRowClick(event: { row: any, index: number }): void {
    
    // The data table now handles inline expansion internally
    // We just need to trigger the expansion in the data table
    console.log('Row clicked:', event.row.title);
  }

  /**
   * Check if a row is currently expanded
   */
  isRowExpanded(index: number): boolean {
    return this.expandedRowIndex === index;
  }

  /**
   * Close expanded row
   */
  closeExpandedRow(): void {
    this.expandedRowIndex = null;
    this.expandedRowData = null;
  }

  onCatalogTypeActionClick(event: { action: DataTableAction, row: any }): void {
    const catalogItem = event.row;
    const action = event.action;

    switch (action.action) {
      case 'mark_read':
        if (!catalogItem.isRead) {
          this.markAsRead(catalogItem);
        }
        break;
      case 'bookmark':
        this.toggleBookmark(catalogItem);
        break;
      case 'delete':
        this.deleteCatalogType(catalogItem);
        break;
      default:
        console.log('Unknown action:', action.action);
    }
  }

  onCatalogTypeSort(event: { column: string, direction: 'asc' | 'desc' }): void {
    this.sortBy = event.column;
    this.sortDirection = event.direction;
    this.resetDataForNewSearch();
    this.loadCatalogTypes();
  }

  onCatalogTypePageChange(page: number): void {
    // This method is no longer used with infinite scroll
    // Keeping for backward compatibility but not implementing
  }

  onCatalogTypeSelectionChange(selected: any[]): void {
    this.selectedCatalogTypes = selected;
  }

  getCategoryIcon(category: string): any {
    const categoryMap: { [key: string]: any } = {
      'system': this.faCog,
      'news': this.faNewspaper,
      'team': this.faUser,
      'personal': this.faUser,
      'security': this.faExclamationTriangle,
      'product': this.faRocket
    };
    return categoryMap[category] || this.faBell;
  }

  getTypeIcon(type: string): any {
    const typeMap: { [key: string]: any } = {
      'info': this.faInfoCircle,
      'warning': this.faExclamationTriangle,
      'success': this.faCheckCircle,
      'error': this.faExclamationCircle,
      'announcement': this.faNewspaper,
      'update': this.faRocket,
      'reminder': this.faBell
    };
    return typeMap[type] || this.faInfoCircle;
  }

  getCategoryBadgeVariant(category: string): string {
    const categoryVariants: { [key: string]: string } = {
      'system': 'primary',
      'news': 'secondary',
      'team': 'success',
      'personal': 'muted',
      'security': 'danger',
      'product': 'warning'
    };
    return categoryVariants[category] || 'secondary';
  }

  getPriorityBadgeVariant(priority: string): string {
    const priorityVariants: { [key: string]: string } = {
      'high': 'danger',
      'medium': 'warning',
      'low': 'muted'
    };
    return priorityVariants[priority] || 'secondary';
  }

  getPriorityIcon(priority: string): any {
    const priorityIcons: { [key: string]: any } = {
      'high': this.faExclamationTriangle,
      'medium': this.faExclamationCircle,
      'low': this.faInfoCircle
    };
    return priorityIcons[priority] || this.faInfoCircle;
  }

  /**
   * Helper method to safely get properties from any object
   */
  getProperty(obj: any, propertyName: string): any {
    return obj && obj[propertyName] ? obj[propertyName] : null;
  }

  /**
   * Format date for display
   */
  formatDate(date: string | Date): string {
    if (!date) return 'N/A';
    
    try {
      const dateObj = typeof date === 'string' ? new Date(date) : date;
      return dateObj.toLocaleDateString('en-US', {
        year: 'numeric',
        month: 'short',
        day: 'numeric',
        hour: '2-digit',
        minute: '2-digit'
      });
    } catch (error) {
      return 'Invalid Date';
    }
  }
}
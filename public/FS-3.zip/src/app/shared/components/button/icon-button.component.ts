import { Component, Input, Output, EventEmitter } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FontAwesomeModule } from '@fortawesome/angular-fontawesome';
import { IconDefinition } from '@fortawesome/fontawesome-svg-core';

export type IconButtonVariant = 'default' | 'view' | 'edit' | 'delete' | 'approve' | 'reject' | 'toggle' | 'info';
export type IconButtonSize = 'small' | 'medium' | 'large';

@Component({
  selector: 'app-icon-button',
  standalone: true,
  imports: [CommonModule, FontAwesomeModule],
  template: `
    <button 
      [class]="getButtonClasses()"
      [disabled]="disabled"
      (click)="handleClick($event)"
      [type]="type"
      [title]="tooltip"
      [attr.aria-label]="ariaLabel || tooltip"
    >
      <fa-icon 
        [icon]="icon"
        [spin]="spinning"
        class="icon-btn-icon"
      ></fa-icon>
      <span *ngIf="badge" class="icon-badge">{{ badge }}</span>
    </button>
  `,
  styles: [`
    .icon-button {
      display: inline-flex;
      align-items: center;
      justify-content: center;
      border: none;
      border-radius: 0; /* Make buttons square instead of rounded */
      cursor: pointer;
      transition: all 0.2s ease;
      font-family: 'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', system-ui, sans-serif;
      position: relative;
      aspect-ratio: 1;
    }

    .icon-button:disabled {
      opacity: 0.5;
      cursor: not-allowed;
      pointer-events: none;
    }

    /* Sizes */
    .icon-button.small {
      width: 28px;
      height: 28px;
      font-size: 0.75rem;
    }

    .icon-button.medium {
      width: 32px;
      height: 32px;
      font-size: 0.875rem;
    }

    .icon-button.large {
      width: 40px;
      height: 40px;
      font-size: 1rem;
    }

    /* Variants */
    .icon-button.default {
      background: transparent; /* Remove background */
      color: var(--fm-secondary-blue);
    }

    .icon-button.default:hover:not(:disabled) {
      background: transparent; /* Remove background on hover */
      color: var(--fm-primary-blue); /* Darker color on hover */
      transform: scale(1.05);
    }

    .icon-button.view {
      background: transparent; /* Remove background */
      color: var(--fm-secondary-blue);
    }

    .icon-button.view:hover:not(:disabled) {
      background: transparent; /* Remove background on hover */
      color: var(--fm-primary-blue); /* Darker color on hover */
      transform: scale(1.05);
    }

    .icon-button.edit {
      background: transparent; /* Remove background */
      color: var(--fm-green);
    }

    .icon-button.edit:hover:not(:disabled) {
      background: transparent; /* Remove background on hover */
      color: var(--fm-green); /* Keep color */
      filter: brightness(0.9); /* Slightly darker on hover */
      transform: scale(1.05);
    }

    .icon-button.delete {
      background: transparent; /* Remove background */
      color: var(--fm-red);
    }

    .icon-button.delete:hover:not(:disabled) {
      background: transparent; /* Remove background on hover */
      color: var(--fm-red); /* Keep color */
      filter: brightness(0.9); /* Slightly darker on hover */
      transform: scale(1.05);
    }

    .icon-button.approve {
      background: transparent; /* Remove background */
      color: var(--fm-green);
    }

    .icon-button.approve:hover:not(:disabled) {
      background: transparent; /* Remove background on hover */
      color: var(--fm-green); /* Keep color */
      filter: brightness(0.9); /* Slightly darker on hover */
      transform: scale(1.05);
    }

    .icon-button.reject {
      background: transparent; /* Remove background */
      color: var(--fm-red);
    }

    .icon-button.reject:hover:not(:disabled) {
      background: transparent; /* Remove background on hover */
      color: var(--fm-red); /* Keep color */
      filter: brightness(0.9); /* Slightly darker on hover */
      transform: scale(1.05);
    }

    .icon-button.toggle {
      background: transparent; /* Remove background */
      color: var(--fm-gray-medium);
    }

    .icon-button.toggle:hover:not(:disabled) {
      background: transparent; /* Remove background on hover */
      color: var(--fm-gray-medium); /* Keep color */
      filter: brightness(0.9); /* Slightly darker on hover */
      transform: scale(1.05);
    }

    .icon-button.toggle.active {
      background: transparent; /* Remove background */
      color: var(--fm-secondary-blue);
    }

    .icon-button.toggle.active:hover:not(:disabled) {
      background: transparent; /* Remove background on hover */
      color: var(--fm-secondary-blue); /* Keep color */
      filter: brightness(0.9); /* Slightly darker on hover */
    }

    .icon-button.info {
      background: transparent; /* Remove background */
      color: var(--fm-yellow);
    }

    .icon-button.info:hover:not(:disabled) {
      background: transparent; /* Remove background on hover */
      color: var(--fm-yellow); /* Keep color */
      filter: brightness(0.9); /* Slightly darker on hover */
      transform: scale(1.05);
    }

    .icon-btn-icon {
      flex-shrink: 0;
    }

    .icon-badge {
      position: absolute;
      top: -0.25rem;
      right: -0.25rem;
      background: var(--fm-red);
      color: var(--fm-white);
      font-size: 0.6rem;
      font-weight: 600;
      padding: 0.125rem 0.25rem;
      border-radius: 8px;
      min-width: 0.875rem;
      height: 0.875rem;
      display: flex;
      align-items: center;
      justify-content: center;
      line-height: 1;
      border: 1px solid var(--fm-white);
    }

    .icon-badge:empty {
      width: 0.5rem;
      height: 0.5rem;
      min-width: 0.5rem;
      padding: 0;
      border-radius: 50%;
    }

    /* Focus styles */
    .icon-button:focus {
      outline: 2px solid var(--fm-secondary-blue);
      outline-offset: 2px;
    }

    .icon-button:focus:not(:focus-visible) {
      outline: none;
    }

    /* Active state */
    .icon-button:active:not(:disabled) {
      transform: scale(0.95);
    }

    /* Responsive */
    @media (max-width: 768px) {
      .icon-button.medium {
        width: 36px;
        height: 36px;
        font-size: 0.9rem;
      }
      
      .icon-button.large {
        width: 44px;
        height: 44px;
        font-size: 1.1rem;
      }
    }
  `]
})
export class IconButtonComponent {
  @Input() variant: IconButtonVariant = 'default';
  @Input() size: IconButtonSize = 'medium';
  @Input() icon!: IconDefinition;
  @Input() disabled = false;
  @Input() spinning = false;
  @Input() badge?: string | number;
  @Input() tooltip?: string;
  @Input() ariaLabel?: string;
  @Input() active = false;
  @Input() type: 'button' | 'submit' | 'reset' = 'button';

  @Output() buttonClick = new EventEmitter<Event>();

  getButtonClasses(): string {
    const classes = ['icon-button'];
    
    classes.push(this.variant);
    classes.push(this.size);
    
    if (this.active && this.variant === 'toggle') {
      classes.push('active');
    }
    
    return classes.join(' ');
  }

  handleClick(event: Event): void {
    if (!this.disabled) {
      this.buttonClick.emit(event);
    }
  }
}
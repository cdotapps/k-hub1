import { Component, Input } from '@angular/core';

@Component({
  selector: 'app-button',
  template: `
    <button 
      [class]="buttonClasses" 
      [disabled]="disabled"
      [type]="type"
      (click)="onClick($event)">
      <ng-content></ng-content>
    </button>
  `,
  styles: [`
    button {
      font-family: 'Inter', sans-serif;
      font-weight: 600;
      border: none;
      border-radius: 4px;
      padding: 0.75rem 1.5rem;
      cursor: pointer;
      transition: all 0.3s ease;
      text-transform: none;
      font-size: 1rem;
      display: inline-block;
      text-align: center;
      text-decoration: none;
    }

    button:disabled {
      opacity: 0.6;
      cursor: not-allowed;
    }

    .btn-primary {
      background-color: var(--fm-primary-blue);
      color: var(--fm-white);
    }

    .btn-primary:hover:not(:disabled) {
      background-color: var(--fm-navy);
      transform: translateY(-1px);
      box-shadow: 0 4px 8px rgba(0, 63, 127, 0.2);
    }

    .btn-secondary {
      background-color: var(--fm-secondary-blue);
      color: var(--fm-white);
    }

    .btn-secondary:hover:not(:disabled) {
      background-color: var(--fm-primary-blue);
      transform: translateY(-1px);
    }

    .btn-outline {
      background-color: transparent;
      color: var(--fm-primary-blue);
      border: 2px solid var(--fm-primary-blue);
    }

    .btn-outline:hover:not(:disabled) {
      background-color: var(--fm-primary-blue);
      color: var(--fm-white);
      transform: translateY(-1px);
    }

    .btn-success {
      background-color: var(--fm-green);
      color: var(--fm-white);
    }

    .btn-success:hover:not(:disabled) {
      background-color: #218838;
      transform: translateY(-1px);
    }

    .btn-warning {
      background-color: var(--fm-orange);
      color: var(--fm-white);
    }

    .btn-warning:hover:not(:disabled) {
      background-color: #e96800;
      transform: translateY(-1px);
    }

    .btn-danger {
      background-color: var(--fm-red);
      color: var(--fm-white);
    }

    .btn-danger:hover:not(:disabled) {
      background-color: #c82333;
      transform: translateY(-1px);
    }

    .btn-sm {
      padding: 0.5rem 1rem;
      font-size: 0.875rem;
    }

    .btn-lg {
      padding: 1rem 2rem;
      font-size: 1.125rem;
    }

    .btn-xl {
      padding: 1.25rem 2.5rem;
      font-size: 1.25rem;
    }

    .btn-block {
      width: 100%;
      display: block;
    }

    .btn-rounded {
      border-radius: 50px;
    }
  `]
})
export class ButtonComponent {
  @Input() variant: 'primary' | 'secondary' | 'outline' | 'success' | 'warning' | 'danger' = 'primary';
  @Input() size: 'sm' | 'md' | 'lg' | 'xl' = 'md';
  @Input() disabled: boolean = false;
  @Input() block: boolean = false;
  @Input() rounded: boolean = false;
  @Input() type: 'button' | 'submit' | 'reset' = 'button';

  get buttonClasses(): string {
    const classes = [`btn-${this.variant}`];
    
    if (this.size !== 'md') {
      classes.push(`btn-${this.size}`);
    }
    
    if (this.block) {
      classes.push('btn-block');
    }
    
    if (this.rounded) {
      classes.push('btn-rounded');
    }
    
    return classes.join(' ');
  }

  onClick(event: Event): void {
    if (!this.disabled) {
      // Event will bubble up to parent click handlers
    }
  }
}
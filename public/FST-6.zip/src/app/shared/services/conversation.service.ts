import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { BaseApiService } from './base-api.service';
import { CatalogConversation, ConversationMessage } from '../models/user.interface';

@Injectable({
  providedIn: 'root'
})
export class ConversationService extends BaseApiService {

  /**
   * Get conversations for a catalog item
   */
  getCatalogConversations(catalogId: string): Observable<CatalogConversation> {
    return this.get<any>(`/catalog/${catalogId}/conversations`).pipe(
      map((response: any) => {
        console.log('✅ Conversation API response received:', response);
        
        // Handle the actual API response format
        if (Array.isArray(response)) {
          const messages: ConversationMessage[] = response.map((item: any, index: number) => ({
            id: item.id || `msg_${Date.now()}_${index}`,
            user_id: item.user_id || '',
            user_name: item.user_name || item.user_id || 'Unknown User',
            message: item.message || '',
            created_date: item.timestamp || item.created_date || new Date().toISOString(),
            updated_date: item.updated_date,
            parent_id: item.parent_id,
            likes: item.likes || 0,
            replies: item.replies || []
          }));
          
          console.log('✅ Mapped conversation messages:', messages);
          
          return {
            messages: messages,
            total_messages: messages.length,
            last_activity: messages.length > 0 ? messages[messages.length - 1].created_date : new Date().toISOString()
          };
        }
        
        // Handle other possible response formats
        if (response && typeof response === 'object') {
          if ('messages' in response && Array.isArray(response.messages)) {
            return {
              messages: response.messages,
              total_messages: response.total_messages || response.messages.length,
              last_activity: response.last_activity || new Date().toISOString()
            };
          }
          else if ('data' in response && response.data) {
            const data = response.data as any;
            if (Array.isArray(data)) {
              const messages: ConversationMessage[] = data.map((item: any, index: number) => ({
                id: item.id || `msg_${Date.now()}_${index}`,
                user_id: item.user_id || '',
                user_name: item.user_name || item.user_id || 'Unknown User',
                message: item.message || '',
                created_date: item.timestamp || item.created_date || new Date().toISOString(),
                updated_date: item.updated_date,
                parent_id: item.parent_id,
                likes: item.likes || 0,
                replies: item.replies || []
              }));
              
              return {
                messages: messages,
                total_messages: messages.length,
                last_activity: messages.length > 0 ? messages[messages.length - 1].created_date : new Date().toISOString()
              };
            } else {
              return {
                messages: Array.isArray(data.messages) ? data.messages : [],
                total_messages: data.total_messages || (Array.isArray(data.messages) ? data.messages.length : 0),
                last_activity: data.last_activity || new Date().toISOString()
              };
            }
          }
        }
        
        // Fallback for unexpected response structure
        console.warn('⚠️ Unexpected conversation API response structure:', response);
        return {
          messages: [],
          total_messages: 0,
          last_activity: new Date().toISOString()
        };
      })
    );
  }

  /**
   * Add a message to catalog conversations
   */
  addConversationMessage(catalogId: string, message: string, parentId?: string): Observable<ConversationMessage> {
    const payload = {
      message,
      parent_id: parentId
    };
    
    console.log('📤 Sending conversation message:', payload);
    
    return this.post<any>(`/catalog/${catalogId}/conversations`, payload).pipe(
      map((response: any) => {
        console.log('✅ Conversation message API response:', response);
        
        // Handle different possible API response formats
        if (response && typeof response === 'object') {
          if ('id' in response && 'message' in response) {
            return response as ConversationMessage;
          }
          else if ('data' in response && response.data) {
            return response.data as ConversationMessage;
          }
          else if ('message' in response && 'user_id' in response) {
            return {
              id: response.id || Date.now().toString(),
              user_id: response.user_id || '',
              user_name: response.user_name || response.user_id || 'Unknown User',
              message: response.message || '',
              created_date: response.timestamp || response.created_date || new Date().toISOString(),
              updated_date: response.updated_date,
              parent_id: response.parent_id,
              likes: response.likes || 0,
              replies: response.replies || []
            } as ConversationMessage;
          }
        }
        
        // Fallback response structure
        console.warn('⚠️ Unexpected message API response structure:', response);
        return {
          id: Date.now().toString(),
          user_id: '',
          user_name: 'Unknown User',
          message: message,
          created_date: new Date().toISOString(),
          likes: 0,
          replies: []
        } as ConversationMessage;
      })
    );
  }

  /**
   * Update a conversation message
   */
  updateConversationMessage(catalogId: string, messageId: string, message: string): Observable<ConversationMessage> {
    const payload = { message };
    
    console.log('📝 Updating conversation message:', { messageId, payload });
    
    return this.put<any>(`/catalog/${catalogId}/conversations/${messageId}`, payload).pipe(
      map((response: any) => {
        console.log('✅ Update message API response:', response);
        
        if (response && typeof response === 'object') {
          if ('id' in response && 'message' in response) {
            return response as ConversationMessage;
          }
          else if ('data' in response && response.data) {
            return response.data as ConversationMessage;
          }
        }
        
        console.warn('⚠️ Unexpected update message API response structure:', response);
        return {
          id: messageId,
          user_id: '',
          user_name: 'Unknown User',
          message: message,
          created_date: new Date().toISOString(),
          updated_date: new Date().toISOString()
        } as ConversationMessage;
      })
    );
  }

  /**
   * Delete a conversation message
   */
  deleteConversationMessage(catalogId: string, messageId: string): Observable<void> {
    console.log('🗑️ Deleting conversation message:', messageId);
    return this.delete<void>(`/catalog/${catalogId}/conversations/${messageId}`);
  }

  /**
   * Like a conversation message
   */
  likeConversationMessage(catalogId: string, messageId: string): Observable<ConversationMessage> {
    console.log('👍 Liking conversation message:', messageId);
    
    return this.post<any>(`/catalog/${catalogId}/conversations/${messageId}/like`, {}).pipe(
      map((response: any) => {
        console.log('✅ Like message API response:', response);
        
        if (response && typeof response === 'object') {
          if ('id' in response) {
            return response as ConversationMessage;
          }
          else if ('data' in response && response.data) {
            return response.data as ConversationMessage;
          }
        }
        
        console.warn('⚠️ Unexpected like message API response structure:', response);
        return {
          id: messageId,
          user_id: '',
          user_name: 'Unknown User',
          message: '',
          created_date: new Date().toISOString(),
          likes: 1
        } as ConversationMessage;
      })
    );
  }
}
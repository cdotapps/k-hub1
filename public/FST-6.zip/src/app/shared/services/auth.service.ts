import { Injectable } from '@angular/core';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { BehaviorSubject, Observable, throwError } from 'rxjs';
import { map, catchError, tap } from 'rxjs/operators';
import { Router } from '@angular/router';
import { User, LoginRequest, UserCreate, TokenResponse } from '../models/user.interface';
import { environment } from '../../../environments/environment';

@Injectable({
  providedIn: 'root'
})
export class AuthService {
  private readonly API_BASE = `${environment.apiUrl}${environment.apiVersion}`;
  private readonly API_SERVER = environment.apiUrl;
  private readonly TOKEN_KEY = 'access_token';
  private readonly REFRESH_TOKEN_KEY = 'refresh_token';
  private readonly USER_KEY = 'current_user';

  private currentUserSubject = new BehaviorSubject<User | null>(null);
  public currentUser$ = this.currentUserSubject.asObservable();

  constructor(
    private http: HttpClient,
    private router: Router
  ) {
    this.loadStoredUser();
  }

  /**
   * Load user from localStorage on service initialization
   */
  private loadStoredUser(): void {
    const token = this.getToken();
    const userData = localStorage.getItem(this.USER_KEY);
    
    if (token && userData) {
      try {
        const user = JSON.parse(userData);
        this.currentUserSubject.next(user);
      } catch (error) {
        console.error('Error parsing stored user data:', error);
        this.clearStoredAuth();
      }
    }
  }

  /**
   * User login
   */
  login(credentials: LoginRequest): Observable<TokenResponse> {
    console.log('AuthService: Attempting login for user:', credentials.user_id);
    
    return this.http.post<TokenResponse>(`${this.API_BASE}/auth/login`, credentials)
      .pipe(
        tap(response => {
          console.log('AuthService: Login successful');
          this.storeAuthData(response);
          this.currentUserSubject.next(response.user as User);
          
          // Redirect based on user role
          const user = response.user as User;
          const isAdmin = user?.role === 'admin' || user?.is_superuser === true;
          
          if (isAdmin) {
            this.router.navigate(['/admin/']);
          } else {
            this.router.navigate(['/user/']);
            console.log("I am here")
          }
        }),
        catchError((error: HttpErrorResponse) => {
          console.error('AuthService: Login failed:', error);
          
          // Handle login-specific errors without redirecting
          let errorMessage = 'Login failed. Please try again.';
          
          if (error.status === 401) {
            errorMessage = 'Invalid username or password. Please try again.';
          } else if (error.status === 422) {
            if (error.error?.detail && Array.isArray(error.error.detail)) {
              const validationErrors = error.error.detail
                .map((err: any) => err.msg)
                .join(', ');
              errorMessage = `Validation Error: ${validationErrors}`;
            } else {
              errorMessage = 'Please check your input and try again.';
            }
          } else if (error.status === 429) {
            errorMessage = 'Too many login attempts. Please wait a moment and try again.';
          } else if (error.status >= 500) {
            errorMessage = 'Server error. Please try again later.';
          } else if (error.status === 0) {
            errorMessage = 'Unable to connect to server. Please check your internet connection.';
          } else if (error.error?.msg) {
            errorMessage = error.error.msg;
          } else if (error.error?.message) {
            errorMessage = error.error.message;
          }
          
          return throwError(() => new Error(errorMessage));
        })
      );
  }

  /**
   * User registration
   */
  register(userData: UserCreate): Observable<User> {
    console.log('AuthService: Attempting registration with data:', userData);
    
    return this.http.post<User>(`${this.API_BASE}/auth/register`, userData)
      .pipe(
        tap(response => {
          console.log('AuthService: Registration successful:', response);
        }),
        catchError((error) => {
          console.error('AuthService: Registration failed:', error);
          return this.handleError(error);
        })
      );
  }

  /**
   * User logout
   */
  logout(): Observable<any> {
    const token = this.getToken();
    
    if (!token) {
      this.clearStoredAuth();
      this.currentUserSubject.next(null);
      this.router.navigate(['/login']);
      return new Observable(observer => observer.next({}));
    }

    return this.http.post(`${this.API_BASE}/auth/logout`, {}, {
      headers: { Authorization: `Bearer ${token}` }
    }).pipe(
      tap(() => {
        this.clearStoredAuth();
        this.currentUserSubject.next(null);
        this.router.navigate(['/login']);
      }),
      catchError((error) => {
        // Even if logout fails on server, clear local state
        this.clearStoredAuth();
        this.currentUserSubject.next(null);
        this.router.navigate(['/login']);
        return throwError(() => error);
      })
    );
  }

  /**
   * Refresh access token
   */
  refreshToken(): Observable<TokenResponse> {
    const refreshToken = this.getRefreshToken();
    
    if (!refreshToken) {
      return throwError(() => new Error('No refresh token available'));
    }

    return this.http.post<TokenResponse>(`${this.API_BASE}/auth/refresh`, {}, {
      headers: { Authorization: `Bearer ${refreshToken}` }
    }).pipe(
      tap(response => {
        this.storeAuthData(response);
        this.currentUserSubject.next(response.user as User);
      }),
      catchError(error => {
        this.clearStoredAuth();
        this.currentUserSubject.next(null);
        this.router.navigate(['/login']);
        return throwError(() => error);
      })
    );
  }

  /**
   * Get current user profile
   */
  getCurrentUser(): Observable<User> {
    const token = this.getToken();
    
    if (!token) {
      return throwError(() => new Error('No access token available'));
    }

    return this.http.get<User>(`${this.API_BASE}/users/me`, {
      headers: { Authorization: `Bearer ${token}` }
    }).pipe(
      tap(user => {
        this.currentUserSubject.next(user);
        localStorage.setItem(this.USER_KEY, JSON.stringify(user));
      }),
      catchError(this.handleError)
    );
  }

  /**
   * Update current user profile
   */
  updateProfile(userData: Partial<User>): Observable<User> {
    const token = this.getToken();
    
    if (!token) {
      return throwError(() => new Error('No access token available'));
    }

    return this.http.put<User>(`${this.API_BASE}/users/me`, userData, {
      headers: { Authorization: `Bearer ${token}` }
    }).pipe(
      tap(user => {
        this.currentUserSubject.next(user);
        localStorage.setItem(this.USER_KEY, JSON.stringify(user));
      }),
      catchError(this.handleError)
    );
  }

  /**
   * Update current user - alias for updateProfile for component compatibility
   */
  updateCurrentUser(userData: Partial<User>): Observable<User> {
    return this.updateProfile(userData);
  }

  /**
   * Set current user data directly (for use after successful API updates)
   * This updates the observable and localStorage without making an API call
   */
  setCurrentUser(user: User): void {
    this.currentUserSubject.next(user);
    localStorage.setItem(this.USER_KEY, JSON.stringify(user));
  }

  /**
   * Change password
   */
  changePassword(currentPassword: string, newPassword: string): Observable<any> {
    const token = this.getToken();
    
    if (!token) {
      return throwError(() => new Error('No access token available'));
    }

    return this.http.put(`${this.API_BASE}/users/me/password`, {
      current_password: currentPassword,
      new_password: newPassword
    }, {
      headers: { Authorization: `Bearer ${token}` }
    }).pipe(
      catchError(this.handleError)
    );
  }

  /**
   * Check API health status
   */
  checkApiHealth(): Observable<{ status: string; timestamp: string }> {
    // Use the API server base URL for health check
    return this.http.get<{ status: string; timestamp: string }>(`${this.API_SERVER}/health`)
      .pipe(
        catchError((error: HttpErrorResponse) => {
          console.error('API health check failed:', error);
          return throwError(() => new Error('System Offline'));
        })
      );
  }

  /**
   * Store authentication data in localStorage
   */
  private storeAuthData(response: TokenResponse): void {
    localStorage.setItem(this.TOKEN_KEY, response.access_token);
    localStorage.setItem(this.REFRESH_TOKEN_KEY, response.refresh_token);
    localStorage.setItem(this.USER_KEY, JSON.stringify(response.user));
  }

  /**
   * Clear stored authentication data
   */
  private clearStoredAuth(): void {
    localStorage.removeItem(this.TOKEN_KEY);
    localStorage.removeItem(this.REFRESH_TOKEN_KEY);
    localStorage.removeItem(this.USER_KEY);
  }

  /**
   * Get stored access token
   */
  getToken(): string | null {
    return localStorage.getItem(this.TOKEN_KEY);
  }

  /**
   * Get stored refresh token
   */
  getRefreshToken(): string | null {
    return localStorage.getItem(this.REFRESH_TOKEN_KEY);
  }

  /**
   * Check if user is authenticated
   */
  isAuthenticated(): boolean {
    const token = this.getToken();
    const user = this.currentUserSubject.value;
    return !!(token && user);
  }

  /**
   * Check if user has admin role
   */
  isAdmin(): boolean {
    const user = this.currentUserSubject.value;
    return user?.role === 'admin' || user?.is_superuser === true;
  }

  /**
   * Get current user value (synchronous)
   */
  getCurrentUserValue(): User | null {
    return this.currentUserSubject.value;
  }

  /**
   * Handle HTTP errors
   */
  private handleError = (error: HttpErrorResponse): Observable<never> => {
    let errorMessage = 'An unknown error occurred';
    
    if (error.error instanceof ErrorEvent) {
      // Client-side error
      errorMessage = `Client Error: ${error.error.message}`;
    } else {
      // Server-side error
      if (error.status === 401) {
        errorMessage = 'Invalid credentials or session expired';
        // Clear auth data on 401 errors
        this.clearStoredAuth();
        this.currentUserSubject.next(null);
        this.router.navigate(['/login']);
      } else if (error.status === 422) {
        // Validation errors
        if (error.error?.detail && Array.isArray(error.error.detail)) {
          const validationErrors = error.error.detail
            .map((err: any) => err.msg)
            .join(', ');
          errorMessage = `Validation Error: ${validationErrors}`;
        } else {
          errorMessage = 'Validation failed. Please check your input.';
        }
      } else if (error.status === 403) {
        errorMessage = 'Access denied. You do not have permission to perform this action.';
      } else if (error.status === 404) {
        errorMessage = 'The requested resource was not found.';
      } else if (error.status === 500) {
        errorMessage = 'Internal server error. Please try again later.';
      } else if (error.error?.msg) {
        errorMessage = error.error.msg;
      } else if (error.error?.message) {
        errorMessage = error.error.message;
      } else {
        errorMessage = `Server Error: ${error.status} - ${error.statusText}`;
      }
    }

    console.error('AuthService Error:', error);
    return throwError(() => new Error(errorMessage));
  };
}
import { Component, Input, Output, EventEmitter } from '@angular/core';

@Component({
  selector: 'app-popup-bottom',
  template: `
    <div class="popup-backdrop" *ngIf="visible">
      <div class="popup-bottom-sheet">
        <header class="popup-header">
          <h2 class="popup-title">{{ title || 'Header' }}</h2>
          <span (click)="closePopup()" class="close-button">&times;</span>
        </header>
        <div class="popup-tabs" *ngIf="tabs.length > 1">
          <button *ngFor="let tab of tabs"
                  class="tablink"
                  [class.active]="activeTab === tab"
                  (click)="openTab(tab)">{{ tab }}</button>
        </div>
        <div class="popup-content">
          <ng-content></ng-content>
        </div>
        <!-- <div class="popup-actions">
          <button class="cancel-btn" (click)="closePopup()">Close</button>
        </div> -->
      </div>
    </div>
  `,
  styleUrls: ['./popup-bottom.component.css']
})
export class PopupBottomComponent {
  @Input() title: string = '';
  @Input() visible: boolean = true;
  @Input() tabs: string[] = [];
  @Output() close = new EventEmitter<void>();
  activeTab: string = '';

  ngOnInit() {
    this.activeTab = this.tabs[0] || '';
  }

  openTab(tab: string) {
    this.activeTab = tab;
  }

  closePopup() {
    this.close.emit();
  }
}
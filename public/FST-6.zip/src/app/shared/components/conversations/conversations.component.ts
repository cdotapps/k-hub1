import { Component, Input, Output, EventEmitter, OnInit, OnDestroy, OnChanges, SimpleChanges, ViewChild, ElementRef, AfterViewChecked } from '@angular/core';
import { 
  faComments, faPaperPlane, faSpinner, faTimes, faUser, 
  faReply, faHeart, faEdit, faTrash, faEllipsisV,
  faExpand, faCompress, faClock, faCheck
} from '@fortawesome/free-solid-svg-icons';
import { ConversationMessage, CatalogConversation, User } from '../../models/user.interface';
import { ConversationService } from '../../services/conversation.service';
import { AuthService } from '../../services/auth.service';
import { Subscription } from 'rxjs';

@Component({
  selector: 'app-conversations-window',
  templateUrl: './conversations.component.html',
  styleUrls: ['./conversations.component.css']
})
export class ConversationsComponent implements OnInit, OnDestroy, OnChanges, AfterViewChecked {
  @Input() catalogId: string = '';
  @Input() catalogTitle: string = '';
  @Input() isOpen: boolean = false;
  @Output() closeConversations = new EventEmitter<void>();

  @ViewChild('messagesContainer', { static: false }) messagesContainer!: ElementRef;

  // FontAwesome icons
  faComments = faComments;
  faPaperPlane = faPaperPlane;
  faSpinner = faSpinner;
  faTimes = faTimes;
  faUser = faUser;
  faReply = faReply;
  faHeart = faHeart;
  faEdit = faEdit;
  faTrash = faTrash;
  faEllipsisV = faEllipsisV;
  faExpand = faExpand;
  faCompress = faCompress;
  faClock = faClock;
  faCheck = faCheck;

  // Component state
  conversations: CatalogConversation | null = null;
  currentUser: User | null = null;
  newMessage: string = '';
  replyingTo: ConversationMessage | null = null;
  editingMessage: ConversationMessage | null = null;
  editingText: string = '';
  isLoading: boolean = false;
  isExpanded: boolean = false;
  isSubmitting: boolean = false;
  errorMessage: string = '';

  // Message actions state
  showActionsFor: string | null = null;
  likedMessages: Set<string> = new Set();

  private subscriptions = new Subscription();
  private shouldScrollToBottom = false;

  constructor(
    private conversationService: ConversationService,
    private authService: AuthService
  ) {}

  ngOnInit(): void {
    this.subscriptions.add(
      this.authService.currentUser$.subscribe(user => {
        this.currentUser = user;
      })
    );

    if (this.catalogId && this.isOpen) {
      this.loadConversations();
    }
  }

  ngOnDestroy(): void {
    this.subscriptions.unsubscribe();
  }

  ngAfterViewChecked(): void {
    if (this.shouldScrollToBottom) {
      this.scrollToBottom();
      this.shouldScrollToBottom = false;
    }
  }

  ngOnChanges(changes: SimpleChanges): void {
    if (changes['isOpen'] && this.isOpen) {
      this.loadConversations();
    }
  }

  // ===== CONVERSATION LOADING =====

  loadConversations(): void {
    if (!this.catalogId) return;

    this.isLoading = true;
    this.errorMessage = '';

    this.conversationService.getCatalogConversations(this.catalogId).subscribe({
      next: (conversations) => {
        this.conversations = conversations;
        this.isLoading = false;
        this.shouldScrollToBottom = true;
        console.log('✅ Conversations loaded:', conversations);
      },
      error: (error) => {
        console.error('❌ Failed to load conversations:', error);
        this.errorMessage = 'Failed to load conversations. Please try again.';
        this.isLoading = false;
      }
    });
  }

  // ===== MESSAGE SUBMISSION =====

  sendMessage(): void {
    if (!this.newMessage.trim() || this.isSubmitting || !this.catalogId) return;

    const messageText = this.newMessage.trim();
    const parentId = this.replyingTo?.id;

    this.isSubmitting = true;
    this.newMessage = '';
    this.replyingTo = null;

    this.conversationService.addConversationMessage(this.catalogId, messageText, parentId).subscribe({
      next: (newMessage) => {
        console.log('✅ Message sent:', newMessage);
        this.addMessageToConversations(newMessage);
        this.isSubmitting = false;
        this.shouldScrollToBottom = true;
      },
      error: (error) => {
        console.error('❌ Failed to send message:', error);
        this.errorMessage = 'Failed to send message. Please try again.';
        this.isSubmitting = false;
        // Restore the message text for retry
        this.newMessage = messageText;
      }
    });
  }

  // ===== MESSAGE EDITING =====

  startEdit(message: ConversationMessage): void {
    this.editingMessage = message;
    this.editingText = message.message;
    this.showActionsFor = null;
  }

  cancelEdit(): void {
    this.editingMessage = null;
    this.editingText = '';
  }

  saveEdit(): void {
    if (!this.editingMessage || !this.editingText.trim() || this.isSubmitting) return;

    const messageId = this.editingMessage.id;
    const updatedText = this.editingText.trim();

    this.isSubmitting = true;

    this.conversationService.updateConversationMessage(this.catalogId, messageId, updatedText).subscribe({
      next: (updatedMessage) => {
        console.log('✅ Message updated:', updatedMessage);
        this.updateMessageInConversations(updatedMessage);
        this.editingMessage = null;
        this.editingText = '';
        this.isSubmitting = false;
      },
      error: (error) => {
        console.error('❌ Failed to update message:', error);
        this.errorMessage = 'Failed to update message. Please try again.';
        this.isSubmitting = false;
      }
    });
  }

  // ===== MESSAGE ACTIONS =====

  startReply(message: ConversationMessage): void {
    this.replyingTo = message;
    this.showActionsFor = null;
    // Focus on the input
    setTimeout(() => {
      const input = document.querySelector('.message-input') as HTMLTextAreaElement;
      if (input) input.focus();
    }, 100);
  }

  cancelReply(): void {
    this.replyingTo = null;
  }

  likeMessage(message: ConversationMessage): void {
    if (this.likedMessages.has(message.id)) return;

    this.conversationService.likeConversationMessage(this.catalogId, message.id).subscribe({
      next: (updatedMessage) => {
        console.log('✅ Message liked:', updatedMessage);
        this.updateMessageInConversations(updatedMessage);
        this.likedMessages.add(message.id);
        this.showActionsFor = null;
      },
      error: (error) => {
        console.error('❌ Failed to like message:', error);
        this.errorMessage = 'Failed to like message.';
      }
    });
  }

  deleteMessage(message: ConversationMessage): void {
    if (!confirm('Are you sure you want to delete this message?')) return;

    this.conversationService.deleteConversationMessage(this.catalogId, message.id).subscribe({
      next: () => {
        console.log('✅ Message deleted:', message.id);
        this.removeMessageFromConversations(message.id);
        this.showActionsFor = null;
      },
      error: (error) => {
        console.error('❌ Failed to delete message:', error);
        this.errorMessage = 'Failed to delete message. Please try again.';
      }
    });
  }

  // ===== UI INTERACTIONS =====

  toggleExpanded(): void {
    this.isExpanded = !this.isExpanded;
  }

  toggleMessageActions(messageId: string): void {
    this.showActionsFor = this.showActionsFor === messageId ? null : messageId;
  }

  onClose(): void {
    this.closeConversations.emit();
  }

  onKeyPress(event: KeyboardEvent): void {
    if (event.key === 'Enter' && !event.shiftKey) {
      event.preventDefault();
      if (this.editingMessage) {
        this.saveEdit();
      } else {
        this.sendMessage();
      }
    }
  }

  // ===== UTILITY METHODS =====

  private addMessageToConversations(newMessage: ConversationMessage): void {
    if (!this.conversations) {
      this.conversations = {
        messages: [newMessage],
        total_messages: 1,
        last_activity: newMessage.created_date
      };
    } else {
      this.conversations.messages.push(newMessage);
      this.conversations.total_messages = this.conversations.messages.length;
      this.conversations.last_activity = newMessage.created_date;
    }
  }

  private updateMessageInConversations(updatedMessage: ConversationMessage): void {
    if (!this.conversations) return;

    const index = this.conversations.messages.findIndex(msg => msg.id === updatedMessage.id);
    if (index !== -1) {
      this.conversations.messages[index] = updatedMessage;
    }
  }

  private removeMessageFromConversations(messageId: string): void {
    if (!this.conversations) return;

    this.conversations.messages = this.conversations.messages.filter(msg => msg.id !== messageId);
    this.conversations.total_messages = this.conversations.messages.length;
  }

  private scrollToBottom(): void {
    if (this.messagesContainer) {
      try {
        const element = this.messagesContainer.nativeElement;
        element.scrollTop = element.scrollHeight;
      } catch (error) {
        console.warn('Could not scroll to bottom:', error);
      }
    }
  }

  // ===== HELPER METHODS =====

  canEditMessage(message: ConversationMessage): boolean {
    return this.currentUser?.id === message.user_id;
  }

  canDeleteMessage(message: ConversationMessage): boolean {
    return this.currentUser?.id === message.user_id || this.currentUser?.role === 'admin';
  }

  getMessageTime(timestamp: string): string {
    try {
      const date = new Date(timestamp);
      const now = new Date();
      const diffInHours = (now.getTime() - date.getTime()) / (1000 * 60 * 60);

      if (diffInHours < 24) {
        return date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
      } else if (diffInHours < 168) { // 7 days
        return date.toLocaleDateString([], { weekday: 'short', hour: '2-digit', minute: '2-digit' });
      } else {
        return date.toLocaleDateString([], { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' });
      }
    } catch (error) {
      return timestamp;
    }
  }

  getRelativeTime(timestamp: string): string {
    try {
      const date = new Date(timestamp);
      const now = new Date();
      const diffInMinutes = Math.floor((now.getTime() - date.getTime()) / (1000 * 60));

      if (diffInMinutes < 1) return 'Just now';
      if (diffInMinutes < 60) return `${diffInMinutes}m ago`;
      
      const diffInHours = Math.floor(diffInMinutes / 60);
      if (diffInHours < 24) return `${diffInHours}h ago`;
      
      const diffInDays = Math.floor(diffInHours / 24);
      if (diffInDays < 7) return `${diffInDays}d ago`;
      
      return date.toLocaleDateString();
    } catch (error) {
      return timestamp;
    }
  }

  getUserInitials(userName: string): string {
    if (!userName) return '?';
    
    const names = userName.split(' ');
    if (names.length === 1) {
      return names[0].charAt(0).toUpperCase();
    }
    
    return (names[0].charAt(0) + names[names.length - 1].charAt(0)).toUpperCase();
  }

  isReplyMessage(message: ConversationMessage): boolean {
    return !!message.parent_id;
  }

  getReplyToMessage(parentId: string): ConversationMessage | null {
    if (!this.conversations) return null;
    return this.conversations.messages.find(msg => msg.id === parentId) || null;
  }

  getMessagesByParent(): { [parentId: string]: ConversationMessage[] } {
    if (!this.conversations) return {};
    
    const grouped: { [parentId: string]: ConversationMessage[] } = { 'root': [] };
    
    this.conversations.messages.forEach(message => {
      const parentKey = message.parent_id || 'root';
      if (!grouped[parentKey]) {
        grouped[parentKey] = [];
      }
      grouped[parentKey].push(message);
    });
    
    return grouped;
  }

  getRootMessages(): ConversationMessage[] {
    if (!this.conversations) return [];
    return this.conversations.messages.filter(msg => !msg.parent_id);
  }

  getReplies(messageId: string): ConversationMessage[] {
    if (!this.conversations) return [];
    return this.conversations.messages.filter(msg => msg.parent_id === messageId);
  }

  clearError(): void {
    this.errorMessage = '';
  }

  refreshConversations(): void {
    this.loadConversations();
  }

  trackByMessageId(index: number, message: ConversationMessage): string {
    return message.id;
  }
}
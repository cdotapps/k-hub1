import { Component, OnInit, OnDestroy } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router, ActivatedRoute } from '@angular/router';
import { Subscription } from 'rxjs';

// FontAwesome Icons
import { 
  faNewspaper, faFileAlt, faBell, faFileContract, faBook, faGraduationCap,
  faBlog, faFlask, faFileImage, faChartLine, faSave, faTimes, faSpinner,
  faEye, faArrowLeft, faInfoCircle, faExclamationTriangle, faCheckCircle,
  faPlus, faTag, faUser, faCalendar, faGlobe, faLock, faEdit, faClock, faSync,
  faSearch, faSquare, faCheckSquare, faArrowUp, faArrowDown
} from '@fortawesome/free-solid-svg-icons';

// Services and Models
import { CatalogService } from '../../shared/services/catalog.service';
import { AuthService } from '../../shared/services/auth.service';
import { TemplateService, NewsletterTemplate } from '../../shared/services/template.service';
import { CatalogCreate, User, CatalogChildItem } from '../../shared/models/user.interface';
import { BreadcrumbItem } from '../../shared/components/breadcrumb/breadcrumb.component';

@Component({
  selector: 'app-create-newsletter',
  templateUrl: './create-newsletter.component.html',
  styleUrls: ['./create-newsletter.component.css']
})
export class CreateNewsletterComponent implements OnInit, OnDestroy {
  // FontAwesome Icons
  faNewspaper = faNewspaper;
  faFileAlt = faFileAlt;
  faBell = faBell;
  faFileContract = faFileContract;
  faBook = faBook;
  faGraduationCap = faGraduationCap;
  faBlog = faBlog;
  faFlask = faFlask;
  faFileImage = faFileImage;
  faChartLine = faChartLine;
  faSave = faSave;
  faTimes = faTimes;
  faSpinner = faSpinner;
  faEye = faEye;
  faArrowLeft = faArrowLeft;
  faInfoCircle = faInfoCircle;
  faExclamationTriangle = faExclamationTriangle;
  faCheckCircle = faCheckCircle;
  faPlus = faPlus;
  faTag = faTag;
  faUser = faUser;
  faCalendar = faCalendar;
  faGlobe = faGlobe;
  faLock = faLock;
  faEdit = faEdit;
  faClock = faClock;
  faSync = faSync;
  faSearch = faSearch;
  faSquare = faSquare;
  faCheckSquare = faCheckSquare;
  faArrowUp = faArrowUp;
  faArrowDown = faArrowDown;

  // Form and Data
  articleForm: FormGroup;
  currentUser: User | null = null;
  selectedCatalogType = 'newsletter'; // Default to newsletter
  parentId: string = ''; // Added property for parent_id
  
  // Template Management
  availableTemplates: NewsletterTemplate[] = [];
  selectedTemplateId: string = '';
  isLoadingTemplates = false;
  
  // Catalog Items Selection - Updated to use CatalogChildItem interface
  selectedCatalogItems: CatalogChildItem[] = [];
  availableCatalogItems: any[] = [];
  showCatalogItemsPopup = false;
  isLoadingCatalogItems = false;
  catalogSearchTerm = '';
  filteredCatalogItems: any[] = [];
  
  // UI State
  isLoading = false;
  isSaving = false;
  isApplyingTemplate = false; // Renamed from isApplyingPreview
  successMessage = '';
  errorMessage = '';
  
  // Word count tracking
  private currentWordCount: number = 0;
  
  breadcrumbItems: BreadcrumbItem[] = [
    { label: 'Dashboard', url: '/user/dashboard' },
    { label: 'Catalog', url: '/user/catalog' },
    { label: 'Create Newsletter', active: true }
  ];

  private subscriptions = new Subscription();

  // Quill Editor Configuration
  quillConfig = {
    toolbar: [
      ['bold', 'italic', 'underline', 'strike'],        // toggled buttons
      ['blockquote', 'code-block'],
      [{ 'header': 1 }, { 'header': 2 }],               // custom button values
      [{ 'list': 'ordered'}, { 'list': 'bullet' }],
      [{ 'script': 'sub'}, { 'script': 'super' }],      // superscript/subscript
      [{ 'indent': '-1'}, { 'indent': '+1' }],          // outdent/indent
      [{ 'direction': 'rtl' }],                         // text direction
      [{ 'size': ['small', false, 'large', 'huge'] }],  // custom dropdown
      [{ 'header': [1, 2, 3, 4, 5, 6, false] }],
      [{ 'color': [] }, { 'background': [] }],          // dropdown with defaults from theme
      [{ 'font': [] }],
      [{ 'align': [] }],
      ['clean'],                                         // remove formatting button
      ['link', 'image']                                 // link and image, video
    ]
  };

  constructor(
    private formBuilder: FormBuilder,
    public catalogService: CatalogService, // Made public to access in template
    private authService: AuthService,
    private templateService: TemplateService,
    private router: Router,
    private route: ActivatedRoute
  ) {
    this.articleForm = this.createArticleForm();
  }

  ngOnInit(): void {
    // Subscribe to authentication state
    this.subscriptions.add(
      this.authService.currentUser$.subscribe((user: User | null) => {
        this.currentUser = user;
      })
    );

    // Set default newsletter type
    this.articleForm.patchValue({ type: 'newsletter' });

    // Load available newsletter templates
    this.loadNewsletterTemplates();

    // Check for parent_id from route query params (remove type checking)
    this.subscriptions.add(
      this.route.queryParams.subscribe(params => {
        if (params['parent_id']) {
          this.parentId = params['parent_id'];
          this.articleForm.patchValue({ parent_id: this.parentId });
        }
      })
    );
  }

  ngOnDestroy(): void {
    this.subscriptions.unsubscribe();
  }

  /**
   * Create article form with validation
   */
  private createArticleForm(): FormGroup {
    return this.formBuilder.group({
      title: ['', [Validators.required, Validators.minLength(3), Validators.maxLength(200)]],
      type: ['', [Validators.required]],
      description: ['', [Validators.maxLength(500)]],
      summary: ['', [Validators.maxLength(300)]],
      content: ['', [Validators.required, Validators.minLength(10)]],
      url: [''],
      image: [''],
      tags: [''],
      status: ['draft', [Validators.required]],
      category: [''],
      parent_id: [''],
      selectedTemplate: [''] // Add form control for template selection
    });
  }

  /**
   * Get selected catalog type details - return newsletter type
   */
  getSelectedCatalogType(): any {
    return {
      value: 'newsletter',
      label: 'Newsletter',
      icon: this.faNewspaper,
      color: '#007bff',
      background: '#d1e7ff',
      description: 'Newsletter content for regular updates and announcements'
    };
  }

  /**
   * Load available newsletter templates
   */
  loadNewsletterTemplates(): void {
    this.isLoadingTemplates = true;
    
    this.subscriptions.add(
      this.templateService.getAllNewsletterTemplates().subscribe({
        next: (templates) => {
          this.availableTemplates = templates;
          this.isLoadingTemplates = false;
          
          // Set default template
          const defaultTemplate = templates.find(t => t.isDefault);
          if (defaultTemplate) {
            this.selectedTemplateId = defaultTemplate.id;
            // Also update the form control
            this.articleForm.patchValue({ selectedTemplate: defaultTemplate.id });
          }
        },
        error: (error) => {
          console.error('Error loading templates:', error);
          this.isLoadingTemplates = false;
          this.errorMessage = 'Failed to load newsletter templates';
        }
      })
    );
  }

  /**
   * Handle template selection change
   */
  onTemplateSelectionChange(event: any): void {
    const templateId = event.target.value;
    this.selectedTemplateId = templateId;
    
    // Update the form control value
    this.articleForm.patchValue({ selectedTemplate: templateId });
    
    console.log('Template selection changed to:', templateId);
  }

  /**
   * Apply selected template to rich text editor
   */
  applySelectedTemplate(): void {
    if (!this.selectedTemplateId) {
      this.errorMessage = 'Please select a template first';
      return;
    }

    this.isApplyingTemplate = true;
    this.errorMessage = '';
    this.successMessage = '';

    console.log('Applying template:', this.selectedTemplateId);

    // Clear existing content immediately
    this.clearRichTextEditor();

    // Get current form values to populate template placeholders
    const currentFormData = this.articleForm.value;
    
    // Prepare template data for placeholder replacement
    const templateData = {
      title: currentFormData.title || 'Sample Newsletter Title',
      companyName: 'Your Company Name',
      currentDate: new Date().toLocaleDateString(),
      author: this.getUserDisplayName() || 'Newsletter Team',
      readingTime: this.calculateReadingTime(currentFormData.content || ''),
      featuredImage: currentFormData.image || 'https://via.placeholder.com/600x300/667eea/ffffff?text=Newsletter+Header',
      introduction: currentFormData.summary || 'Welcome to our newsletter template.',
      content: currentFormData.content || this.getSampleContentForTemplate(this.selectedTemplateId),
      tags: this.formatTags(currentFormData.tags || 'newsletter, updates'),
      catalogItems: this.selectedCatalogItems
    };

    console.log('Template data:', templateData);

    // Call template service to load and process the template
    this.subscriptions.add(
      this.templateService.loadTemplate(this.selectedTemplateId, templateData).subscribe({
        next: (templateHtml: string) => {
          console.log('Template loaded successfully, length:', templateHtml.length);
          
          if (templateHtml && templateHtml.trim()) {
            // Refresh the rich text editor with the template content
            this.refreshRichTextEditor(templateHtml);
            
            this.successMessage = `Template "${this.getSelectedTemplateName()}" applied successfully!`;
            
            // Clear success message after 3 seconds
            setTimeout(() => {
              this.successMessage = '';
            }, 3000);
          } else {
            this.errorMessage = 'Template loaded but content is empty. Please check the template file.';
          }
          
          this.isApplyingTemplate = false;
        },
        error: (error: any) => {
          console.error('Error loading template:', error);
          this.errorMessage = `Failed to load template: ${error.message || 'Please check if the template file exists.'}`;
          this.isApplyingTemplate = false;
        }
      })
    );
  }

  /**
   * Clear the rich text editor content
   */
  private clearRichTextEditor(): void {
    const contentControl = this.articleForm.get('content');
    if (contentControl) {
      console.log('Clearing rich text editor content');
      contentControl.setValue('');
      contentControl.markAsDirty();
      contentControl.updateValueAndValidity();
      
      // Reset word count
      this.currentWordCount = 0;
      this.onWordCountChange(0);
    }
  }

  /**
   * Refresh the rich text editor with new template content
   */
  private refreshRichTextEditor(templateHtml: string): void {
    const contentControl = this.articleForm.get('content');
    if (!contentControl) {
      console.error('Content form control not found');
      return;
    }

    console.log('Refreshing rich text editor with template content');

    // Apply the new template content with a delay to ensure the editor is ready
    setTimeout(() => {
      contentControl.setValue(templateHtml);
      contentControl.markAsDirty();
      contentControl.updateValueAndValidity();
      
      // Update word count based on new content
      const plainText = templateHtml.replace(/<[^>]*>/g, '');
      const wordCount = plainText.trim() ? plainText.trim().split(/\s+/).length : 0;
      this.currentWordCount = wordCount;
      this.onWordCountChange(wordCount);
      
      console.log('Rich text editor refreshed with template content, word count:', wordCount);
    }, 200);
  }

  /**
   * Calculate reading time based on content length
   */
  private calculateReadingTime(content: string): number {
    const wordsPerMinute = 200;
    const words = content.replace(/<[^>]*>/g, '').split(/\s+/).length;
    return Math.max(1, Math.ceil(words / wordsPerMinute));
  }

  /**
   * Apply selected template to editor (original method for reference)
   */
  /*applySelectedTemplate(): void {
    if (!this.selectedTemplateId) {
      this.errorMessage = 'Please select a template first';
      return;
    }

    this.isApplyingPreview = true;
    this.errorMessage = '';
    this.successMessage = '';

    // Get current form values for template data
    const currentFormData = this.articleForm.value;
    
    // Enhanced template data with sample content to show differences
    const templateData = {
      title: currentFormData.title || `Sample Newsletter Title - ${this.getSelectedTemplateName()}`,
      companyName: 'Your Company Name',
      currentDate: new Date().toLocaleDateString(),
      author: this.getUserDisplayName() || 'Newsletter Team',
      readingTime: '3',
      featuredImage: currentFormData.image || 'https://via.placeholder.com/600x300/667eea/ffffff?text=Newsletter+Header',
      introduction: currentFormData.summary || `This is a sample introduction for the ${this.getSelectedTemplateName()} template. Each template has its own unique styling and layout.`,
      content: currentFormData.content || this.getSampleContentForTemplate(this.selectedTemplateId),
      tags: this.formatTags(currentFormData.tags || 'newsletter, updates, company-news'),
      catalogItems: this.selectedCatalogItems
    };

    console.log('Applying template:', this.selectedTemplateId, 'with data:', templateData);

    this.subscriptions.add(
      this.templateService.applyNewsletterTemplate(this.selectedTemplateId, templateData).subscribe({
        next: (templateHtml) => {
          console.log('Template HTML received:', templateHtml.substring(0, 200) + '...');
          
          if (templateHtml && templateHtml.trim()) {
            // Force update the rich text editor content
            this.updateRichTextEditor(templateHtml);
            
            this.successMessage = `${this.getSelectedTemplateName()} template applied successfully!`;
            
            // Clear success message after 3 seconds
            setTimeout(() => {
              this.successMessage = '';
            }, 3000);
          } else {
            this.errorMessage = 'Failed to generate template content';
          }
          this.isApplyingPreview = false;
        },
        error: (error) => {
          console.error('Error applying template:', error);
          this.errorMessage = 'Failed to apply template. Please try again.';
          this.isApplyingPreview = false;
        }
      })
    );
  }*/

  /**
   * Force update the rich text editor with new content
   */
  private updateRichTextEditor(content: string): void {
    const contentControl = this.articleForm.get('content');
    if (contentControl) {
      // Clear first
      contentControl.setValue('');
      contentControl.markAsDirty();
      contentControl.updateValueAndValidity();
      
      // Apply new content after a short delay
      setTimeout(() => {
        contentControl.setValue(content);
        contentControl.markAsDirty();
        contentControl.updateValueAndValidity();
        
        // Update word count
        this.onWordCountChange(this.getWordCount());
      }, 100);
    }
  }

  /**
   * Get selected template name
   */
  private getSelectedTemplateName(): string {
    const template = this.availableTemplates.find(t => t.id === this.selectedTemplateId);
    return template ? template.name : 'Unknown Template';
  }

  /**
   * Get sample content for different templates
   */
  private getSampleContentForTemplate(templateId: string): string {
    const sampleContent = {
      'newsletter-1': `
        <h2>Welcome to Our Modern Business Newsletter</h2>
        <p>This template features a clean, professional design perfect for business communications.</p>
        <ul>
          <li>Professional header with company branding</li>
          <li>Clean typography and spacing</li>
          <li>Structured content sections</li>
        </ul>
        <p>Perfect for corporate updates, announcements, and business news.</p>
      `,
      'newsletter-2': `
        <h2>🌟 Marketing Campaign Newsletter</h2>
        <p>This vibrant template is designed to catch attention and drive engagement!</p>
        <blockquote>
          <p>"Stand out with eye-catching gradients and call-to-action sections."</p>
        </blockquote>
        <h3>Key Features:</h3>
        <ul>
          <li>Colorful gradient backgrounds</li>
          <li>Built-in call-to-action sections</li>
          <li>Marketing-focused layout</li>
        </ul>
        <p><strong>Ready to boost your marketing campaigns?</strong> This template is perfect for promotions, product launches, and customer engagement.</p>
      `,
      'newsletter-3': `
        <h2>Official Company Announcement</h2>
        <p>This formal template maintains a professional tone suitable for important communications.</p>
        <p>Featuring traditional serif typography and structured layout, this template ensures your message is delivered with authority and clarity.</p>
        <h3>Ideal For:</h3>
        <ol>
          <li>Corporate announcements</li>
          <li>Policy updates</li>
          <li>Executive communications</li>
          <li>Board meeting minutes</li>
        </ol>
        <p><em>This template emphasizes readability and professional presentation.</em></p>
      `
    };
    
    return sampleContent[templateId as keyof typeof sampleContent] || '<p>Sample newsletter content for this template...</p>';
  }

  /**
   * Format tags for display
   */
  private formatTags(tags: string): string {
    if (!tags) return '';
    return tags.split(',').map(tag => tag.trim()).filter(tag => tag).join(', ');
  }

  /**
   * Save article (draft or publish)
   */
  saveArticle(publish: boolean = false): void {
    if (this.articleForm.invalid) {
      this.articleForm.markAllAsTouched();
      return;
    }

    this.isSaving = true;
    this.successMessage = '';
    this.errorMessage = '';

    // Transform form data to match API expectations
    const formData = this.articleForm.value;
    
    // Convert tags string to array
    const tagsArray: string[] = [];
    if (formData.tags && typeof formData.tags === 'string') {
      tagsArray.push(...formData.tags.split(',').map((tag: string) => tag.trim()).filter((tag: string) => tag));
    }

    // Send CatalogChildItem objects directly as the API now supports this structure
    const childIdsArray: CatalogChildItem[] = this.selectedCatalogItems
      .sort((a, b) => a.index - b.index) // Sort by index to maintain order
      .map(item => ({
        id: String(item.id),
        index: item.index,
        title: item.title || '',
        description: item.description || '',
        author: item.author || ''
      }));

    // Prepare article data according to API schema
    const articleData: CatalogCreate = {
      title: formData.title,
      type: formData.type,
      description: formData.description || '',
      summary: formData.summary || '',
      content: formData.content,
      url: formData.url || '',
      image: formData.image || '',
      tags: tagsArray,
      status: formData.status,
      category: formData.category || '',
      parent_id: formData.parent_id || '',
      child_ids: childIdsArray, // Send array of CatalogChildItem objects
      author: this.getUserDisplayName(),
      created_date: new Date().toISOString(),
      updated_date: new Date().toISOString()
    };

    console.log('Sending article data with child_ids as CatalogChildItem objects:', articleData);

    this.subscriptions.add(
      this.catalogService.createArticle(articleData).subscribe({
        next: (response) => {
          console.log('Article created successfully:', response);
          this.isSaving = false;
          this.successMessage = publish ? 'Article published successfully!' : 'Draft saved successfully!';
          this.errorMessage = '';
          this.articleForm.markAsPristine();
          if (publish) {
            setTimeout(() => {
              this.router.navigate(['/user/catalog']);
            }, 1000);
          }
        },
        error: (error) => {
          console.error('Error saving article:', error);
          this.isSaving = false;
          
          // Provide more specific error messages
          let errorMessage = 'Failed to save article. Please try again.';
          if (error.message) {
            errorMessage = error.message;
          }
          
          this.errorMessage = errorMessage;
          this.successMessage = '';
        }
      })
    );
  }

  /**
   * Cancel article creation or editing
   */
  cancel(): void {
    this.router.navigate(['/user/catalog']);
  }

  /**
   * Handle word count changes from rich text editor
   */
  onWordCountChange(wordCount: number): void {
    this.currentWordCount = wordCount;
  }

  /**
   * Get word count
   */
  getWordCount(): number {
    return this.currentWordCount;
  }

  /**
   * Get reading time calculation
   */
  getReadingTime(): number {
    const wordsPerMinute = 200;
    return Math.max(1, Math.ceil(this.currentWordCount / wordsPerMinute));
  }

  /**
   * Handle page hero action clicks
   */
  onHeroActionClick(actionIndex: number): void {
    switch (actionIndex) {
      case 0: // Cancel
        this.cancel();
        break;
      case 1: // Save Draft
        this.saveDraft();
        break;
    }
  }

  /**
   * Check if a form field has validation errors
   */
  hasFieldError(fieldName: string): boolean {
    const field = this.articleForm.get(fieldName);
    return !!(field && field.invalid && (field.dirty || field.touched));
  }

  /**
   * Get validation error message for a field
   */
  getFieldError(fieldName: string): string {
    const field = this.articleForm.get(fieldName);
    if (field && field.errors) {
      if (field.errors['required']) {
        return `${fieldName.charAt(0).toUpperCase() + fieldName.slice(1)} is required`;
      }
      if (field.errors['minlength']) {
        return `${fieldName.charAt(0).toUpperCase() + fieldName.slice(1)} must be at least ${field.errors['minlength'].requiredLength} characters`;
      }
      if (field.errors['maxlength']) {
        return `${fieldName.charAt(0).toUpperCase() + fieldName.slice(1)} must not exceed ${field.errors['maxlength'].requiredLength} characters`;
      }
      if (field.errors['email']) {
        return 'Please enter a valid email address';
      }
      if (field.errors['url']) {
        return 'Please enter a valid URL';
      }
    }
    return '';
  }

  /**
   * Get character count for a field
   */
  getCharacterCount(fieldName: string): number {
    const value = this.articleForm.get(fieldName)?.value;
    return value ? value.length : 0;
  }

  /**
   * Get maximum length for a field
   */
  getMaxLength(fieldName: string): number {
    const maxLengths: { [key: string]: number } = {
      title: 200,
      description: 500,
      summary: 300
    };
    return maxLengths[fieldName] || 0;
  }

  /**
   * Clear the form
   */
  clearForm(): void {
    this.articleForm.reset();
    this.selectedCatalogType = '';
    this.currentWordCount = 0;
    this.successMessage = '';
    this.errorMessage = '';
  }

  /**
   * Save article as draft
   */
  saveDraft(): void {
    this.articleForm.patchValue({ status: 'draft' });
    
    if (this.articleForm.invalid) {
      this.articleForm.markAllAsTouched();
      return;
    }

    this.isSaving = true;
    this.successMessage = '';
    this.errorMessage = '';

    // Transform form data to match API expectations
    const formData = this.articleForm.value;
    
    // Convert tags string to array
    const tagsArray: string[] = [];
    if (formData.tags && typeof formData.tags === 'string') {
      tagsArray.push(...formData.tags.split(',').map((tag: string) => tag.trim()).filter((tag: string) => tag));
    }

    // Send CatalogChildItem objects directly as the API now supports this structure
    const childIdsArray: CatalogChildItem[] = this.selectedCatalogItems
      .sort((a, b) => a.index - b.index) // Sort by index to maintain order
      .map(item => ({
        id: String(item.id),
        index: item.index,
        title: item.title || '',
        description: item.description || '',
        author: item.author || ''
      }));

    // Prepare article data according to API schema
    const articleData: CatalogCreate = {
      title: formData.title,
      type: formData.type,
      description: formData.description || '',
      summary: formData.summary || '',
      content: formData.content,
      url: formData.url || '',
      image: formData.image || '',
      tags: tagsArray,
      status: 'draft',
      category: formData.category || '',
      parent_id: formData.parent_id || '',
      child_ids: childIdsArray, // Send array of CatalogChildItem objects
      author: this.getUserDisplayName(),
      created_date: new Date().toISOString(),
      updated_date: new Date().toISOString()
    };

    console.log('Sending draft data with child_ids as CatalogChildItem objects:', articleData);

    this.subscriptions.add(
      this.catalogService.createArticle(articleData).subscribe({
        next: (response) => {
          console.log('Article created successfully:', response);
          this.isSaving = false;
          this.successMessage = 'Draft saved successfully!';
          this.errorMessage = '';
          this.articleForm.markAsPristine();
          
          // Redirect to catalog with the same catalog type filter
          setTimeout(() => {
            const catalogType = this.selectedCatalogType || formData.type;
            if (catalogType) {
              // Navigate to catalog with the catalog type as a query parameter to pre-filter
              this.router.navigate(['/user/catalog'], { 
                queryParams: { type: catalogType }
              });
            } else {
              // Fallback to catalog without filter
              this.router.navigate(['/user/catalog']);
            }
          }, 1000);
        },
        error: (error) => {
          console.error('Error saving article:', error);
          this.isSaving = false;
          
          // Provide more specific error messages
          let errorMessage = 'Failed to save article. Please try again.';
          if (error.message) {
            errorMessage = error.message;
          }
          
          this.errorMessage = errorMessage;
          this.successMessage = '';
        }
      })
    );
  }

  /**
   * Get current user display name
   */
  getUserDisplayName(): string {
    if (this.currentUser?.first_name && this.currentUser?.last_name) {
      return `${this.currentUser.first_name} ${this.currentUser.last_name}`;
    }
    return this.currentUser?.email || this.currentUser?.user_id || 'Unknown User';
  }

  /**
   * Get current date formatted
   */
  getCurrentDate(): string {
    return new Date().toLocaleDateString();
  }

  /**
   * Open catalog items selection popup
   */
  openCatalogItemsPopup(): void {
    this.showCatalogItemsPopup = true;
    this.loadCatalogItems();
  }

  /**
   * Close catalog items selection popup
   */
  closeCatalogItemsPopup(): void {
    this.showCatalogItemsPopup = false;
  }

  /**
   * Load catalog items for selection - Updated to filter for approved items only
   */
  loadCatalogItems(): void {
    this.isLoadingCatalogItems = true;
    
    // Filter for approved items only
    const params = {
      status: 'approved', // Only load approved catalog items
      page_size: 100,
      sort: 'updated_date',
      order: 'desc' as 'desc' // Fix TypeScript type error by casting to literal type
    };
    
    this.subscriptions.add(
      this.catalogService.getCatalogItems(params).subscribe({
        next: (response: any) => {
          this.availableCatalogItems = response.items || [];
          this.filteredCatalogItems = this.availableCatalogItems; // Initialize filtered items
          this.isLoadingCatalogItems = false;
          console.log('Loaded approved catalog items:', this.availableCatalogItems.length);
        },
        error: (error: any) => {
          console.error('Error loading catalog items:', error);
          this.isLoadingCatalogItems = false;
          this.errorMessage = 'Failed to load catalog items';
        }
      })
    );
  }

  /**
   * Search catalog items
   */
  searchCatalogItems(): void {
    const searchTerm = this.catalogSearchTerm.toLowerCase();
    
    this.filteredCatalogItems = this.availableCatalogItems.filter(item => 
      item.title.toLowerCase().includes(searchTerm)
    );
  }

  /**
   * Toggle selection of a catalog item - Updated to properly use catalogID and child index
   */
  toggleCatalogItemSelection(item: any): void {
    const existingIndex = this.selectedCatalogItems.findIndex(i => String(i.id) === String(item.id));
    
    if (existingIndex === -1) {
      // Item not selected, add to selection with catalogID and child index
      const catalogItem: CatalogChildItem = {
        id: item.id, // The catalog ID of the child item
        index: this.selectedCatalogItems.length, // Child index number for ordering (0-based)
        title: item.title,
        description: item.description || '',
        author: item.author || ''
      };
      this.selectedCatalogItems.push(catalogItem);
    } else {
      // Item already selected, remove from selection and reindex remaining items
      this.selectedCatalogItems.splice(existingIndex, 1);
      this.reindexSelectedItems();
    }
  }

  /**
   * Reindex selected catalog items to maintain proper child index ordering
   */
  private reindexSelectedItems(): void {
    this.selectedCatalogItems.forEach((item, childIndex) => {
      item.index = childIndex; // Update child index number (0-based)
    });
  }

  /**
   * Move catalog item up in sequence - Updated to accept CatalogChildItem
   */
  moveCatalogItemUp(item: CatalogChildItem): void {
    const currentIndex = this.selectedCatalogItems.findIndex(i => String(i.id) === String(item.id));
    if (currentIndex > 0) {
      // Swap with previous item
      const temp = this.selectedCatalogItems[currentIndex];
      this.selectedCatalogItems[currentIndex] = this.selectedCatalogItems[currentIndex - 1];
      this.selectedCatalogItems[currentIndex - 1] = temp;
      
      // Update child index numbers
      this.reindexSelectedItems();
    }
  }

  /**
   * Move catalog item down in sequence - Updated to accept CatalogChildItem
   */
  moveCatalogItemDown(item: CatalogChildItem): void {
    const currentIndex = this.selectedCatalogItems.findIndex(i => String(i.id) === String(item.id));
    if (currentIndex !== -1 && currentIndex < this.selectedCatalogItems.length - 1) {
      // Swap with next item
      const temp = this.selectedCatalogItems[currentIndex];
      this.selectedCatalogItems[currentIndex] = this.selectedCatalogItems[currentIndex + 1];
      this.selectedCatalogItems[currentIndex + 1] = temp;
      
      // Update child index numbers
      this.reindexSelectedItems();
    }
  }

  /**
   * Check if a catalog item is selected - Updated to accept CatalogChildItem
   */
  isCatalogItemSelected(item: CatalogChildItem | {id: string | number, title: string}): boolean {
    return this.selectedCatalogItems.some(i => String(i.id) === String(item.id));
  }

  /**
   * Get the sequence index (1-based) of a selected catalog item - Updated to accept CatalogChildItem
   */
  getCatalogItemSequenceIndex(item: CatalogChildItem | {id: string | number, title: string}): number {
    const catalogItem = this.selectedCatalogItems.find(i => String(i.id) === String(item.id));
    return catalogItem ? catalogItem.index + 1 : 0; // Return 1-based display index
  }

  /**
   * Check if catalog item can be moved up - Updated to accept CatalogChildItem
   */
  canMoveCatalogItemUp(item: CatalogChildItem): boolean {
    const catalogItem = this.selectedCatalogItems.find(i => String(i.id) === String(item.id));
    return catalogItem ? catalogItem.index > 0 : false;
  }

  /**
   * Check if catalog item can be moved down - Updated to accept CatalogChildItem
   */
  canMoveCatalogItemDown(item: CatalogChildItem): boolean {
    const catalogItem = this.selectedCatalogItems.find(i => String(i.id) === String(item.id));
    return catalogItem ? catalogItem.index < this.selectedCatalogItems.length - 1 : false;
  }

  /**
   * Apply selected catalog items to the article
   */
  applySelectedCatalogItems(): void {
    if (this.selectedCatalogItems.length === 0) {
      this.errorMessage = 'Please select at least one catalog item';
      return;
    }

    this.isApplyingTemplate = true;
    
    // Get current form values for catalog items data
    const currentFormData = this.articleForm.value;
    
    // Prepare catalog items data
    const catalogItemsData = this.selectedCatalogItems.map(item => ({
      id: item.id,
      title: item.title
    }));

    // Enhanced template data with catalog items
    const templateData = {
      title: currentFormData.title || `Newsletter Title - ${this.getSelectedTemplateName()}`,
      companyName: 'Your Company Name',
      currentDate: new Date().toLocaleDateString(),
      author: this.getUserDisplayName() || 'Newsletter Team',
      readingTime: this.calculateReadingTime(currentFormData.content || ''),
      featuredImage: currentFormData.image || 'https://via.placeholder.com/600x300/667eea/ffffff?text=Newsletter+Header',
      introduction: currentFormData.summary || `Newsletter with selected catalog items from ${this.getSelectedTemplateName()} template.`,
      content: currentFormData.content || this.getSampleContentForTemplate(this.selectedTemplateId),
      tags: this.formatTags(currentFormData.tags || 'newsletter, updates, company-news'),
      catalogItems: catalogItemsData
    };

    console.log('Applying catalog items to template:', this.selectedTemplateId, 'with data:', templateData);

    this.subscriptions.add(
      this.templateService.loadTemplate(this.selectedTemplateId, templateData).subscribe({
        next: (templateHtml) => {
          console.log('Template HTML with catalog items received:', templateHtml.substring(0, 200) + '...');
          
          if (templateHtml && templateHtml.trim()) {
            // Update the rich text editor with the template including catalog items
            this.updateRichTextEditor(templateHtml);
            
            this.successMessage = `Catalog items applied successfully!`;
            this.errorMessage = '';
            
            // Clear success message after 3 seconds
            setTimeout(() => {
              this.successMessage = '';
            }, 3000);
          } else {
            this.errorMessage = 'Failed to generate template content with catalog items';
          }
          this.isApplyingTemplate = false;
        },
        error: (error) => {
          console.error('Error applying template with catalog items:', error);
          this.errorMessage = 'Failed to apply template with catalog items. Please try again.';
          this.isApplyingTemplate = false;
        }
      })
    );
  }

  /**
   * Handle catalog items selection from the reusable popup component
   */
  onCatalogItemsSelected(selectedItems: CatalogChildItem[]): void {
    this.selectedCatalogItems = selectedItems;
    console.log('Catalog items selected from popup:', selectedItems);
    
    // Close the popup
    this.closeCatalogItemsPopup();
    
    // Optional: Apply the selected items to the template automatically
    if (selectedItems.length > 0 && this.selectedTemplateId) {
      // Show a brief success message
      this.successMessage = `${selectedItems.length} catalog item(s) selected successfully!`;
      setTimeout(() => {
        this.successMessage = '';
      }, 2000);
    }
  }
}
# User Search Component Usage Guide

## Overview
The `UserSearchComponent` is a highly customizable, searchable dropdown component designed for selecting users, particularly useful for manager selection in admin interfaces.

## Features
- 🔍 **Real-time search** with debounced input
- ⌨️ **Keyboard navigation** (Arrow keys, Enter, Escape)
- 🎨 **User avatars** with initials
- 🏷️ **Role and status badges**
- 📱 **Responsive design**
- ♿ **Accessibility support**
- 🎛️ **Form control integration** (ControlValueAccessor)
- 🚫 **Exclusion filters** (current user, roles, status)

## Basic Usage

### Template (HTML)
```html
<app-user-search
  label="Select Manager"
  placeholder="Search for a manager..."
  [required]="true"
  [excludeCurrentUser]="true"
  [activeOnly]="true"
  [allowClear]="true"
  (userSelected)="onManagerSelected($event)">
</app-user-search>
```

### Component (TypeScript)
```typescript
export class MyComponent {
  selectedManager: User | null = null;

  onManagerSelected(user: User | null): void {
    this.selectedManager = user;
    console.log('Selected manager:', user);
  }
}
```

## Reactive Forms Integration

### Template
```html
<form [formGroup]="userForm">
  <app-user-search
    label="Manager"
    placeholder="Search for a manager..."
    formControlName="manager"
    [required]="true"
    [excludeCurrentUser]="true"
    [rolesFilter]="['admin']"
    [showUserRole]="true"
    [showUserStatus]="true">
  </app-user-search>
</form>
```

### Component
```typescript
export class MyComponent {
  userForm = this.fb.group({
    firstName: ['', Validators.required],
    lastName: ['', Validators.required],
    manager: [null, Validators.required] // User object or null
  });

  constructor(private fb: FormBuilder) {}

  onSubmit(): void {
    if (this.userForm.valid) {
      const formValue = this.userForm.value;
      console.log('Selected manager:', formValue.manager);
    }
  }
}
```

## Input Properties

| Property | Type | Default | Description |
|----------|------|---------|-------------|
| `label` | string | 'Select User' | Label text displayed above the input |
| `placeholder` | string | 'Search for a user...' | Placeholder text for the search input |
| `disabled` | boolean | false | Disables the component |
| `required` | boolean | false | Shows required indicator (*) |
| `excludeCurrentUser` | boolean | true | Excludes the current logged-in user from results |
| `rolesFilter` | string[] | [] | Filter users by roles ('user', 'admin') |
| `activeOnly` | boolean | true | Only show active users |
| `maxResults` | number | 10 | Maximum number of search results to display |
| `showUserRole` | boolean | true | Show user role badges |
| `showUserStatus` | boolean | true | Show user status badges |
| `allowClear` | boolean | true | Show clear button when user is selected |

## Output Events

| Event | Type | Description |
|-------|------|-------------|
| `userSelected` | User \| null | Emitted when a user is selected or cleared |
| `searchChanged` | string | Emitted when the search term changes |

## Advanced Examples

### Manager Selection for User Creation
```html
<app-card title="User Information">
  <form [formGroup]="createUserForm" (ngSubmit)="createUser()">
    <div class="form-row">
      <div class="form-group">
        <label>First Name *</label>
        <input formControlName="firstName" class="form-input" />
      </div>
      <div class="form-group">
        <label>Last Name *</label>
        <input formControlName="lastName" class="form-input" />
      </div>
    </div>

    <div class="form-group">
      <app-user-search
        label="Manager"
        placeholder="Search for a manager..."
        formControlName="manager"
        [excludeCurrentUser]="true"
        [rolesFilter]="['admin']"
        [activeOnly]="true"
        [showUserRole]="true"
        [showUserStatus]="false"
        [maxResults]="15">
      </app-user-search>
    </div>

    <div class="form-actions">
      <app-action-button
        type="submit"
        variant="primary"
        [disabled]="createUserForm.invalid"
        [loading]="isCreating">
        Create User
      </app-action-button>
    </div>
  </form>
</app-card>
```

### Multi-purpose User Selection
```html
<!-- For Admin Selection -->
<app-user-search
  label="Select Administrator"
  placeholder="Search administrators..."
  [rolesFilter]="['admin']"
  [excludeCurrentUser]="false"
  [showUserRole]="true"
  (userSelected)="onAdminSelected($event)">
</app-user-search>

<!-- For Team Member Selection -->
<app-user-search
  label="Team Member"
  placeholder="Search team members..."
  [rolesFilter]="['user']"
  [activeOnly]="true"
  [maxResults]="20"
  (userSelected)="onTeamMemberSelected($event)">
</app-user-search>

<!-- For Any User Selection -->
<app-user-search
  label="Select Any User"
  placeholder="Search all users..."
  [excludeCurrentUser]="false"
  [activeOnly]="false"
  [showUserStatus]="true"
  (userSelected)="onUserSelected($event)">
</app-user-search>
```

## Styling Customization

The component uses CSS custom properties for easy theming:

```css
app-user-search {
  --user-search-border-color: #d1d5db;
  --user-search-focus-color: #3b82f6;
  --user-search-background: #ffffff;
  --user-search-text-color: #374151;
  --user-search-placeholder-color: #9ca3af;
}

/* Dark theme example */
.dark-theme app-user-search {
  --user-search-border-color: #374151;
  --user-search-focus-color: #60a5fa;
  --user-search-background: #1f2937;
  --user-search-text-color: #f3f4f6;
  --user-search-placeholder-color: #6b7280;
}
```

## Accessibility Features

- **ARIA labels** for screen readers
- **Keyboard navigation** support
- **Focus management** with proper tab order
- **High contrast** mode support
- **Screen reader** announcements for selections

## Performance Considerations

- **Debounced search** (300ms) to reduce API calls
- **Maximum results limit** to prevent UI overload
- **Efficient filtering** with early returns
- **Observable cleanup** to prevent memory leaks

## Integration with Admin Dashboard

For admin user management, you can integrate this component as follows:

```typescript
export class AdminUserEditComponent {
  editUserForm = this.fb.group({
    firstName: ['', Validators.required],
    lastName: ['', Validators.required],
    email: ['', [Validators.required, Validators.email]],
    manager: [null], // Optional manager selection
    role: ['user', Validators.required]
  });

  constructor(
    private fb: FormBuilder,
    private userService: UserService
  ) {}

  onManagerSelected(manager: User | null): void {
    console.log('Manager selected:', manager);
    // Additional logic for manager selection
    if (manager) {
      // Update related fields, validate permissions, etc.
      this.validateManagerSelection(manager);
    }
  }

  private validateManagerSelection(manager: User): void {
    // Ensure manager has appropriate permissions
    if (manager.role !== 'admin') {
      // Show warning or prevent selection
      console.warn('Selected manager is not an administrator');
    }
  }

  updateUser(): void {
    if (this.editUserForm.valid) {
      const userData = this.editUserForm.value;
      const managerId = userData.manager?.id || null;
      
      this.userService.updateUser({
        ...userData,
        manager_id: managerId
      }).subscribe({
        next: (updatedUser) => {
          console.log('User updated successfully:', updatedUser);
        },
        error: (error) => {
          console.error('Failed to update user:', error);
        }
      });
    }
  }
}
```

This component provides a robust, user-friendly interface for manager selection with extensive customization options and seamless form integration.
import { Component, OnInit, OnDestroy } from '@angular/core';
import { Router } from '@angular/router';
import { AuthService } from '../shared/services/auth.service';
import { User } from '../shared/models/user.interface';
import { Subscription } from 'rxjs';

@Component({
  selector: 'app-home',
  template: `
    <div class="loading-container" *ngIf="isRedirecting">
      <div class="loading-content">
        <div class="spinner"></div>
        <p>Redirecting to your dashboard...</p>
      </div>
    </div>
  `,
  styles: [`
    .loading-container {
      display: flex;
      justify-content: center;
      align-items: center;
      min-height: 100vh;
      background: var(--fm-bg-light);
    }
    
    .loading-content {
      text-align: center;
      padding: 2rem;
    }
    
    .spinner {
      width: 40px;
      height: 40px;
      border: 4px solid #f3f3f3;
      border-top: 4px solid var(--fm-primary-blue);
      border-radius: 50%;
      animation: spin 1s linear infinite;
      margin: 0 auto 1rem;
    }
    
    @keyframes spin {
      0% { transform: rotate(0deg); }
      100% { transform: rotate(360deg); }
    }
    
    p {
      color: var(--fm-text-secondary);
      font-size: 1.1rem;
      margin: 0;
    }
  `]
})
export class HomeComponent implements OnInit, OnDestroy {
  isRedirecting = true;
  private subscription = new Subscription();

  constructor(
    private router: Router,
    private authService: AuthService
  ) { }

  ngOnInit(): void {
    this.handleRoleBasedRedirection();
  }

  ngOnDestroy(): void {
    this.subscription.unsubscribe();
  }

  /**
   * Handle role-based redirection to appropriate home page
   */
  private handleRoleBasedRedirection(): void {
    this.subscription.add(
      this.authService.currentUser$.subscribe({
        next: (user: User | null) => {
          if (user) {
            // User is authenticated, redirect based on role
            this.redirectBasedOnRole(user);
          } else {
            // User is not authenticated, redirect to login or show public home
            this.redirectToPublicHome();
          }
        },
        error: (error) => {
          console.error('Error checking user authentication:', error);
          this.redirectToPublicHome();
        }
      })
    );
  }

  /**
   * Redirect user based on their role
   */
  private redirectBasedOnRole(user: User): void {
    const role = user.role?.toLowerCase();
    
    switch (role) {
      case 'admin':
        console.log('Redirecting admin user to admin home');
        this.router.navigate(['/admin/home']);
        break;
      case 'user':
      default:
        console.log('Redirecting regular user to user home');
        this.router.navigate(['/user/home']);
        break;
    }
  }

  /**
   * Redirect to public home page or login
   */
  private redirectToPublicHome(): void {
    // For now, redirect to login if not authenticated
    // In future, you could show a public landing page here
    console.log('User not authenticated, redirecting to login');
    this.router.navigate(['/auth/login']);
  }
}
import { Component, Input, OnInit, OnDestroy, HostListener } from '@angular/core';
import { Router } from '@angular/router';
import {
  faChartLine, faFolder, faFileAlt, faLightbulb, faHandshake, faRocket,
  faUser, faCog, faBookmark, faHeart, faCheck, faTimes, faUserCog,
  faExclamationTriangle, faArrowTrendUp, faArrowTrendDown, faPlus, faSearch,
  faBell, faChartPie, faCalendarAlt, faArrowUp, faArrowDown, faEye,
  faThumbsUp, faShare, faDownload, faEdit, faStar, faChevronDown, faUsers,
  faEllipsisV, faNewspaper, faBook, faGraduationCap, faBlog, faFlask,
  faFileContract, faChartLine as faAnalytics, faCheckCircle,
  faExclamationCircle, faClock, faComments
} from '@fortawesome/free-solid-svg-icons';
import { CatalogService } from '../../shared/services/catalog.service';
import { UserService } from '../../shared/services/user.service';
import { AuthService } from '../../shared/services/auth.service';
import { User, Catalog } from '../../shared/models/user.interface';
import { OverlapButtonConfig } from '../../shared/components/overlap-button/overlap-button.component';
import { HOME_NAVIGATION_BUTTONS, CATALOG_TYPES } from '../../shared/config/site-config';
import { Subscription, Observable, of, forkJoin, timer, interval, merge } from 'rxjs';
import { map, catchError, switchMap, debounceTime, distinctUntilChanged, filter, takeWhile } from 'rxjs/operators';
import { SmartListPost } from '../../shared/components/smart-list/smart-list.component';
import { DeleteConfirmationComponent, DeleteConfirmationData } from '../../shared/components/delete-confirmation/delete-confirmation.component';

// Updated interfaces for real data
interface PendingApproval {
  id: string;
  title: string;
  type: string;
  submittedBy: string;
  submittedByUserId: string;
  submittedDate: string;
  priority: 'high' | 'medium' | 'low';
  status: string;
  description?: string;
  content?: string;
}

interface Alert {
  id: string;
  message: string;
  type: 'warning' | 'info' | 'error';
  timestamp: string;
}

interface ActivityItem {
  id: string;
  title: string;
  type: 'created' | 'updated' | 'approved' | 'shared';
  timestamp: string;
  user: string;
}

interface Recommendation {
  id: string;
  title: string;
  type: 'article' | 'tool' | 'resource';
  description: string;
  url: string;
}

interface BookmarkedItem {
  id: string;
  title: string;
  type: 'project' | 'document';
  bookmarkedDate: string;
}

interface TeamFeedItem {
  id: string;
  title: string;
  type: string;
  sharedBy: string;
  sharedByUserId: string;
  sharedDate: string;
  description?: string;
  priority?: 'high' | 'medium' | 'low';
  action: 'shared' | 'updated' | 'commented';
}

// Smart Refresh Configuration Interface
interface RefreshConfig {
  interval: number;
  priority: 'high' | 'medium' | 'low';
  enabled: boolean;
  lastRefresh: Date;
  errorCount: number;
}

// Data Change Detection Interface
interface DataSnapshot {
  teamShares: { count: number; lastUpdated: string };
  approvalQueue: { count: number; lastUpdated: string };
  quickDrafts: { count: number; lastUpdated: string };
  catalogMetrics: { total: number; projects: number; documents: number; drafts: number };
}

@Component({
  selector: 'app-user-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class UserHomeComponent implements OnInit, OnDestroy {
  // Font Awesome icons
  faChartLine = faChartLine;
  faFolder = faFolder;
  faFileAlt = faFileAlt;
  faLightbulb = faLightbulb;
  faHandshake = faHandshake;
  faRocket = faRocket;
  faUser = faUser;
  faCog = faCog;
  faBookmark = faBookmark;
  faHeart = faHeart;
  faCheck = faCheck;
  faTimes = faTimes;
  faUserCog = faUserCog;
  faExclamationTriangle = faExclamationTriangle;
  faArrowTrendUp = faArrowTrendUp;
  faArrowTrendDown = faArrowTrendDown;
  faPlus = faPlus;
  faSearch = faSearch;
  faBell = faBell;
  faChartPie = faChartPie;
  faCalendarAlt = faCalendarAlt;
  faArrowUp = faArrowUp;
  faArrowDown = faArrowDown;
  faEye = faEye;
  faThumbsUp = faThumbsUp;
  faShare = faShare;
  faDownload = faDownload;
  faEdit = faEdit;
  faStar = faStar;
  faChevronDown = faChevronDown;
  faUsers = faUsers;
  faEllipsisV = faEllipsisV;
  faNewspaper = faNewspaper;
  faBook = faBook;
  faGraduationCap = faGraduationCap;
  faBlog = faBlog;
  faFlask = faFlask;
  faFileContract = faFileContract;
  faAnalytics = faAnalytics;
  faCheckCircle = faCheckCircle;
  faExclamationCircle = faExclamationCircle;
  faClock = faClock;
  faComments = faComments;

  showModal: boolean = false;

  // Navigation buttons configuration
  navigationButtons: OverlapButtonConfig[] = [];

  // Badge counts from API
  dashboardCount = 0;
  weeklyWinsCount = 0;
  approvalsCount = 0;
  teamCount = 0;
  catalogCount = 0;
  reportsCount = 0;

  // Legacy counts for activity section
  projectsCount = 0;
  resourcesCount = 0;
  bookmarksCount = 0;
  myProjectsCount = 0;
  favoritesCount = 0;

  private subscription = new Subscription();

  // New properties for dashboard
  showPendingApprovals = false;
  showCreateDropdown = false;
  showCreatePostPopup = false;
  searchQuery = '';

  // Quick Note form fields
  quickNoteTitle: string = '';
  quickNoteContent: string = '';
  quickNoteType: 'notes' | 'quick-wins' | 'documents' = 'notes';
  quickNoteTags: string = '';

  // Statistics
  newItemsCount = 0;
  newItemsTrend = 0;
  unreadPriorityCount = 0;
  completedActionsCount = 0;
  completedActionsProgress = 0;

  // Real data arrays - no mock data
  pendingApprovals: PendingApproval[] = [];
  teamFeed: TeamFeedItem[] = [];
  recommendations: Recommendation[] = [];
  bookmarkedItems: BookmarkedItem[] = [];
  quickWins = [];

  // Current user information
  currentUser: User | null = null;

  // Smart Refresh System Properties
  private refreshConfigs: { [key: string]: RefreshConfig } = {
    teamShares: { interval: 30000, priority: 'high', enabled: true, lastRefresh: new Date(), errorCount: 0 }, // 30s
    approvalQueue: { interval: 20000, priority: 'high', enabled: true, lastRefresh: new Date(), errorCount: 0 }, // 20s
    quickDrafts: { interval: 60000, priority: 'medium', enabled: true, lastRefresh: new Date(), errorCount: 0 }, // 1min
    catalogMetrics: { interval: 120000, priority: 'low', enabled: true, lastRefresh: new Date(), errorCount: 0 } // 2min
  };

  private refreshTimers: { [key: string]: Subscription } = {};
  private lastDataSnapshot: DataSnapshot | null = null;
  private isPageVisible = true;
  private isUserActive = true;
  private lastUserActivity = new Date();
  private refreshInProgress = false;

  // Refresh status indicators
  isRefreshing = false;
  lastRefreshTime = new Date();
  refreshErrors: string[] = [];

  // Delete confirmation state
  showDeleteConfirm = false;
  itemToDelete: DeleteConfirmationData | null = null;
  isDeleting = false;

  constructor(
    private router: Router,
    private catalogService: CatalogService,
    private userService: UserService,
    private authService: AuthService
  ) { }

  ngOnInit(): void {
    this.currentUser = this.authService.getCurrentUserValue();
    this.setupNavigationButtons();
    
    // Initial data load
    this.loadAllData();
    
    // Initialize smart refresh system
    this.initializeSmartRefresh();
    
    // Setup activity tracking
    this.setupActivityTracking();
  }

  ngOnDestroy(): void {
    this.subscription.unsubscribe();
    this.stopAllRefreshTimers();
  }

  /**
   * Navigate to a specific route
   */
  navigateTo(route: string): void {
    console.log('Navigating to:', route);
    switch (route) {
      case 'notifications':
        this.router.navigate(['/user/notifications']);
        break;
      case 'assets':
        this.router.navigate(['/user/catalog-list/assets']);
        break;
      case 'quick-wins':
        this.router.navigate(['/user/catalog-list/quick-wins']);
        break;
      case 'approvals':
        this.navigateToApprovals();
        break;
      default:
        this.router.navigate(['/user', route]);
        break;
    }
  }

  /**
   * Navigate to catalog with approvals filter applied
   */
  navigateToApprovals(): void {
    const currentUser = this.authService.getCurrentUserValue();
    if (!currentUser) {
      console.error('No current user found for approvals navigation');
      return;
    }

    console.log('Navigating to catalog with approvals filter for user:', currentUser.user_id || currentUser.id);
    
    // Navigate to catalog with query parameters for filtering approvals
    this.router.navigate(['/user/catalog'], {
      queryParams: {
        filter: 'approvals',
        status: 'pending_approval,approved',
        approver: currentUser.user_id || currentUser.id || currentUser.email,
        view: 'list'
      }
    });
  }

  /**
   * Toggle pending approvals section
   */
  togglePendingApprovals(): void {
    this.showPendingApprovals = !this.showPendingApprovals;
  }

  /**
   * Toggle create dropdown
   */
  toggleCreateDropdown(): void {
    this.showCreateDropdown = !this.showCreateDropdown;
  }

  /**
   * Open create post popup
   */
  openCreatePostPopup(): void {
    this.showCreatePostPopup = true;
  }

  /**
   * Close create post popup
   */
  closeCreatePostPopup(): void {
    this.showCreatePostPopup = false;
    this.resetQuickNoteForm();
  }

  /**
   * Perform search operation
   */
  performSearch(): void {
    if (this.searchQuery.trim()) {
      console.log('Searching for:', this.searchQuery);
      this.router.navigate(['/user/catalog'], {
        queryParams: { search: this.searchQuery }
      });
    }
  }

  /**
   * Create new item of specified type
   */
  createNew(type: string): void {
    console.log('Creating new:', type);
    this.showCreateDropdown = false;
    this.router.navigate(['/user/catalog/create'], {
      queryParams: { type }
    });
  }

  /**
   * Submit create post form
   */
  submitCreatePost(): void {
    this.createQuickNote();
  }

  /**
   * Create a Quick Note item
   */
  createQuickNote(): void {
    if (!this.quickNoteTitle.trim() || !this.quickNoteContent.trim()) {
      alert('Please fill in both title and content fields.');
      return;
    }

    const quickNoteData = {
      title: this.quickNoteTitle,
      description: this.quickNoteContent.trimStart().split(/\s+/).slice(0, 20).join(' ') + '...',
      content: this.quickNoteContent,
      type: this.quickNoteType as 'notes' | 'quick-wins' | 'documents',
      category: '',
      tags: this.quickNoteTags ? this.quickNoteTags.split(',').map(tag => tag.trim()) : [],
      status: 'draft',
      author: this.currentUser ? `${this.currentUser.first_name} ${this.currentUser.last_name}` : 'Unknown Author',
      author_id: this.currentUser?.id || '',
      created_date: new Date().toISOString(),
      updated_date: new Date().toISOString()
    };

    this.catalogService.createCatalogItem(quickNoteData).subscribe({
      next: (newItem) => {
        console.log('Quick Note created successfully:', newItem.title, 'New ID:', newItem.id);
        this.resetQuickNoteForm();
        this.closeCreatePostPopup();
        
        // Refresh drafts and metrics after creating new item
        this.loadQuickDrafts();
        this.loadCatalogMetrics();
      },
      error: (error) => {
        console.error('Failed to create Quick Note:', error);
        alert('Failed to create Quick Note. Please try again.');
      }
    });
  }

  /**
   * Reset Quick Note form fields
   */
  private resetQuickNoteForm(): void {
    this.quickNoteTitle = '';
    this.quickNoteContent = '';
    this.quickNoteType = 'notes';
    this.quickNoteTags = '';
  }

  /**
   * Setup navigation buttons configuration
   */
  private setupNavigationButtons(): void {
    this.navigationButtons = HOME_NAVIGATION_BUTTONS.map(buttonConfig => ({
      ...buttonConfig,
      badgeCount: this.getBadgeCountForRoute(buttonConfig.route)
    }));
  }

  /**
   * Get badge count for a specific route
   */
  private getBadgeCountForRoute(route: string): number {
    switch (route) {
      case 'dashboard':
        return this.dashboardCount;
      case 'weekly-wins':
        return this.weeklyWinsCount;
      case 'approvals':
        return this.approvalsCount;
      case 'team':
        return this.teamCount;
      case 'catalog':
        return this.catalogCount;
      case 'reports':
        return this.reportsCount;
      default:
        return 0;
    }
  }

  /**
   * Update navigation buttons with latest counts
   */
  private updateNavigationButtons(): void {
    this.navigationButtons.forEach(button => {
      button.badgeCount = this.getBadgeCountForRoute(button.route || '');
    });
  }

  /**
   * Load user dashboard counts from API
   */
  private loadUserCounts(): void {
    this.subscription.add(
      forkJoin({
        projects: this.catalogService.getCatalogItems({ type: 'project', limit: 1 }),
        resources: this.catalogService.getCatalogItems({ type: 'document', limit: 1 }),
        pendingApprovals: this.loadPendingApprovals()
      }).subscribe({
        next: (results) => {
          this.projectsCount = results.projects.total || 0;
          this.resourcesCount = results.resources.total || 0;
          this.catalogCount = this.projectsCount + this.resourcesCount;

          // Update pending approvals with real data
          this.pendingApprovals = results.pendingApprovals;
          this.approvalsCount = this.pendingApprovals.length;

          // Set navigation badge counts
          this.dashboardCount = this.calculateUserDashboardItems();
          this.weeklyWinsCount = this.calculateWeeklyWinsCount();
          this.teamCount = this.calculateTeamCount();
          this.reportsCount = this.calculateReportsCount();

          // Set activity section counts
          this.bookmarksCount = this.calculateBookmarksCount();
          this.myProjectsCount = this.calculateMyProjectsCount();
          this.favoritesCount = this.calculateFavoritesCount();

          // Update navigation buttons with new counts
          this.updateNavigationButtons();
        },
        error: (error) => {
          console.error('Failed to load user counts:', error);
          // Set fallback values and update navigation buttons
          this.updateNavigationButtons();
        }
      })
    );
  }

  /**
   * Load pending approvals where current user is the manager
   */
  private loadPendingApprovals(): Observable<PendingApproval[]> {
    const currentUser = this.authService.getCurrentUserValue();
    if (!currentUser) {
      return of([]);
    }

    return this.catalogService.searchCatalogItems({
      status: 'pending_approval',
      limit: 50
    }).pipe(
      map(response => {
        const filteredItems = response.items?.filter(item => {
          return item.approved_by === currentUser.user_id ||
            item.approved_by === currentUser.id ||
            item.approved_by === currentUser.email;
        }) || [];

        return filteredItems.map(item => this.transformCatalogToPendingApproval(item));
      }),
      catchError(error => {
        console.error('Error loading pending approvals:', error);
        return of([]);
      })
    );
  }

  /**
   * Transform catalog item to PendingApproval interface
   */
  private transformCatalogToPendingApproval(catalog: Catalog): PendingApproval {
    const submittedDate = this.formatRelativeTime(catalog.created_date || catalog.updated_date);
    const priority = this.determinePriority(catalog);
    const submittedBy = catalog.author || 'Unknown';
    const submittedByUserId = catalog.author_id || '';

    return {
      id: catalog.id,
      title: catalog.title || 'Untitled',
      type: catalog.type || 'document',
      submittedBy,
      submittedByUserId,
      submittedDate,
      priority,
      status: catalog.status || 'pending_approval',
      description: catalog.description,
      content: catalog.content
    };
  }

  /**
   * Determine priority based on catalog properties
   */
  private determinePriority(catalog: Catalog): 'high' | 'medium' | 'low' {
    if (catalog.priority) {
      return catalog.priority as 'high' | 'medium' | 'low';
    }

    if (catalog.urgent || catalog.important) {
      return 'high';
    }

    if (catalog.expire_date || catalog.due_date) {
      const targetDate = new Date(catalog.expire_date || catalog.due_date!);
      const now = new Date();
      const daysUntilDue = Math.ceil((targetDate.getTime() - now.getTime()) / (1000 * 60 * 60 * 24));

      if (daysUntilDue <= 1) {
        return 'high';
      } else if (daysUntilDue <= 7) {
        return 'medium';
      }
    }

    const highPriorityTypes = ['policy', 'compliance', 'security', 'legal'];
    if (highPriorityTypes.includes(catalog.type?.toLowerCase() || '')) {
      return 'high';
    }

    return 'low';
  }

  /**
   * Format relative time for display
   */
  private formatRelativeTime(dateString?: string): string {
    if (!dateString) {
      return 'Unknown time';
    }

    const date = new Date(dateString);
    const now = new Date();
    const diffInMs = now.getTime() - date.getTime();
    const diffInMinutes = Math.floor(diffInMs / (1000 * 60));
    const diffInHours = Math.floor(diffInMinutes / 60);
    const diffInDays = Math.floor(diffInHours / 24);

    if (diffInMinutes < 1) {
      return 'Just now';
    } else if (diffInMinutes < 60) {
      return `${diffInMinutes} minute${diffInMinutes !== 1 ? 's' : ''} ago`;
    } else if (diffInHours < 24) {
      return `${diffInHours} hour${diffInHours !== 1 ? 's' : ''} ago`;
    } else if (diffInDays < 7) {
      return `${diffInDays} day${diffInDays !== 1 ? 's' : ''} ago`;
    } else {
      return date.toLocaleDateString();
    }
  }

  /**
   * Load team feed - items shared with the current user
   */
  private loadTeamFeed(): void {
    const currentUser = this.authService.getCurrentUserValue();
    if (!currentUser) {
      return;
    }

    this.subscription.add(
      this.catalogService.getCatalogItems({
        limit: 20,
        sort: 'updated_date',
        order: 'desc'
      }).subscribe({
        next: (response) => {
          const sharedItems = response.items?.filter(item => {
            return item.shared_with_ids &&
              item.shared_with_ids.includes(currentUser.user_id || currentUser.id || currentUser.email || '');
          }) || [];

          this.teamFeed = sharedItems
            .slice(0, 10)
            .map(item => this.transformCatalogToTeamFeedItem(item));
        },
        error: (error) => {
          console.error('Failed to load team feed:', error);
          this.teamFeed = [];
        }
      })
    );
  }

  /**
   * Transform catalog item to team feed item
   */
  private transformCatalogToTeamFeedItem(catalog: Catalog): TeamFeedItem {
    const sharedDate = this.formatRelativeTime(catalog.updated_date || catalog.created_date);

    return {
      id: catalog.id,
      title: catalog.title || 'Untitled',
      type: catalog.type || 'document',
      sharedBy: catalog.author || 'Unknown',
      sharedByUserId: catalog.author_id || '',
      sharedDate,
      description: catalog.description,
      priority: catalog.priority,
      action: 'shared'
    };
  }

  /**
   * Initialize chart for content distribution
   */
  private initializeChart(): void {
    console.log('Chart initialization - to be implemented with Chart.js');
  }

  /**
   * Calculate dashboard items count
   */
  private calculateUserDashboardItems(): number {
    return this.projectsCount + this.resourcesCount + this.pendingApprovals.length;
  }

  /**
   * Calculate weekly wins count
   */
  private calculateWeeklyWinsCount(): number {
    return Math.floor(this.completedActionsCount * 0.3);
  }

  /**
   * Calculate team count
   */
  private calculateTeamCount(): number {
    return this.teamFeed.length;
  }

  /**
   * Calculate reports count
   */
  private calculateReportsCount(): number {
    return 3;
  }

  /**
   * Calculate bookmarks count
   */
  private calculateBookmarksCount(): number {
    return this.bookmarkedItems.length;
  }

  /**
   * Calculate my projects count
   */
  private calculateMyProjectsCount(): number {
    return this.projectsCount;
  }

  /**
   * Calculate favorites count
   */
  private calculateFavoritesCount(): number {
    return Math.floor(this.catalogCount * 0.2);
  }

  @Input() smartListPosts: SmartListPost[] = [];
  @Input() approvalQueuePosts: SmartListPost[] = [];
  @Input() quickDrafts: SmartListPost[] = [];

  // Card metrics data
  catalogMetrics = [
    { icon: this.faFileAlt, label: 'Total Items', value: 0 },
    { icon: this.faFolder, label: 'Projects', value: 0 },
    { icon: this.faNewspaper, label: 'Documents', value: 0 },
    { icon: this.faClock, label: 'Drafts', value: 0 }
  ];

  // Other utility methods...
  getActivityIcon(action: string): any {
    switch (action) {
      case 'shared': return this.faShare;
      case 'updated': return this.faEdit;
      case 'commented': return this.faComments;
      case 'created': return this.faPlus;
      case 'approved': return this.faCheck;
      default: return this.faFileAlt;
    }
  }

  getApprovalTypeIcon(type: string): any {
    const typeIconMap: { [key: string]: any } = {
      'assets': this.faFolder,
      'documents': this.faFileAlt,
      'policy': this.faFileContract,
      'article': this.faNewspaper,
      'guide': this.faBook,
      'tutorial': this.faGraduationCap,
      'blog': this.faBlog,
      'research': this.faFlask,
      'reports': this.faAnalytics,
      'notifications': this.faBell,
      'resource': this.faBookmark
    };
    return typeIconMap[type] || this.faFileAlt;
  }

  /**
   * Load team updates for the current user using the new dedicated team shares endpoint
   */
  loadTeamUpdates(): void {
    const currentUser = this.authService.getCurrentUserValue();
    if (!currentUser) {
      console.log('No current user found, empty team updates');
      this.smartListPosts = [];
      return;
    }

    console.log('🔍 [DEBUG] Loading team updates for user:', currentUser.user_id || currentUser.id);
    
    this.subscription.add(
      this.catalogService.getTeamShares({
        limit: 10,
        sort: 'created_date',
        order: 'desc'
      }).subscribe({
        next: (response) => {
          console.log('🔍 [DEBUG] Team shares API response:', response);
          console.log('🔍 [DEBUG] Team shares items count:', response.items?.length || 0);
          
          // Transform Catalog items to SmartListPost format for the smart-list component
          this.smartListPosts = response.items?.map((item: Catalog) => this.transformCatalogToSmartListPost(item)) || [];
          
          console.log('🔍 [DEBUG] Transformed smartListPosts:', this.smartListPosts);
          console.log(`✅ Loaded ${this.smartListPosts.length} team shares from dedicated endpoint`);
          
          // Update team count for navigation badge
          this.teamCount = response.total || this.smartListPosts.length;
          this.updateNavigationButtons();
        },
        error: (error) => {
          console.error('❌ Failed to load team shares from dedicated endpoint:', error);
          // Set empty array if API fails
          this.smartListPosts = [];
        }
      })
    );
  }

  /**
   * Load approval queue for the current user using the new dedicated approval queue endpoint
   */
  loadApprovalQueue(): void {
    const currentUser = this.authService.getCurrentUserValue();
    if (!currentUser) {
      console.log('No current user found, empty approval queue');
      this.approvalQueuePosts = [];
      return;
    }

    console.log('🔍 [DEBUG] Loading approval queue for user:', currentUser.user_id || currentUser.id);

    this.subscription.add(
      this.catalogService.getApprovalQueue({
        limit: 10,
        sort: 'created_date',
        order: 'desc'
      }).subscribe({
        next: (response) => {
          console.log('🔍 [DEBUG] Approval queue API response:', response);
          console.log('🔍 [DEBUG] Approval queue items count:', response.items?.length || 0);
          
          // Filter items to only include those with pending_approval status
          const pendingApprovalItems = response.items?.filter(item => 
            item.status === 'pending_approval'
          ) || [];
          
          // Transform Catalog items to SmartListPost format for the smart-list component
          this.approvalQueuePosts = pendingApprovalItems.map((item: Catalog) => this.transformCatalogToSmartListPost(item));
          
          console.log('🔍 [DEBUG] Filtered pending approval items:', pendingApprovalItems.length);
          console.log('🔍 [DEBUG] Transformed approvalQueuePosts:', this.approvalQueuePosts);
          console.log(`✅ Loaded ${this.approvalQueuePosts.length} pending approval items from dedicated endpoint`);
          
          // Update approvals count for navigation badge - only count pending approvals
          this.approvalsCount = pendingApprovalItems.length;
          this.updateNavigationButtons();
        },
        error: (error) => {
          console.error('❌ Failed to load approval queue from dedicated endpoint:', error);
          // Set empty array if API fails
          this.approvalQueuePosts = [];
          this.approvalsCount = 0;
          this.updateNavigationButtons();
        }
      })
    );
  }

  /**
   * Transform Catalog item to SmartListPost interface
   */
  private transformCatalogToSmartListPost(item: Catalog): SmartListPost {
    // Try to get author name from multiple possible sources
    let authorName = 'Unknown';
    
    if (item.author && item.author.trim()) {
      authorName = item.author;
    } else if (item.author_id) {
      // If we have author_id but no author name, we could potentially look it up
      // For now, just use the ID as fallback
      authorName = `User ${item.author_id}`;
    }

    return {
      id: item.id, // Add ID field for navigation
      title: item.title || 'Untitled',
      content: item.content || item.description || 'No content available',
      postedBy: authorName,
      time: this.formatRelativeTime(item.created_date || item.updated_date),
      category: item.category,
      type: item.type,
      created_date: item.created_date,
      updated_date: item.updated_date,
      status: item.status, // Add status field
      read: item.read || false // Map the read flag from the API response
    };
  }

  /**
   * Handle approve item action from smart-list
   */
  onApproveItem(post: SmartListPost): void {
    console.log('Approving item:', post.id, post.title);
    
    // Call the catalog service to approve the item
    this.subscription.add(
      this.catalogService.approveCatalogItem(post.id).subscribe({
        next: (approvedItem) => {
          console.log('✅ Item approved successfully:', approvedItem.title);
          
          // Remove the approved item from the approval queue
          this.approvalQueuePosts = this.approvalQueuePosts.filter(item => item.id !== post.id);
          
          // Update the approvals count
          this.approvalsCount = this.approvalQueuePosts.length;
          this.updateNavigationButtons();
          
          // Show success message
          alert(`Successfully approved: ${post.title}`);
        },
        error: (error) => {
          console.error('❌ Failed to approve item:', error);
          alert('Failed to approve item. Please try again.');
        }
      })
    );
  }

  /**
   * Load recent drafts for quick access
   */
  loadQuickDrafts(): void {
    const currentUser = this.authService.getCurrentUserValue();
    if (!currentUser) {
      console.log('No current user found, empty quick drafts');
      this.quickDrafts = [];
      return;
    }

    const authorId = currentUser.user_id || currentUser.id || currentUser.email;
    console.log('🔍 [DEBUG] Loading quick drafts for user:', authorId);
    console.log('🔍 [DEBUG] Current user object:', currentUser);
    
    // Try multiple approaches to load drafts
    this.subscription.add(
      this.catalogService.getCatalogItems({
        status: 'draft',
        limit: 50 // Increased limit to see if any drafts exist
      }).subscribe({
        next: (response) => {
          console.log('🔍 [DEBUG] All drafts API response:', response);
          console.log('🔍 [DEBUG] Total draft items found:', response.total);
          console.log('🔍 [DEBUG] Draft items array:', response.items);
          
          // Filter drafts by current user
          const userDrafts = response.items?.filter(item => {
            const isUserDraft = item.author_id === authorId || 
                               item.author_id === currentUser.user_id ||
                               item.author_id === currentUser.id ||
                               item.author === `${currentUser.first_name} ${currentUser.last_name}` ||
                               item.author === currentUser.email;
            
            console.log(`🔍 [DEBUG] Checking draft item ${item.id}: author_id=${item.author_id}, author=${item.author}, isUserDraft=${isUserDraft}`);
            return isUserDraft;
          }) || [];
          
          console.log('🔍 [DEBUG] Filtered user drafts:', userDrafts);
          
          // Transform to SmartListPost format and take only first 3
          this.quickDrafts = userDrafts
            .slice(0, 3)
            .map((item: Catalog) => this.transformCatalogToSmartListPost(item));
          
          console.log(`✅ Loaded ${this.quickDrafts.length} quick drafts:`, this.quickDrafts);
        },
        error: (error) => {
          console.error('❌ Failed to load quick drafts:', error);
          this.quickDrafts = [];
        }
      })
    );
  }

  /**
   * Load and update catalog metrics
   */
  loadCatalogMetrics(): void {
    const currentUser = this.authService.getCurrentUserValue();
    if (!currentUser) {
      return;
    }

    this.subscription.add(
      forkJoin({
        totalItems: this.catalogService.getCatalogItems({ limit: 1 }),
        projects: this.catalogService.getCatalogItems({ type: 'project', limit: 1 }),
        documents: this.catalogService.getCatalogItems({ type: 'document', limit: 1 }),
        drafts: this.catalogService.getCatalogItems({ 
          status: 'draft', 
          author: currentUser.user_id || currentUser.id,
          limit: 1 
        })
      }).subscribe({
        next: (results) => {
          this.catalogMetrics = [
            { 
              icon: this.faFileAlt, 
              label: 'Total Items', 
              value: results.totalItems.total || 0 
            },
            { 
              icon: this.faFolder, 
              label: 'Projects', 
              value: results.projects.total || 0 
            },
            { 
              icon: this.faNewspaper, 
              label: 'Documents', 
              value: results.documents.total || 0 
            },
            { 
              icon: this.faClock, 
              label: 'Drafts', 
              value: results.drafts.total || 0 
            }
          ];
          
          console.log('✅ Updated catalog metrics:', this.catalogMetrics);
        },
        error: (error) => {
          console.error('❌ Failed to load catalog metrics:', error);
          // Keep default values if API fails
        }
      })
    );
  }

  /**
   * Navigate to draft item for viewing
   */
  onDraftClick(draft: SmartListPost): void {
    console.log('Opening draft for viewing:', draft.id, draft.title);
    this.router.navigate(['/user/catalog', draft.id]);
  }

  /**
   * Navigate to edit catalog page for draft
   */
  onEditDraft(event: any, draft: SmartListPost): void {
    console.log('Editing draft:', event.id || draft.id, event.title || draft.title);
    const draftId = event.id || draft.id;
    this.router.navigate(['/user/catalog', draftId, 'edit']);
  }

  /**
   * Delete draft item with confirmation
   */
  onDeleteDraft(event: any, draft: SmartListPost): void {
    const draftId = event.id || draft.id;
    const draftTitle = event.title || draft.title;
    
    // Set up the delete confirmation data
    this.itemToDelete = {
      id: draftId,
      title: draftTitle,
      type: draft.type,
      description: draft.content ? `${draft.content.substring(0, 100)}...` : undefined
    };
    this.showDeleteConfirm = true;
  }

  /**
   * Confirm delete action from the delete confirmation popup
   */
  onConfirmDelete(item: DeleteConfirmationData): void {
    if (!item) return;
    
    this.isDeleting = true;
    console.log('Deleting draft:', item.id, item.title);
    
    this.subscription.add(
      this.catalogService.deleteCatalogItem(item.id).subscribe({
        next: () => {
          console.log('✅ Draft deleted successfully:', item.title);
          
          // Remove the deleted draft from the local array
          this.quickDrafts = this.quickDrafts.filter(draft => draft.id !== item.id);
          
          // Refresh catalog metrics to update the drafts count
          this.loadCatalogMetrics();
          
          // Close the confirmation modal and reset state
          this.showDeleteConfirm = false;
          this.itemToDelete = null;
          this.isDeleting = false;
          
          console.log(`Draft "${item.title}" has been deleted successfully.`);
        },
        error: (error) => {
          console.error('❌ Failed to delete draft:', error);
          alert('Failed to delete draft. Please try again.');
          
          // Reset deleting state on error
          this.isDeleting = false;
        }
      })
    );
  }

  /**
   * Cancel delete action from the delete confirmation popup
   */
  onCancelDelete(): void {
    this.showDeleteConfirm = false;
    this.itemToDelete = null;
    this.isDeleting = false;
  }

  /**
   * Temporary method to test drafts loading - can be called from browser console
   */
  testDraftsLoading(): void {
    console.log('🧪 [TEST] Testing drafts loading manually...');
    this.loadQuickDrafts();
  }

  /**
   * Force refresh all data - can be called from browser console
   */
  refreshAllData(): void {
    console.log('🔄 [REFRESH] Refreshing all home page data...');
    this.loadQuickDrafts();
    this.loadCatalogMetrics();
    this.loadTeamUpdates();
    this.loadApprovalQueue();
  }

  /**
   * Initialize the smart refresh system
   */
  private initializeSmartRefresh(): void {
    console.log('🔄 [SMART-REFRESH] Initializing smart refresh system...');
    
    // Listen to catalog service refresh triggers
    this.subscription.add(
      this.catalogService.catalogRefresh$.subscribe(() => {
        console.log('🔄 [SMART-REFRESH] External refresh trigger received');
        this.performSmartRefresh();
      })
    );

    // Start intelligent refresh timers
    this.startRefreshTimers();
    
    // Setup visibility change detection
    this.setupVisibilityDetection();
  }

  /**
   * Start refresh timers for different data types
   */
  private startRefreshTimers(): void {
    Object.keys(this.refreshConfigs).forEach(dataType => {
      const config = this.refreshConfigs[dataType];
      
      if (config.enabled) {
        this.refreshTimers[dataType] = interval(config.interval)
          .pipe(
            filter(() => this.shouldRefresh(dataType)),
            switchMap(() => this.refreshDataType(dataType))
          )
          .subscribe({
            next: () => {
              config.lastRefresh = new Date();
              config.errorCount = 0;
              console.log(`🔄 [SMART-REFRESH] ${dataType} refreshed successfully`);
            },
            error: (error) => {
              config.errorCount++;
              console.error(`❌ [SMART-REFRESH] Error refreshing ${dataType}:`, error);
              this.handleRefreshError(dataType, error);
            }
          });
      }
    });
  }

  /**
   * Stop all refresh timers
   */
  private stopAllRefreshTimers(): void {
    Object.keys(this.refreshTimers).forEach(key => {
      if (this.refreshTimers[key]) {
        this.refreshTimers[key].unsubscribe();
      }
    });
    this.refreshTimers = {};
  }

  /**
   * Determine if data type should be refreshed
   */
  private shouldRefresh(dataType: string): boolean {
    const config = this.refreshConfigs[dataType];
    
    // Don't refresh if page is not visible
    if (!this.isPageVisible) {
      return false;
    }
    
    // Don't refresh if user is inactive for more than 5 minutes
    const inactiveTime = new Date().getTime() - this.lastUserActivity.getTime();
    if (inactiveTime > 300000) { // 5 minutes
      return false;
    }
    
    // Don't refresh if too many recent errors
    if (config.errorCount >= 3) {
      return false;
    }
    
    // Don't refresh if another refresh is in progress
    if (this.refreshInProgress) {
      return false;
    }
    
    return true;
  }

  /**
   * Refresh specific data type
   */
  private refreshDataType(dataType: string): Observable<any> {
    this.refreshInProgress = true;
    
    switch (dataType) {
      case 'teamShares':
        return this.refreshTeamShares();
      case 'approvalQueue':
        return this.refreshApprovalQueue();
      case 'quickDrafts':
        return this.refreshQuickDrafts();
      case 'catalogMetrics':
        return this.refreshCatalogMetrics();
      default:
        return of(null);
    }
  }

  /**
   * Refresh team shares data
   */
  private refreshTeamShares(): Observable<any> {
    const currentUser = this.authService.getCurrentUserValue();
    if (!currentUser) return of([]);
    
    return this.catalogService.getTeamShares({
      limit: 10,
      sort: 'created_date',
      order: 'desc',
      useCache: false
    }).pipe(
      map(response => {
        const newPosts = response.items?.map((item: Catalog) => 
          this.transformCatalogToSmartListPost(item)) || [];
        
        // Only update if data has changed
        if (this.hasDataChanged('teamShares', newPosts)) {
          this.smartListPosts = newPosts;
          this.teamCount = response.total || newPosts.length;
          this.updateNavigationButtons();
          console.log(`🔄 [SMART-REFRESH] Team shares updated: ${newPosts.length} items`);
        }
        
        this.refreshInProgress = false;
        return newPosts;
      }),
      catchError(error => {
        this.refreshInProgress = false;
        throw error;
      })
    );
  }

  /**
   * Refresh approval queue data
   */
  private refreshApprovalQueue(): Observable<any> {
    const currentUser = this.authService.getCurrentUserValue();
    if (!currentUser) return of([]);
    
    return this.catalogService.getApprovalQueue({
      limit: 10,
      sort: 'created_date',
      order: 'desc',
      useCache: false
    }).pipe(
      map(response => {
        // Filter items to only include those with pending_approval status
        const pendingApprovalItems = response.items?.filter(item => 
          item.status === 'pending_approval'
        ) || [];
        
        const newPosts = pendingApprovalItems.map((item: Catalog) => 
          this.transformCatalogToSmartListPost(item));
        
        // Only update if data has changed
        if (this.hasDataChanged('approvalQueue', newPosts)) {
          this.approvalQueuePosts = newPosts;
          this.approvalsCount = pendingApprovalItems.length;
          this.updateNavigationButtons();
          console.log(`🔄 [SMART-REFRESH] Approval queue updated: ${newPosts.length} pending approval items`);
        }
        
        this.refreshInProgress = false;
        return newPosts;
      }),
      catchError(error => {
        this.refreshInProgress = false;
        throw error;
      })
    );
  }

  /**
   * Refresh quick drafts data
   */
  private refreshQuickDrafts(): Observable<any> {
    const currentUser = this.authService.getCurrentUserValue();
    if (!currentUser) return of([]);
    
    return this.catalogService.getCatalogItems({
      status: 'draft',
      limit: 50,
      sort: 'updated_date',
      order: 'desc',
      useCache: false
    }).pipe(
      map(response => {
        const authorId = currentUser.user_id || currentUser.id || currentUser.email;
        const userDrafts = response.items?.filter(item => {
          return item.author_id === authorId || 
                 item.author_id === currentUser.user_id ||
                 item.author_id === currentUser.id ||
                 item.author === `${currentUser.first_name} ${currentUser.last_name}` ||
                 item.author === currentUser.email;
        }) || [];
        
        const newDrafts = userDrafts
          .slice(0, 3)
          .map((item: Catalog) => this.transformCatalogToSmartListPost(item));
        
        // Only update if data has changed
        if (this.hasDataChanged('quickDrafts', newDrafts)) {
          this.quickDrafts = newDrafts;
          console.log(`🔄 [SMART-REFRESH] Quick drafts updated: ${newDrafts.length} items`);
        }
        
        this.refreshInProgress = false;
        return newDrafts;
      }),
      catchError(error => {
        this.refreshInProgress = false;
        throw error;
      })
    );
  }

  /**
   * Refresh catalog metrics data
   */
  private refreshCatalogMetrics(): Observable<any> {
    const currentUser = this.authService.getCurrentUserValue();
    if (!currentUser) return of({});
    
    return forkJoin({
      totalItems: this.catalogService.getCatalogItems({ limit: 1, useCache: false }),
      projects: this.catalogService.getCatalogItems({ type: 'project', limit: 1, useCache: false }),
      documents: this.catalogService.getCatalogItems({ type: 'document', limit: 1, useCache: false }),
      drafts: this.catalogService.getCatalogItems({ 
        status: 'draft', 
        author: currentUser.user_id || currentUser.id,
        limit: 1,
        useCache: false
      })
    }).pipe(
      map(results => {
        const newMetrics = [
          { icon: this.faFileAlt, label: 'Total Items', value: results.totalItems.total || 0 },
          { icon: this.faFolder, label: 'Projects', value: results.projects.total || 0 },
          { icon: this.faNewspaper, label: 'Documents', value: results.documents.total || 0 },
          { icon: this.faClock, label: 'Drafts', value: results.drafts.total || 0 }
        ];
        
        // Only update if data has changed
        if (this.hasDataChanged('catalogMetrics', newMetrics)) {
          this.catalogMetrics = newMetrics;
          console.log('🔄 [SMART-REFRESH] Catalog metrics updated:', newMetrics);
        }
        
        this.refreshInProgress = false;
        return newMetrics;
      }),
      catchError(error => {
        this.refreshInProgress = false;
        throw error;
      })
    );
  }

  /**
   * Check if data has changed compared to last snapshot
   */
  private hasDataChanged(dataType: string, newData: any): boolean {
    if (!this.lastDataSnapshot) {
      this.createDataSnapshot();
      return true;
    }
    
    switch (dataType) {
      case 'teamShares':
        return newData.length !== this.smartListPosts.length ||
               JSON.stringify(newData.map((item: any) => ({ id: item.id, time: item.time }))) !==
               JSON.stringify(this.smartListPosts.map(item => ({ id: item.id, time: item.time })));
      
      case 'approvalQueue':
        return newData.length !== this.approvalQueuePosts.length ||
               JSON.stringify(newData.map((item: any) => ({ id: item.id, time: item.time }))) !==
               JSON.stringify(this.approvalQueuePosts.map(item => ({ id: item.id, time: item.time })));
      
      case 'quickDrafts':
        return newData.length !== this.quickDrafts.length ||
               JSON.stringify(newData.map((item: any) => ({ id: item.id, time: item.time }))) !==
               JSON.stringify(this.quickDrafts.map(item => ({ id: item.id, time: item.time })));
      
      case 'catalogMetrics':
        const currentValues = this.catalogMetrics.map(m => m.value);
        const newValues = newData.map((m: any) => m.value);
        return JSON.stringify(currentValues) !== JSON.stringify(newValues);
      
      default:
        return true;
    }
  }

  /**
   * Create a snapshot of current data for change detection
   */
  private createDataSnapshot(): void {
    this.lastDataSnapshot = {
      teamShares: { 
        count: this.smartListPosts.length, 
        lastUpdated: this.smartListPosts[0]?.time || '' 
      },
      approvalQueue: { 
        count: this.approvalQueuePosts.length, 
        lastUpdated: this.approvalQueuePosts[0]?.time || '' 
      },
      quickDrafts: { 
        count: this.quickDrafts.length, 
        lastUpdated: this.quickDrafts[0]?.time || '' 
      },
      catalogMetrics: {
        total: this.catalogMetrics[0]?.value || 0,
        projects: this.catalogMetrics[1]?.value || 0,
        documents: this.catalogMetrics[2]?.value || 0,
        drafts: this.catalogMetrics[3]?.value || 0
      }
    };
  }

  /**
   * Handle refresh errors with exponential backoff
   */
  private handleRefreshError(dataType: string, error: any): void {
    const config = this.refreshConfigs[dataType];
    
    // Increase interval on errors (exponential backoff)
    if (config.errorCount >= 2) {
      config.interval = Math.min(config.interval * 2, 300000); // Max 5 minutes
      
      // Restart timer with new interval
      if (this.refreshTimers[dataType]) {
        this.refreshTimers[dataType].unsubscribe();
      }
      
      this.refreshTimers[dataType] = interval(config.interval)
        .pipe(
          filter(() => this.shouldRefresh(dataType)),
          switchMap(() => this.refreshDataType(dataType))
        )
        .subscribe({
          next: () => {
            config.lastRefresh = new Date();
            config.errorCount = 0;
          },
          error: (err) => {
            config.errorCount++;
            this.handleRefreshError(dataType, err);
          }
        });
    }
    
    this.refreshErrors.push(`${dataType}: ${error.message || 'Unknown error'}`);
    
    // Keep only last 5 errors
    if (this.refreshErrors.length > 5) {
      this.refreshErrors = this.refreshErrors.slice(-5);
    }
  }

  /**
   * Setup activity tracking for intelligent refresh
   */
  private setupActivityTracking(): void {
    // Track mouse movement, clicks, and keyboard activity
    const activityEvents = ['mousedown', 'mousemove', 'keypress', 'scroll', 'touchstart'];
    
    const activityObservable = merge(
      ...activityEvents.map(event => 
        new Observable(observer => {
          const handler = () => observer.next(event);
          document.addEventListener(event, handler, { passive: true });
          return () => document.removeEventListener(event, handler);
        })
      )
    ).pipe(
      debounceTime(1000), // Debounce to avoid excessive updates
      distinctUntilChanged()
    );
    
    this.subscription.add(
      activityObservable.subscribe(() => {
        this.lastUserActivity = new Date();
        this.isUserActive = true;
      })
    );
  }

  /**
   * Setup page visibility detection
   */
  private setupVisibilityDetection(): void {
    document.addEventListener('visibilitychange', () => {
      this.isPageVisible = !document.hidden;
      
      if (this.isPageVisible) {
        console.log('🔄 [SMART-REFRESH] Page became visible, performing refresh...');
        // Perform immediate refresh when page becomes visible
        setTimeout(() => this.performSmartRefresh(), 1000);
      } else {
        console.log('🔄 [SMART-REFRESH] Page hidden, reducing refresh activity');
      }
    });
  }

  /**
   * Perform immediate smart refresh of all data
   */
  performSmartRefresh(): void {
    if (this.refreshInProgress) {
      console.log('🔄 [SMART-REFRESH] Refresh already in progress, skipping...');
      return;
    }
    
    this.isRefreshing = true;
    console.log('🔄 [SMART-REFRESH] Performing smart refresh of all data...');
    
    const refreshPromises = [
      this.refreshTeamShares().toPromise(),
      this.refreshApprovalQueue().toPromise(),
      this.refreshQuickDrafts().toPromise(),
      this.refreshCatalogMetrics().toPromise()
    ];
    
    Promise.allSettled(refreshPromises).then(() => {
      this.isRefreshing = false;
      this.lastRefreshTime = new Date();
      console.log('🔄 [SMART-REFRESH] Smart refresh completed');
      this.createDataSnapshot();
    });
  }

  /**
   * Load all data initially
   */
  private loadAllData(): void {
    this.loadUserCounts();
    this.loadTeamFeed();
    this.initializeChart();
    this.loadTeamUpdates();
    this.loadApprovalQueue();
    this.loadQuickDrafts();
    this.loadCatalogMetrics();
  }

  /**
   * Manual refresh trigger for user
   */
  onManualRefresh(): void {
    console.log('🔄 [SMART-REFRESH] Manual refresh triggered by user');
    this.performSmartRefresh();
  }
}
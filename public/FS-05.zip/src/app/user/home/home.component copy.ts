import { Component, OnInit, OnDestroy } from '@angular/core';
import { Router } from '@angular/router';
import { 
  faChartLine, faFolder, faFileAlt, faLightbulb, faHandshake, faRocket, 
  faUser, faCog, faBookmark, faHeart, faCheck, faTimes, faUserCog, 
  faExclamationTriangle, faArrowTrendUp, faArrowTrendDown, faPlus, faSearch,
  faBell, faChartPie, faCalendarAlt, faArrowUp, faArrowDown, faEye,
  faThumbsUp, faShare, faDownload, faEdit, faStar, faChevronDown, faUsers,
  faEllipsisV, faNewspaper, faBook, faGraduationCap, faBlog, faFlask, 
  faFileContract, faChartLine as faAnalytics, faCheckCircle, 
  faExclamationCircle, faClock, faComments
} from '@fortawesome/free-solid-svg-icons';
import { CatalogService } from '../../shared/services/catalog.service';
import { UserService } from '../../shared/services/user.service';
import { AuthService } from '../../shared/services/auth.service';
import { User, Catalog } from '../../shared/models/user.interface';
import { OverlapButtonConfig } from '../../shared/components/overlap-button/overlap-button.component';
import { HOME_NAVIGATION_BUTTONS, CATALOG_TYPES } from '../../shared/config/site-config';
import { Subscription, Observable, of, forkJoin } from 'rxjs';
import { map, catchError } from 'rxjs/operators';

// Updated interfaces for real data
interface PendingApproval {
  id: string;
  title: string;
  type: string;
  submittedBy: string;
  submittedByUserId: string;
  submittedDate: string;
  priority: 'high' | 'medium' | 'low';
  status: string;
  description?: string;
  content?: string;
}

interface Alert {
  id: string;
  message: string;
  type: 'warning' | 'info' | 'error';
  timestamp: string;
}

interface ActivityItem {
  id: string;
  title: string;
  type: 'created' | 'updated' | 'approved' | 'shared';
  timestamp: string;
  user: string;
}

interface Recommendation {
  id: string;
  title: string;
  type: 'article' | 'tool' | 'resource';
  description: string;
  url: string;
}

interface BookmarkedItem {
  id: string;
  title: string;
  type: 'project' | 'document';
  bookmarkedDate: string;
}

interface TeamFeedItem {
  id: string;
  title: string;
  type: string;
  sharedBy: string;
  sharedByUserId: string;
  sharedDate: string;
  description?: string;
  priority?: 'high' | 'medium' | 'low';
  action: 'shared' | 'updated' | 'commented';
}

@Component({
  selector: 'app-user-home',
  template: `
    <div class="home-container">
      <section class="hero-section">
        <app-container>
          <div class="hero-content">
            <h1 class="hero-title">Welcome to FST-Hub</h1>
            <p class="hero-subtitle">Your personal workspace for innovation, collaboration, and professional growth</p>
            <!-- <app-button variant="primary" size="lg" (click)="navigateTo('dashboard')">Go to Dashboard</app-button> -->
          </div>
        </app-container>
      </section>
      
      <!-- Overlapping Navigation -->
      <app-overlap-navigation 
        [buttons]="navigationButtons" 
        (navigate)="navigateTo($event)">
      </app-overlap-navigation>

      <!-- Dashboard Section -->
      <section class="dashboard-section">
        <app-container>
          <div class="dashboard-grid">
            <!-- Left Column - Team Feed (35%) -->
            <div class="dashboard-left">
              <!-- Team Feed -->
              <app-card title="Team Feed" [icon]="faUsers" variant="elevated">
                <div class="activity-feed">
                  <div class="activity-item" *ngFor="let item of teamFeed" 
                       (click)="viewTeamFeedItem(item)">
                    <div class="activity-icon" [class]="'activity-' + item.action">
                      <app-icon [faIcon]="getActivityIcon(item.action)" size="sm"></app-icon>
                    </div>
                    <div class="activity-content">
                      <div class="activity-title">{{ item.title }}</div>
                      <div class="activity-meta">
                        <span class="activity-user">
                          <app-icon [faIcon]="faUser" size="xs"></app-icon>
                          {{ item.sharedBy }}
                        </span>
                        <span class="activity-action">{{ item.action }}</span>
                        <span class="activity-time">{{ item.sharedDate }}</span>
                      </div>
                      <div class="activity-description" *ngIf="item.description">
                        {{ getTruncatedText(item.description, 100) }}
                      </div>
                      <div class="activity-type" [class]="'type-' + item.type">
                        <app-icon [faIcon]="getTeamFeedTypeIcon(item.type)" size="xs"></app-icon>
                        {{ item.type | titlecase }}
                      </div>
                    </div>
                  </div>
                  
                  <!-- Empty State for Team Feed -->
                  <div class="team-feed-empty-state" *ngIf="teamFeed.length === 0">
                    <div class="empty-state-content">
                      <div class="empty-state-icon">
                        <app-icon [faIcon]="faUsers" size="xl"></app-icon>
                      </div>
                      <h4 class="empty-state-title">No shared items yet</h4>
                      <p class="empty-state-text">When your team shares items with you, they'll appear here.</p>
                    </div>
                  </div>
                </div>
              </app-card>
            </div>

            <!-- Middle Column - Priority Actions, Summary & Charts (40%) -->
            <div class="dashboard-middle">
              <!-- Priority Actions Card -->
              <app-card title="Priority Actions" [icon]="faExclamationTriangle" variant="elevated">
                <div class="priority-actions">
                  <div class="expandable-section">
                    <button 
                      class="expand-toggle" 
                      (click)="togglePendingApprovals()"
                      [class.expanded]="showPendingApprovals">
                      <app-icon [faIcon]="faChevronDown" size="sm"></app-icon>
                      Pending Approvals ({{ pendingApprovals.length }})
                    </button>
                    <div class="expandable-content" *ngIf="showPendingApprovals">
                      <div class="approval-card" *ngFor="let approval of pendingApprovals" 
                           (click)="viewApprovalDetails(approval)">
                        <!-- Card Header with Type and Priority -->
                        <div class="approval-card-header">
                          <div class="header-left">
                            <div class="type-indicator">
                              <div class="type-icon-container" [ngClass]="getApprovalTypeClass(approval.type)">
                                <app-icon [faIcon]="getApprovalTypeIcon(approval.type)" class="type-icon" size="sm"></app-icon>
                              </div>
                              <div class="type-info">
                                <span class="type-label">{{ approval.type | titlecase }}</span>
                                <div class="submitter-info">
                                  <app-icon [faIcon]="faUser" size="xs"></app-icon>
                                  <span class="submitted-by">{{ approval.submittedBy }}</span>
                                </div>
                              </div>
                            </div>
                          </div>
                          <div class="header-right">
                            <span class="priority-badge" [class]="'priority-' + approval.priority">
                              <app-icon [faIcon]="getPriorityIcon(approval.priority)" size="xs"></app-icon>
                              {{ approval.priority | uppercase }}
                            </span>
                            <span class="time-badge">{{ approval.submittedDate }}</span>
                          </div>
                        </div>

                        <!-- Card Content -->
                        <div class="approval-card-content">
                          <h3 class="approval-title">{{ approval.title }}</h3>
                          <p class="approval-description" *ngIf="approval.description">
                            {{ getTruncatedText(approval.description, 140) }}
                          </p>
                          <p class="approval-content-text" *ngIf="!approval.description && approval.content">
                            {{ getTruncatedText(approval.content, 160) }}
                          </p>
                        </div>

                        <!-- Card Actions Footer -->
                        <div class="approval-card-footer">
                          <div class="footer-actions">
                            <button class="view-details-btn" (click)="viewApprovalDetails(approval, $event)">
                              <app-icon [faIcon]="faEye" size="sm"></app-icon>
                              View Details
                            </button>
                            <div class="action-buttons">
                              <button class="action-btn approve" (click)="handleApproval(approval.id, 'approve', $event)"
                                      title="Approve this item">
                                <app-icon [faIcon]="faCheck" size="sm"></app-icon>
                                <span>Approve</span>
                              </button>
                              <button class="action-btn reject" (click)="handleApproval(approval.id, 'reject', $event)"
                                      title="Reject this item">
                                <app-icon [faIcon]="faTimes" size="sm"></app-icon>
                                <span>Reject</span>
                              </button>
                              <button class="action-btn delegate" (click)="handleApproval(approval.id, 'delegate', $event)"
                                      title="Delegate to another manager">
                                <app-icon [faIcon]="faUserCog" size="sm"></app-icon>
                                <span>Delegate</span>
                              </button>
                            </div>
                          </div>
                        </div>
                      </div>

                      <!-- Empty State -->
                      <div class="approval-empty-state" *ngIf="pendingApprovals.length === 0">
                        <div class="empty-state-content">
                          <div class="empty-state-icon">
                            <app-icon [faIcon]="faCheckCircle" size="xl"></app-icon>
                          </div>
                          <h4 class="empty-state-title">All caught up!</h4>
                          <p class="empty-state-text">No pending approvals at this time. Check back later for new items to review.</p>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </app-card>

              <!-- Summary Statistics -->
              <div class="stats-grid">
                <div class="stat-card">
                  <div class="stat-icon">
                    <app-icon [faIcon]="faPlus" size="lg" variant="primary"></app-icon>
                  </div>
                  <div class="stat-content">
                    <div class="stat-number">{{ newItemsCount }}</div>
                    <div class="stat-label">New Items (7d)</div>
                    <div class="stat-trend" [class.positive]="newItemsTrend > 0" [class.negative]="newItemsTrend < 0">
                      <app-icon [faIcon]="newItemsTrend > 0 ? faArrowTrendUp : faArrowTrendDown" size="sm"></app-icon>
                      {{ getAbsoluteValue(newItemsTrend) }}%
                    </div>
                  </div>
                </div>

                <div class="stat-card">
                  <div class="stat-icon">
                    <app-icon [faIcon]="faEye" size="lg" variant="warning"></app-icon>
                  </div>
                  <div class="stat-content">
                    <div class="stat-number">{{ unreadPriorityCount }}</div>
                    <div class="stat-label">Unread Priority</div>
                    <div class="stat-badge" *ngIf="unreadPriorityCount > 0">{{ unreadPriorityCount }}</div>
                  </div>
                </div>

                <div class="stat-card">
                  <div class="stat-icon">
                    <app-icon [faIcon]="faCheck" size="lg" variant="success"></app-icon>
                  </div>
                  <div class="stat-content">
                    <div class="stat-number">{{ completedActionsCount }}</div>
                    <div class="stat-label">Completed Actions</div>
                    <div class="stat-progress">
                      <div class="progress-bar">
                        <div class="progress-fill" [style.width.%]="completedActionsProgress"></div>
                      </div>
                      <span class="progress-text">{{ completedActionsProgress }}% monthly</span>
                    </div>
                  </div>
                </div>
              </div>

              <!-- Chart Section -->
              <app-card title="Content Distribution" [icon]="faChartPie" variant="elevated">
                <div class="chart-container">
                  <canvas #chartCanvas id="contentChart"></canvas>
                </div>
              </app-card>
            </div>

            <!-- Right Column - Quick Actions & Recommendations (25%) -->
            <div class="dashboard-right">
              <!-- Quick Tools at top -->
              <app-card title="Quick Actions" [icon]="faCog" variant="elevated">
                <div class="quick-tools">
                  <div class="search-tool">
                    <input 
                      type="text" 
                      placeholder="Search catalog..." 
                      class="search-input"
                      [(ngModel)]="searchQuery"
                      (keyup.enter)="performSearch()">
                    <button class="search-btn" (click)="performSearch()">
                      <app-icon [faIcon]="faSearch" size="sm"></app-icon>
                    </button>
                  </div>

                  <div class="create-tool">
                    <button class="create-btn" (click)="openCreatePostPopup()">
                      <app-icon [faIcon]="faPlus" size="sm"></app-icon>
                      Quick Post
                    </button>
                  </div>
                </div>
              </app-card>

              <!-- Create Post Popup -->
              <div class="create-post-popup-backdrop" *ngIf="showCreatePostPopup">
                <div class="create-post-popup">
                  <h3>Quick Post</h3>
                  <form (ngSubmit)="createQuickDraft()">
                    <!-- <label>Description</label>
                    <textarea [(ngModel)]="createPostDescription" name="description" rows="2"></textarea> -->
                    <label>Content</label>
                    <textarea [(ngModel)]="createPostContent" name="content" rows="4" required></textarea>
                    <label>Type</label>
                    <div style="margin-bottom: 1.5rem;">
                      <select [(ngModel)]="selectedCatalogType" name="type" required style="width: 100%; padding: 0.75rem; border-radius: 6px; border: 1px solid #e9ecef; font-size: 1rem;">
                        <option value="notes">Notes</option>
                        <option value="quick-wins">Quick Wins</option>
                        <option value="documents">Document</option>
                        <option value="presentatons">Presentation</option>
                      </select>
                    </div>
                    <div class="popup-actions">
                      <button type="submit" class="create-btn">Post</button>
                      <button type="button" class="cancel-btn" (click)="closeCreatePostPopup()">Cancel</button>
                    </div>
                  </form>
                </div>
              </div>

              <!-- Recommendations -->
              <app-card title="Recommendations" [icon]="faLightbulb" variant="elevated">
                <div class="recommendations-list">
                  <div class="recommendation-item" *ngFor="let rec of recommendations">
                    <h4 class="recommendation-title">
                      <a [href]="rec.url" target="_blank">{{ rec.title }}</a>
                    </h4>
                    <p class="recommendation-description">{{ rec.description }}</p>
                  </div>
                </div>
              </app-card>
            </div>
          </div>
        </app-container>
      </section>
    </div>
  `,
  styles: [`
    .home-container {
      width: 100%;
      position: relative;
    }
    
    .hero-section {
      background: linear-gradient(135deg, var(--fm-primary-hero) 0%, var(--fm-secondary-hero) 100%);
      color: var(--fm-white);
      padding: 3rem 0;
      text-align: center;
      min-height: 350px;
      display: flex;
      align-items: center;
      justify-content: center;
      position: relative;
      z-index: 1;
    }
    
    .hero-content {
      max-width: 500px;
      margin: 0 auto;
    }
    
    .hero-title {
      font-size: 3rem;
      font-weight: 700;
      margin-bottom: 1rem;
      line-height: 1.2;
      color: var(--fm-white);
    }
    
    .hero-subtitle {
      font-size: 1.25rem;
      margin-bottom: 2rem;
      opacity: 0.85;
      line-height: 1.5;
      color: var(--fm-white);
    }
    
    /* Dashboard Section */
    .dashboard-section {
      padding: 1rem 0;
      background: var(--fm-gray-lighter);
    }
    
    .dashboard-grid {
      display: grid;
      grid-template-columns: 30% 37% 30%;
      gap: 1.5rem;
      margin-top: 2rem;
      max-width: 100%;
    }
    
    .dashboard-left, .dashboard-middle, .dashboard-right {
      display: flex;
      flex-direction: column;
      gap: 1.5rem;
      min-width: 0;
    }
    
    /* Priority Actions */
    .priority-actions {
      padding: 0;
    }
    
    .expand-toggle {
      display: flex;
      align-items: center;
      gap: 0.5rem;
      width: 100%;
      padding: 0.75rem;
      background: var(--fm-light-blue);
      border: none;
      border-radius: 6px;
      font-weight: 600;
      color: var(--fm-primary-blue);
      cursor: pointer;
      transition: all 0.3s ease;
      font-size: 0.875rem;
    }
    
    .expand-toggle:hover {
      background: var(--fm-secondary-blue);
      color: var(--fm-white);
    }
    
    .expandable-content {
      margin-top: 1rem;
    }
    
    /* Approval Card Styles */
    .approval-card {
      background: var(--fm-white);
      border: 1px solid #e9ecef;
      border-radius: 12px;
      padding: 0;
      margin-bottom: 1rem;
      transition: all 0.3s ease;
      cursor: pointer;
      overflow: hidden;
      box-shadow: 0 2px 4px rgba(0, 0, 0, 0.05);
    }
    
    .approval-card:hover {
      box-shadow: 0 6px 20px rgba(0, 0, 0, 0.12);
      border-color: var(--fm-primary-blue);
      transform: translateY(-1px);
    }
    
    .approval-card-header {
      display: flex;
      justify-content: space-between;
      align-items: center;
      padding: 1rem 1.25rem;
      background: var(--fm-gray-lighter);
      border-bottom: 1px solid #e9ecef;
    }
    
    .header-left {
      display: flex;
      align-items: center;
      flex: 1;
      min-width: 0;
    }
    
    .type-indicator {
      display: flex;
      align-items: center;
      gap: 0.75rem;
      min-width: 0;
    }
    
    .type-icon-container {
      width: 40px;
      height: 40px;
      border-radius: 50%;
      display: flex;
      align-items: center;
      justify-content: center;
      flex-shrink: 0;
      box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
    }
    
    .type-info {
      display: flex;
      flex-direction: column;
      gap: 0.25rem;
      min-width: 0;
    }
    
    .type-label {
      font-weight: 600;
      color: var(--fm-text-primary);
      font-size: 0.875rem;
      line-height: 1.2;
    }
    
    .submitter-info {
      display: flex;
      align-items: center;
      gap: 0.375rem;
      font-size: 0.75rem;
      color: var(--fm-text-secondary);
    }
    
    .submitted-by {
      font-weight: 500;
      color: var(--fm-text-secondary);
    }
    
    .header-right {
      display: flex;
      flex-direction: column;
      align-items: flex-end;
      gap: 0.375rem;
      flex-shrink: 0;
    }
    
    .priority-badge {
      display: flex;
      align-items: center;
      gap: 0.25rem;
      padding: 0.25rem 0.625rem;
      border-radius: 16px;
      font-size: 0.7rem;
      font-weight: 700;
      text-transform: uppercase;
      letter-spacing: 0.5px;
      white-space: nowrap;
    }
    
    .priority-high {
      background: linear-gradient(135deg, #dc3545, #c82333);
      color: var(--fm-white);
      box-shadow: 0 2px 4px rgba(220, 53, 69, 0.3);
    }
    
    .priority-medium {
      background: linear-gradient(135deg, #fd7e14, #e0a800);
      color: var(--fm-white);
      box-shadow: 0 2px 4px rgba(253, 126, 20, 0.3);
    }
    
    .priority-low {
      background: linear-gradient(135deg, #6c757d, #5a6268);
      color: var(--fm-white);
      box-shadow: 0 2px 4px rgba(108, 117, 125, 0.3);
    }
    
    .time-badge {
      font-size: 0.75rem;
      color: var(--fm-text-muted);
      font-weight: 500;
    }
    
    .approval-card-content {
      padding: 1.25rem;
      flex: 1;
      min-width: 0;
    }
    
    .approval-title {
      font-weight: 600;
      color: var(--fm-text-primary);
      margin-bottom: 0.75rem;
      font-size: 1rem;
      line-height: 1.4;
      display: -webkit-box;
      -webkit-line-clamp: 2;
      line-clamp: 2;
      -webkit-box-orient: vertical;
      overflow: hidden;
    }
    
    .approval-description,
    .approval-content-text {
      font-size: 0.875rem;
      color: var(--fm-text-secondary);
      margin: 0;
      line-height: 1.5;
      display: -webkit-box;
      -webkit-line-clamp: 3;
      line-clamp: 3;
      -webkit-box-orient: vertical;
      overflow: hidden;
    }
    
    .approval-card-footer {
      padding: 1rem 1.25rem;
      background: var(--fm-white);
      border-top: 1px solid #f0f0f0;
    }
    
    .footer-actions {
      display: flex;
      justify-content: space-between;
      align-items: center;
      gap: 1rem;
    }
    
    .view-details-btn {
      display: flex;
      align-items: center;
      gap: 0.375rem;
      padding: 0.5rem 1rem;
      background: var(--fm-light-blue);
      color: var(--fm-primary-blue);
      border: 1px solid var(--fm-primary-blue);
      border-radius: 8px;
      font-weight: 600;
      cursor: pointer;
      transition: all 0.3s ease;
      font-size: 0.8rem;
      white-space: nowrap;
    }
    
    .view-details-btn:hover {
      background: var(--fm-primary-blue);
      color: var(--fm-white);
      transform: translateY(-1px);
      box-shadow: 0 2px 8px rgba(0, 123, 255, 0.3);
    }
    
    .action-buttons {
      display: flex;
      gap: 0.5rem;
      flex-wrap: wrap;
    }
    
    .action-btn {
      display: flex;
      align-items: center;
      gap: 0.25rem;
      padding: 0.5rem 0.75rem;
      border: none;
      border-radius: 8px;
      font-size: 0.75rem;
      font-weight: 600;
      cursor: pointer;
      transition: all 0.3s ease;
      white-space: nowrap;
      min-width: fit-content;
    }
    
    .action-btn span {
      display: none;
    }
    
    .action-btn:hover span {
      display: inline;
    }
    
    .action-btn.approve {
      background: var(--fm-green);
      color: var(--fm-white);
    }
    
    .action-btn.approve:hover {
      background: #218838;
      transform: translateY(-1px);
      box-shadow: 0 2px 8px rgba(40, 167, 69, 0.3);
    }
    
    .action-btn.reject {
      background: var(--fm-red);
      color: var(--fm-white);
    }
    
    .action-btn.reject:hover {
      background: #c82333;
      transform: translateY(-1px);
      box-shadow: 0 2px 8px rgba(220, 53, 69, 0.3);
    }
    
    .action-btn.delegate {
      background: var(--fm-orange);
      color: var(--fm-white);
    }
    
    .action-btn.delegate:hover {
      background: #e0a800;
      transform: translateY(-1px);
      box-shadow: 0 2px 8px rgba(255, 193, 7, 0.3);
    }
    
    /* Type Icon Colors */
    .type-project .type-icon-container {
      background: linear-gradient(135deg, var(--fm-green), #218838);
    }
    
    .type-document .type-icon-container {
      background: linear-gradient(135deg, var(--fm-primary-blue), #0056b3);
    }
    
    .type-policy .type-icon-container {
      background: linear-gradient(135deg, var(--fm-red), #c82333);
    }
    
    .type-article .type-icon-container {
      background: linear-gradient(135deg, var(--fm-secondary-blue), #0056b3);
    }
    
    .type-guide .type-icon-container {
      background: linear-gradient(135deg, var(--fm-orange), #e0a800);
    }
    
    .type-tutorial .type-icon-container {
      background: linear-gradient(135deg, #6f42c1, #59359a);
    }
    
    .type-blog .type-icon-container {
      background: linear-gradient(135deg, #20c997, #17a2b8);
    }
    
    .type-research .type-icon-container {
      background: linear-gradient(135deg, #6610f2, #520dc2);
    }
    
    .type-report .type-icon-container {
      background: linear-gradient(135deg, #ffc107, #e0a800);
    }
    
    .type-notification .type-icon-container {
      background: linear-gradient(135deg, #17a2b8, #138496);
    }
    
    .type-resource .type-icon-container {
      background: linear-gradient(135deg, #343a40, #23272b);
    }
    
    .type-default .type-icon-container {
      background: linear-gradient(135deg, var(--fm-gray), #6c757d);
    }
    
    .type-icon {
      color: var(--fm-white);
    }
    
    /* Empty State */
    .approval-empty-state {
      text-align: center;
      padding: 3rem 2rem;
      background: var(--fm-white);
      border: 2px dashed #e9ecef;
      border-radius: 12px;
      margin-top: 1rem;
    }
    
    .empty-state-content {
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      max-width: 300px;
      margin: 0 auto;
    }
    
    .empty-state-icon {
      margin-bottom: 1.5rem;
      color: var(--fm-green);
      opacity: 0.8;
    }
    
    .empty-state-title {
      font-size: 1.25rem;
      font-weight: 600;
      margin-bottom: 0.75rem;
      color: var(--fm-text-primary);
    }
    
    .empty-state-text {
      font-size: 0.9rem;
      font-weight: 400;
      margin: 0;
      text-align: center;
      line-height: 1.6;
      color: var(--fm-text-secondary);
    }
    
    /* Statistics Cards */
    .stats-grid {
      display: grid;
      grid-template-columns: repeat(3, 1fr);
      gap: 0.875rem;
      margin-bottom: 1.5rem;
    }
    
    .stat-card {
      background: var(--fm-white);
      border-radius: 8px;
      padding: 1.25rem;
      box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
      display: flex;
      align-items: center;
      gap: 0.875rem;
      min-width: 0;
    }
    
    .stat-icon {
      flex-shrink: 0;
    }
    
    .stat-content {
      flex: 1;
      min-width: 0;
    }
    
    .stat-number {
      font-size: 1.75rem;
      font-weight: 700;
      color: var(--fm-text-primary);
      line-height: 1;
    }
    
    .stat-label {
      font-size: 0.8rem;
      color: var(--fm-text-secondary);
      margin-bottom: 0.5rem;
    }
    
    .stat-trend {
      display: flex;
      align-items: center;
      gap: 0.25rem;
      font-size: 0.875rem;
      font-weight: 600;
    }
    
    .stat-trend.positive {
      color: var(--fm-green);
    }
    
    .stat-trend.negative {
      color: var(--fm-red);
    }
    
    .stat-badge {
      background: var(--fm-red);
      color: var(--fm-white);
      padding: 0.25rem 0.5rem;
      border-radius: 12px;
      font-size: 0.75rem;
      font-weight: 600;
    }
    
    .stat-progress {
      margin-top: 0.5rem;
    }
    
    .progress-bar {
      height: 4px;
      background: #e9ecef;
      border-radius: 2px;
      overflow: hidden;
      margin-bottom: 0.25rem;
    }
    
    .progress-fill {
      height: 100%;
      background: var(--fm-green);
      transition: width 0.3s ease;
    }
    
    .progress-text {
      font-size: 0.75rem;
      color: var(--fm-text-secondary);
    }
    
    /* Chart Container */
    .chart-container {
      height: 220px;
      position: relative;
    }
    
    /* Activity Feed */
    .activity-feed {
      display: flex;
      flex-direction: column;
      gap: 0.875rem;
      max-height: 400px;
      overflow-y: auto;
    }
    
    .activity-item {
      display: flex;
      align-items: center;
      gap: 0.875rem;
      padding: 0.75rem;
      background: var(--fm-white);
      border: 1px solid #e9ecef;
      border-radius: 8px;
    }
    
    .activity-icon {
      width: 36px;
      height: 36px;
      border-radius: 50%;
      display: flex;
      align-items: center;
      justify-content: center;
      flex-shrink: 0;
    }
    
    .activity-created {
      background: var(--fm-green);
      color: var(--fm-white);
    }
    
    .activity-updated {
      background: var(--fm-orange);
      color: var(--fm-white);
    }
    
    .activity-approved {
      background: var(--fm-secondary-blue);
      color: var(--fm-white);
    }
    
    .activity-shared {
      background: var(--fm-primary-blue);
      color: var(--fm-white);
    }
    
    .activity-content {
      flex: 1;
      min-width: 0;
    }
    
    .activity-title {
      font-weight: 600;
      color: var(--fm-text-primary);
      margin-bottom: 0.25rem;
      font-size: 0.875rem;
      line-height: 1.3;
    }
    
    .activity-meta {
      display: flex;
      gap: 0.75rem;
      font-size: 0.8rem;
      color: var(--fm-text-secondary);
    }
    
    /* Recommendations */
    .recommendations-list {
      margin-bottom: 1.25rem;
    }
    
    .recommendation-item {
      margin-bottom: 0.875rem;
      padding-bottom: 0.875rem;
      border-bottom: 1px solid #e9ecef;
    }
    
    .recommendation-item:last-child {
      border-bottom: none;
      margin-bottom: 0;
      padding-bottom: 0;
    }
    
    .recommendation-title {
      margin-bottom: 0.4rem;
      font-size: 0.875rem;
    }
    
    .recommendation-title a {
      color: var(--fm-secondary-blue);
      text-decoration: none;
      font-weight: 600;
      line-height: 1.3;
    }
    
    .recommendation-title a:hover {
      color: var(--fm-primary-blue);
      text-decoration: underline;
    }
    
    .recommendation-description {
      font-size: 0.8rem;
      color: var(--fm-text-secondary);
      margin: 0;
      line-height: 1.4;
    }
    
    /* Quick Tools */
    .quick-tools {
      display: flex;
      flex-direction: column;
      gap: 0.875rem;
    }
    
    .search-tool {
      display: flex;
      gap: 0.4rem;
    }
    
    .search-input {
      flex: 1;
      padding: 0.625rem;
      border: 1px solid #e9ecef;
      border-radius: 6px;
      font-size: 0.8rem;
    }
    
    .search-btn {
      padding: 0.625rem 0.875rem;
      background: var(--fm-primary-blue);
      color: var(--fm-white);
      border: none;
      border-radius: 6px;
      cursor: pointer;
      transition: background 0.3s ease;
    }
    
    .create-tool {
      position: relative;
    }
    
    .create-btn {
      display: flex;
      align-items: center;
      gap: 0.4rem;
      width: 100%;
      padding: 0.625rem 0.875rem;
      background: var(--fm-green);
      color: var(--fm-white);
      border: none;
      border-radius: 6px;
      font-weight: 600;
      cursor: pointer;
      transition: background 0.3s ease;
      font-size: 0.8rem;
    }
    
    .create-btn:hover {
      background: #218838;
    }
    
    .create-dropdown {
      position: absolute;
      top: 100%;
      left: 0;
      right: 0;
      background: var(--fm-white);
      border: 1px solid #e9ecef;
      border-radius: 6px;
      box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
      z-index: 10;
    }
    
    .create-dropdown button {
      display: block;
      width: 100%;
      padding: 0.75rem 1rem;
      background: none;
      border: none;
      text-align: left;
      cursor: pointer;
      transition: background 0.3s ease;
    }
    
    .create-dropdown button:hover {
      background: var(--fm-light-blue);
    }
    
    /* Create Post Popup */
    .create-post-popup-backdrop {
      position: fixed;
      top: 0;
      left: 0;
      right: 0;
      bottom: 0;
      background: rgba(0, 0, 0, 0.7);
      display: flex;
      align-items: center;
      justify-content: center;
      z-index: 1000;
    }
    
    .create-post-popup {
      background: var(--fm-white);
      border-radius: 12px;
      padding: 2.5rem 2.5rem 2rem 2.5rem;
      max-width: 700px;
      width: 100%;
      box-shadow: 0 4px 24px rgba(0, 0, 0, 0.18);
      position: relative;
    }
    
    .create-post-popup h3 {
      margin-top: 0;
      margin-bottom: 1.5rem;
      font-size: 1.5rem;
      font-weight: 600;
      color: var(--fm-text-primary);
    }
    
    .create-post-popup label {
      font-size: 0.875rem;
      font-weight: 500;
      color: var(--fm-text-secondary);
      margin-bottom: 0.5rem;
      display: block;
    }
    
    .create-post-popup input,
    .create-post-popup textarea {
      width: 100%;
      padding: 0.75rem;
      border: 1px solid #e9ecef;
      border-radius: 6px;
      font-size: 0.875rem;
      color: var(--fm-text-primary);
      margin-bottom: 1rem;
    }
    
    .create-post-popup textarea {
      min-height: 180px;
      font-size: 1rem;
      padding: 1rem;
    }
    
    .create-post-popup .popup-actions {
      display: flex;
      justify-content: flex-end;
      gap: 0.75rem;
    }
    
    .create-post-popup .create-btn {
      background: var(--fm-primary-blue);
      color: var(--fm-white);
      padding: 0.625rem 1.25rem;
      border: none;
      border-radius: 6px;
      font-weight: 600;
      cursor: pointer;
      transition: background 0.3s ease;
      font-size: 0.875rem;
    }
    
    .create-post-popup .create-btn:hover {
      background: #0056b3;
    }
    
    .create-post-popup .cancel-btn {
      background: var(--fm-gray);
      color: var(--fm-text-primary);
      padding: 0.625rem 1.25rem;
      border: none;
      border-radius: 6px;
      font-weight: 500;
      cursor: pointer;
      transition: background 0.3s ease;
      font-size: 0.875rem;
    }
    
    .create-post-popup .cancel-btn:hover {
      background: #e0e0e0;
    }
    
    /* Responsive Design */
    @media (max-width: 1400px) {
      .dashboard-grid {
        gap: 1rem;
      }
      
      .stat-card {
        padding: 1rem;
      }
      
      .stat-number {
        font-size: 1.5rem;
      }
    }
    
    @media (max-width: 1200px) {
      .dashboard-grid {
        grid-template-columns: 1fr;
        gap: 1.25rem;
      }
      
      .stats-grid {
        grid-template-columns: repeat(3, 1fr);
      }
    }
    
    @media (max-width: 768px) {
      .dashboard-section {
        padding: 2rem 0;
      }
      
      .approval-card-header {
        flex-direction: column;
        align-items: stretch;
        gap: 0.75rem;
        padding: 1rem;
      }
      
      .header-right {
        flex-direction: row;
        justify-content: space-between;
        align-items: center;
      }
      
      .footer-actions {
        flex-direction: column;
        gap: 0.75rem;
      }
      
      .action-buttons {
        width: 100%;
        justify-content: space-between;
      }
      
      .action-btn {
        flex: 1;
        justify-content: center;
      }
      
      .action-btn span {
        display: inline;
      }
      
      .view-details-btn {
        width: 100%;
        justify-content: center;
      }
      
      .stats-grid {
        grid-template-columns: 1fr;
      }
      
      .stat-card {
        padding: 1rem;
      }
      
      .stat-number {
        font-size: 1.5rem;
      }
      
      .chart-container {
        height: 200px;
      }
      
      .activity-feed {
        max-height: 300px;
      }
    }
  `]
})
export class UserHomeComponent implements OnInit, OnDestroy {
  // Font Awesome icons
  faChartLine = faChartLine;
  faFolder = faFolder;
  faFileAlt = faFileAlt;
  faLightbulb = faLightbulb;
  faHandshake = faHandshake;
  faRocket = faRocket;
  faUser = faUser;
  faCog = faCog;
  faBookmark = faBookmark;
  faHeart = faHeart;
  faCheck = faCheck;
  faTimes = faTimes;
  faUserCog = faUserCog;
  faExclamationTriangle = faExclamationTriangle;
  faArrowTrendUp = faArrowTrendUp;
  faArrowTrendDown = faArrowTrendDown;
  faPlus = faPlus;
  faSearch = faSearch;
  faBell = faBell;
  faChartPie = faChartPie;
  faCalendarAlt = faCalendarAlt;
  faArrowUp = faArrowUp;
  faArrowDown = faArrowDown;
  faEye = faEye;
  faThumbsUp = faThumbsUp;
  faShare = faShare;
  faDownload = faDownload;
  faEdit = faEdit;
  faStar = faStar;
  faChevronDown = faChevronDown;
  faUsers = faUsers;
  faEllipsisV = faEllipsisV;
  faNewspaper = faNewspaper;
  faBook = faBook;
  faGraduationCap = faGraduationCap;
  faBlog = faBlog;
  faFlask = faFlask;
  faFileContract = faFileContract;
  faAnalytics = faAnalytics;
  faCheckCircle = faCheckCircle;
  faExclamationCircle = faExclamationCircle;
  faClock = faClock;
  faComments = faComments;

  // Navigation buttons configuration
  navigationButtons: OverlapButtonConfig[] = [];

  // Badge counts from API
  dashboardCount = 0;
  weeklyWinsCount = 0;
  approvalsCount = 0;
  teamCount = 0;
  catalogCount = 0;
  reportsCount = 0;
  
  // Legacy counts for activity section
  projectsCount = 0;
  resourcesCount = 0;
  bookmarksCount = 0;
  myProjectsCount = 0;
  favoritesCount = 0;
  
  private subscription = new Subscription();

  // New properties for dashboard
  showPendingApprovals = false;
  showCreateDropdown = false;
  showCreatePostPopup = false;
  searchQuery = '';

  // Create Post form fields
  createPostTitle: string = '';
  createPostDescription: string = '';
  createPostContent: string = '';
  selectedCatalogType: string = 'article';
  
  // Statistics
  newItemsCount = 12;
  newItemsTrend = 15;
  unreadPriorityCount = 5;
  completedActionsCount = 28;
  completedActionsProgress = 75;
  
  // Mock data
  pendingApprovals: PendingApproval[] = [
    {
      id: '1',
      title: 'New FinTech Partnership Proposal',
      type: 'project',
      submittedBy: 'Sarah Johnson',
      submittedByUserId: 'user-1',
      submittedDate: '2 hours ago',
      priority: 'high',
      status: 'pending'
    },
    {
      id: '2',
      title: 'Updated Security Policy Document',
      type: 'document',
      submittedBy: 'Michael Chen',
      submittedByUserId: 'user-2',
      submittedDate: '1 day ago',
      priority: 'medium',
      status: 'pending'
    },
    {
      id: '3',
      title: 'Compliance Framework Update',
      type: 'policy',
      submittedBy: 'Emma Davis',
      submittedByUserId: 'user-3',
      submittedDate: '2 days ago',
      priority: 'low',
      status: 'pending'
    }
  ];
  
  teamFeed: TeamFeedItem[] = [
    {
      id: '1',
      title: 'Q4 Financial Strategy Document',
      type: 'document',
      sharedBy: 'Sarah Johnson',
      sharedByUserId: 'user-1',
      sharedDate: '2 hours ago',
      description: 'Updated financial strategy for Q4 2025',
      priority: 'high',
      action: 'shared'
    },
    {
      id: '2',
      title: 'API Security Best Practices',
      type: 'guide',
      sharedBy: 'Michael Chen',
      sharedByUserId: 'user-2',
      sharedDate: '4 hours ago',
      description: 'Comprehensive guide for securing financial APIs',
      priority: 'medium',
      action: 'updated'
    },
    {
      id: '3',
      title: 'Digital Transformation Roadmap',
      type: 'project',
      sharedBy: 'Emma Davis',
      sharedByUserId: 'user-3',
      sharedDate: '1 day ago',
      description: 'Strategic roadmap for digital transformation initiatives',
      priority: 'high',
      action: 'shared'
    },
    {
      id: '4',
      title: 'Compliance Framework Update',
      type: 'policy',
      sharedBy: 'Alex Rodriguez',
      sharedByUserId: 'user-4',
      sharedDate: '1 day ago',
      description: 'Updated compliance framework for new regulations',
      priority: 'medium',
      action: 'commented'
    },
    {
      id: '5',
      title: 'Customer Onboarding Process',
      type: 'document',
      sharedBy: 'Lisa Wang',
      sharedByUserId: 'user-5',
      sharedDate: '2 days ago',
      description: 'Streamlined customer onboarding workflow',
      priority: 'low',
      action: 'shared'
    }
  ];
  
  recommendations: Recommendation[] = [
    {
      id: '1',
      title: 'Best Practices for API Security',
      type: 'article',
      description: 'Essential security measures for financial APIs',
      url: '#'
    },
    {
      id: '2',
      title: 'Digital Transformation Roadmap',
      type: 'resource',
      description: 'Step-by-step guide for fintech innovation',
      url: '#'
    },
    {
      id: '3',
      title: 'Regulatory Compliance Updates',
      type: 'article',
      description: 'Latest changes in financial regulations',
      url: '#'
    }
  ];
  
  quickWins = [
    { title: 'Review pending documents', icon: faFileAlt },
    { title: 'Update team status', icon: faUsers },
    { title: 'Check system alerts', icon: faBell },
    { title: 'Schedule team meeting', icon: faCalendarAlt }
  ];
  
  bookmarkedItems: BookmarkedItem[] = [
    {
      id: '1',
      title: 'FinTech Innovation Framework',
      type: 'project',
      bookmarkedDate: '2 days ago'
    },
    {
      id: '2',
      title: 'API Documentation Standards',
      type: 'document',
      bookmarkedDate: '1 week ago'
    },
    {
      id: '3',
      title: 'Risk Management Protocol',
      type: 'document',
      bookmarkedDate: '2 weeks ago'
    }
  ];

  // Current user information
  currentUser: User | null = null;

  constructor(
    private router: Router,
    private catalogService: CatalogService,
    private userService: UserService,
    private authService: AuthService
  ) { }

  ngOnInit(): void {
    this.currentUser = this.authService.getCurrentUserValue();
    this.setupNavigationButtons();
    this.loadUserCounts();
    this.loadTeamFeed(); // Replace loadRecentActivity
    this.initializeChart();
  }

  ngOnDestroy(): void {
    this.subscription.unsubscribe();
  }

  /**
   * Navigate to a specific route
   */
  navigateTo(route: string): void {
    console.log('Navigating to:', route);
    switch (route) {
      case 'notifications':
        this.router.navigate(['/user/notifications']);
        break;
      case 'assets':
          this.router.navigate(['/user/catalog-list/assets']);
          break;
      case 'quick-wins':
        this.router.navigate(['/user/catalog-list/quick-wins']);
        break;
      default:
        this.router.navigate(['/user', route]);
        break;
    }
  }

  /**
   * Toggle pending approvals section
   */
  togglePendingApprovals(): void {
    this.showPendingApprovals = !this.showPendingApprovals;
  }

  /**
   * Toggle create dropdown
   */
  toggleCreateDropdown(): void {
    this.showCreateDropdown = !this.showCreateDropdown;
  }

  /**
   * Open create post popup
   */
  openCreatePostPopup(): void {
    this.showCreatePostPopup = true;
  }

  /**
   * Close create post popup
   */
  closeCreatePostPopup(): void {
    this.showCreatePostPopup = false;
  }

  /**
   * Perform search operation
   */
  performSearch(): void {
    if (this.searchQuery.trim()) {
      console.log('Searching for:', this.searchQuery);
      this.router.navigate(['/user/catalog'], { 
        queryParams: { search: this.searchQuery } 
      });
    }
  }

  /**
   * Create new item of specified type
   */
  createNew(type: string): void {
    console.log('Creating new:', type);
    this.showCreateDropdown = false;
    this.router.navigate(['/user/catalog/create'], { 
      queryParams: { type } 
    });
  }

  /**
   * Submit create post form
   */
  submitCreatePost(): void {
    console.log('Creating post with title:', this.createPostTitle);
    
    // Here you would typically call a service to create the post
    // For now, we'll just log the data and close the popup
    const postData = {
      title: this.createPostTitle,
      description: this.createPostDescription,
      content: this.createPostContent
    };
    
    console.log('Post data:', postData);
    
    // Close the popup
    this.closeCreatePostPopup();
    
    // Reset form fields
    this.createPostTitle = '';
    this.createPostDescription = '';
    this.createPostContent = '';
  }

  /**
   * Setup navigation buttons configuration
   */
  private setupNavigationButtons(): void {
    this.navigationButtons = HOME_NAVIGATION_BUTTONS.map(buttonConfig => ({
      ...buttonConfig,
      badgeCount: this.getBadgeCountForRoute(buttonConfig.route)
    }));
  }

  /**
   * Get badge count for a specific route
   */
  private getBadgeCountForRoute(route: string): number {
    switch(route) {
      case 'dashboard':
        return this.dashboardCount;
      case 'weekly-wins':
        return this.weeklyWinsCount;
      case 'approvals':
        return this.approvalsCount;
      case 'team':
        return this.teamCount;
      case 'catalog':
        return this.catalogCount;
      case 'reports':
        return this.reportsCount;
      default:
        return 0;
    }
  }

  /**
   * Update navigation buttons with latest counts
   */
  private updateNavigationButtons(): void {
    this.navigationButtons.forEach(button => {
      button.badgeCount = this.getBadgeCountForRoute(button.route || '');
    });
  }

  /**
   * Load user dashboard counts from API
   */
  private loadUserCounts(): void {
    this.subscription.add(
      forkJoin({
        projects: this.catalogService.getCatalogItems({ type: 'project', limit: 1 }),
        resources: this.catalogService.getCatalogItems({ type: 'document', limit: 1 }),
        pendingApprovals: this.loadPendingApprovals()
      }).subscribe({
        next: (results) => {
          this.projectsCount = results.projects.total || 0;
          this.resourcesCount = results.resources.total || 0;
          this.catalogCount = this.projectsCount + this.resourcesCount;
          
          // Update pending approvals with real data
          this.pendingApprovals = results.pendingApprovals;
          this.approvalsCount = this.pendingApprovals.length;
          
          // Set navigation badge counts
          this.dashboardCount = this.calculateUserDashboardItems();
          this.weeklyWinsCount = this.calculateWeeklyWinsCount();
          this.teamCount = this.calculateTeamCount();
          this.reportsCount = this.calculateReportsCount();
          
          // Set activity section counts
          this.bookmarksCount = this.calculateBookmarksCount();
          this.myProjectsCount = this.calculateMyProjectsCount();
          this.favoritesCount = this.calculateFavoritesCount();
          
          // Update navigation buttons with new counts
          this.updateNavigationButtons();
        },
        error: (error) => {
          console.error('Failed to load user counts:', error);
          // Set fallback values
          this.dashboardCount = 0;
          this.weeklyWinsCount = 0;
          this.approvalsCount = 0;
          this.teamCount = 0;
          this.catalogCount = 0;
          this.reportsCount = 0;
          this.projectsCount = 0;
          this.resourcesCount = 0;
          this.bookmarksCount = 0;
          this.myProjectsCount = 0;
          this.favoritesCount = 0;
          
          // Update navigation buttons with fallback counts
          this.updateNavigationButtons();
        }
      })
    );
  }

  /**
   * Load pending approvals where current user is the manager
   */
  private loadPendingApprovals(): Observable<PendingApproval[]> {
    const currentUser = this.authService.getCurrentUserValue();
    if (!currentUser) {
      console.log('No current user found, returning empty approvals');
      return of([]);
    }

    console.log('Loading pending approvals for manager:', currentUser.user_id);
    
    // Search for catalog items with status "pending_approval" and current user as approved_by
    return this.catalogService.searchCatalogItems({
      status: 'pending_approval',
      limit: 50 // Get up to 50 pending approvals
    }).pipe(
      map(response => {
        console.log('Raw pending approval items:', response.items);
        
        // Filter items where current user is the manager/approver
        const filteredItems = response.items?.filter(item => {
          // Check if current user ID matches the approved_by field
          return item.approved_by === currentUser.user_id || 
                 item.approved_by === currentUser.id ||
                 item.approved_by === currentUser.email;
        }) || [];
        
        console.log('Filtered pending approvals for current user:', filteredItems);
        
        // Transform catalog items to PendingApproval interface
        return filteredItems.map(item => this.transformCatalogToPendingApproval(item));
      }),
      catchError(error => {
        console.error('Error loading pending approvals:', error);
        return of([]);
      })
    );
  }

  /**
   * Transform catalog item to PendingApproval interface
   */
  private transformCatalogToPendingApproval(catalog: Catalog): PendingApproval {
    // Calculate time difference for display
    const submittedDate = this.formatRelativeTime(catalog.created_date || catalog.updated_date);
    
    // Determine priority based on catalog properties
    const priority = this.determinePriority(catalog);
    
    // Get author information
    const submittedBy = catalog.author || 'Unknown';
    const submittedByUserId = catalog.author_id || '';

    return {
      id: catalog.id,
      title: catalog.title || 'Untitled',
      type: catalog.type || 'document',
      submittedBy,
      submittedByUserId,
      submittedDate,
      priority,
      status: catalog.status || 'pending_approval',
      description: catalog.description,
      content: catalog.content
    };
  }

  createQuickDraft(): void {
    const draftData = {
      title: this.createPostContent.trimStart().split(/\s+/).slice(0, 5).join(' '),
      description: this.createPostContent.trimStart().split(/\s+/).slice(0, 10).join(' '),
      content: this.createPostContent,
      type: this.selectedCatalogType || 'article',
      category: '',
      tags: [],
      status: 'draft',
      author: this.currentUser ? `${this.currentUser.first_name} ${this.currentUser.last_name}` : 'Unknown Author',
      author_id: this.currentUser?.id || '',
      created_date: new Date().toISOString(),
      updated_date: new Date().toISOString()
    };

    this.catalogService.createCatalogItem(draftData).subscribe({
      next: (newItem) => {
        console.log('Quick draft created successfully:', newItem.title, 'New ID:', newItem.id);
        // Optionally reset form fields and close popup
        this.createPostTitle = '';
        this.createPostDescription = '';
        this.createPostContent = '';
        this.closeCreatePostPopup();
      },
      error: (error) => {
        console.error('Failed to create quick draft:', error);
      }
    });
  }

  /**
   * Determine priority based on catalog properties
   */
  private determinePriority(catalog: Catalog): 'high' | 'medium' | 'low' {
    // Check if catalog has explicit priority
    if (catalog.priority) {
      return catalog.priority as 'high' | 'medium' | 'low';
    }
    
    // Determine priority based on other factors
    if (catalog.urgent || catalog.important) {
      return 'high';
    }
    
    // Check if it's time-sensitive based on expire_date or due_date
    if (catalog.expire_date || catalog.due_date) {
      const targetDate = new Date(catalog.expire_date || catalog.due_date!);
      const now = new Date();
      const daysUntilDue = Math.ceil((targetDate.getTime() - now.getTime()) / (1000 * 60 * 60 * 24));
      
      if (daysUntilDue <= 1) {
        return 'high';
      } else if (daysUntilDue <= 7) {
        return 'medium';
      }
    }
    
    // Check content type for priority
    const highPriorityTypes = ['policy', 'compliance', 'security', 'legal'];
    if (highPriorityTypes.includes(catalog.type?.toLowerCase() || '')) {
      return 'high';
    }
    
    return 'low';
  }

  /**
   * Format relative time for display
   */
  private formatRelativeTime(dateString?: string): string {
    if (!dateString) {
      return 'Unknown time';
    }
    
    const date = new Date(dateString);
    const now = new Date();
    const diffInMs = now.getTime() - date.getTime();
    const diffInMinutes = Math.floor(diffInMs / (1000 * 60));
    const diffInHours = Math.floor(diffInMinutes / 60);
    const diffInDays = Math.floor(diffInHours / 24);
    
    if (diffInMinutes < 1) {
      return 'Just now';
    } else if (diffInMinutes < 60) {
      return `${diffInMinutes} minute${diffInMinutes !== 1 ? 's' : ''} ago`;
    } else if (diffInHours < 24) {
      return `${diffInHours} hour${diffInHours !== 1 ? 's' : ''} ago`;
    } else if (diffInDays < 7) {
      return `${diffInDays} day${diffInDays !== 1 ? 's' : ''} ago`;
    } else {
      return date.toLocaleDateString();
    }
  }

  /**
   * Calculate pending approvals count
   */
  private calculateApprovalsCount(): number {
    return this.pendingApprovals.length;
  }

  /**
   * Approve a catalog item
   */
  private approveItem(id: string, item: PendingApproval): void {
    console.log('Approving item:', id, item.title);
    
    this.subscription.add(
      this.catalogService.approveCatalogItem(id).subscribe({
        next: (updatedItem) => {
          console.log('Item approved successfully:', updatedItem);
          // Remove from pending approvals
          this.pendingApprovals = this.pendingApprovals.filter(approval => approval.id !== id);
          this.approvalsCount = this.pendingApprovals.length;
          this.updateNavigationButtons();
          
          // Show success message (you might want to use a toast service here)
          alert(`Successfully approved: ${item.title}`);
        },
        error: (error) => {
          console.error('Failed to approve item:', error);
          alert(`Failed to approve item: ${error.message || 'Unknown error'}`);
        }
      })
    );
  }

  /**
   * Reject a catalog item
   */
  private rejectItem(id: string, item: PendingApproval): void {
    console.log('Rejecting item:', id, item.title);
    
    // For rejection, we'll update the status to 'rejected'
    const rejectionReason = prompt(`Provide a reason for rejecting "${item.title}":`);
    if (rejectionReason === null) {
      return; // User cancelled
    }

    this.subscription.add(
      this.catalogService.reviewCatalogItem(id, 'rejected').subscribe({
        next: (updatedItem) => {
          console.log('Item rejected successfully:', updatedItem);
          // Remove from pending approvals
          this.pendingApprovals = this.pendingApprovals.filter(approval => approval.id !== id);
          this.approvalsCount = this.pendingApprovals.length;
          this.updateNavigationButtons();
          
          // Show success message
          alert(`Successfully rejected: ${item.title}`);
        },
        error: (error) => {
          console.error('Failed to reject item:', error);
          alert(`Failed to reject item: ${error.message || 'Unknown error'}`);
        }
      })
    );
  }

  /**
   * Delegate a catalog item to another manager
   */
  private delegateItem(id: string, item: PendingApproval): void {
    console.log('Delegating item:', id, item.title);
    
    // For now, show a simple prompt. In a real app, you'd show a user picker dialog
    const delegateToEmail = prompt(`Delegate "${item.title}" to (enter email address):`);
    if (!delegateToEmail) {
      return; // User cancelled or provided no email
    }

    // Update the catalog item to change the approved_by field
    this.subscription.add(
      this.catalogService.updateCatalogItem(id, {
        approved_by: delegateToEmail
      }).subscribe({
        next: (updatedItem) => {
          console.log('Item delegated successfully:', updatedItem);
          // Remove from current user's pending approvals
          this.pendingApprovals = this.pendingApprovals.filter(approval => approval.id !== id);
          this.approvalsCount = this.pendingApprovals.length;
          this.updateNavigationButtons();
          
          // Show success message
          alert(`Successfully delegated "${item.title}" to ${delegateToEmail}`);
        },
        error: (error) => {
          console.error('Failed to delegate item:', error);
          alert(`Failed to delegate item: ${error.message || 'Unknown error'}`);
        }
      })
    );
  }

  /**
   * Load team feed - items shared with the current user
   */
  private loadTeamFeed(): void {
    const currentUser = this.authService.getCurrentUserValue();
    if (!currentUser) {
      console.log('No current user found, showing empty team feed');
      return;
    }

    console.log('Loading team feed for user:', currentUser.user_id);
    
    // Get catalog items where current user is in shared_with_ids
    this.subscription.add(
      this.catalogService.getCatalogItems({
        limit: 20, // Get more items to have a good feed
        sort: 'updated_date',
        order: 'desc'
      }).subscribe({
        next: (response) => {
          console.log('Raw catalog items for team feed:', response.items);
          
          // Filter items that are shared with the current user
          const sharedItems = response.items?.filter(item => {
            return item.shared_with_ids && 
                   item.shared_with_ids.includes(currentUser.user_id || currentUser.id || currentUser.email || '');
          }) || [];
          
          console.log('Filtered shared items:', sharedItems);
          
          // Transform to team feed items and take the most recent 10
          this.teamFeed = sharedItems
            .slice(0, 10)
            .map(item => this.transformCatalogToTeamFeedItem(item));
          
          console.log('Final team feed:', this.teamFeed);
        },
        error: (error) => {
          console.error('Failed to load team feed:', error);
          // Fall back to mock data
          this.teamFeed = this.getMockTeamFeed();
        }
      })
    );
  }

  /**
   * Transform catalog item to team feed item
   */
  private transformCatalogToTeamFeedItem(catalog: Catalog): TeamFeedItem {
    const sharedDate = this.formatRelativeTime(catalog.updated_date || catalog.created_date);
    
    return {
      id: catalog.id,
      title: catalog.title || 'Untitled',
      type: catalog.type || 'document',
      sharedBy: catalog.author || 'Unknown',
      sharedByUserId: catalog.author_id || '',
      sharedDate,
      description: catalog.description,
      priority: catalog.priority,
      action: 'shared' // Default action, could be enhanced based on last activity
    };
  }

  /**
   * Get mock team feed data as fallback
   */
  private getMockTeamFeed(): TeamFeedItem[] {
    return [
      {
        id: '1',
        title: 'Q4 Financial Strategy Document',
        type: 'document',
        sharedBy: 'Sarah Johnson',
        sharedByUserId: 'user-1',
        sharedDate: '2 hours ago',
        description: 'Updated financial strategy for Q4 2025',
        priority: 'high',
        action: 'shared'
      },
      {
        id: '2',
        title: 'API Security Best Practices',
        type: 'guide',
        sharedBy: 'Michael Chen',
        sharedByUserId: 'user-2',
        sharedDate: '4 hours ago',
        description: 'Comprehensive guide for securing financial APIs',
        priority: 'medium',
        action: 'updated'
      },
      {
        id: '3',
        title: 'Digital Transformation Roadmap',
        type: 'project',
        sharedBy: 'Emma Davis',
        sharedByUserId: 'user-3',
        sharedDate: '1 day ago',
        description: 'Strategic roadmap for digital transformation initiatives',
        priority: 'high',
        action: 'shared'
      },
      {
        id: '4',
        title: 'Compliance Framework Update',
        type: 'policy',
        sharedBy: 'Alex Rodriguez',
        sharedByUserId: 'user-4',
        sharedDate: '1 day ago',
        description: 'Updated compliance framework for new regulations',
        priority: 'medium',
        action: 'commented'
      },
      {
        id: '5',
        title: 'Customer Onboarding Process',
        type: 'document',
        sharedBy: 'Lisa Wang',
        sharedByUserId: 'user-5',
        sharedDate: '2 days ago',
        description: 'Streamlined customer onboarding workflow',
        priority: 'low',
        action: 'shared'
      }
    ];
  }

  /**
   * Get activity icon based on action type
   */
  getActivityIcon(action: string): any {
    switch (action) {
      case 'shared': return this.faShare;
      case 'updated': return this.faEdit;
      case 'commented': return this.faComments;
      case 'created': return this.faPlus;
      case 'approved': return this.faCheck;
      default: return this.faFileAlt;
    }
  }

  /**
   * Get team feed type icon
   */
  getTeamFeedTypeIcon(type: string): any {
    return this.getApprovalTypeIcon(type); // Reuse existing type icon logic
  }

  /**
   * View team feed item details
   */
  viewTeamFeedItem(item: TeamFeedItem): void {
    console.log('Viewing team feed item:', item.title);
    this.router.navigate(['/user/catalog', item.id]);
  }

  /**
   * Get truncated text for display
   */
  getTruncatedText(text: string, maxLength: number): string {
    if (!text) return '';
    if (text.length <= maxLength) return text;
    
    // Find the last space before the max length to avoid cutting words
    const truncated = text.substring(0, maxLength);
    const lastSpaceIndex = truncated.lastIndexOf(' ');
    
    if (lastSpaceIndex > 0 && lastSpaceIndex > maxLength * 0.8) {
      return truncated.substring(0, lastSpaceIndex) + '...';
    }
    
    return truncated + '...';
  }

  /**
   * Get approval type icon based on type
   */
  getApprovalTypeIcon(type: string): any {
    const typeIconMap: { [key: string]: any } = {
      'assets': this.faFolder,
      'documents': this.faFileAlt,
      'policy': this.faFileContract,
      'article': this.faNewspaper,
      'guide': this.faBook,
      'tutorial': this.faGraduationCap,
      'blog': this.faBlog,
      'research': this.faFlask,
      'reports': this.faAnalytics,
      'notifications': this.faBell,
      'resource': this.faBookmark
    };
    return typeIconMap[type] || this.faFileAlt;
  }

  /**
   * Get approval type CSS class
   */
  getApprovalTypeClass(type: string): string {
    const typeClassMap: { [key: string]: string } = {
      'project': 'type-project',
      'document': 'type-document',
      'policy': 'type-policy',
      'article': 'type-article',
      'guide': 'type-guide',
      'tutorial': 'type-tutorial',
      'blog': 'type-blog',
      'research': 'type-research',
      'report': 'type-report',
      'notification': 'type-notification',
      'resource': 'type-resource'
    };
    return typeClassMap[type] || 'type-default';
  }

  /**
   * View approval details - navigate to the catalog item
   */
  viewApprovalDetails(approval: PendingApproval, event?: Event): void {
    if (event) {
      event.stopPropagation();
    }
    console.log('Viewing approval details for:', approval.title);
    this.router.navigate(['/user/catalog', approval.id]);
  }

  /**
   * Navigate to the dedicated approvals page
   */
  navigateToApprovalsPage(): void {
    console.log('Navigating to dedicated approvals page');
    this.router.navigate(['/user/approvals']);
  }

  /**
   * View all pending approvals on dedicated page
   */
  viewAllApprovals(): void {
    this.navigateToApprovalsPage();
  }

  /**
   * Get priority icon based on priority level
   */
  getPriorityIcon(priority: string): any {
    switch (priority) {
      case 'high':
        return this.faExclamationTriangle;
      case 'medium':
        return this.faExclamationCircle;
      case 'low':
        return this.faClock;
      default:
        return this.faExclamationCircle;
    }
  }

  /**
   * Handle approval actions (approve, reject, delegate)
   */
  handleApproval(id: string, action: 'approve' | 'reject' | 'delegate', event?: Event): void {
    if (event) {
      event.stopPropagation();
    }
    
    const approval = this.pendingApprovals.find(a => a.id === id);
    if (!approval) {
      console.error('Approval not found:', id);
      return;
    }

    switch (action) {
      case 'approve':
        this.approveItem(id, approval);
        break;
      case 'reject':
        this.rejectItem(id, approval);
        break;
      case 'delegate':
        this.delegateItem(id, approval);
        break;
      default:
        console.error('Unknown approval action:', action);
    }
  }

  /**
   * Get absolute value for trend display
   */
  getAbsoluteValue(value: number): number {
    return Math.abs(value);
  }

  /**
   * Initialize chart for content distribution
   */
  private initializeChart(): void {
    // Chart initialization will be implemented when Chart.js is added
    // For now, this prevents the compilation error
    console.log('Chart initialization - to be implemented with Chart.js');
  }

  /**
   * Calculate dashboard items count
   */
  private calculateUserDashboardItems(): number {
    return this.projectsCount + this.resourcesCount + this.pendingApprovals.length;
  }

  /**
   * Calculate weekly wins count
   */
  private calculateWeeklyWinsCount(): number {
    // Mock calculation - in real app, this would be based on completed actions in the past week
    return Math.floor(this.completedActionsCount * 0.3);
  }

  /**
   * Calculate team count
   */
  private calculateTeamCount(): number {
    // Mock calculation - in real app, this would be based on team members or shared items
    return this.teamFeed.length;
  }

  /**
   * Calculate reports count
   */
  private calculateReportsCount(): number {
    // Mock calculation - in real app, this would be based on available reports
    return 3;
  }

  /**
   * Calculate bookmarks count
   */
  private calculateBookmarksCount(): number {
    return this.bookmarkedItems.length;
  }

  /**
   * Calculate my projects count
   */
  private calculateMyProjectsCount(): number {
    return this.projectsCount;
  }

  /**
   * Calculate favorites count
   */
  private calculateFavoritesCount(): number {
    // Mock calculation - in real app, this would be based on favorited items
    return Math.floor(this.catalogCount * 0.2);
  }
}
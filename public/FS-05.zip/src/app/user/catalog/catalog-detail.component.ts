import { Component, OnInit, OnDestroy } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Subscription } from 'rxjs';
import { 
  faArrowLeft, faUser, faCalendar, faClock, faEye, faTag, 
  faHeart, faShare, faEdit, faTrash, faFileText,
  faCopy, faCheck, faInfoCircle, faExclamationTriangle, faSpinner, faRobot, faComments
} from '@fortawesome/free-solid-svg-icons';

// Services and Models
import { CatalogService } from '../../shared/services/catalog.service';
import { AuthService } from '../../shared/services/auth.service';
import { DateUtilityService } from '../../shared/services/date-utility.service';
import { Catalog, User } from '../../shared/models/user.interface';

@Component({
  selector: 'app-catalog-detail',
  templateUrl: './catalog-detail.component.html',
  styleUrls: ['./catalog-detail.component.css']
})
export class CatalogDetailComponent implements OnInit, OnDestroy {
  // FontAwesome icons
  faArrowLeft = faArrowLeft;
  faUser = faUser;
  faCalendar = faCalendar;
  faClock = faClock;
  faEye = faEye;
  faTag = faTag;
  faHeart = faHeart;
  faShare = faShare;
  faEdit = faEdit;
  faCheck= faCheck;
  faTrash = faTrash;
  faFileText = faFileText;
  faCopy = faCopy;
  faInfoCircle = faInfoCircle;
  faExclamationTriangle = faExclamationTriangle;
  faSpinner = faSpinner;
  faRobot = faRobot;
  faComments = faComments;
  
  // Core data
  catalogItem: Catalog | null = null;
  relatedItems: Catalog[] = [];
  currentUser: User | null = null;
  
    // Add this property to prevent multiple markAsRead calls
    private hasMarkedAsRead = false;

  // State management
  isLoading = false;
  errorMessage = '';
  isLiked = false;
  showShareModal = false;
  showAiChat = false;
  showConversations = false;
  
  // Tab configuration
  dynamicTabItems = [
    { key: 'content', value: 'content', label: 'Content', count: 0 },
    { key: 'summary', value: 'summary', label: 'AI Summary', count: 0 },
    { key: 'details', value: 'details', label: 'Details', count: 0 }
  ];
  activeTab = 'content';
  
  // Navigation
  breadcrumbItems = [
    { label: 'Dashboard', routerLink: '/user/dashboard' },
    { label: 'Catalog', routerLink: '/user/catalog' },
    { label: 'Article Details', routerLink: null }
  ];

  private subscriptions = new Subscription();

  constructor(
    private route: ActivatedRoute,
    private router: Router,
    private catalogService: CatalogService,
    private authService: AuthService,
    private dateUtilityService: DateUtilityService
  ) {}

  ngOnInit(): void {
    this.initializeComponent();

    window.addEventListener('scroll', this.onScroll, true);
  }

  ngOnDestroy(): void {
    this.subscriptions.unsubscribe();

    window.removeEventListener('scroll', this.onScroll, true);
  }

  /**
   * Scroll event handler to mark as read when user scrolls past 30% of the page
   */
  onScroll = (): void => {
    if (this.hasMarkedAsRead || !this.catalogItem) return;

    const scrollTop = window.scrollY || document.documentElement.scrollTop;
    const docHeight = document.documentElement.scrollHeight - document.documentElement.clientHeight;
    if (docHeight <= 0) return;

    const scrollPercent = scrollTop / docHeight;
    if (scrollPercent > 0.3) {
      this.markAsRead();
      this.hasMarkedAsRead = true;
    }
  };

  approveItem(): void {
    if (!this.catalogItem) return;
    this.isLoading = true;
    this.catalogService.approveCatalogItem(this.catalogItem.id).subscribe({
      next: (updatedItem) => {
        this.catalogItem = updatedItem;
        this.isLoading = false;
      },
      error: (err) => {
        this.isLoading = false;
        // Optionally show an error message
        this.errorMessage = 'Failed to approve item. Please try again.';
        console.error('Approve error:', err);
      }
    });
  }

  // ===== INITIALIZATION METHODS =====

  private initializeComponent(): void {
    this.initializeBreadcrumbs();
    this.subscribeToAuthState();
    this.subscribeToRouteParams();
  }

  private initializeBreadcrumbs(): void {
    this.breadcrumbItems = [
      { label: 'Dashboard', routerLink: '/user/dashboard' },
      { label: 'Catalog', routerLink: '/user/catalog' },
      { label: 'Article Details', routerLink: null }
    ];
  }

  private subscribeToAuthState(): void {
    this.subscriptions.add(
      this.authService.currentUser$.subscribe((user: User | null) => {
        this.currentUser = user;
      })
    );
  }

  private subscribeToRouteParams(): void {
    this.subscriptions.add(
      this.route.params.subscribe(params => {
        const itemId = params['id'];
        if (itemId) {
          this.loadCatalogItem(itemId);
        }
      })
    );
  }

  private updateBreadcrumbs(): void {
    if (this.catalogItem) {
      this.breadcrumbItems = [
        { label: 'Dashboard', routerLink: '/user/dashboard' },
        { label: 'Catalog', routerLink: '/user/catalog' },
        { label: this.catalogItem.title, routerLink: null }
      ];
    }
  }

  // ===== DATA LOADING METHODS =====

  loadCatalogItem(itemId: string): void {
    this.isLoading = true;
    this.errorMessage = '';

    this.catalogService.getCatalogItem(itemId).subscribe({
      next: (item) => {
        this.catalogItem = {
          ...item,
          read: item.read === true ? true : false
        };
        
        this.isLoading = false;
        this.updateBreadcrumbs();
        this.loadRelatedItems();
        this.initializeUserInteractions();
      },
      error: (error) => {
        console.error('Failed to load catalog item:', error);
        this.errorMessage = 'Failed to load article. Please try again.';
        this.isLoading = false;
      }
    });
  }

  private initializeUserInteractions(): void {
    if (this.catalogItem) {
      this.isLiked = this.catalogItem.user_has_liked || false;
    }
  }

  private loadRelatedItems(): void {
    if (!this.catalogItem) return;

    const params = {
      category: this.catalogItem.category,
      limit: 3,
      exclude: this.catalogItem.id
    };

    this.catalogService.getCatalogItems(params).subscribe({
      next: (response) => {
        this.relatedItems = response.items || [];
      },
      error: (error) => {
        console.error('Failed to load related items:', error);
        this.relatedItems = [];
      }
    });
  }

  // ===== NAVIGATION METHODS =====

  goBack(): void {
    this.router.navigate(['/user/catalog']);
  }

  goToRelatedItem(item: Catalog): void {
    this.router.navigate(['/user/catalog', item.id]);
  }

  // ===== USER INTERACTION METHODS =====

  toggleLike(): void {
    if (!this.catalogItem || !this.currentUser) return;

    const action = this.isLiked ? 'unlike' : 'like';

    this.catalogService.toggleLike(this.catalogItem.id, action).subscribe({
      next: (response) => {
        this.isLiked = !this.isLiked;
        if (this.catalogItem) {
          this.catalogItem.likes_count = response.likes_count;
          this.catalogItem.user_has_liked = this.isLiked;
        }
      },
      error: (error) => {
        console.error('Failed to toggle like:', error);
      }
    });
  }

  shareArticle(): void {
    if (!this.catalogItem) return;

    if (navigator.share) {
      navigator.share({
        title: this.catalogItem.title,
        text: this.catalogItem.description || this.getExcerpt(this.catalogItem.content || '', 100),
        url: window.location.href
      }).catch(console.error);
    } else {
      this.showShareModal = true;
    }
  }

  closeShareModal(): void {
    this.showShareModal = false;
  }

  copyLink(): void {
    navigator.clipboard.writeText(window.location.href).then(() => {
      console.log('Link copied to clipboard');
      this.closeShareModal();
    }).catch(console.error);
  }

  emailArticle(): void {
    if (!this.catalogItem) return;

    const subject = encodeURIComponent(`Article: ${this.catalogItem.title}`);
    const body = encodeURIComponent(`
I thought you might be interested in this article:

${this.catalogItem.title}

${this.catalogItem.description || ''}

Read the full article here: ${window.location.href}
    `);

    window.location.href = `mailto:?subject=${subject}&body=${body}`;
  }

  markAsRead(): void {
    if (!this.catalogItem || this.catalogItem.read) return;

    this.catalogService.markAsRead(this.catalogItem.id).subscribe({
      next: (updatedItem) => {
        if (this.catalogItem) {
          this.catalogItem.read = true;
          this.catalogItem = { ...this.catalogItem, ...updatedItem };
        }
      },
      error: (error) => {
        console.error('Failed to mark as read:', error);
      }
    });
  }

  // ===== AI CHAT METHODS =====

  openAiChat(): void {
    this.showAiChat = true;
  }

  closeAiChat(): void {
    this.showAiChat = false;
  }

  // ===== CONVERSATIONS METHODS =====

  openConversations(): void {
    this.showConversations = true;
  }

  closeConversations(): void {
    this.showConversations = false;
  }

  // ===== CONTENT MANAGEMENT METHODS =====

  editItem(): void {
    if (!this.catalogItem || !this.canEdit()) return;
    this.router.navigate(['/user/catalog/edit', this.catalogItem.id]);
  }

  deleteItem(): void {
    if (!this.catalogItem || !this.canDelete()) return;

    if (confirm('Are you sure you want to delete this article?')) {
      this.catalogService.deleteCatalogItem(this.catalogItem.id).subscribe({
        next: () => {
          this.router.navigate(['/user/catalog']);
        },
        error: (error) => {
          console.error('Failed to delete item:', error);
        }
      });
    }
  }

  // ===== TAB MANAGEMENT =====

  changeTab(tabValue: string): void {
    this.activeTab = tabValue;
  }

  // ===== PERMISSION CHECKS =====

  canEdit(): boolean {
    if (!this.catalogItem || !this.currentUser) return false;
    return this.currentUser.id === this.catalogItem.author_id || this.currentUser.role === 'admin';
  }

  canDelete(): boolean {
    if (!this.catalogItem || !this.currentUser) return false;
    return this.currentUser.id === this.catalogItem.author_id || this.currentUser.role === 'admin';
  }

  // ===== UTILITY METHODS =====

  getFormattedPublishDate(): string {
    if (!this.catalogItem) return '';
    return this.catalogItem.published_at
      ? this.formatDate(this.catalogItem.published_at)
      : this.formatDate(this.catalogItem.created_date || '');
  }

  getReadingTime(): string {
    if (!this.catalogItem?.content) return '1 min';
    const wordsPerMinute = 200;
    const wordCount = this.catalogItem.content.split(' ').length;
    const minutes = Math.ceil(wordCount / wordsPerMinute);
    return `${minutes} min`;
  }

  getAuthorDisplayName(): string {
    return this.catalogItem?.author || 'Unknown Author';
  }

  formatDate(dateString: string): string {
    if (!dateString) return '';
    return this.dateUtilityService.formatDate(dateString);
  }

  getExcerpt(text: string | undefined, maxLength: number = 150): string {
    if (!text) return '';
    if (text.length <= maxLength) return text;
    return text.substring(0, maxLength) + '...';
  }

  // ===== STYLING METHODS =====

  getCategoryClass(category: string | undefined): string {
    if (!category) return 'status-badge';
    const categoryMap: { [key: string]: string } = {
      'technology': 'status-badge status-info',
      'business': 'status-badge status-success',
      'news': 'status-badge status-warning',
      'research': 'status-badge status-primary',
      'announcement': 'status-badge status-announcement'
    };
    return categoryMap[category] || 'status-badge';
  }

  getStatusClass(status: string | undefined): string {
    if (!status) return 'status-badge status-published';
    const statusMap: { [key: string]: string } = {
      'published': 'status-badge status-success',
      'draft': 'status-badge status-medium',
      'pending': 'status-badge status-warning'
    };
    return statusMap[status] || 'status-badge status-published';
  }

  // ===== CONTENT CHECKS =====

  hasInlineStyles(): boolean {
    return !!(this.catalogItem?.content && this.catalogItem.content.includes('style='));
  }

  hasTags(): boolean {
    return !!(this.catalogItem?.tags && this.catalogItem.tags.length > 0);
  }

  getTags(): string[] {
    return this.catalogItem?.tags || [];
  }

  hasSummary(): boolean {
    return !!(this.catalogItem?.summary && this.catalogItem.summary.trim());
  }

  hasChildIds(): boolean {
    return !!(this.catalogItem?.child_ids && this.catalogItem.child_ids.length > 0);
  }

  getChildItemsCount(): number {
    if (!this.catalogItem?.child_ids) return 0;
    return this.catalogItem.child_ids.length;
  }

  hasAdditionalDetails(): boolean {
    const hasChildIds = this.hasChildIds();
    const hasCustomData = !!(this.catalogItem?.custom && Object.keys(this.catalogItem.custom).length > 0);
    return hasChildIds || hasCustomData;
  }

  getChildIdsAsStrings(): string[] {
    if (!this.catalogItem?.child_ids) return [];
    
    return this.catalogItem.child_ids.map(item => {
      if (typeof item === 'string') {
        return item;
      }
      if (typeof item === 'number') {
        return String(item);
      }
      if (item && typeof item === 'object' && 'id' in item) {
        return String((item as any).id);
      }
      return String(item);
    });
  }

  // ===== DEVELOPMENT UTILITIES =====

  showJSON(): void {
    if (!this.catalogItem) return;
    const dataStr = JSON.stringify(this.catalogItem, null, 2);
    const html = `
      <html>
        <head>
          <title>${this.catalogItem.title || 'Catalog Item'} - JSON</title>
          <style>
            body { background: #222; color: #eee; margin: 0; padding: 0; }
            pre { background: #181818; color: #00e676; padding: 2rem; margin: 0; font-size: 1.1rem; overflow-x: auto; }
            .header { background: #111; color: #fff; padding: 1rem 2rem; font-size: 1.2rem; font-family: sans-serif; }
          </style>
        </head>
        <body>
          <div class="header">${this.catalogItem.title || 'Catalog Item'} JSON</div>
          <pre>${dataStr.replace(/</g, '&lt;').replace(/>/g, '&gt;')}</pre>
        </body>
      </html>
    `;
    const win = window.open('', '_blank');
    if (win) {
      win.document.open();
      win.document.write(html);
      win.document.close();
    }
  }
}
import { Component, Input, TemplateRef, OnInit, OnDestroy } from '@angular/core';
import { IconDefinition } from '@fortawesome/fontawesome-svg-core';
import { faChevronLeft, faChevronRight } from '@fortawesome/free-solid-svg-icons';

@Component({
  selector: 'app-card-metric-list',
  template: `
    <div class="metric-list-wrapper">
      <button class="chevron-btn" (click)="scrollLeft()" [disabled]="activeIndex === 0">
        <fa-icon [icon]="faChevronLeft"></fa-icon>
      </button>
      <div class="metric-list-scroll">
  <ng-container *ngFor="let metric of metrics; let i = index">
    <div
      class="slide-card"
      [class.active]="i === activeIndex"
      [class.slide-left]="i < activeIndex"
      [class.slide-right]="i > activeIndex">
      <app-card-metric
        [icon]="metric.icon"
        [label]="metric.label"
        [value]="metric.value"
        [graphic]="metric.graphic">
      </app-card-metric>
    </div>
  </ng-container>
</div>
      <button class="chevron-btn" (click)="scrollRight()" [disabled]="activeIndex === metrics.length - 1">
        <fa-icon [icon]="faChevronRight"></fa-icon>
      </button>
    </div>
    <div class="metric-dots" *ngIf="metrics.length > 1">
      <span *ngFor="let m of metrics; let i = index"
            class="dot" [class.active]="activeIndex === i" (click)="goTo(i)"></span>
    </div>
  `,
  styles: [`
    .card-metric-minimal {
      display: flex;
      flex-direction: column;
      align-items: center;
      background: var(--fm-white, #fff);
      border-radius: 10px;
      box-shadow: 0 2px 8px rgba(44, 62, 80, 0.08);
      padding: 1rem 0.5rem;
      width: 150px;
      height: 150px;
      gap: 0.5rem;
    }
    .metric-icon fa-icon {
      font-size: 1.5rem;
      color: var(--fm-primary-blue, #007bff);
      margin-bottom: 0.5rem;
    }
    .metric-label {
      font-size: 0.8rem;
      color: var(--fm-text-secondary, #6c757d);
      margin-bottom: 0.25rem;
      text-align: center;
    }
    .metric-value {
      font-size: 2rem;
      font-weight: 700;
      color: var(--fm-text-primary, #222);
      margin-bottom: 0.5rem;
      text-align: center;
    }
    .metric-graphic {
      width: 100%;
      display: flex;
      justify-content: center;
      align-items: center;
      min-height: 40px;
    }
    .metric-graphic img {
      max-width: 80px;
      max-height: 40px;
      object-fit: contain;
    }
    .metric-list-wrapper {
      display: flex;
      align-items: center;
      justify-content: center;
      width: 100%;
      gap: 1rem;
      padding: 1rem 0; /* Add vertical padding */
    }
    .chevron-btn {
      background: none;
      border: none;
      cursor: pointer;
      font-size: 1rem;
      color: var(--fm-primary-blue, #007bff);
      padding: 0 0.5rem;
      display: flex;
      align-items: center;
      z-index: 1;
    }
    .metric-list-scroll {
      display: flex;
      overflow-x: hidden;
      scroll-behavior: smooth;
      width: 150px;
      min-width: 150px;
      max-width: 150px;
      justify-content: flex-start;
      align-items: center;
      gap: 0;
      margin: 0 auto;
      scroll-snap-type: x mandatory;
      position: relative;
      height: 150px;
    }
    .slide-card {
      position: absolute;
      top: 0;
      left: 0;
      width: 150px;
      height: 150px;
      opacity: 0;
      transition: opacity 0.4s, transform 0.4s;
      will-change: opacity, transform;
      z-index: 1;
      pointer-events: none;
    }
    .slide-card.active {
      opacity: 1;
      transform: translateX(0);
      z-index: 2;
      pointer-events: auto;
    }
    .slide-card.slide-left {
      opacity: 0;
      transform: translateX(-40px);
    }
    .slide-card.slide-right {
      opacity: 0;
      transform: translateX(40px);
    }
    .metric-dots {
      display: flex;
      justify-content: center;
      align-items: center;
      margin-top: 0.5rem;
      gap: 0.5rem;
    }
    .dot {
      width: 10px;
      height: 10px;
      border-radius: 50%;
      background: #ccc;
      display: inline-block;
      cursor: pointer;
      transition: background 0.2s;
    }
    .dot.active {
      background: var(--fm-primary-blue, #007bff);
    }
  `]
})
export class CardMetricListComponent implements OnInit, OnDestroy {
  @Input() metrics: Array<{ icon?: IconDefinition, label?: string, value?: string | number, graphic?: string | TemplateRef<any> }> = [];
  faChevronLeft = faChevronLeft;
  faChevronRight = faChevronRight;
  activeIndex = 0;
  timer: any;
  interval = 3000; // 3 seconds

  ngOnInit() {
    this.startAutoScroll();
  }

  ngOnDestroy() {
    this.clearAutoScroll();
  }

  startAutoScroll() {
    this.clearAutoScroll();
    if (this.metrics.length > 1) {
      this.timer = setInterval(() => {
        if (this.activeIndex < this.metrics.length - 1) {
          this.activeIndex++;
        } else {
          this.activeIndex = 0;
        }
      }, this.interval);
    }
  }

  clearAutoScroll() {
    if (this.timer) {
      clearInterval(this.timer);
      this.timer = null;
    }
  }

  scrollLeft(): void {
    if (this.activeIndex > 0) {
      this.activeIndex--;
    } else {
      this.activeIndex = this.metrics.length - 1;
    }
    this.startAutoScroll();
  }
  scrollRight(): void {
    if (this.activeIndex < this.metrics.length - 1) {
      this.activeIndex++;
    } else {
      this.activeIndex = 0;
    }
    this.startAutoScroll();
  }
  goTo(index: number) {
    this.activeIndex = index;
    this.startAutoScroll();
  }
}
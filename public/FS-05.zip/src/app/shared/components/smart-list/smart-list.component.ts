import { Component, Input, Output, EventEmitter } from '@angular/core';
import { Router } from '@angular/router';
import { faEdit, faTrash, faStickyNote, faLink, faUser, faTimes, faCheck, faInbox, faSearch, faPlus, faFileAlt } from '@fortawesome/free-solid-svg-icons';

export interface SmartListPost {
  id: string; // Add ID field for navigation
  title: string;
  content: string;
  postedBy: string;
  time: string;
  category?: string;
  type?: string;
  created_date?: string;
  updated_date?: string;
  status?: string; // Add status field
  read?: boolean; // Add read status
}

@Component({
  selector: 'app-smart-list',
  templateUrl: './smart-list.component.html',
  styleUrls: ['./smart-list.component.css']
})
export class SmartListComponent {
  @Input() posts: SmartListPost[] = [];
  @Input() title: string = 'Top Posts';
  @Input() barColor: string = '#3b82f6';
  @Input() flip: boolean = true;
  @Input() showApproveButton: boolean = false; // Add input to control approve button visibility
  @Input() badgeList: string[] = ['category', 'type', 'status']; // List of badges to show: 'category', 'type', 'status'
  @Input() pageSize: number = 3; // Number of items to show per page
  @Input() emptyStateTitle: string = 'No items found';
  @Input() emptyStateMessage: string = 'There are currently no items to display. Check back later or try refreshing the page.';
  @Input() emptyStateIcon: string = 'inbox'; // Options: 'inbox', 'search', 'file', 'plus'
  @Input() showEmptyStateAction: boolean = false;
  @Input() emptyStateActionText: string = 'Add New Item';
  @Output() approveItem = new EventEmitter<SmartListPost>(); // Add event emitter for approve action
  @Output() emptyStateAction = new EventEmitter<void>();
  currentIndex = 0;

  faEdit = faEdit;
  faDelete = faTrash;
  faLink = faLink;
  faClose = faTimes; // Define the faClose property
  faCheck = faCheck; // Define the faCheck property
  faUser= faUser; // Define the faUser property
  faStickyNote = faStickyNote; // Use faEdit for note icon
  faInbox = faInbox;
  faSearch = faSearch;
  faPlus = faPlus;
  faFileAlt = faFileAlt;

  constructor(private router: Router) {}

  get topPosts(): SmartListPost[] {
    return this.posts.slice(0, 30);
  }

  scrollLeft() {
    // Always move back by full pageSize
    this.currentIndex = Math.max(0, this.currentIndex - this.pageSize);
  }

  scrollRight() {
    // Always move forward by full pageSize, but don't go beyond what makes sense
    const nextIndex = this.currentIndex + this.pageSize;
    if (nextIndex < this.posts.length) {
      this.currentIndex = nextIndex;
    }
  }

  get visiblePosts(): SmartListPost[] {
    return this.posts.slice(this.currentIndex, this.currentIndex + this.pageSize);
  }

  get startCount(): number {
    if (this.posts.length === 0) return 0;
    return this.currentIndex + 1;
  }

  get endCount(): number {
    if (this.posts.length === 0) return 0;
    const actualEndIndex = this.currentIndex + this.visiblePosts.length;
    return actualEndIndex;
  }

  get totalCount(): number {
    return this.posts.length;
  }

  onToolClick(action: string, post: any): void {
    // Implement your logic here
    console.log('Tool clicked:', action, post);
  }

  /**
   * Handle approve button click
   */
  onApproveClick(post: SmartListPost, event: Event): void {
    event.stopPropagation(); // Prevent navigation
    console.log('Approving item:', post.id);
    this.approveItem.emit(post);
  }

  /**
   * Handle list item click - navigate to catalog detail page
   */
  onItemClick(post: SmartListPost): void {
    console.log('Navigating to catalog detail for ID:', post.id);
    this.router.navigate(['/user/catalog', post.id]);
  }

  /**
   * Get the latest time from created_date and updated_date
   */
  getLatestTime(post: SmartListPost): string {
    if (!post.created_date && !post.updated_date) {
      return post.time; // Fallback to existing time field
    }

    const createdDate = post.created_date ? new Date(post.created_date) : null;
    const updatedDate = post.updated_date ? new Date(post.updated_date) : null;
    
    let latestDate: Date;
    if (createdDate && updatedDate) {
      latestDate = updatedDate > createdDate ? updatedDate : createdDate;
    } else if (createdDate) {
      latestDate = createdDate;
    } else if (updatedDate) {
      latestDate = updatedDate;
    } else {
      return post.time; // Fallback
    }

    return this.formatRelativeTime(latestDate);
  }

  /**
   * Format date as relative time (e.g., "2 hours ago")
   */
  private formatRelativeTime(date: Date): string {
    const now = new Date();
    const diffInMs = now.getTime() - date.getTime();
    const diffInMinutes = Math.floor(diffInMs / (1000 * 60));
    const diffInHours = Math.floor(diffInMinutes / 60);
    const diffInDays = Math.floor(diffInHours / 24);

    if (diffInMinutes < 1) {
      return 'Just now';
    } else if (diffInMinutes < 60) {
      return `${diffInMinutes} minute${diffInMinutes !== 1 ? 's' : ''} ago`;
    } else if (diffInHours < 24) {
      return `${diffInHours} hour${diffInHours !== 1 ? 's' : ''} ago`;
    } else if (diffInDays < 7) {
      return `${diffInDays} day${diffInDays !== 1 ? 's' : ''} ago`;
    } else {
      return date.toLocaleDateString();
    }
  }

  /**
   * Get badge color for category
   */
  getCategoryBadgeColor(category?: string): string {
    if (!category) return '#6b7280'; // gray
    
    const colors: { [key: string]: string } = {
      'document': '#3b82f6', // blue
      'project': '#10b981', // green
      'policy': '#f59e0b', // amber
      'security': '#ef4444', // red
      'compliance': '#8b5cf6', // purple
      'tutorial': '#06b6d4', // cyan
      'guide': '#84cc16', // lime
      'news': '#f97316', // orange
      'announcement': '#ec4899', // pink
      'research': '#6366f1' // indigo
    };
    
    return colors[category.toLowerCase()] || '#6b7280';
  }

  /**
   * Get badge color for type
   */
  getTypeBadgeColor(type?: string): string {
    if (!type) return '#6b7280'; // gray
    
    const colors: { [key: string]: string } = {
      'urgent': '#ef4444', // red
      'high': '#f59e0b', // amber
      'medium': '#3b82f6', // blue
      'low': '#10b981', // green
      'draft': '#6b7280', // gray
      'published': '#10b981', // green
      'archived': '#6b7280' // gray
    };
    
    return colors[type.toLowerCase()] || '#6b7280';
  }

  /**
   * Get badge color for status
   */
  getStatusBadgeColor(status?: string): string {
    if (!status) return '#6b7280'; // gray
    
    const colors: { [key: string]: string } = {
      'draft': '#6b7280', // gray
      'pending_approval': '#f59e0b', // amber
      'pending-approval': '#f59e0b', // amber (alternative format)
      'approved': '#10b981', // green
      'published': '#10b981', // green
      'rejected': '#ef4444', // red
      'archived': '#6b7280' // gray
    };
    
    return colors[status.toLowerCase()] || '#6b7280';
  }

  /**
   * Check if post needs approval
   */
  needsApproval(post: SmartListPost): boolean {
    return post.status === 'pending_approval' || post.status === 'pending-approval';
  }

  /**
   * Check if a specific badge should be shown
   */
  shouldShowBadge(badgeType: string): boolean {
    return this.badgeList.includes(badgeType);
  }

  /**
   * Check if a post is marked as read
   */
  isRead(post: SmartListPost): boolean {
    return post.read === true;
  }

  /**
   * Mark a post as read
   */
  markAsRead(post: SmartListPost): void {
    post.read = true;
    console.log(`Post with ID ${post.id} marked as read.`);
  }

  /**
   * Handle empty state action
   */
  onEmptyStateAction(): void {
    this.emptyStateAction.emit();
  }
}

import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';
import { Observable, BehaviorSubject, throwError } from 'rxjs';
import { tap, catchError, map } from 'rxjs/operators';
import { User, UserCreate, ApiResponse } from '../models/user.interface';
import { AuthService } from './auth.service';
import { environment } from '../../../environments/environment';

export interface UserListResponse {
  items: User[];
  total: number;
  limit: number;
  offset: number;
  page?: number;
  page_size?: number;
  total_pages?: number;
}

export interface UserQueryParams {
  skip?: number;
  limit?: number;
  page?: number;
  page_size?: number;
}

export interface UserProfileUpdate {
  first_name?: string;
  last_name?: string;
  email?: string;          // Format: email
  manager_id?: string;
  portfolio_id?: string;
  organization_id?: string;
  costcenter_id?: string;
  user_type?: string;
  designation?: "Associate" | "Lead Associate" | "Manager" | "Senior Manager" | "Advisor" | "Director" | "Senior Director" | "Principal" | "Vice President" | "Senior Vice President" | "Fellow";    // Job designation/title
}

export interface UserAdminUpdate {
  user_id?: string;
  email?: string;
  first_name?: string;
  last_name?: string;
  is_active?: boolean;
  role?: "user" | "admin";
  is_superuser?: boolean;
  email_verified?: boolean;
  manager_id?: string;
  portfolio_id?: string;
  organization_id?: string;
  costcenter_id?: string;
  user_type?: string;
  designation?: "Associate" | "Lead Associate" | "Manager" | "Senior Manager" | "Advisor" | "Director" | "Senior Director" | "Principal" | "Vice President" | "Senior Vice President" | "Fellow";    // Job designation/title
}

export interface PasswordUpdate {
  current_password: string;
  new_password: string;
}

@Injectable({
  providedIn: 'root'
})
export class UserService {
  private readonly API_BASE = `${environment.apiUrl}${environment.apiVersion}`;
  
  private userProfileSubject = new BehaviorSubject<User | null>(null);
  public userProfile$ = this.userProfileSubject.asObservable();

  constructor(
    private http: HttpClient,
    private authService: AuthService
  ) {
    // Subscribe to current user changes from auth service
    this.authService.currentUser$.subscribe(user => {
      this.userProfileSubject.next(user);
      
      // If we have a user but it's missing manager information, fetch complete profile
      if (user && !user.hasOwnProperty('manager_id')) {
        console.log('🔍 [DEBUG] User profile missing manager data, fetching complete profile...');
        this.getCurrentUserProfile().subscribe({
          next: (completeProfile) => {
            console.log('🔍 [DEBUG] Complete profile fetched with manager data:', completeProfile);
            // Update the auth service with complete profile data
            this.authService.setCurrentUser(completeProfile);
          },
          error: (error) => {
            console.warn('⚠️ [DEBUG] Failed to fetch complete profile:', error);
          }
        });
      }
    });
  }

  /**
   * Get authorization headers for API requests
   */
  private getAuthHeaders(): HttpHeaders {
    const token = this.authService.getToken();
    return new HttpHeaders({
      'Content-Type': 'application/json',
      'Authorization': token ? `Bearer ${token}` : ''
    });
  }

  /**
   * Handle HTTP errors
   */
  private handleError(error: any): Observable<never> {
    console.error('API Error:', error);
    let errorMessage = 'An unexpected error occurred';
    
    if (error.error?.detail) {
      if (Array.isArray(error.error.detail)) {
        errorMessage = error.error.detail.map((d: any) => d.msg).join(', ');
      } else {
        errorMessage = error.error.detail;
      }
    } else if (error.error?.message) {
      errorMessage = error.error.message;
    } else if (error.message) {
      errorMessage = error.message;
    }
    
    return throwError(() => ({ message: errorMessage }));
  }

  /**
   * Get current user profile
   */
  getCurrentUserProfile(): Observable<User> {
    return this.http.get<User>(`${this.API_BASE}/users/me`, {
      headers: this.getAuthHeaders()
    }).pipe(
      tap(user => this.userProfileSubject.next(user)),
      catchError(this.handleError)
    );
  }

  /**
   * Update current user profile
   */
  updateCurrentUserProfile(userData: UserProfileUpdate): Observable<User> {
    return this.http.put<User>(`${this.API_BASE}/users/me`, userData, {
      headers: this.getAuthHeaders()
    }).pipe(
      tap(user => this.userProfileSubject.next(user)),
      catchError(this.handleError)
    );
  }

  /**
   * Update current user password
   */
  updateCurrentUserPassword(passwordData: PasswordUpdate): Observable<any> {
    return this.http.put(`${this.API_BASE}/users/me/password`, passwordData, {
      headers: this.getAuthHeaders()
    }).pipe(
      catchError(this.handleError)
    );
  }

  /**
   * Get all users (public endpoint)
   */
  getAllUsers(params?: UserQueryParams): Observable<User[]> {
    let httpParams = new HttpParams();
    
    if (params) {
      Object.entries(params).forEach(([key, value]) => {
        if (value !== undefined && value !== null) {
          httpParams = httpParams.set(key, value.toString());
        }
      });
    }

    return this.http.get<User[]>(`${this.API_BASE}/users/`, {
      params: httpParams
    }).pipe(
      catchError(this.handleError)
    );
  }

  /**
   * Get users with pagination support (alias for getAllUsers)
   */
  getUsers(params?: UserQueryParams): Observable<User[]> {
    return this.getAllUsers(params);
  }

  /**
   * Get user by ID (admin only)
   */
  getUserById(userId: string): Observable<User> {
    return this.http.get<User>(`${this.API_BASE}/users/${userId}`, {
      headers: this.getAuthHeaders()
    }).pipe(
      catchError(this.handleError)
    );
  }

  /**
   * Create new admin user (admin only)
   */
  createAdminUser(userData: UserCreate): Observable<User> {
    return this.http.post<User>(`${this.API_BASE}/auth/register-admin`, userData, {
      headers: this.getAuthHeaders()
    }).pipe(
      catchError(this.handleError)
    );
  }

  /**
   * Create new user (admin only) - alias for createAdminUser
   */
  createUser(userData: UserCreate): Observable<User> {
    return this.createAdminUser(userData);
  }

  /**
   * Update user by ID (admin only)
   */
  updateUserById(userId: string, userData: UserAdminUpdate): Observable<User> {
    return this.http.put<User>(`${this.API_BASE}/users/${userId}`, userData, {
      headers: this.getAuthHeaders()
    }).pipe(
      catchError(this.handleError)
    );
  }

  /**
   * Update user (handles both current user and admin updates)
   */
  updateUser(userData: Partial<User> & { id?: string }): Observable<User> {
    const { id, ...updateData } = userData;
    
    if (id && id !== this.getCurrentUserProfileValue()?.id) {
      // Admin updating another user
      return this.updateUserById(id, updateData as UserAdminUpdate);
    } else {
      // User updating their own profile
      return this.updateCurrentUserProfile(updateData as UserProfileUpdate);
    }
  }

  /**
   * Delete user (admin only)
   */
  deleteUser(userId: string): Observable<any> {
    return this.http.delete(`${this.API_BASE}/users/${userId}`, {
      headers: this.getAuthHeaders()
    }).pipe(
      catchError(this.handleError)
    );
  }

  /**
   * Update user role (admin only)
   */
  updateUserRole(userId: string, role: 'user' | 'admin'): Observable<User> {
    return this.http.patch<User>(`${this.API_BASE}/users/${userId}/role`, { role }, {
      headers: this.getAuthHeaders()
    }).pipe(
      catchError(this.handleError)
    );
  }

  /**
   * Update user status (admin only)
   */
  updateUserStatus(userId: string, isActive: boolean): Observable<User> {
    return this.http.patch<User>(`${this.API_BASE}/users/${userId}/status`, { is_active: isActive }, {
      headers: this.getAuthHeaders()
    }).pipe(
      catchError(this.handleError)
    );
  }

  /**
   * Toggle user status (admin only)
   */
  toggleUserStatus(userId: string): Observable<User> {
    return this.http.patch<User>(`${this.API_BASE}/users/${userId}/toggle-status`, {}, {
      headers: this.getAuthHeaders()
    }).pipe(
      catchError(this.handleError)
    );
  }

  /**
   * Change password for current user
   */
  changePassword(currentPassword: string, newPassword: string): Observable<ApiResponse<any>> {
    const passwordData: PasswordUpdate = {
      current_password: currentPassword,
      new_password: newPassword
    };
    
    return this.updateCurrentUserPassword(passwordData).pipe(
      catchError(this.handleError)
    );
  }

  /**
   * Get current user profile value (synchronous)
   */
  getCurrentUserProfileValue(): User | null {
    return this.userProfileSubject.value;
  }

  /**
   * Refresh user profile from server
   */
  refreshProfile(): Observable<User> {
    return this.getCurrentUserProfile();
  }

  /**
   * Check if current user is admin
   */
  isCurrentUserAdmin(): boolean {
    const user = this.getCurrentUserProfileValue();
    return user?.role === 'admin' || user?.is_superuser === true;
  }

  /**
   * Check if current user is superuser
   */
  isCurrentUserSuperuser(): boolean {
    const user = this.getCurrentUserProfileValue();
    return user?.is_superuser === true;
  }

  /**
   * Get user display name
   */
  getUserDisplayName(user?: User | null): string {
    const currentUser = user || this.getCurrentUserProfileValue();
    if (!currentUser) return 'Unknown User';
    
    if (currentUser.first_name && currentUser.last_name) {
      return `${currentUser.first_name} ${currentUser.last_name}`;
    }
    
    if (currentUser.first_name) {
      return currentUser.first_name;
    }
    
    return currentUser.user_id || currentUser.email || 'Unknown User';
  }

  /**
   * Get user initials for avatar
   */
  getUserInitials(user?: User | null): string {
    const currentUser = user || this.getCurrentUserProfileValue();
    if (!currentUser) return 'U';
    
    if (currentUser.first_name && currentUser.last_name) {
      return `${currentUser.first_name.charAt(0)}${currentUser.last_name.charAt(0)}`.toUpperCase();
    }
    
    if (currentUser.first_name) {
      return currentUser.first_name.charAt(0).toUpperCase();
    }
    
    if (currentUser.user_id) {
      return currentUser.user_id.charAt(0).toUpperCase();
    }
    
    return 'U';
  }

  /**
   * Get user status display
   */
  getUserStatusDisplay(user: User): string {
    if (user.is_active === false) return 'Inactive';
    if (user.email_verified === false) return 'Unverified';
    return 'Active';
  }

  /**
   * Get user role display
   */
  getUserRoleDisplay(user: User): string {
    if (user.is_superuser) return 'Super Admin';
    if (user.role === 'admin') return 'Administrator';
    return 'User';
  }

  /**
   * Check if user can be edited by current user
   */
  canEditUser(user: User): boolean {
    const currentUser = this.getCurrentUserProfileValue();
    if (!currentUser) return false;
    
    // Super admin can edit anyone
    if (currentUser.is_superuser) return true;
    
    // Admin can edit non-admin users and themselves
    if (currentUser.role === 'admin') {
      return user.role !== 'admin' || user.id === currentUser.id;
    }
    
    // Users can only edit themselves
    return user.id === currentUser.id;
  }

  /**
   * Check if user can be deleted by current user
   */
  canDeleteUser(user: User): boolean {
    const currentUser = this.getCurrentUserProfileValue();
    if (!currentUser) return false;
    
    // Cannot delete yourself
    if (user.id === currentUser.id) return false;
    
    // Super admin can delete anyone (except themselves)
    if (currentUser.is_superuser) return true;
    
    // Admin can delete non-admin users
    if (currentUser.role === 'admin') {
      return user.role !== 'admin' && !user.is_superuser;
    }
    
    // Regular users cannot delete anyone
    return false;
  }

  /**
   * Check if user role can be changed by current user
   */
  canChangeUserRole(user: User): boolean {
    const currentUser = this.getCurrentUserProfileValue();
    if (!currentUser) return false;
    
    // Only super admin and admin can change roles
    if (!currentUser.is_superuser && currentUser.role !== 'admin') return false;
    
    // Cannot change your own role
    if (user.id === currentUser.id) return false;
    
    // Super admin can change anyone's role
    if (currentUser.is_superuser) return true;
    
    // Admin can only change non-admin users to admin (not vice versa)
    return user.role === 'user';
  }

  /**
   * Check if user status can be changed by current user
   */
  canChangeUserStatus(user: User): boolean {
    const currentUser = this.getCurrentUserProfileValue();
    if (!currentUser) return false;
    
    // Cannot change your own status
    if (user.id === currentUser.id) return false;
    
    // Super admin can change anyone's status
    if (currentUser.is_superuser) return true;
    
    // Admin can change non-admin users' status
    if (currentUser.role === 'admin') {
      return user.role !== 'admin' && !user.is_superuser;
    }
    
    return false;
  }

  /**
   * Get team members who report to the same manager as the current user
   */
  getTeamMembers(): Observable<User[]> {
    const currentUser = this.getCurrentUserProfileValue();
    
    console.log('🔍 [DEBUG] getTeamMembers called');
    console.log('🔍 [DEBUG] Current user:', currentUser);
    
    if (!currentUser) {
      console.warn('⚠️ [DEBUG] No current user found');
      return new Observable<User[]>(observer => {
        observer.next([]);
        observer.complete();
      });
    }

    if (!currentUser.manager_id) {
      console.warn('⚠️ [DEBUG] Current user has no manager_id:', currentUser.user_id);
      // If current user has no manager, return empty array
      return new Observable<User[]>(observer => {
        observer.next([]);
        observer.complete();
      });
    }

    console.log('🔍 [DEBUG] Looking for team members with manager_id:', currentUser.manager_id);

    // Get all users and filter by same manager_id
    return this.getAllUsers().pipe(
      map((users: User[]) => {
        console.log('🔍 [DEBUG] Total users fetched:', users.length);
        
        const teamMembers = users.filter(user => {
          // Debug each user
          const isSameManager = user.manager_id === currentUser.manager_id;
          const isNotCurrentUser = user.id !== currentUser.id;
          const isActive = user.is_active !== false;
          
          console.log(`🔍 [DEBUG] User ${user.user_id}: manager_id=${user.manager_id}, same_manager=${isSameManager}, not_current=${isNotCurrentUser}, active=${isActive}`);
          
          return isSameManager && isNotCurrentUser && isActive;
        });
        
        console.log('🔍 [DEBUG] Filtered team members:', teamMembers.length);
        console.log('🔍 [DEBUG] Team members:', teamMembers.map(u => ({ user_id: u.user_id, name: this.getUserDisplayName(u) })));
        
        return teamMembers;
      }),
      catchError(error => {
        console.error('❌ [DEBUG] Error in getTeamMembers:', error);
        return new Observable<User[]>(observer => {
          observer.next([]);
          observer.complete();
        });
      })
    );
  }

  /**
   * Get users who report directly to the current user (if current user is a manager)
   */
  getDirectReports(): Observable<User[]> {
    const currentUser = this.getCurrentUserProfileValue();
    
    console.log('🔍 [DEBUG] getDirectReports called');
    console.log('🔍 [DEBUG] Current user:', currentUser);
    
    if (!currentUser) {
      console.warn('⚠️ [DEBUG] No current user found for direct reports');
      return new Observable<User[]>(observer => {
        observer.next([]);
        observer.complete();
      });
    }

    console.log('🔍 [DEBUG] Looking for direct reports where manager_id equals current user id:', currentUser.id);

    // Get all users who report to the current user (current user is their manager)
    return this.getAllUsers().pipe(
      map((users: User[]) => {
        console.log('🔍 [DEBUG] Total users fetched for direct reports:', users.length);
        
        const directReports = users.filter(user => {
          const reportsToCurrentUser = user.manager_id === currentUser.id;
          const isActive = user.is_active !== false;
          
          console.log(`🔍 [DEBUG] User ${user.user_id}: reports_to_current=${reportsToCurrentUser}, active=${isActive}`);
          
          return reportsToCurrentUser && isActive;
        });
        
        console.log('🔍 [DEBUG] Direct reports found:', directReports.length);
        console.log('🔍 [DEBUG] Direct reports:', directReports.map(u => ({ user_id: u.user_id, name: this.getUserDisplayName(u) })));
        
        return directReports;
      }),
      catchError(error => {
        console.error('❌ [DEBUG] Error in getDirectReports:', error);
        return new Observable<User[]>(observer => {
          observer.next([]);
          observer.complete();
        });
      })
    );
  }

  /**
   * Get your peers - users who report to the same manager as you (API endpoint)
   */
  getPeers(): Observable<User[]> {
    console.log('🔍 [DEBUG] getPeers called - using API endpoint');
    
    return this.http.get<User[]>(`${this.API_BASE}/users/me/peers`, {
      headers: this.getAuthHeaders()
    }).pipe(
      tap(peers => {
        console.log('🔍 [DEBUG] Peers from API:', peers.length);
        console.log('🔍 [DEBUG] Peers list:', peers.map(u => ({ user_id: u.user_id, name: this.getUserDisplayName(u) })));
      }),
      catchError(error => {
        console.error('❌ [DEBUG] Error in getPeers API call:', error);
        return this.handleError(error);
      })
    );
  }

  /**
   * Get your team - users who report directly to you (API endpoint)
   */
  getMyTeam(): Observable<User[]> {
    console.log('🔍 [DEBUG] getMyTeam called - using API endpoint');
    
    return this.http.get<User[]>(`${this.API_BASE}/users/me/team`, {
      headers: this.getAuthHeaders()
    }).pipe(
      tap(team => {
        console.log('🔍 [DEBUG] Team from API:', team.length);
        console.log('🔍 [DEBUG] Team list:', team.map(u => ({ user_id: u.user_id, name: this.getUserDisplayName(u) })));
      }),
      catchError(error => {
        console.error('❌ [DEBUG] Error in getMyTeam API call:', error);
        return this.handleError(error);
      })
    );
  }

  /**
   * Get all relevant users for sharing (peers, team, and manager)
   */
  getShareableUsers(): Observable<{ peers: User[], team: User[], manager: User | null }> {
    const currentUser = this.getCurrentUserProfileValue();
    
    console.log('🔍 [DEBUG] getShareableUsers called');
    console.log('🔍 [DEBUG] Current user profile:', currentUser);
    console.log('🔍 [DEBUG] Current user manager_id:', currentUser?.manager_id);
    console.log('🔍 [DEBUG] Current user manager object:', currentUser?.manager);
    
    if (!currentUser) {
      console.warn('⚠️ [DEBUG] No current user found for shareable users');
      return new Observable(observer => {
        observer.next({ peers: [], team: [], manager: null });
        observer.complete();
      });
    }

    // Get peers and team from API endpoints
    const peers$ = this.getPeers().pipe(
      catchError(() => new Observable<User[]>(observer => {
        observer.next([]);
        observer.complete();
      }))
    );
    
    const team$ = this.getMyTeam().pipe(
      catchError(() => new Observable<User[]>(observer => {
        observer.next([]);
        observer.complete();
      }))
    );

    // Get manager information - try to fetch full user details if manager_id is available
    let manager$: Observable<User | null>;
    
    if (currentUser.manager_id) {
      console.log('🔍 [DEBUG] Attempting to fetch manager by ID:', currentUser.manager_id);
      manager$ = this.getUserById(currentUser.manager_id).pipe(
        tap(manager => console.log('🔍 [DEBUG] Successfully fetched manager from API:', manager)),
        catchError(error => {
          console.warn('⚠️ [DEBUG] Failed to fetch manager from API:', error);
          // If API call fails, fall back to basic manager info from currentUser.manager
          if (currentUser.manager) {
            console.log('🔍 [DEBUG] Falling back to basic manager info from user object');
            const managerUser: User = {
              id: currentUser.manager.id,
              user_id: currentUser.manager.user_id,
              first_name: currentUser.manager.first_name,
              last_name: currentUser.manager.last_name,
              designation: currentUser.manager.designation,
              created_date: new Date().toISOString(),
              is_active: true,
              role: 'user'
            };
            console.log('🔍 [DEBUG] Created manager user object:', managerUser);
            return new Observable<User>(observer => {
              observer.next(managerUser);
              observer.complete();
            });
          }
          console.warn('⚠️ [DEBUG] No fallback manager data available');
          return new Observable<User | null>(observer => {
            observer.next(null);
            observer.complete();
          });
        })
      );
    } else if (currentUser.manager) {
      console.log('🔍 [DEBUG] No manager_id but manager object exists, using basic manager info');
      const managerUser: User = {
        id: currentUser.manager.id,
        user_id: currentUser.manager.user_id,
        first_name: currentUser.manager.first_name,
        last_name: currentUser.manager.last_name,
        designation: currentUser.manager.designation,
        created_date: new Date().toISOString(),
        is_active: true,
        role: 'user'
      };
      console.log('🔍 [DEBUG] Using manager object from user profile:', managerUser);
      manager$ = new Observable<User>(observer => {
        observer.next(managerUser);
        observer.complete();
      });
    } else {
      console.log('🔍 [DEBUG] No manager_id and no manager object available');
      manager$ = new Observable<User | null>(observer => {
        observer.next(null);
        observer.complete();
      });
    }

    // Combine all results
    return new Observable(observer => {
      let peersResult: User[] = [];
      let teamResult: User[] = [];
      let managerResult: User | null = null;
      let completed = 0;

      const checkComplete = () => {
        completed++;
        if (completed === 3) {
          console.log('🔍 [DEBUG] Shareable users summary:');
          console.log(`   - Peers: ${peersResult.length}`);
          console.log(`   - Team: ${teamResult.length}`);
          console.log(`   - Manager: ${managerResult ? this.getUserDisplayName(managerResult) : 'None'}`);
          
          observer.next({ 
            peers: peersResult, 
            team: teamResult, 
            manager: managerResult 
          });
          observer.complete();
        }
      };

      peers$.subscribe({
        next: (peers) => {
          peersResult = peers;
          checkComplete();
        },
        error: () => {
          peersResult = [];
          checkComplete();
        }
      });

      team$.subscribe({
        next: (team) => {
          teamResult = team;
          checkComplete();
        },
        error: () => {
          teamResult = [];
          checkComplete();
        }
      });

      manager$.subscribe({
        next: (manager) => {
          managerResult = manager;
          checkComplete();
        },
        error: () => {
          managerResult = null;
          checkComplete();
        }
      });
    });
  }
}
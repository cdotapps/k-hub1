export const environment = {
  production: false,
  apiUrl: 'http://localhost:8000',
  apiVersion: '/api/v1',
  enableWebSockets: true,  // Enable WebSockets in production
  wsUrl: 'ws://localhost:8000',  // Use WebSocket protocol (ws://) instead of HTTP
  wsEndpoint: '/api/v1/webhooks'  // WebSocket endpoint path
};
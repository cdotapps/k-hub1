#!/usr/bin/env python3
"""
API Usage Example for SharePoint Asset Management
This script shows how to use the FastAPI endpoints for asset management
"""

import requests
import json
from typing import Dict, Any

class AssetManagementAPI:
    """Client for the Asset Management API"""
    
    def __init__(self, base_url: str = "http://localhost:8000", token: str = None):
        self.base_url = base_url
        self.token = token
        self.headers = {
            "Content-Type": "application/json"
        }
        if token:
            self.headers["Authorization"] = f"Bearer {token}"
    
    def configure_sharepoint(self, config: Dict[str, str]) -> Dict[str, Any]:
        """Configure SharePoint connection"""
        response = requests.post(
            f"{self.base_url}/api/v1/assets/configure",
            json=config,
            headers=self.headers
        )
        return response.json()
    
    def test_connection(self) -> Dict[str, Any]:
        """Test SharePoint connection"""
        response = requests.post(
            f"{self.base_url}/api/v1/assets/test-connection",
            headers=self.headers
        )
        return response.json()
    
    def get_all_assets(self) -> list:
        """Get all assets"""
        response = requests.get(
            f"{self.base_url}/api/v1/assets/",
            headers=self.headers
        )
        return response.json()
    
    def get_asset_by_id(self, asset_id: str) -> Dict[str, Any]:
        """Get asset by business ID"""
        response = requests.get(
            f"{self.base_url}/api/v1/assets/asset-id/{asset_id}",
            headers=self.headers
        )
        return response.json()
    
    def create_asset(self, asset_data: Dict[str, Any]) -> Dict[str, Any]:
        """Create new asset"""
        response = requests.post(
            f"{self.base_url}/api/v1/assets/",
            json=asset_data,
            headers=self.headers
        )
        return response.json()
    
    def update_asset(self, sp_id: int, asset_data: Dict[str, Any]) -> Dict[str, Any]:
        """Update existing asset"""
        response = requests.put(
            f"{self.base_url}/api/v1/assets/sp-id/{sp_id}",
            json=asset_data,
            headers=self.headers
        )
        return response.json()
    
    def delete_asset(self, sp_id: int) -> Dict[str, Any]:
        """Delete asset"""
        response = requests.delete(
            f"{self.base_url}/api/v1/assets/sp-id/{sp_id}",
            headers=self.headers
        )
        return response.json()
    
    def search_assets(self, filters: Dict[str, str]) -> list:
        """Search assets with filters"""
        params = {k: v for k, v in filters.items() if v}
        response = requests.get(
            f"{self.base_url}/api/v1/assets/search",
            params=params,
            headers=self.headers
        )
        return response.json()
    
    def get_statistics(self) -> Dict[str, Any]:
        """Get asset statistics"""
        response = requests.get(
            f"{self.base_url}/api/v1/assets/statistics",
            headers=self.headers
        )
        return response.json()


def main():
    """Demonstrate API usage"""
    
    print("🚀 SharePoint Asset Management API Usage Example")
    print("=" * 55)
    
    # Initialize API client
    # Note: You'll need to authenticate first to get a token
    api = AssetManagementAPI(base_url="http://localhost:8000")
    
    print("📝 Example API Usage:")
    print()
    
    # 1. Configure SharePoint
    print("1️⃣ Configure SharePoint Connection:")
    sharepoint_config = {
        "site_url": "https://yourcompany.sharepoint.com/sites/yoursite",
        "list_name": "Assets",
        "client_id": "your-azure-app-client-id",
        "client_secret": "your-azure-app-client-secret",
        "tenant_id": "your-tenant-id"
    }
    print(f"   POST /api/v1/assets/configure")
    print(f"   Body: {json.dumps(sharepoint_config, indent=2)}")
    print()
    
    # 2. Test connection
    print("2️⃣ Test SharePoint Connection:")
    print(f"   POST /api/v1/assets/test-connection")
    print()
    
    # 3. Create asset
    print("3️⃣ Create New Asset:")
    asset_data = {
        "AssetID": "SRV-001",
        "AssetName": "Production Web Server",
        "Business": "IT",
        "Block": "Infrastructure",
        "Capability": "Web Services",
        "AssetType": "Hardware",
        "AssetStatus": "Active",
        "SizeAttributes": json.dumps({
            "cpu_cores": 16,
            "ram_gb": 64,
            "storage_tb": 4
        }),
        "Description": "Primary web server for company website",
        "Location": "Data Center A",
        "Owner": "IT Operations",
        "ContactPerson": "Jane Smith",
        "ContactEmail": "jane.smith@company.com",
        "Cost": 8500.0,
        "Currency": "USD",
        "Vendor": "HPE",
        "Model": "ProLiant DL380",
        "Version": "Gen10",
        "Tags": json.dumps(["server", "web", "production"]),
        "RiskLevel": "Medium",
        "Criticality": "High"
    }
    print(f"   POST /api/v1/assets/")
    print(f"   Body: {json.dumps(asset_data, indent=2)}")
    print()
    
    # 4. Get all assets
    print("4️⃣ Get All Assets:")
    print(f"   GET /api/v1/assets/")
    print()
    
    # 5. Get asset by ID
    print("5️⃣ Get Asset by Business ID:")
    print(f"   GET /api/v1/assets/asset-id/SRV-001")
    print()
    
    # 6. Update asset
    print("6️⃣ Update Asset (by SharePoint ID):")
    updated_asset = asset_data.copy()
    updated_asset["AssetStatus"] = "Maintenance"
    updated_asset["Description"] = "Web server under maintenance"
    print(f"   PUT /api/v1/assets/sp-id/123")
    print(f"   Body: {json.dumps(updated_asset, indent=2)}")
    print()
    
    # 7. Search assets
    print("7️⃣ Search Assets:")
    search_filters = {
        "business": "IT",
        "asset_type": "Hardware",
        "asset_status": "Active"
    }
    print(f"   GET /api/v1/assets/search?business=IT&asset_type=Hardware&asset_status=Active")
    print()
    
    # 8. Get statistics
    print("8️⃣ Get Asset Statistics:")
    print(f"   GET /api/v1/assets/statistics")
    print()
    
    # 9. Delete asset
    print("9️⃣ Delete Asset:")
    print(f"   DELETE /api/v1/assets/sp-id/123")
    print()
    
    print("🔐 Authentication Note:")
    print("   All endpoints require authentication. First login to get a bearer token:")
    print("   POST /api/v1/auth/login")
    print("   Then include: Authorization: Bearer <your-token>")
    print()
    
    print("📋 Next Steps:")
    print("   1. Set up your SharePoint list (see SHAREPOINT_ASSET_SETUP.md)")
    print("   2. Configure Azure AD app registration")
    print("   3. Start the FastAPI server: python main.py")
    print("   4. Use these endpoints to manage your assets!")
    print()
    
    print("🌐 API Documentation:")
    print("   Interactive docs: http://localhost:8000/docs")
    print("   OpenAPI spec: http://localhost:8000/openapi.json")


if __name__ == "__main__":
    main()

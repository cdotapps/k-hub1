import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, of } from 'rxjs';
import { map } from 'rxjs/operators';

// Newsletter Template Interface
export interface NewsletterTemplate {
  id: string;
  name: string;
  description: string;
  preview: string;
  htmlStructure: string;
  category: 'business' | 'marketing' | 'announcement' | 'update' | 'custom';
  isDefault?: boolean;
}

@Injectable({
  providedIn: 'root'
})
export class TemplateService {
  private templateCache = new Map<string, string>();
  
  // Newsletter Templates Collection
  private newsletterTemplates: NewsletterTemplate[] = [
    {
      id: 'newsletter-1',
      name: 'Modern Business',
      description: 'Clean and professional design for business newsletters',
      category: 'business',
      isDefault: true,
      preview: 'Modern layout with header, content sections, and footer',
      htmlStructure: '' // Will be loaded from external file
    },
    {
      id: 'newsletter-2',
      name: 'Marketing Vibrant',
      description: 'Eye-catching design perfect for marketing campaigns',
      category: 'marketing',
      preview: 'Colorful layout with call-to-action sections',
      htmlStructure: '' // Will be loaded from external file
    },
    {
      id: 'newsletter-3',
      name: 'Formal Announcement',
      description: 'Professional and formal design for important announcements',
      category: 'announcement',
      preview: 'Traditional layout with emphasis on content clarity',
      htmlStructure: '' // Will be loaded from external file
    }
  ];

  constructor(private http: HttpClient) {}

  /**
   * Load an HTML template and replace placeholders with provided data
   */
  loadTemplate(templateName: string, data: { [key: string]: any }): Observable<string> {
    const templatePath = `/assets/templates/${templateName}.template.html`;
    
    return this.http.get(templatePath, { responseType: 'text' }).pipe(
      map(template => this.replacePlaceholders(template, data))
    );
  }

  /**
   * Replace placeholders in template with actual data
   */
  private replacePlaceholders(template: string, data: { [key: string]: any }): string {
    let processedTemplate = template;

    // Replace simple placeholders like {{key}}
    Object.keys(data).forEach(key => {
      const placeholder = `{{${key}}}`;
      const value = data[key] || '';
      processedTemplate = processedTemplate.replace(new RegExp(placeholder, 'g'), value);
    });

    // Handle conditional blocks like {{#if key}}...{{/if}}
    processedTemplate = this.processConditionals(processedTemplate, data);

    // return processedTemplate;
    return processedTemplate;
  }

  /**
   * Process conditional blocks in templates
   */
  private processConditionals(template: string, data: { [key: string]: any }): string {
    // Handle {{#if key}}...{{/if}} blocks
    const ifPattern = /\{\{#if\s+(\w+)\}\}([\s\S]*?)\{\{\/if\}\}/g;
    
    return template.replace(ifPattern, (match, key, content) => {
      const value = data[key];
      // Return content if value exists and is truthy, otherwise return empty string
      return (value && value !== '') ? content : '';
    });
  }

  /**
   * Get a newsletter template by ID
   */
  getNewsletterTemplateById(templateId: string): Observable<NewsletterTemplate | undefined> {
    const template = this.newsletterTemplates.find(t => t.id === templateId);
    return of(template);
  }

  /**
   * Get default newsletter template
   */
  getDefaultNewsletterTemplate(): Observable<NewsletterTemplate | undefined> {
    const defaultTemplate = this.newsletterTemplates.find(t => t.isDefault);
    return of(defaultTemplate);
  }

  /**
   * Get all newsletter templates
   */
  getAllNewsletterTemplates(): Observable<NewsletterTemplate[]> {
    return of(this.newsletterTemplates);
  }

  /**
   * Get newsletter templates by category
   */
  getNewsletterTemplatesByCategory(category: string): Observable<NewsletterTemplate[]> {
    const templates = this.newsletterTemplates.filter(t => t.category === category);
    return of(templates);
  }

  /**
   * Apply newsletter template with form data
   */
  applyNewsletterTemplate(templateId: string, formData: any): Observable<string> {
    const template = this.newsletterTemplates.find(t => t.id === templateId);
    if (!template) {
      return of('');
    }

    const templateData = {
      title: formData.title || 'Newsletter Title',
      companyName: 'Company Newsletter',
      currentDate: new Date().toLocaleDateString(),
      author: formData.author || 'Newsletter Team',
      readingTime: this.calculateReadingTime(formData.content || ''),
      featuredImage: formData.image || '',
      introduction: formData.summary || '',
      content: formData.content || '<p>Newsletter content goes here...</p>',
      tags: this.formatTags(formData.tags || ''),
      catalogItems: formData.catalogItems || []
    };

    // Load template from external file and apply data
    return this.loadTemplate(templateId, templateData);
  }

  /**
   * Calculate reading time based on content
   */
  private calculateReadingTime(content: string): number {
    const wordsPerMinute = 200;
    const words = content.replace(/<[^>]*>/g, '').split(/\s+/).length;
    return Math.max(1, Math.ceil(words / wordsPerMinute));
  }

  /**
   * Format tags for display
   */
  private formatTags(tags: string): string {
    if (!tags) return '';
    return tags.split(',').map(tag => tag.trim()).filter(tag => tag).join(', ');
  }
}
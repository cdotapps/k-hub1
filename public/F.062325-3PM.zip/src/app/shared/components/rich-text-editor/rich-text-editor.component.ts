import { Component, Input, Output, EventEmitter, forwardRef, ViewChild, ElementRef } from '@angular/core';
import { ControlValueAccessor, NG_VALUE_ACCESSOR } from '@angular/forms';
import { 
  faBold, faItalic, faUnderline, faStrikethrough, faListUl, faListOl, 
  faLink, faHeading, faQuoteLeft, faCode, faUndo, faRedo,
  faAlignLeft, faAlignCenter, faAlignRight, faTable, faImage
} from '@fortawesome/free-solid-svg-icons';

@Component({
  selector: 'app-rich-text-editor',
  templateUrl: './rich-text-editor.component.html',
  styleUrls: ['./rich-text-editor.component.css'],
  providers: [
    {
      provide: NG_VALUE_ACCESSOR,
      useExisting: forwardRef(() => RichTextEditorComponent),
      multi: true
    }
  ]
})
export class RichTextEditorComponent implements ControlValueAccessor {
  @Input() placeholder: string = 'Enter your content here...';
  @Input() minHeight: string = '200px';
  @Input() disabled: boolean = false;
  @Output() contentChange = new EventEmitter<string>();
  @Output() wordCountChange = new EventEmitter<number>();

  @ViewChild('editor', { static: true }) editor!: ElementRef<HTMLDivElement>;

  // FontAwesome icons
  faBold = faBold;
  faItalic = faItalic;
  faUnderline = faUnderline;
  faStrikethrough = faStrikethrough;
  faListUl = faListUl;
  faListOl = faListOl;
  faLink = faLink;
  faHeading = faHeading;
  faQuoteLeft = faQuoteLeft;
  faCode = faCode;
  faUndo = faUndo;
  faRedo = faRedo;
  faAlignLeft = faAlignLeft;
  faAlignCenter = faAlignCenter;
  faAlignRight = faAlignRight;
  faTable = faTable;
  faImage = faImage;

  private content: string = '';
  private onChange = (value: string) => {};
  private onTouched = () => {};

  ngOnInit() {
    // Initialize editor content
    this.updateEditorContent();
  }

  // ControlValueAccessor implementation
  writeValue(value: string): void {
    this.content = value || '';
    this.updateEditorContent();
  }

  registerOnChange(fn: (value: string) => void): void {
    this.onChange = fn;
  }

  registerOnTouched(fn: () => void): void {
    this.onTouched = fn;
  }

  setDisabledState(isDisabled: boolean): void {
    this.disabled = isDisabled;
    if (this.editor) {
      this.editor.nativeElement.contentEditable = (!isDisabled).toString();
    }
  }

  private updateEditorContent(): void {
    if (this.editor && this.editor.nativeElement) {
      this.editor.nativeElement.innerHTML = this.content;
      this.updateWordCount();
    }
  }

  onContentChange(): void {
    if (this.editor) {
      this.content = this.editor.nativeElement.innerHTML;
      this.onChange(this.content);
      this.contentChange.emit(this.content);
      this.updateWordCount();
    }
  }

  onBlur(): void {
    this.onTouched();
  }

  private updateWordCount(): void {
    const text = this.getPlainText();
    const wordCount = text.trim() ? text.trim().split(/\s+/).length : 0;
    this.wordCountChange.emit(wordCount);
  }

  getPlainText(): string {
    if (this.editor) {
      return this.editor.nativeElement.textContent || '';
    }
    return '';
  }

  getWordCount(): number {
    const text = this.getPlainText();
    return text.trim() ? text.trim().split(/\s+/).length : 0;
  }

  // Toolbar actions
  execCommand(command: string, value?: string): void {
    document.execCommand(command, false, value);
    this.onContentChange();
    this.editor.nativeElement.focus();
  }

  insertHeading(level: number): void {
    this.execCommand('formatBlock', `h${level}`);
  }

  insertLink(): void {
    const url = prompt('Enter the URL:');
    if (url) {
      this.execCommand('createLink', url);
    }
  }

  insertList(ordered: boolean): void {
    this.execCommand(ordered ? 'insertOrderedList' : 'insertUnorderedList');
  }

  formatText(format: string): void {
    this.execCommand(format);
  }

  insertBlockquote(): void {
    this.execCommand('formatBlock', 'blockquote');
  }

  insertCodeBlock(): void {
    this.execCommand('formatBlock', 'pre');
  }

  setTextAlignment(alignment: string): void {
    this.execCommand('justify' + alignment.charAt(0).toUpperCase() + alignment.slice(1));
  }

  insertTable(): void {
    const rows = prompt('Number of rows:', '3');
    const cols = prompt('Number of columns:', '3');
    
    if (rows && cols) {
      const numRows = parseInt(rows);
      const numCols = parseInt(cols);
      
      let tableHTML = '<table border="1" style="border-collapse: collapse; width: 100%;">';
      
      for (let i = 0; i < numRows; i++) {
        tableHTML += '<tr>';
        for (let j = 0; j < numCols; j++) {
          tableHTML += `<td style="padding: 8px; border: 1px solid #ddd;">${i === 0 ? `Header ${j + 1}` : `Cell ${i},${j + 1}`}</td>`;
        }
        tableHTML += '</tr>';
      }
      
      tableHTML += '</table>';
      this.execCommand('insertHTML', tableHTML);
    }
  }

  insertImage(): void {
    const url = prompt('Enter image URL:');
    const alt = prompt('Enter alt text:');
    
    if (url) {
      const imgHTML = `<img src="${url}" alt="${alt || 'Image'}" style="max-width: 100%; height: auto;">`;
      this.execCommand('insertHTML', imgHTML);
    }
  }

  undo(): void {
    this.execCommand('undo');
  }

  redo(): void {
    this.execCommand('redo');
  }
}
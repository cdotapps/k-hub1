import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { RouterModule } from '@angular/router';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';

// Chart.js imports
import { NgChartsModule } from 'ng2-charts';

// Font Awesome imports
import { FontAwesomeModule } from '@fortawesome/angular-fontawesome';
import { FaIconLibrary } from '@fortawesome/angular-fontawesome';
import { fas } from '@fortawesome/free-solid-svg-icons';
import { far } from '@fortawesome/free-regular-svg-icons';
import { fab } from '@fortawesome/free-brands-svg-icons';

import { AppComponent } from './app.component';
import { HomeComponent } from './home/home.component';
import { AdminHomeComponent } from './admin/home/home.component';
import { LoginComponent } from './auth/login/login.component';
import { RegisterComponent } from './auth/register/register.component';
import { SharedModule } from './shared/shared.module';
import { UserModule } from './user/user.module';
import { AuthGuard, AdminGuard, UserGuard, RoleRedirectGuard, NoAuthGuard } from './shared/guards/auth.guard';
import { AuthInterceptor } from './shared/interceptors/auth.interceptor';
import { ProfileComponent } from './profile/profile.component';
import { DashboardComponent } from './admin/dashboard/dashboard.component';
import { UserHomeComponent } from './user/home/home.component';
import { DashboardComponent as UserDashboardComponent } from './user/dashboard/dashboard.component';
import { CatalogComponent } from './user/catalog/catalog.component';
import { CatalogDetailComponent } from './user/catalog/catalog-detail.component';
import { CreateArticleComponent } from './user/catalog/create-article.component';
import { EditArticleComponent } from './user/catalog/edit-article.component';
import { CreateNewsletterComponent } from './user/catalog/create-newsletter.component';

@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    AdminHomeComponent,
    LoginComponent,
    RegisterComponent,
    ProfileComponent,
    DashboardComponent,
    CatalogComponent,
    CatalogDetailComponent,
    CreateArticleComponent,
    EditArticleComponent,
    CreateNewsletterComponent
  ],
  imports: [
    BrowserModule,
    BrowserAnimationsModule,
    ReactiveFormsModule,
    FormsModule,
    HttpClientModule,
    SharedModule,
    UserModule,
    FontAwesomeModule,
    NgChartsModule,
    RouterModule.forRoot([
      // Default route - role-based home redirection
      { path: '', component: HomeComponent },
      
      // Role-specific home pages
      { path: 'admin/home', component: AdminHomeComponent, canActivate: [AdminGuard] },
      { path: 'user/home', component: UserHomeComponent, canActivate: [UserGuard] },
      
      // User routes - accessible by all authenticated users
      { path: 'dashboard', component: UserDashboardComponent, canActivate: [UserGuard] },
      { path: 'user/dashboard', component: UserDashboardComponent, canActivate: [UserGuard] },
      { path: 'catalog', component: CatalogComponent, canActivate: [UserGuard] },
      { path: 'user/catalog', component: CatalogComponent, canActivate: [UserGuard] },
      { path: 'user/catalog/create', component: CreateArticleComponent, canActivate: [UserGuard] },
      { path: 'user/catalog/create-article', component: CreateArticleComponent, canActivate: [UserGuard] },
      { path: 'user/catalog/create-newsletter', component: CreateNewsletterComponent, canActivate: [UserGuard] },
      { path: 'user/catalog/edit/:id', component: EditArticleComponent, canActivate: [UserGuard] },
      { path: 'user/catalog/:id', component: CatalogDetailComponent, canActivate: [UserGuard] },
      { path: 'profile', component: ProfileComponent, canActivate: [UserGuard] },
      
      // Admin routes - accessible only by admin users
      { path: 'admin/dashboard', component: DashboardComponent, canActivate: [AdminGuard] },
      
      // Auth routes - accessible only by unauthenticated users
      { path: 'auth/login', component: LoginComponent, canActivate: [NoAuthGuard] },
      { path: 'auth/register', component: RegisterComponent, canActivate: [NoAuthGuard] },
      { path: 'login', redirectTo: 'auth/login', pathMatch: 'full' },
      { path: 'register', redirectTo: 'auth/register', pathMatch: 'full' },
      
      // Fallback route - role-based home redirection
      { path: '**', component: HomeComponent }
    ])
  ],
  providers: [
    {
      provide: HTTP_INTERCEPTORS,
      useClass: AuthInterceptor,
      multi: true
    }
  ],
  bootstrap: [AppComponent]
})
export class AppModule {
  constructor(library: FaIconLibrary) {
    // Add icon packs to the library
    library.addIconPacks(fas, far, fab);
  }
}
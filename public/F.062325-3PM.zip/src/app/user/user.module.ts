import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

// Import SharedModule to get access to all shared components
import { SharedModule } from '../shared/shared.module';

// User Components
import { UserHomeComponent } from './home/home.component';
import { DashboardComponent } from './dashboard/dashboard.component';

@NgModule({
  declarations: [
    UserHomeComponent,
    DashboardComponent
  ],
  imports: [
    CommonModule,
    RouterModule,
    FormsModule,
    ReactiveFormsModule,
    SharedModule  // This provides access to app-container, app-card, app-icon, etc.
  ],
  exports: [
    UserHomeComponent,
    DashboardComponent
  ]
})
export class UserModule { }
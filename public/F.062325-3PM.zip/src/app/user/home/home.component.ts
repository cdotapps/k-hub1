import { Component, OnInit, OnDestroy } from '@angular/core';
import { Router } from '@angular/router';
import { 
  faChartLine, faFolder, faFileAlt, faLightbulb, faHandshake, faRocket, 
  faUser, faCog, faBookmark, faHeart, faCheck, faTimes, faUserCog, 
  faExclamationTriangle, faArrowTrendUp, faArrowTrendDown, faPlus, faSearch,
  faBell, faChartPie, faCalendarAlt, faArrowUp, faArrowDown, faEye,
  faThumbsUp, faShare, faDownload, faEdit, faStar, faChevronDown, faUsers
} from '@fortawesome/free-solid-svg-icons';
import { CatalogService } from '../../shared/services/catalog.service';
import { UserService } from '../../shared/services/user.service';
import { AuthService } from '../../shared/services/auth.service';
import { User } from '../../shared/models/user.interface';
import { OverlapButtonConfig } from '../../shared/components/overlap-button/overlap-button.component';
import { HOME_NAVIGATION_BUTTONS } from '../../shared/config/site-config';
import { Subscription } from 'rxjs';
import { forkJoin } from 'rxjs';

// Mock data interfaces
interface PendingApproval {
  id: string;
  title: string;
  type: 'project' | 'document' | 'policy';
  submittedBy: string;
  submittedDate: string;
  priority: 'high' | 'medium' | 'low';
  status: 'pending' | 'approved' | 'rejected';
}

interface Alert {
  id: string;
  message: string;
  type: 'warning' | 'info' | 'error';
  timestamp: string;
}

interface ActivityItem {
  id: string;
  title: string;
  type: 'created' | 'updated' | 'approved' | 'shared';
  timestamp: string;
  user: string;
}

interface Recommendation {
  id: string;
  title: string;
  type: 'article' | 'tool' | 'resource';
  description: string;
  url: string;
}

interface BookmarkedItem {
  id: string;
  title: string;
  type: 'project' | 'document';
  bookmarkedDate: string;
}

@Component({
  selector: 'app-user-home',
  template: `
    <div class="home-container">
      <section class="hero-section">
        <app-container>
          <div class="hero-content">
            <h1 class="hero-title">Welcome to FST-Hub</h1>
            <p class="hero-subtitle">Your personal workspace for innovation, collaboration, and professional growth</p>
            <app-button variant="primary" size="lg" (click)="navigateTo('dashboard')">Go to Dashboard</app-button>
          </div>
        </app-container>
      </section>
      
      <!-- Overlapping Navigation -->
      <app-overlap-navigation 
        [buttons]="navigationButtons" 
        (navigate)="navigateTo($event)">
      </app-overlap-navigation>

      <!-- Dashboard Section -->
      <section class="dashboard-section">
        <app-container>
          <div class="dashboard-grid">
            <!-- Left Column - Recent Activity (35%) -->
            <div class="dashboard-left">
              <!-- Recent Activity -->
              <app-card title="Recent Activity" [icon]="faCalendarAlt" variant="elevated">
                <div class="activity-feed">
                  <div class="activity-item" *ngFor="let item of recentActivity">
                    <div class="activity-icon" [class]="'activity-' + item.type">
                      <app-icon [faIcon]="getActivityIcon(item.type)" size="sm"></app-icon>
                    </div>
                    <div class="activity-content">
                      <div class="activity-title">{{ item.title }}</div>
                      <div class="activity-meta">
                        <span class="activity-user">{{ item.user }}</span>
                        <span class="activity-time">{{ item.timestamp }}</span>
                      </div>
                    </div>
                  </div>
                </div>
              </app-card>
            </div>

            <!-- Middle Column - Priority Actions, Summary & Charts (40%) -->
            <div class="dashboard-middle">
              <!-- Priority Actions Card -->
              <app-card title="Priority Actions" [icon]="faExclamationTriangle" variant="elevated">
                <div class="priority-actions">
                  <div class="expandable-section">
                    <button 
                      class="expand-toggle" 
                      (click)="togglePendingApprovals()"
                      [class.expanded]="showPendingApprovals">
                      <app-icon [faIcon]="faChevronDown" size="sm"></app-icon>
                      Pending Approvals ({{ pendingApprovals.length }})
                    </button>
                    <div class="expandable-content" *ngIf="showPendingApprovals">
                      <div class="approval-item" *ngFor="let approval of pendingApprovals">
                        <div class="approval-header">
                          <span class="approval-title">{{ approval.title }}</span>
                          <span class="priority-badge" [class]="'priority-' + approval.priority">
                            {{ approval.priority }}
                          </span>
                        </div>
                        <div class="approval-meta">
                          <span class="approval-submitter">{{ approval.submittedBy }}</span>
                          <span class="approval-date">{{ approval.submittedDate }}</span>
                        </div>
                        <div class="approval-actions">
                          <button class="action-btn approve" (click)="handleApproval(approval.id, 'approve')">
                            <app-icon [faIcon]="faCheck" size="sm"></app-icon>
                            Approve
                          </button>
                          <button class="action-btn reject" (click)="handleApproval(approval.id, 'reject')">
                            <app-icon [faIcon]="faTimes" size="sm"></app-icon>
                            Reject
                          </button>
                          <button class="action-btn delegate" (click)="handleApproval(approval.id, 'delegate')">
                            <app-icon [faIcon]="faUserCog" size="sm"></app-icon>
                            Delegate
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </app-card>

              <!-- Summary Statistics -->
              <div class="stats-grid">
                <div class="stat-card">
                  <div class="stat-icon">
                    <app-icon [faIcon]="faPlus" size="lg" variant="primary"></app-icon>
                  </div>
                  <div class="stat-content">
                    <div class="stat-number">{{ newItemsCount }}</div>
                    <div class="stat-label">New Items (7d)</div>
                    <div class="stat-trend" [class.positive]="newItemsTrend > 0" [class.negative]="newItemsTrend < 0">
                      <app-icon [faIcon]="newItemsTrend > 0 ? faArrowTrendUp : faArrowTrendDown" size="sm"></app-icon>
                      {{ getAbsoluteValue(newItemsTrend) }}%
                    </div>
                  </div>
                </div>

                <div class="stat-card">
                  <div class="stat-icon">
                    <app-icon [faIcon]="faEye" size="lg" variant="warning"></app-icon>
                  </div>
                  <div class="stat-content">
                    <div class="stat-number">{{ unreadPriorityCount }}</div>
                    <div class="stat-label">Unread Priority</div>
                    <div class="stat-badge" *ngIf="unreadPriorityCount > 0">{{ unreadPriorityCount }}</div>
                  </div>
                </div>

                <div class="stat-card">
                  <div class="stat-icon">
                    <app-icon [faIcon]="faCheck" size="lg" variant="success"></app-icon>
                  </div>
                  <div class="stat-content">
                    <div class="stat-number">{{ completedActionsCount }}</div>
                    <div class="stat-label">Completed Actions</div>
                    <div class="stat-progress">
                      <div class="progress-bar">
                        <div class="progress-fill" [style.width.%]="completedActionsProgress"></div>
                      </div>
                      <span class="progress-text">{{ completedActionsProgress }}% monthly</span>
                    </div>
                  </div>
                </div>
              </div>

              <!-- Chart Section -->
              <app-card title="Content Distribution" [icon]="faChartPie" variant="elevated">
                <div class="chart-container">
                  <canvas #chartCanvas id="contentChart"></canvas>
                </div>
              </app-card>
            </div>

            <!-- Right Column - Quick Actions & Recommendations (25%) -->
            <div class="dashboard-right">
              <!-- Quick Tools at top -->
              <app-card title="Quick Actions" [icon]="faCog" variant="elevated">
                <div class="quick-tools">
                  <div class="search-tool">
                    <input 
                      type="text" 
                      placeholder="Search catalog..." 
                      class="search-input"
                      [(ngModel)]="searchQuery"
                      (keyup.enter)="performSearch()">
                    <button class="search-btn" (click)="performSearch()">
                      <app-icon [faIcon]="faSearch" size="sm"></app-icon>
                    </button>
                  </div>

                  <div class="create-tool">
                    <button class="create-btn" (click)="toggleCreateDropdown()">
                      <app-icon [faIcon]="faPlus" size="sm"></app-icon>
                      Create New
                    </button>
                    <div class="create-dropdown" *ngIf="showCreateDropdown">
                      <button (click)="createNew('project')">New Project</button>
                      <button (click)="createNew('document')">New Document</button>
                      <button (click)="createNew('policy')">New Policy</button>
                    </div>
                  </div>
                </div>
              </app-card>

              <!-- Recommendations -->
              <app-card title="Recommendations" [icon]="faLightbulb" variant="elevated">
                <div class="recommendations-list">
                  <div class="recommendation-item" *ngFor="let rec of recommendations">
                    <h4 class="recommendation-title">
                      <a [href]="rec.url" target="_blank">{{ rec.title }}</a>
                    </h4>
                    <p class="recommendation-description">{{ rec.description }}</p>
                  </div>
                </div>
              </app-card>
            </div>
          </div>
        </app-container>
      </section>
    </div>
  `,
  styles: [`
    .home-container {
      width: 100%;
      position: relative;
    }
    
    .hero-section {
      background: linear-gradient(135deg, var(--fm-primary-hero) 0%, var(--fm-secondary-hero) 100%);
      color: var(--fm-white);
      padding: 3rem 0;
      text-align: center;
      min-height: 350px;
      display: flex;
      align-items: center;
      justify-content: center;
      position: relative;
      z-index: 1;
    }
    
    .hero-content {
      max-width: 500px;
      margin: 0 auto;
    }
    
    .hero-title {
      font-size: 3rem;
      font-weight: 700;
      margin-bottom: 1rem;
      line-height: 1.2;
      color: var(--fm-white);
    }
    
    .hero-subtitle {
      font-size: 1.25rem;
      margin-bottom: 2rem;
      opacity: 0.85;
      line-height: 1.5;
      color: var(--fm-white);
    }
    
    /* Dashboard Section */
    .dashboard-section {
      padding: 1rem 0;
      background: var(--fm-gray-lighter);
    }
    
    .dashboard-grid {
      display: grid;
      grid-template-columns: 30% 37% 30%;
      gap: 1.5rem;
      margin-top: 2rem;
      max-width: 100%;
    }
    
    .dashboard-left, .dashboard-middle, .dashboard-right {
      display: flex;
      flex-direction: column;
      gap: 1.5rem;
      min-width: 0; /* Prevents flex children from overflowing */
    }
    
    /* Priority Actions */
    .priority-actions {
      padding: 0;
    }
    
    .expand-toggle {
      display: flex;
      align-items: center;
      gap: 0.5rem;
      width: 100%;
      padding: 0.75rem;
      background: var(--fm-light-blue);
      border: none;
      border-radius: 6px;
      font-weight: 600;
      color: var(--fm-primary-blue);
      cursor: pointer;
      transition: all 0.3s ease;
      font-size: 0.875rem;
    }
    
    .expand-toggle:hover {
      background: var(--fm-secondary-blue);
      color: var(--fm-white);
    }
    
    .expandable-content {
      margin-top: 1rem;
    }
    
    .approval-item {
      background: var(--fm-white);
      border: 1px solid #e9ecef;
      border-radius: 8px;
      padding: 0.875rem;
      margin-bottom: 0.75rem;
      transition: all 0.3s ease;
      overflow: hidden;
    }
    
    .approval-item:hover {
      box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
    }
    
    .approval-header {
      display: flex;
      justify-content: space-between;
      align-items: flex-start;
      margin-bottom: 0.5rem;
      gap: 0.5rem;
    }
    
    .approval-title {
      font-weight: 600;
      color: var(--fm-text-primary);
      font-size: 0.875rem;
      line-height: 1.3;
      flex: 1;
    }
    
    .approval-meta {
      display: flex;
      gap: 1rem;
      margin-bottom: 1rem;
      font-size: 0.875rem;
      color: var(--fm-text-secondary);
    }
    
    .approval-actions {
      display: flex;
      gap: 0.375rem;
      flex-wrap: wrap;
    }
    
    .action-btn {
      display: flex;
      align-items: center;
      gap: 0.25rem;
      padding: 0.4rem 0.6rem;
      border: none;
      border-radius: 6px;
      font-size: 0.75rem;
      font-weight: 600;
      cursor: pointer;
      transition: all 0.3s ease;
      flex: 1;
      min-width: fit-content;
      justify-content: center;
    }
    
    .action-btn.approve {
      background: var(--fm-green);
      color: var(--fm-white);
    }
    
    .action-btn.reject {
      background: var(--fm-red);
      color: var(--fm-white);
    }
    
    .action-btn.delegate {
      background: var(--fm-orange);
      color: var(--fm-white);
    }
    
    .action-btn:hover {
      opacity: 0.9;
      transform: translateY(-1px);
    }
    
    /* Statistics Cards */
    .stats-grid {
      display: grid;
      grid-template-columns: repeat(3, 1fr);
      gap: 0.875rem;
      margin-bottom: 1.5rem;
    }
    
    .stat-card {
      background: var(--fm-white);
      border-radius: 8px;
      padding: 1.25rem;
      box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
      display: flex;
      align-items: center;
      gap: 0.875rem;
      min-width: 0;
    }
    
    .stat-icon {
      flex-shrink: 0;
    }
    
    .stat-content {
      flex: 1;
      min-width: 0;
    }
    
    .stat-number {
      font-size: 1.75rem;
      font-weight: 700;
      color: var(--fm-text-primary);
      line-height: 1;
    }
    
    .stat-label {
      font-size: 0.8rem;
      color: var(--fm-text-secondary);
      margin-bottom: 0.5rem;
    }
    
    .stat-trend {
      display: flex;
      align-items: center;
      gap: 0.25rem;
      font-size: 0.875rem;
      font-weight: 600;
    }
    
    .stat-trend.positive {
      color: var(--fm-green);
    }
    
    .stat-trend.negative {
      color: var(--fm-red);
    }
    
    .stat-badge {
      background: var(--fm-red);
      color: var(--fm-white);
      padding: 0.25rem 0.5rem;
      border-radius: 12px;
      font-size: 0.75rem;
      font-weight: 600;
    }
    
    .stat-progress {
      margin-top: 0.5rem;
    }
    
    .progress-bar {
      height: 4px;
      background: #e9ecef;
      border-radius: 2px;
      overflow: hidden;
      margin-bottom: 0.25rem;
    }
    
    .progress-fill {
      height: 100%;
      background: var(--fm-green);
      transition: width 0.3s ease;
    }
    
    .progress-text {
      font-size: 0.75rem;
      color: var(--fm-text-secondary);
    }
    
    /* Chart Container */
    .chart-container {
      height: 220px;
      position: relative;
    }
    
    /* Activity Feed */
    .activity-feed {
      display: flex;
      flex-direction: column;
      gap: 0.875rem;
      max-height: 400px;
      overflow-y: auto;
    }
    
    .activity-item {
      display: flex;
      align-items: center;
      gap: 0.875rem;
      padding: 0.75rem;
      background: var(--fm-white);
      border: 1px solid #e9ecef;
      border-radius: 8px;
    }
    
    .activity-icon {
      width: 36px;
      height: 36px;
      border-radius: 50%;
      display: flex;
      align-items: center;
      justify-content: center;
      flex-shrink: 0;
    }
    
    .activity-created {
      background: var(--fm-green);
      color: var(--fm-white);
    }
    
    .activity-updated {
      background: var(--fm-orange);
      color: var(--fm-white);
    }
    
    .activity-approved {
      background: var(--fm-secondary-blue);
      color: var(--fm-white);
    }
    
    .activity-shared {
      background: var(--fm-primary-blue);
      color: var(--fm-white);
    }
    
    .activity-content {
      flex: 1;
      min-width: 0;
    }
    
    .activity-title {
      font-weight: 600;
      color: var(--fm-text-primary);
      margin-bottom: 0.25rem;
      font-size: 0.875rem;
      line-height: 1.3;
    }
    
    .activity-meta {
      display: flex;
      gap: 0.75rem;
      font-size: 0.8rem;
      color: var(--fm-text-secondary);
    }
    
    /* Recommendations */
    .recommendations-list {
      margin-bottom: 1.25rem;
    }
    
    .recommendation-item {
      margin-bottom: 0.875rem;
      padding-bottom: 0.875rem;
      border-bottom: 1px solid #e9ecef;
    }
    
    .recommendation-item:last-child {
      border-bottom: none;
      margin-bottom: 0;
      padding-bottom: 0;
    }
    
    .recommendation-title {
      margin-bottom: 0.4rem;
      font-size: 0.875rem;
    }
    
    .recommendation-title a {
      color: var(--fm-secondary-blue);
      text-decoration: none;
      font-weight: 600;
      line-height: 1.3;
    }
    
    .recommendation-title a:hover {
      color: var(--fm-primary-blue);
      text-decoration: underline;
    }
    
    .recommendation-description {
      font-size: 0.8rem;
      color: var(--fm-text-secondary);
      margin: 0;
      line-height: 1.4;
    }
    
    .quick-wins {
      border-top: 1px solid #e9ecef;
      padding-top: 1rem;
    }
    
    .quick-wins h4 {
      margin-bottom: 0.875rem;
      color: var(--fm-text-primary);
      font-size: 0.875rem;
    }
    
    .quick-win-item {
      display: flex;
      align-items: center;
      gap: 0.625rem;
      padding: 0.5rem;
      border-radius: 6px;
      margin-bottom: 0.5rem;
      transition: background 0.3s ease;
      font-size: 0.8rem;
    }
    
    /* Quick Tools */
    .quick-tools {
      display: flex;
      flex-direction: column;
      gap: 0.875rem;
    }
    
    .search-tool {
      display: flex;
      gap: 0.4rem;
    }
    
    .search-input {
      flex: 1;
      padding: 0.625rem;
      border: 1px solid #e9ecef;
      border-radius: 6px;
      font-size: 0.8rem;
    }
    
    .search-btn {
      padding: 0.625rem 0.875rem;
      background: var(--fm-primary-blue);
      color: var(--fm-white);
      border: none;
      border-radius: 6px;
      cursor: pointer;
      transition: background 0.3s ease;
    }
    
    .create-tool {
      position: relative;
    }
    
    .create-btn {
      display: flex;
      align-items: center;
      gap: 0.4rem;
      width: 100%;
      padding: 0.625rem 0.875rem;
      background: var(--fm-green);
      color: var(--fm-white);
      border: none;
      border-radius: 6px;
      font-weight: 600;
      cursor: pointer;
      transition: background 0.3s ease;
      font-size: 0.8rem;
    }
    
    .create-btn:hover {
      background: #218838;
    }
    
    .create-dropdown {
      position: absolute;
      top: 100%;
      left: 0;
      right: 0;
      background: var(--fm-white);
      border: 1px solid #e9ecef;
      border-radius: 6px;
      box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
      z-index: 10;
    }
    
    .create-dropdown button {
      display: block;
      width: 100%;
      padding: 0.75rem 1rem;
      background: none;
      border: none;
      text-align: left;
      cursor: pointer;
      transition: background 0.3s ease;
    }
    
    .create-dropdown button:hover {
      background: var(--fm-light-blue);
    }
    
    /* Responsive Design */
    @media (max-width: 1400px) {
      .dashboard-grid {
        gap: 1rem;
      }
      
      .stat-card {
        padding: 1rem;
      }
      
      .stat-number {
        font-size: 1.5rem;
      }
    }
    
    @media (max-width: 1200px) {
      .dashboard-grid {
        grid-template-columns: 1fr;
        gap: 1.25rem;
      }
      
      .stats-grid {
        grid-template-columns: repeat(3, 1fr);
      }
    }
    
    @media (max-width: 768px) {
      .dashboard-section {
        padding: 2rem 0;
      }
      
      .stats-grid {
        grid-template-columns: 1fr;
      }
      
      .stat-card {
        padding: 1rem;
      }
      
      .stat-number {
        font-size: 1.5rem;
      }
      
      .chart-container {
        height: 200px;
      }
      
      .activity-feed {
        max-height: 300px;
      }
    }
  `]
})
export class UserHomeComponent implements OnInit, OnDestroy {
  // Font Awesome icons
  faChartLine = faChartLine;
  faFolder = faFolder;
  faFileAlt = faFileAlt;
  faLightbulb = faLightbulb;
  faHandshake = faHandshake;
  faRocket = faRocket;
  faUser = faUser;
  faCog = faCog;
  faBookmark = faBookmark;
  faHeart = faHeart;
  faCheck = faCheck;
  faTimes = faTimes;
  faUserCog = faUserCog;
  faExclamationTriangle = faExclamationTriangle;
  faArrowTrendUp = faArrowTrendUp;
  faArrowTrendDown = faArrowTrendDown;
  faPlus = faPlus;
  faSearch = faSearch;
  faBell = faBell;
  faChartPie = faChartPie;
  faCalendarAlt = faCalendarAlt;
  faArrowUp = faArrowUp;
  faArrowDown = faArrowDown;
  faEye = faEye;
  faThumbsUp = faThumbsUp;
  faShare = faShare;
  faDownload = faDownload;
  faEdit = faEdit;
  faStar = faStar;
  faChevronDown = faChevronDown;
  faUsers = faUsers;

  // Navigation buttons configuration
  navigationButtons: OverlapButtonConfig[] = [];

  // Badge counts from API
  dashboardCount = 0;
  weeklyWinsCount = 0;
  approvalsCount = 0;
  teamCount = 0;
  catalogCount = 0;
  reportsCount = 0;
  
  // Legacy counts for activity section
  projectsCount = 0;
  resourcesCount = 0;
  bookmarksCount = 0;
  myProjectsCount = 0;
  favoritesCount = 0;
  
  private subscription = new Subscription();

  // New properties for dashboard
  showPendingApprovals = false;
  showCreateDropdown = false;
  searchQuery = '';
  
  // Statistics
  newItemsCount = 12;
  newItemsTrend = 15;
  unreadPriorityCount = 5;
  completedActionsCount = 28;
  completedActionsProgress = 75;
  
  // Mock data
  pendingApprovals: PendingApproval[] = [
    {
      id: '1',
      title: 'New FinTech Partnership Proposal',
      type: 'project',
      submittedBy: 'Sarah Johnson',
      submittedDate: '2 hours ago',
      priority: 'high',
      status: 'pending'
    },
    {
      id: '2',
      title: 'Updated Security Policy Document',
      type: 'document',
      submittedBy: 'Michael Chen',
      submittedDate: '1 day ago',
      priority: 'medium',
      status: 'pending'
    },
    {
      id: '3',
      title: 'Compliance Framework Update',
      type: 'policy',
      submittedBy: 'Emma Davis',
      submittedDate: '2 days ago',
      priority: 'low',
      status: 'pending'
    }
  ];
  
  recentActivity: ActivityItem[] = [
    {
      id: '1',
      title: 'Created new project "AI Risk Assessment"',
      type: 'created',
      timestamp: '5 minutes ago',
      user: 'You'
    },
    {
      id: '2',
      title: 'Updated "Blockchain Integration Guide"',
      type: 'updated',
      timestamp: '1 hour ago',
      user: 'Alex Rodriguez'
    },
    {
      id: '3',
      title: 'Approved "Payment Processing Standards"',
      type: 'approved',
      timestamp: '2 hours ago',
      user: 'Sarah Johnson'
    },
    {
      id: '4',
      title: 'Shared "Market Analysis Report"',
      type: 'shared',
      timestamp: '3 hours ago',
      user: 'Michael Chen'
    },
    {
      id: '5',
      title: 'Created "Compliance Checklist"',
      type: 'created',
      timestamp: '4 hours ago',
      user: 'Emma Davis'
    }
  ];
  
  recommendations: Recommendation[] = [
    {
      id: '1',
      title: 'Best Practices for API Security',
      type: 'article',
      description: 'Essential security measures for financial APIs',
      url: '#'
    },
    {
      id: '2',
      title: 'Digital Transformation Roadmap',
      type: 'resource',
      description: 'Step-by-step guide for fintech innovation',
      url: '#'
    },
    {
      id: '3',
      title: 'Regulatory Compliance Updates',
      type: 'article',
      description: 'Latest changes in financial regulations',
      url: '#'
    }
  ];
  
  quickWins = [
    { title: 'Review pending documents', icon: faFileAlt },
    { title: 'Update team status', icon: faUsers },
    { title: 'Check system alerts', icon: faBell },
    { title: 'Schedule team meeting', icon: faCalendarAlt }
  ];
  
  bookmarkedItems: BookmarkedItem[] = [
    {
      id: '1',
      title: 'FinTech Innovation Framework',
      type: 'project',
      bookmarkedDate: '2 days ago'
    },
    {
      id: '2',
      title: 'API Documentation Standards',
      type: 'document',
      bookmarkedDate: '1 week ago'
    },
    {
      id: '3',
      title: 'Risk Management Protocol',
      type: 'document',
      bookmarkedDate: '2 weeks ago'
    }
  ];

  constructor(
    private router: Router,
    private catalogService: CatalogService,
    private userService: UserService,
    private authService: AuthService
  ) { }

  ngOnInit(): void {
    this.setupNavigationButtons();
    this.loadUserCounts();
    this.initializeChart();
  }

  ngOnDestroy(): void {
    this.subscription.unsubscribe();
  }

  /**
   * Setup navigation buttons configuration
   */
  private setupNavigationButtons(): void {
    this.navigationButtons = HOME_NAVIGATION_BUTTONS.map(buttonConfig => ({
      ...buttonConfig,
      badgeCount: this.getBadgeCountForRoute(buttonConfig.route)
    }));
  }

  /**
   * Get badge count for a specific route
   */
  private getBadgeCountForRoute(route: string): number {
    switch(route) {
      case 'dashboard':
        return this.dashboardCount;
      case 'weekly-wins':
        return this.weeklyWinsCount;
      case 'approvals':
        return this.approvalsCount;
      case 'team':
        return this.teamCount;
      case 'catalog':
        return this.catalogCount;
      case 'reports':
        return this.reportsCount;
      default:
        return 0;
    }
  }

  /**
   * Update navigation buttons with latest counts
   */
  private updateNavigationButtons(): void {
    this.navigationButtons.forEach(button => {
      button.badgeCount = this.getBadgeCountForRoute(button.route || '');
    });
  }

  /**
   * Load user dashboard counts from API
   */
  private loadUserCounts(): void {
    this.subscription.add(
      forkJoin({
        projects: this.catalogService.getCatalogItems({ type: 'project', limit: 1 }),
        resources: this.catalogService.getCatalogItems({ type: 'document', limit: 1 })
      }).subscribe({
        next: (results) => {
          this.projectsCount = results.projects.total || 0;
          this.resourcesCount = results.resources.total || 0;
          this.catalogCount = this.projectsCount + this.resourcesCount;
          
          // Set navigation badge counts
          this.dashboardCount = this.calculateUserDashboardItems();
          this.weeklyWinsCount = this.calculateWeeklyWinsCount();
          this.approvalsCount = this.calculateApprovalsCount();
          this.teamCount = this.calculateTeamCount();
          this.reportsCount = this.calculateReportsCount();
          
          // Set activity section counts
          this.bookmarksCount = this.calculateBookmarksCount();
          this.myProjectsCount = this.calculateMyProjectsCount();
          this.favoritesCount = this.calculateFavoritesCount();
          
          // Update navigation buttons with new counts
          this.updateNavigationButtons();
        },
        error: (error) => {
          console.error('Failed to load user counts:', error);
          // Set fallback values
          this.dashboardCount = 0;
          this.weeklyWinsCount = 0;
          this.approvalsCount = 0;
          this.teamCount = 0;
          this.catalogCount = 0;
          this.reportsCount = 0;
          this.projectsCount = 0;
          this.resourcesCount = 0;
          this.bookmarksCount = 0;
          this.myProjectsCount = 0;
          this.favoritesCount = 0;
          
          // Update navigation buttons with fallback counts
          this.updateNavigationButtons();
        }
      })
    );
  }

  /**
   * Calculate weekly wins count
   */
  private calculateWeeklyWinsCount(): number {
    // Placeholder - would come from weekly wins API
    return Math.floor(Math.random() * 5);
  }

  /**
   * Calculate pending approvals count
   */
  private calculateApprovalsCount(): number {
    // Placeholder - would come from approvals API
    return Math.floor(Math.random() * 3);
  }

  /**
   * Calculate team members count
   */
  private calculateTeamCount(): number {
    // Placeholder - would come from team API
    return Math.floor(Math.random() * 12) + 5;
  }

  /**
   * Calculate reports count
   */
  private calculateReportsCount(): number {
    // Placeholder - would come from reports API
    return Math.floor(Math.random() * 8);
  }

  /**
   * Calculate user dashboard items count
   */
  private calculateUserDashboardItems(): number {
    // User dashboard could show notifications, updates, etc.
    return Math.min(this.myProjectsCount + this.bookmarksCount, 99);
  }

  /**
   * Calculate bookmarks count
   */
  private calculateBookmarksCount(): number {
    // Placeholder - would come from user's bookmarks API
    return Math.floor(Math.random() * 10);
  }

  /**
   * Calculate user's projects count
   */
  private calculateMyProjectsCount(): number {
    // Placeholder - would come from user's projects API
    return Math.floor(Math.random() * 5);
  }

  /**
   * Calculate favorites count
   */
  private calculateFavoritesCount(): number {
    // Placeholder - would come from user's favorites API
    return Math.floor(Math.random() * 8);
  }

  /**
   * Get account age in days
   */
  getAccountAge(): number {
    const user = this.authService.getCurrentUserValue();
    if (user?.created_date) {
      const createdDate = new Date(user.created_date);
      const now = new Date();
      const diffTime = Math.abs(now.getTime() - createdDate.getTime());
      return Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    }
    return 0;
  }
  
  navigateTo(section: string): void {
    console.log(`User navigating to: ${section}`);
    this.router.navigate([section]);
  }

  // New methods for dashboard functionality
  togglePendingApprovals(): void {
    this.showPendingApprovals = !this.showPendingApprovals;
  }

  toggleCreateDropdown(): void {
    this.showCreateDropdown = !this.showCreateDropdown;
  }

  handleApproval(id: string, action: string): void {
    console.log(`${action} approval for item ${id}`);
    // Implement approval logic here
  }

  performSearch(): void {
    if (this.searchQuery.trim()) {
      console.log(`Searching for: ${this.searchQuery}`);
      // Implement search logic here
      this.router.navigate(['/search'], { queryParams: { q: this.searchQuery } });
    }
  }

  createNew(type: string): void {
    console.log(`Creating new ${type}`);
    this.showCreateDropdown = false;
    // Implement create logic here
  }

  getActivityIcon(type: string) {
    switch (type) {
      case 'created': return faPlus;
      case 'updated': return faEdit;
      case 'approved': return faCheck;
      case 'shared': return faShare;
      default: return faFileAlt;
    }
  }

  private initializeChart(): void {
    // Initialize Chart.js chart for content distribution
    setTimeout(() => {
      const canvas = document.querySelector('#chartCanvas') as HTMLCanvasElement;
      if (canvas) {
        const ctx = canvas.getContext('2d');
        if (ctx) {
          // Import Chart.js dynamically to avoid SSR issues
          import('chart.js/auto').then((Chart) => {
            new Chart.default(ctx, {
              type: 'doughnut',
              data: {
                labels: ['Projects', 'Documents', 'Policies', 'Resources'],
                datasets: [{
                  data: [35, 28, 15, 22],
                  backgroundColor: [
                    'var(--fm-primary-blue)',
                    'var(--fm-secondary-blue)',
                    'var(--fm-green)',
                    'var(--fm-orange)'
                  ],
                  borderWidth: 0
                }]
              },
              options: {
                responsive: true,
                maintainAspectRatio: false,
                cutout: '60%',
                plugins: {
                  legend: {
                    position: 'bottom',
                    labels: {
                      padding: 20,
                      usePointStyle: true,
                      font: {
                        family: 'Inter'
                      }
                    }
                  },
                  tooltip: {
                    callbacks: {
                      label: function(context: any) {
                        return context.label + ': ' + context.parsed + '%';
                      }
                    }
                  }
                }
              }
            });
          }).catch(error => {
            console.error('Failed to load Chart.js:', error);
          });
        }
      }
    }, 100);
  }

  getAbsoluteValue(value: number): number {
    return Math.abs(value);
  }
}
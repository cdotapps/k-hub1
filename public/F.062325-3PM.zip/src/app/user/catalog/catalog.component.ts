import { Component, OnInit, OnDestroy, HostListener } from '@angular/core';
import { Router } from '@angular/router';
import { Subscription, merge } from 'rxjs';
import { debounceTime, distinctUntilChanged, filter } from 'rxjs/operators';
import { Subject } from 'rxjs';

// FontAwesome Icons
import { 
  faNewspaper, faPlus, faRefresh, faSearch, faGripHorizontal, faList, faFilter, faEye, faEdit, faTrash,
  faHeart, faShare, faTimes, faChevronLeft, faChevronRight, faChevronDown, faFileAlt, 
  faSortAmountDown, faSortAmountUp, faThLarge, faSpinner, faExclamationTriangle,
  faUser, faCalendar, faClock, faCheckCircle, faBell, faBook, faGraduationCap,
  faBlog, faFlask, faFileContract, faChartLine, faLightbulb, faInfoCircle,
  faBookOpen, faFileImage, faVideo, faMicrophone, faWifi, faBan
} from '@fortawesome/free-solid-svg-icons';

// Services and Models
import { CatalogService } from '../../shared/services/catalog.service';
import { AuthService } from '../../shared/services/auth.service';
import { UserService } from '../../shared/services/user.service';
import { DateUtilityService } from '../../shared/services/date-utility.service';
import { Catalog, User } from '../../shared/models/user.interface';
import { CATALOG_TYPES, CatalogType, filterCatalogTypesByRole } from '../../shared/config/site-config';

type ViewMode = 'list' | 'card' | 'grid';

interface FilterOption {
  value: string;
  label: string;
}

interface AuthorOption {
  id: string;
  name: string;
}

@Component({
  selector: 'app-catalog',
  templateUrl: './catalog.component.html',
  styleUrls: ['./catalog.component.css']
})
export class CatalogComponent implements OnInit, OnDestroy {
getSharedCount(_t278: Catalog): number {
throw new Error('Method not implemented.');
}
  // FontAwesome Icons
  faNewspaper = faNewspaper;
  faPlus = faPlus;
  faRefresh = faRefresh;
  faSearch = faSearch;
  faGripHorizontal = faGripHorizontal;
  faList = faList;
  faFilter = faFilter;
  faEye = faEye;
  faEdit = faEdit;
  faTrash = faTrash;
  faHeart = faHeart;
  faShare = faShare;
  faTimes = faTimes;
  faChevronLeft = faChevronLeft;
  faChevronRight = faChevronRight;
  faChevronDown = faChevronRight; // Added missing icon
  faFileAlt = faFileAlt;
  faSortAmountDown = faSortAmountDown;
  faSortAmountUp = faSortAmountUp;
  faThLarge = faThLarge;
  faSpinner = faSpinner;
  faExclamationTriangle = faExclamationTriangle;
  faUser = faUser;
  faCalendar = faCalendar;
  faClock = faClock;
  faCheckCircle = faCheckCircle;
  faBell = faBell;
  faBook = faBook;
  faGraduationCap = faGraduationCap;
  faBlog = faBlog;
  faFlask = faFlask;
  faFileContract = faFileContract;
  faChartLine = faChartLine;
  faLightbulb = faLightbulb;
  faInfoCircle = faInfoCircle;
  faBookOpen = faBookOpen;
  faFileImage = faFileImage;
  faVideo = faVideo;
  faMicrophone = faMicrophone;
  faWifi = faWifi; // Added for websocket connection status
  faBan = faBan; // Added for disabled websocket connection status

  // Data Properties
  catalogItems: Catalog[] = [];
  currentUser: User | null = null;
  isLoading = false;
  errorMessage = '';
  breadcrumbItems: any[] = [];
  showMyItems = false;
  isCreatingDraft = false; // Add loading state for draft creation
  
  // Auto-refresh state tracking
  lastRefreshTime = Date.now();
  refreshing = false;
  autoRefreshEnabled = true;
  refreshVisualIndicator = false;
  
  // Load more functionality
  currentPage = 1;
  totalPages = 1;
  totalItems = 0;
  itemsPerPage = 12;
  isLoadingMore = false;
  allItemsLoaded = false;
  skeletonItems = Array(4).fill(0); // Array for skeleton loading effect

  // View and Filtering
  viewMode: ViewMode = 'card';
  searchQuery = '';
  selectedCatalogType = '';
  selectedStatus = '';
  selectedAuthor = '';
  selectedDateRange = '';
  sortBy = 'created_date';
  sortDirection: 'asc' | 'desc' = 'desc';

  // Filter Options
  availableCatalogTypes: FilterOption[] = [
    { value: '', label: 'All Catalog Types' }
    // Other catalog types will be loaded from site-config.ts
  ];

  availableStatuses: FilterOption[] = [
    { value: '', label: 'All Statuses' },
    { value: 'draft', label: 'Draft' },
    { value: 'published', label: 'Published' },
    { value: 'archived', label: 'Archived' },
    { value: 'pending', label: 'Pending Review' },
    { value: 'approved', label: 'Approved' },
    { value: 'rejected', label: 'Rejected' }
  ];

  availableAuthors: AuthorOption[] = [];

  availableDateRanges: FilterOption[] = [
    { value: '', label: 'All Time' },
    { value: 'today', label: 'Today' },
    { value: 'week', label: 'This Week' },
    { value: 'month', label: 'This Month' },
    { value: 'quarter', label: 'This Quarter' },
    { value: 'year', label: 'This Year' }
  ];

  availableSortOptions: FilterOption[] = [
    { value: 'created_date', label: 'Date Created' },
    { value: 'updated_date', label: 'Date Modified' },
    { value: 'title', label: 'Title' },
    { value: 'author', label: 'Author' },
    { value: 'category', label: 'Category' },
    { value: 'views_count', label: 'Views' },
    { value: 'likes_count', label: 'Likes' }
  ];

  // Delete confirmation
  showDeleteConfirm = false;
  itemToDelete: Catalog | null = null;

  // Share popup state
  showSharePopup = false;
  shareSelectedItem: Catalog | null = null;

  // Search debounce
  private searchSubject = new Subject<string>();
  private subscriptions = new Subscription();

  // Expose Math for template
  Math = Math;

  constructor(
    private catalogService: CatalogService,
    private authService: AuthService,
    private userService: UserService,
    private dateUtilityService: DateUtilityService,
    private router: Router
  ) {}

  ngOnInit(): void {
    // Subscribe to authentication state
    this.subscriptions.add(
      this.authService.currentUser$.subscribe((user: User | null) => {
        this.currentUser = user;
        // Initialize catalog types based on user role
        this.initializeCatalogTypes();
      })
    );

    // Setup search debounce
    this.subscriptions.add(
      this.searchSubject.pipe(
        debounceTime(300),
        distinctUntilChanged()
      ).subscribe(() => {
        this.performSearch();
      })
    );

    // Subscribe to catalog refresh events
    this.subscriptions.add(
      this.catalogService.catalogRefresh$.subscribe((shouldRefresh) => {
        if (shouldRefresh && !this.refreshing && this.autoRefreshEnabled) {
          // Show visual indicator for update
          this.showUpdateIndicator();
          
          // Refresh the data
          this.refreshCatalog(true);
        }
      })
    );

    // Load initial data
    this.loadCatalogItems();
    this.loadAuthors();
    this.breadcrumbItems = [
      { label: 'Catalog', routerLink: '/user/catalog' }
    ];
    this.setViewMode('grid');
  }

  ngOnDestroy(): void {
    this.subscriptions.unsubscribe();
    // Stop polling when component is destroyed
    this.catalogService.stopPollingForUpdates();
  }

  /**
   * Display update indicator
   */
  showUpdateIndicator(): void {
    // Show subtle refresh visual indicator
    this.refreshVisualIndicator = true;
    
    // Hide indicator after a short delay
    setTimeout(() => {
      this.refreshVisualIndicator = false;
    }, 1000);
  }

  /**
   * Load catalog items from API
   */
  loadCatalogItems(resetItems: boolean = true, silent: boolean = false): void {
    if (resetItems) {
      if (!silent) {
        this.isLoading = true;
      }
      this.errorMessage = '';
      this.currentPage = 1;
      this.catalogItems = [];
    } else {
      this.isLoadingMore = true;
    }

    const params = this.buildQueryParams();
    
    // Use cache for subsequent pages, but not for first page
    if (this.currentPage > 1) {
      params.useCache = true;
    }

    this.catalogService.getCatalogItems(params).subscribe({
      next: (response) => {
        const newItems = response.items || [];
        
        // Sort items by latest date (client-side sorting as fallback)
        const sortedItems = newItems.sort((a, b) => {
          const dateA = new Date(this.getLatestDate(a));
          const dateB = new Date(this.getLatestDate(b));
          return this.sortDirection === 'desc' ? dateB.getTime() - dateA.getTime() : dateA.getTime() - dateB.getTime();
        });
        
        if (resetItems) {
          this.catalogItems = sortedItems;
        } else {
          this.catalogItems = [...this.catalogItems, ...sortedItems];
        }
        
        this.totalItems = response.total || 0;
        this.totalPages = Math.ceil(this.totalItems / this.itemsPerPage);
        this.allItemsLoaded = this.currentPage >= this.totalPages;
        
        this.isLoading = false;
        this.isLoadingMore = false;
        this.lastRefreshTime = Date.now();
      },
      error: (error) => {
        console.error('Failed to load catalog items:', error);
        this.errorMessage = 'Failed to load catalog items. Please try again.';
        this.isLoading = false;
        this.isLoadingMore = false;
        if (resetItems) {
          this.catalogItems = [];
        }
      }
    });
  }

  /**
   * Load available authors for filter
   */
  loadAuthors(): void {
    this.catalogService.getAuthors().subscribe({
      next: (authors) => {
        this.availableAuthors = [
          { id: '', name: 'All Authors' },
          ...authors.map(author => ({ id: author, name: author }))
        ];
      },
      error: (error) => {
        console.error('Failed to load authors:', error);
        this.availableAuthors = [{ id: '', name: 'All Authors' }];
      }
    });
  }

  /**
   * Initialize catalog types from site configuration based on user role
   */
  private initializeCatalogTypes(): void {
    // Reset to default "All Catalog Types" option
    this.availableCatalogTypes = [{ value: '', label: 'All Catalog Types' }];
    
    if (this.currentUser) {
      // Get filtered catalog types based on user role
      const userRole = this.currentUser.role;
      const filteredCatalogTypes = filterCatalogTypesByRole(userRole);
      
      // Add filtered types to the available options
      filteredCatalogTypes.forEach(type => {
        this.availableCatalogTypes.push({
          value: type.value,
          label: type.label
        });
      });
    }
  }

  /**
   * Get the latest date between created_date and updated_date
   */
  getLatestDate(item: Catalog): string {
    if (!item.created_date && !item.updated_date) return '';
    if (!item.created_date) return item.updated_date || '';
    if (!item.updated_date) return item.created_date;
    
    const createdDate = new Date(item.created_date);
    const updatedDate = new Date(item.updated_date);
    
    return createdDate > updatedDate ? item.created_date : item.updated_date;
  }

  /**
   * Build query parameters for API call
   */
  private buildQueryParams(): any {
    // Use latest_date for sorting by most recent activity
    const sortField = this.sortBy === 'created_date' || this.sortBy === 'updated_date' ? 'latest_date' : this.sortBy;
    
    return {
      page: this.currentPage,
      page_size: this.itemsPerPage,
      query: this.searchQuery || undefined,
      type: this.selectedCatalogType || undefined,
      status: this.selectedStatus || undefined,
      author: this.selectedAuthor || undefined,
      sort: sortField,
      order: this.sortDirection,
      date_range: this.selectedDateRange || undefined,
      owner: this.showMyItems ? this.currentUser?.id : undefined
    };
  }

  /**
   * Handle search input changes
   */
  onSearchChange(): void {
    this.searchSubject.next(this.searchQuery);
  }

  /**
   * Perform search and reset to first page
   */
  performSearch(): void {
    this.currentPage = 1;
    this.loadCatalogItems();
  }

  /**
   * Clear search query
   */
  clearSearch(): void {
    this.searchQuery = '';
    this.performSearch();
  }

  /**
   * Handle category filter change
   */
  onCatalogTypeChange(): void {
    this.currentPage = 1;
    this.loadCatalogItems();
  }

  /**
   * Handle status filter change
   */
  onStatusChange(): void {
    this.currentPage = 1;
    this.loadCatalogItems();
  }

  /**
   * Handle author filter change
   */
  onAuthorChange(): void {
    this.currentPage = 1;
    this.loadCatalogItems();
  }

  /**
   * Handle date range filter change
   */
  onDateRangeChange(): void {
    this.currentPage = 1;
    this.loadCatalogItems();
  }

  /**
   * Handle sort option change
   */
  onSortChange(): void {
    this.loadCatalogItems();
  }

  /**
   * Toggle sort direction
   */
  toggleSortDirection(): void {
    this.sortDirection = this.sortDirection === 'asc' ? 'desc' : 'asc';
    this.loadCatalogItems();
  }

  /**
   * Set view mode
   */
  setViewMode(mode: ViewMode): void {
    this.viewMode = mode;
  }

  /**
   * Check if user owns the item
   */
  isOwner(item: Catalog): boolean {
    return this.currentUser?.id === item.author_id || this.currentUser?.role === 'admin';
  }

  /**
   * Check if user can create content
   */
  canCreateContent(): boolean {
    return !!this.currentUser && (this.currentUser.role === 'admin' || this.currentUser.role === 'user');
  }

  /**
   * Check if item is recent (created within last 7 days)
   */
  isRecentItem(item: Catalog): boolean {
    if (!item.created_date) return false;
    const createdDate = new Date(item.created_date);
    const weekAgo = new Date();
    weekAgo.setDate(weekAgo.getDate() - 7);
    return createdDate > weekAgo;
  }

  /**
   * Get excerpt from text
   */
  getExcerpt(text: string | undefined, maxLength: number = 150): string {
    if (!text) return '';
    if (text.length <= maxLength) return text;
    return text.substring(0, maxLength) + '...';
  }

  /**
   * Format relative time
   */
  formatRelativeTime(dateString: string | undefined): string {
    if (!dateString) return '';
    return this.dateUtilityService.getRelativeTime(dateString);
  }

  /**
   * Format date
   */
  formatDate(dateString: string | undefined): string {
    if (!dateString) return '';
    return this.dateUtilityService.formatDate(dateString);
  }

  /**
   * Format sharing date for display
   */
  formatSharedDate(dateString: string): string {
    return this.dateUtilityService.formatDate(dateString);
  }

  /**
   * Get the most recent sharing date for display
   */
  getMostRecentShareDate(item: Catalog): string {
    if (!item.shared_with || item.shared_with.length === 0) {
      return '';
    }

    const mostRecent = item.shared_with.reduce((latest, user) => {
      return new Date(user.shared_date) > new Date(latest.shared_date) ? user : latest;
    });

    return this.formatSharedDate(mostRecent.shared_date);
  }

  /**
   * Get category CSS class
   */
  getCategoryClass(category: string | undefined): string {
    if (!category) return '';
    const categoryMap: { [key: string]: string } = {
      'news': 'category-news',
      'article': 'category-article',
      'announcement': 'category-announcement',
      'guide': 'category-guide',
      'tutorial': 'category-tutorial',
      'documentation': 'category-documentation',
      'blog': 'category-blog',
      'research': 'category-research',
      'whitepaper': 'category-whitepaper',
      'case-study': 'category-case-study'
    };
    return categoryMap[category] || 'category-default';
  }

  /**
   * Get item status CSS class
   */
  getItemStatusClass(status: string | undefined): string {
    if (!status) return '';
    const statusMap: { [key: string]: string } = {
      'draft': 'status-draft',
      'published': 'status-published',
      'archived': 'status-archived',
      'pending': 'status-pending',
      'approved': 'status-approved',
      'rejected': 'status-rejected'
    };
    return statusMap[status] || 'status-default';
  }

  /**
   * Get reading time estimate
   */
  getReadingTime(content: string | undefined): string {
    if (!content) return '0 min read';
    const wordsPerMinute = 200;
    const wordCount = content.split(/\s+/).length;
    const minutes = Math.ceil(wordCount / wordsPerMinute);
    return `${minutes} min read`;
  }

  /**
   * Check if there are active filters
   */
  hasActiveFilters(): boolean {
    return !!(this.searchQuery || this.selectedCatalogType || this.selectedStatus || 
              this.selectedAuthor || this.selectedDateRange || this.showMyItems);
  }

  /**
   * Get active filters text
   */
  getActiveFiltersText(): string {
    const filters = [];
    if (this.searchQuery) filters.push(`"${this.searchQuery}"`);
    if (this.selectedCatalogType) filters.push(this.getCatalogTypeLabel(this.selectedCatalogType));
    if (this.selectedStatus) filters.push(this.getStatusLabel(this.selectedStatus));
    if (this.selectedAuthor) filters.push(this.getAuthorLabel(this.selectedAuthor));
    if (this.selectedDateRange) filters.push(this.getDateRangeLabel(this.selectedDateRange));
    if (this.showMyItems) filters.push('My Items Only');
    return filters.join(', ');
  }

  /**
   * Clear all filters
   */
  clearAllFilters(): void {
    this.searchQuery = '';
    this.selectedCatalogType = '';
    this.selectedStatus = '';
    this.selectedAuthor = '';
    this.selectedDateRange = '';
    this.showMyItems = false;
    this.currentPage = 1;
    this.loadCatalogItems();
  }

  /**
   * Get empty state title
   */
  getEmptyStateTitle(): string {
    if (this.hasActiveFilters()) {
      return 'No Results Found';
    }
    return 'No Articles Available';
  }

  /**
   * Get empty state message
   */
  getEmptyStateMessage(): string {
    if (this.hasActiveFilters()) {
      return 'Try adjusting your search criteria or clearing filters to see more results.';
    }
    return 'There are currently no articles in the catalog. Check back later or create the first article.';
  }

  /**
   * Select category tab and update filter
   */
  selectCatalogTypeTab(type: string): void {
    this.selectedCatalogType = type;
    this.currentPage = 1;
    this.loadCatalogItems();
  }

  /**
   * Get catalog type icon based on catalog type value
   */
  getCatalogTypeIcon(type: string): any {
    // Find the catalog type in the configuration
    const catalogType = CATALOG_TYPES.find(t => t.value === type);
    
    if (catalogType) {
      return catalogType.icon;
    }
    
    // Default fallback if type not found
    return this.faFileAlt;
  }

  /**
   * Get catalog type color class for visual differentiation
   */
  getCatalogTypeColorClass(type: string): string {
    const colorMap: { [key: string]: string } = {
      'news': 'type-default',
      'article': 'type-default', 
      'notification': 'type-default',
      'document': 'type-default',
      'guide': 'type-default',
      'tutorial': 'type-default',
      'blog': 'type-default',
      'research': 'type-default',
      'whitepaper': 'type-default',
      'case-study': 'type-default'
    };
    return colorMap[type] || 'type-default';
  }

  /**
   * Get catalog type placeholder image or icon
   */
  getCatalogTypePlaceholder(type: string): { icon: any; color: string; background: string } {
    // Find the catalog type in the configuration
    const catalogType = CATALOG_TYPES.find(t => t.value === type);
    
    if (catalogType) {
      return {
        icon: catalogType.icon,
        color: catalogType.color,
        background: catalogType.background
      };
    }
    
    // Default fallback if type not found
    return { icon: this.faFileAlt, color: '#fff', background: '#003f7f' };
  }

  // Helper methods for filter labels
  getCatalogTypeLabel(value: string): string {
    const option = this.availableCatalogTypes.find(cat => cat.value === value);
    return option ? option.label : value;
  }

  getStatusLabel(value: string): string {
    const option = this.availableStatuses.find(status => status.value === value);
    return option ? option.label : value;
  }

  getAuthorLabel(value: string): string {
    const option = this.availableAuthors.find(author => author.id === value);
    return option ? option.name : value;
  }

  getDateRangeLabel(value: string): string {
    const option = this.availableDateRanges.find(range => range.value === value);
    return option ? option.label : value;
  }

  /**
   * Navigate to item detail
   */
  viewItem(item: Catalog): void {
    this.router.navigate(['/user/catalog', item.id]);
  }

  /**
   * Handle action from catalog card - centralized action handler
   * @param actionData Object containing action, item, and event
   */
  onCatalogCardAction(actionData: { action: string; item: Catalog; event: Event }): void {
    const { action, item, event } = actionData;
    
    event.stopPropagation();
    event.preventDefault();
    
    console.log(`Handling card action: ${action} for item: ${item.title}`);
    
    switch (action) {
      case 'view':
        this.viewItem(item);
        break;
      case 'edit':
        this.handleEditItem(item, event);
        break;
      case 'copy':
      case 'duplicate':
        this.handleCopyItem(item, event);
        break;
      case 'delete':
        this.handleDeleteItem(item, event);
        break;
      case 'share':
        this.handleShareItem(item, event);
        break;
      case 'publish':
        this.handlePublishItem(item, event);
        break;
      case 'approve':
        this.handleApproveItem(item, event);
        break;
      case 'reject':
        this.handleRejectItem(item, event);
        break;
      case 'approval':
        this.handleRequestApproval(item, event);
        break;
      case 'toggle-access':
        this.handleToggleItemAccess(item, event);
        break;
      case 'download':
        this.handleDownloadItem(item, event);
        break;
      case 'external':
      case 'open-external':
        this.handleOpenExternalLink(item, event);
        break;
      default:
        console.warn(`Unknown card action: ${action}`);
    }
  }

  /**
   * Handle edit item action
   */
  private handleEditItem(item: Catalog, event: Event): void {
    if (!this.isOwner(item)) {
      console.warn('User does not have permission to edit this item');
      return;
    }
    this.router.navigate(['/user/catalog/edit', item.id]);
  }

  /**
   * Handle copy/duplicate item action
   */
  private handleCopyItem(item: Catalog, event: Event): void {
    // Prevent multiple simultaneous duplicate requests
    if (this.isCreatingDraft) {
      console.log('Duplicate blocked: Already creating a draft item');
      return;
    }

    // Set creating state immediately to prevent multiple requests
    this.isCreatingDraft = true;
    console.log(`Creating duplicate of item: ${item.title} (ID: ${item.id})`);
    
    const duplicateData = {
      title: `[COPY] of ${item.title}`,
      description: item.description,
      content: item.content,
      type: item.type,
      category: item.category,
      tags: item.tags,
      url: item.url,
      image: item.image,
      imageUrl: item.imageUrl,
      display: item.display,
      custom: item.custom,
      status: 'draft',
      author: this.currentUser ? `${this.currentUser.first_name} ${this.currentUser.last_name}` : 'Unknown Author',
      author_id: this.currentUser?.id || '',
      created_date: new Date().toISOString(),
      updated_date: new Date().toISOString()
    };

    this.catalogService.createCatalogItem(duplicateData).subscribe({
      next: (newItem) => {
        console.log('Duplicate created successfully:', newItem.title, 'New ID:', newItem.id);
        
        // Add the new item to the beginning of the catalog list
        this.catalogItems.unshift(newItem);
        this.totalItems++;
        
        // Trigger refresh to update other components
        this.catalogService.triggerRefresh();
        
        // Reset the creating state
        this.isCreatingDraft = false;
      },
      error: (error) => {
        console.error('Failed to duplicate item:', error);
        
        // Reset the creating state with a slight delay to prevent rapid retries
        setTimeout(() => {
          this.isCreatingDraft = false;
        }, 1000);
      }
    });
  }

  /**
   * Handle delete item action
   */
  private handleDeleteItem(item: Catalog, event: Event): void {
    if (!this.isOwner(item)) {
      console.warn('User does not have permission to delete this item');
      return;
    }
    
    this.itemToDelete = item;
    this.showDeleteConfirm = true;
  }

  /**
   * Handle share item action
   */
  private handleShareItem(item: Catalog, event: Event): void {
    // Set the item to share and show the popup
    this.shareSelectedItem = item;
    this.showSharePopup = true;
  }

  /**
   * Close the share popup
   */
  closeSharePopup(): void {
    this.showSharePopup = false;
    this.shareSelectedItem = null;
  }

  /**
   * Handle share completion
   */
  onShareComplete(data: { users: any[], catalogItem: Catalog }): void {
    console.log('Share completed:', data);
    
    // Create shared user entries with minimal info for local display
    const sharedUsers = data.users.map(user => ({
      id: user.id || user.user_id,
      name: this.userService.getUserDisplayName(user),
      shared_date: new Date().toISOString(),
      access: 'read' as const // Default access level
    }));

    // Update the catalog item's shared_with attribute locally
    const updatedCatalog = { ...data.catalogItem };
    
    // Merge with existing shared_with array or create new one
    if (updatedCatalog.shared_with) {
      // Remove duplicates and add new shares
      const existingIds = new Set(updatedCatalog.shared_with.map(s => s.id));
      const newShares = sharedUsers.filter(s => !existingIds.has(s.id));
      updatedCatalog.shared_with = [...updatedCatalog.shared_with, ...newShares];
    } else {
      updatedCatalog.shared_with = sharedUsers;
    }

    // Update the catalog in the local array
    this.updateCatalogInArray(updatedCatalog);

    // Send to backend to persist the sharing (using user IDs only for API)
    this.catalogService.updateCatalogSharing(updatedCatalog.id, sharedUsers)
      .subscribe({
        next: (response: any) => {
          console.log('Sharing updated successfully:', response);
          
          // Show success message
          const userNames = sharedUsers.map(user => user.name).join(', ');
          console.log(`Successfully shared "${updatedCatalog.title}" with: ${userNames}`);
          
          // You could show a toast notification here
          // this.showSuccessMessage(`Successfully shared with ${sharedUsers.length} user(s)`);
        },
        error: (error: any) => {
          console.error('Error updating sharing:', error);
          // Revert the local change if backend update fails
          this.updateCatalogInArray(data.catalogItem);
          // this.showErrorMessage('Failed to update sharing. Please try again.');
        }
      });
  }

  /**
   * Update catalog in the local array
   */
  private updateCatalogInArray(updatedCatalog: Catalog): void {
    // Update in catalogItems array
    const index = this.catalogItems.findIndex((c: Catalog) => c.id === updatedCatalog.id);
    if (index !== -1) {
      this.catalogItems[index] = updatedCatalog;
    }
  }

  /**
   * Handle publish item action
   */
  private handlePublishItem(item: Catalog, event: Event): void {
    console.log('Publish action not yet implemented for:', item.title);
    // TODO: Implement publish functionality
  }

  /**
   * Handle approve item action
   */
  private handleApproveItem(item: Catalog, event: Event): void {
    console.log('Approve action not yet implemented for:', item.title);
    // TODO: Implement approve functionality
  }

  /**
   * Handle reject item action
   */
  private handleRejectItem(item: Catalog, event: Event): void {
    console.log('Reject action not yet implemented for:', item.title);
    // TODO: Implement reject functionality
  }

  /**
   * Handle request approval action
   */
  private handleRequestApproval(item: Catalog, event: Event): void {
    console.log('Request approval action not yet implemented for:', item.title);
    // TODO: Implement request approval functionality
  }

  /**
   * Handle toggle item access action
   */
  private handleToggleItemAccess(item: Catalog, event: Event): void {
    console.log('Toggle access action not yet implemented for:', item.title);
    // TODO: Implement toggle access functionality
  }

  /**
   * Handle download item action
   */
  private handleDownloadItem(item: Catalog, event: Event): void {
    console.log('Download action not yet implemented for:', item.title);
    // TODO: Implement download functionality
  }

  /**
   * Handle open external link action
   */
  private handleOpenExternalLink(item: Catalog, event: Event): void {
    console.log('Open external link action not yet implemented for:', item.title);
    // TODO: Implement external link functionality
  }

  /**
   * Refresh catalog
   * @param silent If true, doesn't show loading indicator
   */
  refreshCatalog(silent: boolean = false): void {
    if (this.refreshing) return;
    
    this.refreshing = true;
    this.loadCatalogItems(true, silent);
    
    // Start the auto-refresh polling again
    this.catalogService.startPollingForUpdates();
    
    // Reset refreshing state after a short delay
    setTimeout(() => {
      this.refreshing = false;
    }, 500);
  }

  /**
   * Toggle auto-refresh feature
   */
  toggleAutoRefresh(): void {
    this.autoRefreshEnabled = !this.autoRefreshEnabled;
    
    if (this.autoRefreshEnabled) {
      // Restart polling if enabled
      this.catalogService.startPollingForUpdates();
    } else {
      // Stop polling if disabled
      this.catalogService.stopPollingForUpdates();
    }
  }

  /**
   * Track by function for ngFor
   */
  trackByItemId(index: number, item: Catalog): string {
    return item.id;
  }

  /**
   * Load more items when user scrolls or clicks load more button
   */
  loadMoreItems(): void {
    if (this.isLoadingMore || this.allItemsLoaded) return;
    
    this.currentPage++;
    this.loadCatalogItems(false);
  }

  /**
   * Detect when user has scrolled to the bottom of the page
   */
  @HostListener('window:scroll', ['$event'])
  onScroll(): void {
    // Don't try to load more if we're already loading, have loaded all items, or have an error
    if (this.isLoadingMore || this.allItemsLoaded || this.errorMessage || this.isLoading) return;
    
    // Check if user has scrolled to the bottom (with a threshold of 300px)
    const windowHeight = window.innerHeight;
    const documentHeight = document.documentElement.scrollHeight;
    const scrollTop = window.pageYOffset || document.documentElement.scrollTop || document.body.scrollTop || 0;
    
    if (windowHeight + scrollTop >= documentHeight - 300) {
      this.loadMoreItems();
    }
  }

  /**
   * Handle hero metric click
   * @param index The index of the metric that was clicked
   */
  onHeroMetricClick(index: number): void {
    switch (index) {
      case 0: // Total Articles
        // No action needed, just for display
        break;
      case 1: // Catalog Type
        // Toggle between all catalog types and first catalog type
        if (this.selectedCatalogType) {
          this.selectCatalogTypeTab('');
        } else if (this.availableCatalogTypes.length > 1) {
          this.selectCatalogTypeTab(this.availableCatalogTypes[1].value);
        }
        break;
      case 2: // Create Access
        if (this.canCreateContent()) {
          this.createNew();
        }
        break;
      case 3: // Refresh
        this.refreshCatalog();
        break;
    }
  }

  /**
   * Handle hero action click
   * @param index The index of the action that was clicked
   */
  onHeroActionClick(index: number): void {
    switch (index) {
      case 0: // Create Article
        this.createNew();
        break;
      case 1: // Refresh
        this.refreshCatalog();
        break;
    }
  }

  /**
   * Handle show my items checkbox change
   */
  onShowMyItemsChange(): void {
    this.currentPage = 1;
    this.loadCatalogItems();
  }

  /**
   * Get count of items owned by current user
   */
  getMyItemsCount(): number {
    if (!this.currentUser) return 0;
    return this.catalogItems.filter(item => this.isOwner(item)).length;
  }

  /**
   * Navigate to create new article
   */
  createNew(): void {
    if (!this.canCreateContent()) {
      console.warn('User does not have permission to create content');
      return;
    }
    this.router.navigate(['/user/catalog/create']);
  }

  /**
   * Create a quick draft article when specific catalog type is selected
   */
  createQuickDraft(): void {
    if (!this.canCreateContent() || this.isCreatingDraft) {
      return;
    }

    this.isCreatingDraft = true;
    
    const draftData = {
      title: `[NEW] ${this.selectedCatalogType ? this.getCatalogTypeLabel(this.selectedCatalogType) : 'Article'}`,
      description: 'This is a quick draft article created automatically.',
      content: 'This is the content of the quick draft article. You can edit it later.',
      type: this.selectedCatalogType || 'article',
      category: '',
      tags: [],
      status: 'draft',
      author: this.currentUser ? `${this.currentUser.first_name} ${this.currentUser.last_name}` : 'Unknown Author',
      author_id: this.currentUser?.id || '',
      created_date: new Date().toISOString(),
      updated_date: new Date().toISOString()
    };

    this.catalogService.createCatalogItem(draftData).subscribe({
      next: (newItem) => {
        console.log('Quick draft created successfully:', newItem.title, 'New ID:', newItem.id);
        
        // Add the new item to the beginning of the catalog list
        this.catalogItems.unshift(newItem);
        this.totalItems++;
        
        // Trigger refresh to update other components
        this.catalogService.triggerRefresh();
        
        // Reset the creating state
        this.isCreatingDraft = false;
      },
      error: (error) => {
        console.error('Failed to create quick draft:', error);
        
        // Reset the creating state with a slight delay to prevent rapid retries
        setTimeout(() => {
          this.isCreatingDraft = false;
        }, 1000);
      }
    });
  }

  // Legacy methods for backward compatibility - these now delegate to the centralized handler
  /**
   * @deprecated Use onCatalogCardAction instead
   */
  editItem(itemOrEvent: Catalog | { item: Catalog, event: Event }, event?: Event): void {
    let item: Catalog;
    let eventObj: Event;
    
    if ((itemOrEvent as { item: Catalog, event: Event }).item) {
      const eventData = itemOrEvent as { item: Catalog, event: Event };
      item = eventData.item;
      eventObj = eventData.event;
    } else {
      item = itemOrEvent as Catalog;
      eventObj = event as Event;
    }
    
    this.onCatalogCardAction({ action: 'edit', item, event: eventObj });
  }

  /**
   * @deprecated Use onCatalogCardAction instead
   */
  deleteItem(itemOrEvent: Catalog | { item: Catalog, event: Event }, event?: Event): void {
    let item: Catalog;
    let eventObj: Event;
    
    if ((itemOrEvent as { item: Catalog, event: Event }).item) {
      const eventData = itemOrEvent as { item: Catalog, event: Event };
      item = eventData.item;
      eventObj = eventData.event;
    } else {
      item = itemOrEvent as Catalog;
      eventObj = event as Event;
    }
    
    this.onCatalogCardAction({ action: 'delete', item, event: eventObj });
  }

  /**
   * @deprecated Use onCatalogCardAction instead
   */
  copyItem(itemOrEvent: Catalog | { item: Catalog, event: Event }, event?: Event): void {
    let item: Catalog;
    let eventObj: Event;
    
    if ((itemOrEvent as { item: Catalog, event: Event }).item) {
      const eventData = itemOrEvent as { item: Catalog, event: Event };
      item = eventData.item;
      eventObj = eventData.event;
    } else {
      item = itemOrEvent as Catalog;
      eventObj = event as Event;
    }
    
    this.onCatalogCardAction({ action: 'copy', item, event: eventObj });
  }

  /**
   * Confirm delete action
   */
  confirmDelete(): void {
    if (!this.itemToDelete) return;
    
    this.catalogService.deleteCatalogItem(this.itemToDelete.id).subscribe({
      next: () => {
        // Remove item from the list
        this.catalogItems = this.catalogItems.filter(item => item.id !== this.itemToDelete!.id);
        this.totalItems--;
        
        // Trigger refresh to update other components
        this.catalogService.triggerRefresh();
        
        // Close the confirmation modal
        this.showDeleteConfirm = false;
        this.itemToDelete = null;
        
        console.log('Item deleted successfully');
      },
      error: (error) => {
        console.error('Failed to delete item:', error);
        this.showDeleteConfirm = false;
        this.itemToDelete = null;
      }
    });
  }

  /**
   * Cancel delete action
   */
  cancelDelete(): void {
    this.showDeleteConfirm = false;
    this.itemToDelete = null;
  }

  /**
   * Get shared users count for a catalog item
   */
  getSharedUsersCount(item: Catalog): number {
    return item.shared_with ? item.shared_with.length : 0;
  }

  /**
   * Get shared users names for display (first few names)
   */
  getSharedUsersDisplay(item: Catalog, maxNames: number = 3): string {
    if (!item.shared_with || item.shared_with.length === 0) {
      return '';
    }

    const names = item.shared_with.slice(0, maxNames).map(user => user.name);
    const remaining = item.shared_with.length - maxNames;
    
    if (remaining > 0) {
      return `${names.join(', ')} and ${remaining} more`;
    }
    
    return names.join(', ');
  }

  /**
   * Check if current user has access to shared item
   */
  hasSharedAccess(item: Catalog): boolean {
    if (!item.shared_with || !this.currentUser) {
      return false;
    }
    
    return item.shared_with.some(user => user.id === this.currentUser?.id);
  }
}
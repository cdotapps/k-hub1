import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

@NgModule({
  declarations: [
    // ...existing declarations...
  ],
  imports: [
    CommonModule,
    FormsModule,
    // ...existing imports...
  ],
  // ...existing code...
})
export class YourModuleName { }
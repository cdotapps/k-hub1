import { Component, Input } from '@angular/core';
import { Router } from '@angular/router';
import { faHome, faChevronRight } from '@fortawesome/free-solid-svg-icons';

export interface BreadcrumbItem {
  label: string;
  url?: string;
  active?: boolean;
}

@Component({
  selector: 'app-breadcrumb',
  template: `
    <nav class="breadcrumb-nav" [attr.aria-label]="ariaLabel">
      <ol class="breadcrumb-list">
        <!-- Home Link -->
        <li class="breadcrumb-item" *ngIf="showHome">
          <a 
            [routerLink]="homeUrl" 
            class="breadcrumb-link home-link"
            [attr.aria-label]="homeLabel"
          >
            <fa-icon [icon]="faHome" class="home-icon"></fa-icon>
            <span *ngIf="showHomeText">{{ homeLabel }}</span>
          </a>
          <fa-icon [icon]="faChevronRight" class="separator" *ngIf="items.length > 0"></fa-icon>
        </li>

        <!-- Breadcrumb Items -->
        <li 
          *ngFor="let item of items; let last = last; let i = index" 
          class="breadcrumb-item"
          [class.active]="item.active || last"
        >
          <a 
            *ngIf="item.url && !item.active && !last; else textItem"
            [routerLink]="item.url" 
            class="breadcrumb-link"
          >
            {{ item.label }}
          </a>
          
          <ng-template #textItem>
            <span class="breadcrumb-text">{{ item.label }}</span>
          </ng-template>

          <fa-icon 
            [icon]="faChevronRight" 
            class="separator" 
            *ngIf="!last"
          ></fa-icon>
        </li>
      </ol>
    </nav>
  `,
  styles: [`
    .breadcrumb-nav {
      max-height:1.5rem;
      margin-top: -0.25rem;
    }

    .breadcrumb-list {
      display: flex;
      flex-wrap: wrap;
      align-items: center;
      list-style: none;
      margin: 0;
      padding: 0;
      font-size: 0.9rem;
      gap: 0.5rem;
    }

    .breadcrumb-item {
      display: flex;
      align-items: center;
      gap: 0.5rem;
    }

    .breadcrumb-link {
      color: var(--fm-text-secondary);
      text-decoration: none;
      transition: all 0.2s ease;
      padding: 0.25rem 0.5rem;
      border-radius: 4px;
      font-weight: 500;
      display: flex;
      align-items: center;
      gap: 0.375rem;
    }

    .breadcrumb-link:hover {
      color: var(--fm-primary-blue);
      background: var(--fm-light-blue);
    }

    .breadcrumb-link.home-link {
      color: var(--fm-secondary-blue);
      font-weight: 600;
    }

    .breadcrumb-link.home-link:hover {
      color: var(--fm-primary-blue);
      background: var(--fm-light-blue);
    }

    .breadcrumb-text {
      color: var(--fm-text-primary);
      font-weight: 600;
      padding: 0.25rem 0.5rem;
    }

    .breadcrumb-item.active .breadcrumb-text {
      color: var(--fm-primary-blue);
    }

    .separator {
      color: var(--fm-text-light);
      font-size: 0.75rem;
      flex-shrink: 0;
    }

    .home-icon {
      font-size: 0.875rem;
    }

    /* Responsive Design */
    @media (max-width: 768px) {
      .breadcrumb-list {
        font-size: 0.85rem;
        gap: 0.375rem;
      }

      .breadcrumb-link,
      .breadcrumb-text {
        padding: 0.25rem 0.375rem;
      }

      .separator {
        font-size: 0.7rem;
      }

      .home-icon {
        font-size: 0.8rem;
      }
    }

    @media (max-width: 480px) {
      .breadcrumb-list {
        font-size: 0.8rem;
      }

      /* Hide intermediate items on very small screens, show only first and last */
      .breadcrumb-item:not(:first-child):not(:last-child) {
        display: none;
      }

      /* Add ellipsis when items are hidden */
      .breadcrumb-item:first-child:not(:last-child)::after {
        content: "...";
        color: var(--fm-text-light);
        margin: 0 0.5rem;
        font-weight: bold;
      }
    }
  `]
})
export class BreadcrumbComponent {
  @Input() items: BreadcrumbItem[] = [];
  @Input() showHome: boolean = true;
  @Input() showHomeText: boolean = false;
  @Input() homeUrl: string = '/';
  @Input() homeLabel: string = 'Home';
  @Input() ariaLabel: string = 'Breadcrumb navigation';

  // Font Awesome icons
  faHome = faHome;
  faChevronRight = faChevronRight;

  constructor(private router: Router) {}

  // Helper method to generate breadcrumbs from route
  static fromRoute(items: BreadcrumbItem[]): BreadcrumbItem[] {
    return items.map((item, index, array) => ({
      ...item,
      active: index === array.length - 1
    }));
  }
}
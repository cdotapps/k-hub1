import { Component, Input } from '@angular/core';
import { IconDefinition } from '@fortawesome/fontawesome-svg-core';

@Component({
  selector: 'app-card',
  template: `
    <div [class]="cardClasses">
      <div class="card-header" *ngIf="title || hasHeaderContent">
        <div class="card-header-content">
          <div class="card-title-wrapper">
            <fa-icon *ngIf="icon" [icon]="icon" class="card-title-icon"></fa-icon>
            <h3 class="card-title" *ngIf="title">{{ title }}</h3>
          </div>
          <ng-content select="[slot=header]"></ng-content>
        </div>
      </div>
      <div class="card-body">
        <ng-content></ng-content>
      </div>
      <div class="card-footer" *ngIf="hasFooterContent">
        <ng-content select="[slot=footer]"></ng-content>
      </div>
    </div>
  `,
  styles: [`
    .card {
      background: var(--fm-white);
      border-radius: 8px;
      box-shadow: 0 2px 8px rgba(44, 62, 80, 0.1);
      border: 1px solid #e9ecef;
      overflow: hidden;
    }

    .card-elevated {
      box-shadow: 0 4px 12px rgba(44, 62, 80, 0.15);
    }

    .card-flat {
      box-shadow: none;
      border: 1px solid #e9ecef;
    }

    .card-feature {
      text-align: center;
      padding: 0;
    }

    .card-feature .card-body {
      padding: 2.5rem 2rem;
    }

    .card-statistics {
      border-left: 4px solid var(--fm-primary-blue);
    }

    .card-testimonial {
      border-top: 3px solid var(--fm-secondary-blue);
      position: relative;
    }

    .card-testimonial::before {
      content: '"';
      position: absolute;
      top: 1rem;
      left: 1.5rem;
      font-size: 3rem;
      color: var(--fm-light-blue);
    }

    .card-header {
      padding: 1.5rem 1.5rem 1rem;
      border-bottom: 1px solid #f1f3f4;
      background: var(--fm-white);
    }

    .card-header-content {
      display: flex;
      justify-content: space-between;
      align-items: center;
    }

    .card-title-wrapper {
      display: flex;
      align-items: center;
      gap: 0.75rem;
    }

    .card-title-icon {
      color: var(--fm-primary-blue);
      font-size: 1.25rem;
    }

    .card-title {
      margin: 0;
      font-size: 1.25rem;
      font-weight: 600;
      color: var(--fm-text-primary);
    }

    .card-body {
      padding: 1.5rem;
    }

    .card-footer {
      padding: 0 1.5rem 1.5rem;
      border-top: none;
    }

    .card-sm .card-body {
      padding: 1rem;
    }

    .card-sm .card-header {
      padding: 1rem 1rem 0.75rem;
    }

    .card-sm .card-footer {
      padding: 0 1rem 1rem;
    }

    .card-lg .card-body {
      padding: 2rem;
    }

    .card-lg .card-header {
      padding: 2rem 2rem 1.5rem;
    }

    .card-lg .card-footer {
      padding: 0 2rem 2rem;
    }

    /* Interactive card states - only for clickable cards */
    .card-clickable {
      cursor: pointer;
      transition: all 0.3s ease;
    }

    .card-clickable:hover {
      box-shadow: 0 6px 20px rgba(0, 63, 127, 0.15);
      transform: translateY(-3px);
    }

    .card-clickable:active {
      transform: translateY(-1px);
    }
  `]
})
export class CardComponent {
  @Input() title?: string;
  @Input() icon?: IconDefinition;
  @Input() variant: 'default' | 'elevated' | 'flat' | 'feature' | 'statistics' | 'testimonial' = 'default';
  @Input() size: 'sm' | 'md' | 'lg' = 'md';
  @Input() clickable: boolean = false;

  hasHeaderContent = false;
  hasFooterContent = false;

  ngAfterContentInit() {
    // Check if there's content projected into header/footer slots
    // This is a simplified check - in a real implementation you might use ViewChild
    this.hasHeaderContent = !!this.title;
    this.hasFooterContent = true; // Assume footer content exists if slot is used
  }

  get cardClasses(): string {
    const classes = ['card'];
    
    if (this.variant !== 'default') {
      classes.push(`card-${this.variant}`);
    }
    
    if (this.size !== 'md') {
      classes.push(`card-${this.size}`);
    }
    
    if (this.clickable) {
      classes.push('card-clickable');
    }
    
    return classes.join(' ');
  }
}
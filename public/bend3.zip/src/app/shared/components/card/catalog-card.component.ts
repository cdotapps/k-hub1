import { Component, Input, Output, EventEmitter, OnInit, ChangeDetectionStrategy, OnDestroy } from '@angular/core';
import { Catalog } from '../../models/user.interface';
import { CatalogService } from '../../services/catalog.service';
import { DateUtilityService } from '../../services/date-utility.service';
import { PopupContainerComponent } from '../popup-container/popup-container.component';

// FontAwesome Icons
import { 
  faEye, faEdit, faTrash, faCopy, faEllipsisV, faUser, faClock, faHeart, faShare,
  faNewspaper, faFileAlt, faBell, faBook, faGraduationCap, faBlog, faFlask,
  faFileContract, faChartLine, faLightbulb, faBookOpen, faFileImage, faVideo,
  faMicrophone, faCheckCircle, faTimesCircle, faExclamationCircle, faLock,
  faUnlock, faThumbsUp, faThumbsDown, faDownload, faExternalLinkAlt, faPlus,
  faUserCheck, faCrown, faUsers, faUserFriends
} from '@fortawesome/free-solid-svg-icons';

@Component({
  selector: 'app-catalog-card',
  templateUrl: './catalog-card.component.html',
  styleUrls: ['./catalog-card.component.css'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class CatalogCardComponent implements OnInit, OnDestroy {
  @Input() item!: Catalog;
  @Input() isOwner: boolean = false;
  @Input() isRecent: boolean = false;
  @Input() viewMode: 'grid' | 'list' = 'grid';
  @Input() currentUserId?: string; // Add current user ID input

  @Output() cardClick = new EventEmitter<Catalog>();
  @Output() editClick = new EventEmitter<{ item: Catalog; event: Event }>();
  @Output() deleteClick = new EventEmitter<{ item: Catalog; event: Event }>();
  @Output() copyClick = new EventEmitter<{ item: Catalog; event: Event }>();
  @Output() actionClick = new EventEmitter<{ action: string; item: Catalog; event: Event }>();
  @Output() duplicateSuccess = new EventEmitter<Catalog>(); // New event for successful duplication

  // FontAwesome Icons
  faEye = faEye;
  faEdit = faEdit;
  faTrash = faTrash;
  faCopy = faCopy;
  faEllipsisV = faEllipsisV;
  faUser = faUser;
  faClock = faClock;
  faHeart = faHeart;
  faShare = faShare;
  faNewspaper = faNewspaper;
  faFileAlt = faFileAlt;
  faBell = faBell;
  faBook = faBook;
  faGraduationCap = faGraduationCap;
  faBlog = faBlog;
  faFlask = faFlask;
  faFileContract = faFileContract;
  faChartLine = faChartLine;
  faLightbulb = faLightbulb;
  faBookOpen = faBookOpen;
  faFileImage = faFileImage;
  faVideo = faVideo;
  faMicrophone = faMicrophone;
  faCheckCircle = faCheckCircle;
  faTimesCircle = faTimesCircle;
  faExclamationCircle = faExclamationCircle;
  faLock = faLock;
  faUnlock = faUnlock;
  faThumbsUp = faThumbsUp;
  faThumbsDown = faThumbsDown;
  faDownload = faDownload;
  faExternalLinkAlt = faExternalLinkAlt;
  faPlus = faPlus; // Add icon for created action
  faUserCheck = faUserCheck; // Icon for approval request
  faCrown = faCrown; // Icon for owner status
  faUsers = faUsers; // Icon for shared by me
  faUserFriends = faUserFriends; // Icon for shared by others

  // State
  showActionsPopup = false;
  showSharePopup = false; // Add share popup state
  popupPosition = { x: 0, y: 0 };
  isDuplicating = false; // Add loading state for duplication
  shareSuccessMessage = ''; // Add success message state

  // Add caching for relative time to prevent expression changed errors
  private _cachedRelativeTime: string = '';
  private _cachedLastAction: { type: 'created' | 'updated'; timestamp: string; relativeTime: string } | null = null;
  private _lastTimeCalculation: number = 0;
  private _timeUpdateInterval: any;

  constructor(
    private catalogService: CatalogService,
    private dateUtilityService: DateUtilityService
  ) {}

  ngOnInit(): void {
    // Calculate initial relative time
    this.updateRelativeTime();
    
    // Update relative time every minute to prevent expression changed errors
    this._timeUpdateInterval = setInterval(() => {
      this.updateRelativeTime();
    }, 60000); // Update every minute
  }

  ngOnDestroy(): void {
    if (this._timeUpdateInterval) {
      clearInterval(this._timeUpdateInterval);
    }
    
    // Clean up any remaining event listeners
    this.closeActionsPopup();
  }

  /**
   * Handle card click - emit the catalog item
   */
  onCardClick(): void {
    this.cardClick.emit(this.item);
  }

  /**
   * Handle edit button click
   */
  onEditClick(event: Event): void {
    event.stopPropagation();
    this.editClick.emit({ item: this.item, event });
  }

  /**
   * Handle delete button click
   */
  onDeleteClick(event: Event): void {
    event.stopPropagation();
    this.deleteClick.emit({ item: this.item, event });
  }

  /**
   * Handle copy button click - delegate to parent component
   */
  onCopyClick(event: Event): void {
    event.stopPropagation();
    this.copyClick.emit({ item: this.item, event });
  }

  /**
   * Handle action button click - emit action with key and event
   */
  handleActionClick(actionKey: string, event: Event): void {
    event.stopPropagation();
    this.actionClick.emit({ action: actionKey, item: this.item, event });
  }

  /**
   * Toggle actions popup
   */
  toggleActionsPopup(event: Event): void {
    event.stopPropagation();
    if (this.showActionsPopup) {
      this.closeActionsPopup();
      return;
    }

    const target = event.target as HTMLElement;
    const rect = target.getBoundingClientRect();
    this.popupPosition = { x: rect.left - 150, y: rect.bottom + 5 };
    this.showActionsPopup = true;
  }

  /**
   * Close actions popup
   */
  closeActionsPopup(): void {
    this.showActionsPopup = false;
  }

  /**
   * Open the share popup
   */
  openSharePopup(): void {
    this.showSharePopup = true;
  }

  /**
   * Close the share popup
   */
  closeSharePopup(): void {
    this.showSharePopup = false;
  }

  
  /**
   * Get catalog type icon
   */
  getCatalogTypeIcon(): any {
    const typeIconMap: { [key: string]: any } = {
      'news': this.faNewspaper,
      'article': this.faFileAlt,
      'notification': this.faBell,
      'document': this.faFileContract,
      'guide': this.faBook,
      'tutorial': this.faGraduationCap,
      'blog': this.faBlog,
      'research': this.faFlask,
      'whitepaper': this.faFileContract,
      'case-study': this.faChartLine,
      'insight': this.faLightbulb,
      'report': this.faBookOpen,
      'image': this.faFileImage,
      'video': this.faVideo,
      'audio': this.faMicrophone
    };
    return typeIconMap[this.item.type] || this.faFileAlt;
  }

  /**
   * Get status icon
   */
  getStatusIcon(): any {
    const statusIconMap: { [key: string]: any } = {
      'published': this.faCheckCircle,
      'draft': this.faExclamationCircle,
      'pending': this.faClock,
      'approved': this.faCheckCircle,
      'rejected': this.faTimesCircle,
      'archived': this.faLock
    };
    return statusIconMap[this.item.status || 'draft'] || this.faExclamationCircle;
  }

  /**
   * Get status color class
   */
  getStatusColorClass(): string {
    const statusColorMap: { [key: string]: string } = {
      'published': 'status-published',
      'draft': 'status-draft',
      'pending': 'status-pending',
      'approved': 'status-approved',
      'rejected': 'status-rejected',
      'archived': 'status-archived'
    };
    return statusColorMap[this.item.status || 'draft'] || 'status-draft';
  }

  /**
   * Get type color class
   */
  getTypeColorClass(): string {
    const typeColorMap: { [key: string]: string } = {
      'news': 'type-news',
      'article': 'type-article',
      'notification': 'type-notification',
      'document': 'type-document',
      'guide': 'type-guide',
      'tutorial': 'type-tutorial',
      'blog': 'type-blog',
      'research': 'type-research',
      'whitepaper': 'type-whitepaper',
      'case-study': 'type-case-study'
    };
    return typeColorMap[this.item.type] || 'type-default';
  }

  /**
   * Format date for display
   */
  formatDate(dateString: string | undefined): string {
    return this.dateUtilityService.formatDate(dateString);
  }

  /**
   * Update cached relative time
   */
  private updateRelativeTime(): void {
    const now = Date.now();
    // Only update if more than 30 seconds have passed to prevent frequent updates
    if (now - this._lastTimeCalculation > 30000) {
      this._cachedRelativeTime = this.dateUtilityService.formatRelativeTime(this.item.created_date || '');
      this._lastTimeCalculation = now;
    }
  }

  /**
   * Get cached relative time to prevent expression changed errors
   */
  getRelativeTime(dateString: string | undefined): string {
    if (!dateString) return '';
    
    // Return cached value to prevent expression changed errors
    if (this._cachedRelativeTime) {
      return this._cachedRelativeTime;
    }
    
    // Calculate and cache initial value using DateUtilityService
    this._cachedRelativeTime = this.dateUtilityService.formatRelativeTime(dateString);
    this._lastTimeCalculation = Date.now();
    return this._cachedRelativeTime;
  }

  /**
   * Get the timestamp of the last action (created or updated) with better validation
   */
  getLastActionTimestamp(): string {
    // Prioritize updated_date if it exists and is different from created_date
    if (this.item.updated_date && 
        this.item.updated_date !== this.item.created_date &&
        this.isValidDate(this.item.updated_date)) {
      
      const updatedTime = new Date(this.item.updated_date).getTime();
      const createdTime = new Date(this.item.created_date || '').getTime();
      
      // Only use updated_date if it's actually later than created_date
      if (updatedTime > createdTime) {
        return this.item.updated_date;
      }
    }
    
    // Fall back to created_date or published_at
    return this.item.created_date || this.item.published_at || '';
  }

  /**
   * Determine if the last action was 'created' or 'updated' with better logic
   */
  getLastActionType(): 'created' | 'updated' {
    if (!this.item.updated_date || !this.isValidDate(this.item.updated_date)) {
      return 'created';
    }
    
    if (!this.item.created_date || !this.isValidDate(this.item.created_date)) {
      return 'updated';
    }
    
    const updatedTime = new Date(this.item.updated_date).getTime();
    const createdTime = new Date(this.item.created_date).getTime();
    
    // Consider it updated if updated_date is more than 1 minute after created_date
    return (updatedTime - createdTime) > 60000 ? 'updated' : 'created';
  }

  /**
   * Check if a date string is valid
   */
  private isValidDate(dateString: string): boolean {
    if (!dateString) return false;
    const date = new Date(dateString);
    return !isNaN(date.getTime()) && date.getTime() > 0;
  }

  /**
   * Get cached last action info to prevent expression changed errors
   */
  getLastActionInfo(): { type: 'created' | 'updated'; icon: any; label: string; relativeTime: string } {
    // Simplify the logic and remove problematic caching
    const lastActionType = this.getLastActionType();
    const lastActionTimestamp = this.getLastActionTimestamp();
    
    // If no valid timestamp, return a fallback
    if (!lastActionTimestamp) {
      return {
        type: 'created',
        icon: this.faPlus,
        label: 'Created',
        relativeTime: 'Unknown'
      };
    }
    
    // Calculate relative time directly without complex caching
    const relativeTime = this.dateUtilityService.formatRelativeTime(lastActionTimestamp);
    
    return {
      type: lastActionType,
      icon: lastActionType === 'updated' ? this.faEdit : this.faPlus,
      label: lastActionType === 'updated' ? 'Updated' : 'Created',
      relativeTime: relativeTime
    };
  }

  /**
   * Get truncated description for display
   */
  getTruncatedDescription(maxLength: number = 120): string {
    if (!this.item.description) return '';
    
    if (this.item.description.length <= maxLength) {
      return this.item.description;
    }
    
    // Find the last space before the max length to avoid cutting words
    const truncated = this.item.description.substring(0, maxLength);
    const lastSpaceIndex = truncated.lastIndexOf(' ');
    
    if (lastSpaceIndex > 0 && lastSpaceIndex > maxLength * 0.8) {
      return truncated.substring(0, lastSpaceIndex) + '...';
    }
    
    return truncated + '...';
  }

  /**
   * Get author name from the catalog item
   */
  getAuthorName(): string {
    if (this.item.author) {
      return this.item.author;
    }
    return 'Unknown Author';
  }

  /**
   * Calculate estimated reading time based on content length
   */
  getReadingTime(): string {
    if (!this.item.content && !this.item.description) {
      return '1 min read';
    }
    
    // Combine content and description for word count
    const text = (this.item.content || '') + ' ' + (this.item.description || '');
    
    // Average reading speed is about 200-250 words per minute
    const wordsPerMinute = 225;
    const wordCount = text.trim().split(/\s+/).length;
    const readingTimeMinutes = Math.ceil(wordCount / wordsPerMinute);
    
    if (readingTimeMinutes < 1) {
      return '1 min read';
    } else if (readingTimeMinutes === 1) {
      return '1 min read';
    } else {
      return `${readingTimeMinutes} min read`;
    }
  }

  /**
   * Get available actions for the actions popup
   */
  getAvailableActions(): Array<{ key: string; label: string; icon: any; class?: string; disabled?: boolean }> {
    const actions: Array<{ key: string; label: string; icon: any; class?: string; disabled?: boolean }> = [
      { key: 'copy', label: 'Duplicate', icon: this.faCopy }
    ];

    // Add owner-only actions
    if (this.isOwner) {
      actions.push(
        { key: 'edit', label: 'Edit', icon: this.faEdit }
      );
      
      // Show approval request option only if item is not already approved or pending approval
      const shouldShowApproval = !this.item.approved_by && 
        this.item.status !== 'pending' && 
        this.item.status !== 'approved';
      
      if (shouldShowApproval) {
        actions.push(
          { key: 'approval', label: 'Request Approval', icon: this.faUserCheck }
        );
      }
      
      actions.push(
        { key: 'share', label: 'Share', icon: this.faShare }
      );
    }

    // Add additional actions based on item status
    if (this.item.url) {
      actions.push({ key: 'external', label: 'Open Link', icon: this.faExternalLinkAlt });
    }

    return actions;
  }

  /**
   * Get sharing status of the catalog item
   * Returns: 'owner' | 'shared-by-me' | 'shared-with-me' | null
   */
  getSharingStatus(): 'owner' | 'shared-by-me' | 'shared-with-me' | null {
    if (this.isOwner) {
      // Check if item is shared by current user (owner)
      if (this.item.shared_with && this.item.shared_with.length > 0) {
        return 'shared-by-me';
      }
      return 'owner';
    } else {
      // Check if item is shared with current user
      if (this.currentUserId && this.item.shared_with) {
        const hasAccess = this.item.shared_with.some(user => {
          // Handle both string array and SharedUser object array
          return typeof user === 'string' ? user === this.currentUserId : user.id === this.currentUserId;
        });
        if (hasAccess) {
          return 'shared-with-me';
        }
      }
    }
    return null;
  }

  /**
   * Get the appropriate icon for sharing status
   */
  getSharingStatusIcon() {
    const status = this.getSharingStatus();
    switch (status) {
      case 'owner':
        return this.faCrown;
      case 'shared-by-me':
        return this.faUsers;
      case 'shared-with-me':
        return this.faUserFriends;
      default:
        return this.faUser; // Default fallback icon
    }
  }

  /**
   * Get the tooltip text for sharing status
   */
  getSharingStatusTooltip(): string {
    const status = this.getSharingStatus();
    switch (status) {
      case 'owner':
        return 'You own this item';
      case 'shared-by-me':
        return `Shared with ${this.item.shared_with?.length || 0} user(s)`;
      case 'shared-with-me':
        return 'Shared with you';
      default:
        return '';
    }
  }

  /**
   * Get CSS class for sharing status
   */
  getSharingStatusClass(): string {
    const status = this.getSharingStatus();
    return status ? `sharing-status-${status}` : '';
  }
}
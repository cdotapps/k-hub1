import { Component, Input, Output, EventEmitter } from '@angular/core';
import { IconDefinition } from '@fortawesome/fontawesome-svg-core';

export interface OverlapButtonConfig {
  icon: IconDefinition;
  label: string;
  badgeCount?: number;
  isActive?: boolean;
  iconVariant?: 'primary' | 'secondary' | 'success' | 'warning' | 'danger' | 'muted' | 'white';
  route?: string;
}

@Component({
  selector: 'app-overlap-button',
  template: `
    <div 
      class="overlap-item" 
      [class.active]="isActive"
      (click)="onButtonClick()"
      [attr.aria-label]="label"
      role="button"
      tabindex="0"
      (keydown.enter)="onButtonClick()"
      (keydown.space)="onButtonClick()"
    >
      <div class="badge-container">
        <app-icon 
          [faIcon]="icon" 
          size="lg" 
          [variant]="iconVariant || 'primary'"
        ></app-icon>
        <span 
          class="overlap-badge" 
          *ngIf="badgeCount && badgeCount > 0"
          [attr.aria-label]="badgeCount + ' notifications'"
        >
          {{ badgeCount > 99 ? '99+' : badgeCount }}
        </span>
      </div>
      <span class="overlap-text">{{ label }}</span>
    </div>
  `,
  styles: [`
    .overlap-item {
      margin-top: 10px;
      text-align: center;
      padding: 0.5rem;
      display: flex;
      flex-direction: column;
      justify-content: center;
      align-items: center;
      flex-shrink: 0;
      padding:0;
      width: 100px;
      height: 100px;
      cursor: pointer;
      border-radius: 12px;
      transition: all 0.3s ease;
      position: relative;
      overflow: hidden;
      border: 0px solid rgba(0, 0, 0, 0.1);
      .icon{
        font-size: 1.5rem;
        transition: color 0.3s ease;
        color: var(--fm-primary-blue);
      }
      
      
    }
    
    .overlap-item.active {
      background: linear-gradient(135deg, var(--fm-primary-blue), var(--fm-secondary-blue));
      color: white;
      transform: translateY(-3px);
      box-shadow: 0 6px 20px rgba(0, 63, 127, 0.25);
    }
    
    .overlap-item.active .overlap-text {
      color: white;
      font-weight: 700;
    }
    
    .badge-container {
      position: relative;
      display: inline-block;
      margin-bottom: 0.5rem;
    }
    
    .overlap-badge {
      position: absolute;
      top: -5px;
      right: -20px;
      background: var(--fm-red);
      color: white;
      border-radius: 50%;
      min-width: 24px;
      height: 24px;
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 0.75rem;
      font-weight: 700;
      border: 2px solid white;
      box-shadow: 0 2px 4px rgba(0, 0, 0, 0.2);
      transition: all 0.3s ease;
      z-index: 10;
      padding: 0 4px;
    }
    
    .overlap-item:hover .overlap-badge {
      transform: scale(1.1);
    }
    
    .overlap-item::before {
      content: '';
      position: absolute;
      top: 0;
      left: -100%;
      width: 100%;
      height: 100%;
      background: linear-gradient(90deg, transparent, rgba(255,255,255,0.2), transparent);
      transition: left 0.5s;
    }
    
    .overlap-item:hover::before {
      left: 100%;
    }
    
    .overlap-item:hover {
      background: linear-gradient(135deg, var(--fm-primary-blue), var(--fm-secondary-blue));
      color: white;
      transform: translateY(-5px);
      box-shadow: 0 8px 25px rgba(0, 63, 127, 0.3);
      .icon{
        color: var(--fm-white);
      }
     
    }
    
    .overlap-item:hover .overlap-text {
      color: white;
    }
    
    .overlap-item:active {
      transform: translateY(-2px);
      transition: transform 0.1s ease;
    }
    
    .overlap-item:focus {
      outline: 2px solid var(--fm-primary-blue);
      outline-offset: 2px;
    }
    
    .overlap-text {
      font-size: 0.875rem;
      font-weight: 600;
      color: var(--fm-text-primary);
      padding: 0 0.5rem;
      line-height: 1.2;
      transition: color 0.3s ease;
      text-align: center;
      word-break: break-word;
    }
    
    /* Responsive Design */
    @media (max-width: 768px) {
      .overlap-item {
        min-width: 65px;
        width: 65px;
        height: 80px;
        padding: 0.25rem;
      }
      
      .overlap-text {
        font-size: 0.7rem;
        line-height: 1.1;
      }
      
      .overlap-badge {
        min-width: 20px;
        height: 20px;
        font-size: 0.65rem;
        top: -3px;
        right: -15px;
      }
    }
  `]
})
export class OverlapButtonComponent {
  @Input() icon!: IconDefinition;
  @Input() label!: string;
  @Input() badgeCount?: number;
  @Input() isActive: boolean = false;
  @Input() iconVariant?: 'primary' | 'secondary' | 'success' | 'warning' | 'danger' | 'muted' | 'white' = 'primary';
  @Input() route?: string;
  @Input() disabled: boolean = false;
  
  @Output() buttonClick = new EventEmitter<string>();
  
  onButtonClick(): void {
    if (!this.disabled) {
      this.buttonClick.emit(this.route || this.label.toLowerCase().replace(/\s+/g, '-'));
    }
  }
}
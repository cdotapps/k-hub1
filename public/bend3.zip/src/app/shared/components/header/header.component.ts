import { Component, OnInit, OnDestroy, ViewChild } from '@angular/core';
import { faHome, faChevronDown, faCode, faRocket, faMobile, faCloud, faRobot, faBitcoinSign, faWifi, faCogs, faChartLine, faUsers, faTasks, faShieldAlt, faLightbulb, faCreditCard, faBell, faUser, faSignOutAlt, faNewspaper } from '@fortawesome/free-solid-svg-icons';
import { Router } from '@angular/router';
import { AuthService } from '../../services/auth.service';
import { CatalogService } from '../../services/catalog.service';
import { User, Catalog } from '../../models/user.interface';
import { Subscription } from 'rxjs';
import { NewsBarComponent } from '../news-bar/news-bar.component';
import { 
  APP_CONFIG, 
  HEADER_MEGA_MENUS, 
  USER_MENU_ITEMS, 
  MOBILE_MENU_ITEMS, 
  filterMegaMenusByRole, 
  filterItemsByRole,
  MegaMenu,
  MenuItem
} from '../../config/site-config';

@Component({
  selector: 'app-header',
  template: `
    <header class="header">
      <nav class="navbar">
        <app-container>
          <div class="nav-wrapper">
            <!-- Brand with Home Icon -->
            <div class="nav-brand" (click)="navigateTo('')">
              <img [src]="appConfig.logo" [alt]="appConfig.logoAlt" class="nav-logo">
              <h1>FST</h1><span class="title">Hub</span>
            </div>

            <!-- Navigation Menu -->
            <div class="nav-menu" *ngIf="isAuthenticated">
              <!-- Dynamic Mega Menus -->
              <div class="nav-item dropdown" 
                   *ngFor="let menu of visibleMegaMenus"
                   (mouseenter)="showMegaMenu(menu.id)" 
                   (mouseleave)="hideMegaMenu(menu.id)">
                <a class="nav-link">
                  {{ menu.label }}
                  <app-icon [faIcon]="menu.icon" size="xs" color="white"></app-icon>
                </a>
                <div class="mega-menu" [class.active]="activeMegaMenu === menu.id" [style.width]="menu.width || '600px'">
                  <div class="mega-menu-content" [ngStyle]="{'grid-template-columns': menu.sections.length === 1 ? '1fr' : 'repeat(2, 1fr)'}">
                    <div class="mega-menu-section" *ngFor="let section of menu.sections">
                      <h4>{{ section.title }}</h4>
                      
                      <!-- Regular links section -->
                      <ul *ngIf="section.type === 'links'">
                        <li *ngFor="let item of section.items">
                          <a [routerLink]="item.path?.startsWith('/') ? item.path : null" 
                             [href]="item.external || !item.path?.startsWith('/') ? item.path : null"
                             [attr.target]="item.external ? '_blank' : undefined"
                             (click)="closeMegaMenu()">
                            {{ item.label }}
                          </a>
                        </li>
                      </ul>
                      
                      <!-- App icons grid section -->
                      <div class="app-grid" *ngIf="section.type === 'apps'">
                        <div class="app-item" *ngFor="let app of section.items">
                          <app-icon [faIcon]="app.icon" size="lg" [variant]="app.variant"></app-icon>
                          <span>{{ app.label }}</span>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <!-- User Section -->
            <div class="user-section" *ngIf="isAuthenticated">
              <!-- News Button -->
              <div class="news-wrapper" (click)="toggleNews()">
                <app-icon [faIcon]="faNewspaper" size="md" color="white"></app-icon>
                <span class="news-badge" *ngIf="hasUnreadNews">●</span>
              </div>

              <!-- Notifications -->
              <div class="notification-wrapper" (click)="toggleNotifications()">
                <app-icon [faIcon]="faBell" size="md" color="white"></app-icon>
                <span class="notification-badge" *ngIf="notificationCount > 0">{{ notificationCount }}</span>
              </div>

              <!-- User Menu -->
              <div class="user-menu dropdown" 
                   (mouseenter)="showUserMenu()" 
                   (mouseleave)="hideUserMenu()">
                <div class="user-info">
                  <div class="user-avatar">
                    <app-icon [faIcon]="faUser" size="sm" color="white"></app-icon>
                  </div>
                  <span class="user-name">{{ getUserDisplayName() }}</span>
                  <app-icon [faIcon]="faChevronDown" size="xs" color="white"></app-icon>
                </div>
                
                <!-- User Dropdown Menu -->
                <div class="user-dropdown" [class.active]="showUserDropdown">
                  <div class="user-dropdown-content">
                    <div class="user-profile">
                      <div class="user-avatar-large">
                        <app-icon [faIcon]="faUser" size="lg" variant="primary"></app-icon>
                      </div>
                      <div class="user-details">
                        <h4>{{ getUserDisplayName() }}</h4>
                        <p>{{ getUserEmail() }}</p>
                        <small *ngIf="currentUser?.role" class="user-role">{{ currentUser?.role | titlecase }}</small>
                      </div>
                    </div>
                    <hr class="dropdown-divider">
                    <ul class="user-menu-items">
                      <li *ngFor="let item of visibleUserMenuItems">
                        <a (click)="item.label === 'Sign Out' ? logout($event) : navigateTo(item.path || '')" class="user-menu-link" [ngClass]="{'logout-link': item.label === 'Sign Out'}">
                          <app-icon [faIcon]="item.icon" size="sm" [variant]="item.variant"></app-icon>
                          {{ item.label }}
                        </a>
                      </li>
                    </ul>
                    <hr class="dropdown-divider">
                  </div>
                </div>
              </div>

              <!-- Mobile Menu Toggle -->
              <div class="mobile-menu-toggle" (click)="toggleMobileMenu()">
                <span></span>
                <span></span>
                <span></span>
              </div>
            </div>

            <!-- Login/Register buttons for non-authenticated users -->
            <div class="auth-buttons" *ngIf="!isAuthenticated">
              <button class="auth-btn login-btn" (click)="navigateTo('login')">
                Sign In
              </button>
              <button class="auth-btn register-btn" (click)="navigateTo('register')">
                Sign Up
              </button>
            </div>
          </div>
        </app-container>
      </nav>

      <!-- Mobile Menu -->
      <div class="mobile-menu" [class.active]="mobileMenuOpen" *ngIf="isAuthenticated">
        <div class="mobile-menu-item" *ngFor="let item of visibleMobileMenuItems">
          <a [routerLink]="item.path" class="mobile-menu-link">{{ item.label }}</a>
        </div>
      </div>

      <!-- Notifications Panel -->
      <app-notifications-panel 
        [isOpen]="showNotifications"
        [notifications]="notifications"
        (closePanel)="toggleNotifications()"
        *ngIf="isAuthenticated">
      </app-notifications-panel>
    </header>

    <!-- News Bar Component - Controlled by header news icon -->
    <app-news-bar 
      #newsBarRef
      *ngIf="isAuthenticated"
      [forceVisible]="showNewsPopup">
    </app-news-bar>
  `,
  styles: [`
    .header {
      background: linear-gradient(135deg, var(--fm-primary-blue) 0%, var(--fm-navy) 100%);
      color: var(--fm-white);
      padding: 0;
      box-shadow: 0 4px 20px rgba(0, 63, 127, 0.25);
      position: relative;
      z-index: 1000;
    }
    
    .navbar {
      padding: 1rem 0;
    }
    
    .nav-wrapper {
      display: flex;
      justify-content: space-between;
      align-items: center;
    }
    .title{
      opacity: 0.75;
      color: var(--fm-gre);
      margin:-10px -10px 0 0;
      font-size: 1.2rem;
      font-weight: 600;
      padding:0;
    }
    
    .nav-brand {
      display: flex;
      align-items: center;
      gap: 0.75rem;
      cursor: pointer;
      transition: transform 0.3s ease;
    }

    .nav-logo {
      height: 50px;
      margin-right: 0.5rem;
      shadow: 0 4px 20px rgba(0, 63, 127, 0.25);
    }
    
    .nav-brand:hover {
      transform: translateY(-1px);
    }
    
    .nav-brand h1 {
      margin: 0;
      font-size: 1.8rem;
      font-weight: 700;
      color: var(--fm-white);
    }
    
    .nav-menu {
      display: flex;
      align-items: center;
      gap: 2rem;
    }
    
    .nav-item {
      position: relative;
    }
    
    .nav-link {
      display: flex;
      align-items: center;
      gap: 0.5rem;
      color: var(--fm-white);
      text-decoration: none;
      font-weight: 600;
      font-size: 1.1rem;
      padding: 0.75rem 1rem;
      border-radius: 8px;
      transition: all 0.3s ease;
      cursor: pointer;
    }
    
    .nav-link:hover {
      background: rgba(255, 255, 255, 0.1);
      transform: translateY(-1px);
    }
    
    /* Mega Menu Styles */
    .mega-menu {
      position: absolute;
      top: 100%;
      left: -50px;
      width: 600px;
      background: var(--fm-white);
      border-radius: 12px;
      box-shadow: 0 20px 60px rgba(0, 0, 0, 0.15);
      opacity: 0;
      visibility: hidden;
      transform: translateY(-10px);
      transition: all 0.3s ease;
      border: 1px solid rgba(0, 0, 0, 0.1);
      z-index: 100;
    }
    
    .mega-menu.active {
      opacity: 1;
      visibility: visible;
      transform: translateY(0);
    }
    
    .mega-menu-content {
      display: grid;
      grid-template-columns: repeat(2, 1fr);
      gap: 1.5rem;
      padding: 1.5rem;
    }
    
    .mega-menu-section h4 {
      margin: 0 0 0.75rem 0;
      font-size: 1.1rem;
      font-weight: 700;
      color: var(--fm-primary-blue);
      border-bottom: 2px solid var(--fm-light-blue);
      padding-bottom: 0.25rem;
    }
    
    .mega-menu-section ul {
      list-style: none;
      margin: 0;
      padding: 0;
    }
    
    .mega-menu-section li {
      margin-bottom: 0.25rem;
    }
    
    .mega-menu-section a {
      color: var(--fm-text-primary);
      text-decoration: none;
      font-size: 0.9rem;
      padding: 0.35rem 0;
      display: block;
      transition: all 0.3s ease;
      border-radius: 4px;
    }
    
    .mega-menu-section a:hover {
      color: var(--fm-primary-blue);
      background: var(--fm-bg-light);
      padding-left: 0.5rem;
    }
    
    /* App Icons Section */
    .app-grid {
      display: grid;
      grid-template-columns: repeat(2, 1fr);
      gap: 0.75rem;
      margin-top: 0.5rem;
    }
    
    .app-item {
      display: flex;
      flex-direction: column;
      align-items: center;
      text-align: center;
      padding: 0.75rem 0.5rem;
      border-radius: 8px;
      transition: all 0.3s ease;
      cursor: pointer;
      text-decoration: none;
      background: var(--fm-bg-light);
      border: 1px solid transparent;
    }
    
    .app-item:hover {
      background: var(--fm-white);
      transform: translateY(-2px);
      box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
      border-color: var(--fm-border-light);
    }
    
    .app-item span {
      margin-top: 0.35rem;
      font-size: 0.8rem;
      font-weight: 600;
      color: var(--fm-text-primary);
    }
    
    .app-item app-icon {
      margin-bottom: 0.15rem;
    }
    
    /* User Section Styles */
    .user-section {
      display: flex;
      align-items: center;
      gap: 1.5rem;
    }
    
    .news-wrapper {
      position: relative;
      cursor: pointer;
      padding: 0.5rem;
      border-radius: 8px;
      transition: all 0.3s ease;
    }
    
    .news-wrapper:hover {
      background: rgba(255, 255, 255, 0.1);
      transform: translateY(-1px);
    }
    
    .news-badge {
      position: absolute;
      top: 0;
      right: 2px;
      color: var(--fm-orange);
      font-size: 0.8rem;
      font-weight: 700;
      animation: pulse 2s infinite;
    }
    
    @keyframes pulse {
      0%, 100% { opacity: 1; }
      50% { opacity: 0.5; }
    }
    
    .notification-wrapper {
      position: relative;
      cursor: pointer;
      padding: 0.5rem;
      border-radius: 8px;
      transition: background 0.3s ease;
    }
    
    .notification-wrapper:hover {
      background: rgba(255, 255, 255, 0.1);
    }
    
    .notification-badge {
      position: absolute;
      top: -2px;
      right: -2px;
      background: var(--fm-red);
      color: white;
      border-radius: 50%;
      width: 18px;
      height: 18px;
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 0.6rem;
      font-weight: 700;
      border: 2px solid var(--fm-primary-blue);
    }
    
    .user-menu {
      position: relative;
    }
    
    .user-info {
      display: flex;
      align-items: center;
      gap: 0.75rem;
      cursor: pointer;
      padding: 0.5rem 1rem;
      border-radius: 8px;
      transition: all 0.3s ease;
    }
    
    .user-info:hover {
      background: rgba(255, 255, 255, 0.1);
    }
    
    .user-avatar {
      width: 32px;
      height: 32px;
      border-radius: 50%;
      background: rgba(255, 255, 255, 0.2);
      display: flex;
      align-items: center;
      justify-content: center;
    }
    
    .user-name {
      font-weight: 600;
      font-size: 0.95rem;
      color: var(--fm-white);
    }
    
    .user-dropdown {
      position: absolute;
      top: 100%;
      right: 0;
      width: 280px;
      background: var(--fm-white);
      border-radius: 12px;
      box-shadow: 0 20px 60px rgba(0, 0, 0, 0.15);
      opacity: 0;
      visibility: hidden;
      transform: translateY(-10px);
      transition: all 0.3s ease;
      border: 1px solid rgba(0, 0, 0, 0.1);
      z-index: 100;
    }
    
    .user-dropdown.active {
      opacity: 1;
      visibility: visible;
      transform: translateY(0);
    }
    
    .user-dropdown-content {
      padding: 1rem;
    }
    
    .user-profile {
      display: flex;
      align-items: center;
      gap: 0.75rem;
      margin-bottom: 0.75rem;
    }
    
    .user-avatar-large {
      width: 40px;
      height: 40px;
      border-radius: 50%;
      background: var(--fm-bg-light);
      display: flex;
      align-items: center;
      justify-content: center;
    }
    
    .user-details h4 {
      margin: 0;
      font-size: 1rem;
      font-weight: 700;
      color: var(--fm-text-primary);
    }
    
    .user-details p {
      margin: 0.15rem 0 0 0;
      font-size: 0.8rem;
      color: var(--fm-text-secondary);
    }
    
    .dropdown-divider {
      border: none;
      height: 1px;
      background: var(--fm-border-light);
      margin: 0.75rem 0;
    }
    
    .user-menu-items {
      list-style: none;
      margin: 0;
      padding: 0;
    }
    
    .user-menu-items li {
      margin-bottom: 0.25rem;
    }
    
    .user-menu-link {
      display: flex;
      align-items: center;
      gap: 0.6rem;
      color: var(--fm-text-primary);
      text-decoration: none;
      padding: 0.35rem 0.5rem;
      border-radius: 4px;
      transition: all 0.3s ease;
      font-size: 0.9rem;
    }
    
    .user-menu-link:hover {
      color: var(--fm-primary-blue);
      background: var(--fm-bg-light);
      padding-left: 0.75rem;
    }
    
    .logout-link {
      color: var(--fm-red) !important;
    }
    
    .logout-link:hover {
      background: rgba(239, 68, 68, 0.1) !important;
    }
    
    /* Notifications Panel */
    .notifications-panel {
      position: fixed;
      top: 0;
      right: -400px;
      width: 400px;
      height: 100vh;
      background: var(--fm-white);
      box-shadow: -4px 0 20px rgba(0, 0, 0, 0.15);
      transition: right 0.3s ease;
      z-index: 1001;
      overflow-y: auto;
    }
    
    .notifications-panel.active {
      right: 0;
    }
    
    .notifications-header {
      display: flex;
      justify-content: space-between;
      align-items: center;
      padding: 1.5rem;
      border-bottom: 1px solid var(--fm-border-light);
      background: var(--fm-primary-blue);
      color: white;
    }
    
    .notifications-header h3 {
      margin: 0;
      font-size: 1.2rem;
      font-weight: 700;
    }
    
    .close-notifications {
      background: none;
      border: none;
      color: white;
      font-size: 1.5rem;
      cursor: pointer;
      padding: 0.25rem;
      line-height: 1;
    }
    
    .notifications-content {
      padding: 1rem;
    }
    
    .notification-item {
      display: flex;
      gap: 1rem;
      padding: 1rem;
      border-radius: 8px;
      margin-bottom: 0.75rem;
      transition: background 0.3s ease;
      border: 1px solid var(--fm-border-light);
    }
    
    .notification-item:hover {
      background: var(--fm-bg-light);
    }
    
    .notification-icon {
      flex-shrink: 0;
      width: 40px;
      height: 40px;
      border-radius: 50%;
      display: flex;
      align-items: center;
      justify-content: center;
      background: var(--fm-bg-light);
    }
    
    .notification-content h5 {
      margin: 0 0 0.5rem 0;
      font-size: 0.95rem;
      font-weight: 600;
      color: var(--fm-text-primary);
    }
    
    .notification-content p {
      margin: 0 0 0.5rem 0;
      font-size: 0.85rem;
      color: var(--fm-text-secondary);
      line-height: 1.4;
    }
    
    .notification-time {
      font-size: 0.75rem;
      color: var(--fm-text-muted);
    }
    
    .notifications-footer {
      text-align: center;
      padding: 2rem;
      color: var(--fm-text-secondary);
    }
    
    /* Mobile Responsive Updates */
    @media (max-width: 768px) {
      .user-section {
        gap: 1rem;
      }
      
      .user-name {
        display: none;
      }
      
      .user-dropdown {
        width: 260px;
        right: -80px;
      }
      
      .notifications-panel {
        width: 100vw;
        right: -100vw;
      }
      
      .nav-menu {
        display: none;
      }
      
      .mobile-menu-toggle {
        display: flex;
      }
      
      .nav-brand h1 {
        font-size: 1.5rem;
      }
    }
    
    @media (max-width: 480px) {
      .navbar {
        padding: 0.75rem 0;
      }
      
      .nav-brand h1 {
        font-size: 1.3rem;
      }
      
      .nav-brand {
        gap: 0.5rem;
      }
    }
    
    /* Mobile Menu Toggle Styles */
    .mobile-menu-toggle {
      display: none;
      flex-direction: column;
      gap: 4px;
      cursor: pointer;
      padding: 0.5rem;
      border-radius: 4px;
      transition: background 0.3s ease;
    }
    
    .mobile-menu-toggle:hover {
      background: rgba(255, 255, 255, 0.1);
    }
    
    .mobile-menu-toggle span {
      width: 24px;
      height: 2px;
      background: var(--fm-white);
      border-radius: 1px;
      transition: all 0.3s ease;
    }
    
    .mobile-menu {
      display: none;
      position: absolute;
      top: 100%;
      left: 0;
      right: 0;
      background: var(--fm-primary-blue);
      border-top: 1px solid rgba(255, 255, 255, 0.1);
      z-index: 99;
    }
    
    .mobile-menu.active {
      display: block;
    }
    
    .mobile-menu-item {
      border-bottom: 1px solid rgba(255, 255, 255, 0.1);
    }
    
    .mobile-menu-item:last-child {
      border-bottom: none;
    }
    
    .mobile-menu-link {
      display: block;
      color: var(--fm-white);
      text-decoration: none;
      padding: 1rem 1.5rem;
      font-weight: 600;
      transition: background 0.3s ease;
    }
    
    .mobile-menu-link:hover {
      background: rgba(255, 255, 255, 0.1);
    }

    .auth-buttons {
      display: flex;
      align-items: center;
      gap: 1rem;
    }

    .auth-btn {
      padding: 0.75rem 1.5rem;
      border-radius: 8px;
      font-weight: 600;
      font-size: 0.95rem;
      cursor: pointer;
      transition: all 0.3s ease;
      text-decoration: none;
      border: none;
    }

    .login-btn {
      background: transparent;
      color: var(--fm-white);
      border: 2px solid rgba(255, 255, 255, 0.3);
    }

    .login-btn:hover {
      background: rgba(255, 255, 255, 0.1);
      border-color: rgba(255, 255, 255, 0.5);
      transform: translateY(-1px);
    }

    .register-btn {
      background: rgba(255, 255, 255, 0.2);
      color: var(--fm-white);
      border: 2px solid transparent;
    }

    .register-btn:hover {
      background: rgba(255, 255, 255, 0.3);
      transform: translateY(-1px);
    }

    .user-role {
      display: inline-block;
      background: var(--fm-light-blue);
      color: var(--fm-primary-blue);
      padding: 0.25rem 0.5rem;
      border-radius: 12px;
      font-size: 0.7rem;
      font-weight: 600;
      margin-top: 0.25rem;
    }

    @media (max-width: 768px) {
      .auth-buttons {
        gap: 0.5rem;
      }
      
      .auth-btn {
        padding: 0.5rem 1rem;
        font-size: 0.9rem;
      }
    }

    @media (max-width: 480px) {
      .auth-btn {
        padding: 0.5rem 0.75rem;
        font-size: 0.85rem;
      }
    }

    @keyframes coinFlip {
    0%   { transform: perspective(600px) rotateY(0deg); }
    25%  { transform: perspective(600px) rotateY(90deg) scaleY(0.9); }
    50%  { transform: perspective(600px) rotateY(180deg); }
    75%  { transform: perspective(600px) rotateY(270deg) scaleY(0.9); }
    100% { transform: perspective(600px) rotateY(360deg); }
  }
  .nav-logo {
   transform-style: preserve-3d;
   backface-visibility: hidden;
   }
  .nav-logo.flip {
     animation: coinFlip 1s ease-in-out;
   }
  `]
})
export class HeaderComponent implements OnInit, OnDestroy {
  // Icons
  faHome = faHome;
  faChevronDown = faChevronDown;
  faNewspaper = faNewspaper;
  faBell = faBell;
  faUser = faUser;
  faSignOutAlt = faSignOutAlt;

  // Configuration
  appConfig = APP_CONFIG;
  megaMenus = HEADER_MEGA_MENUS;
  userMenuItems = USER_MENU_ITEMS;
  mobileMenuItems = MOBILE_MENU_ITEMS;
  
  // Filtered menus based on user role
  visibleMegaMenus: MegaMenu[] = [];
  visibleUserMenuItems: MenuItem[] = [];
  visibleMobileMenuItems: MenuItem[] = [];

  // User data
  currentUser: User | null = null;
  isAuthenticated = false;

  // Notification data from API
  notifications: Catalog[] = [];
  notificationCount = 0;
  showNotifications = false;
  showUserDropdown = false;

  // News data from API
  newsItems: Catalog[] = [];
  showNewsPopup = false;
  hasUnreadNews = false;

  activeMegaMenu: string | null = null;
  mobileMenuOpen = false;

  private subscription = new Subscription();
  private flipInterval: any;

  @ViewChild('newsBarRef') newsBarComponent!: NewsBarComponent;

  constructor(
    private router: Router,
    private authService: AuthService,
    private catalogService: CatalogService
  ) { }

  ngOnInit(): void {
    // Subscribe to authentication state
    this.subscription.add(
      this.authService.currentUser$.subscribe((user: User | null) => {
        this.currentUser = user;
        this.isAuthenticated = !!user;

        // Update visible menus based on user role
        this.updateVisibleMenus();

        if (this.isAuthenticated) {
          // Add a small delay to ensure token is properly set before making API calls
          setTimeout(() => {
            this.loadNotifications();
            this.loadNews();
          }, 100);
        } else {
          // Clear data when user is not authenticated
          this.clearUserData();
        }
      })
    );

    // Subscribe to notifications from catalog service only when authenticated
    this.subscription.add(
      this.catalogService.notifications$.subscribe((notifications: Catalog[]) => {
        if (this.isAuthenticated) {
          this.notifications = notifications;
          this.notificationCount = notifications.length;
        }
      })
    );

    // Subscribe to news from catalog service only when authenticated
    this.subscription.add(
      this.catalogService.news$.subscribe((news: Catalog[]) => {
        if (this.isAuthenticated) {
          this.newsItems = news;
          this.checkUnreadNews();
        }
      })
    );

    this.flipInterval = setInterval(() => {
      const logo = document.querySelector('.nav-logo');
      if (logo) {
        logo.classList.add('flip');
        setTimeout(() => logo.classList.remove('flip'), 1000);
      }
    }, 10000);
  }

  ngOnDestroy(): void {
    clearInterval(this.flipInterval);
    this.subscription.unsubscribe();
  }

  /**
   * Update visible menus based on user role
   */
  private updateVisibleMenus(): void {
    const userRole = this.currentUser?.role || null;
    
    // Filter menus based on user role
    this.visibleMegaMenus = filterMegaMenusByRole(this.megaMenus, userRole);
    this.visibleUserMenuItems = filterItemsByRole(this.userMenuItems, userRole);
    this.visibleMobileMenuItems = filterItemsByRole(this.mobileMenuItems, userRole);
  }

  /**
   * Clear user-specific data when not authenticated
   */
  private clearUserData(): void {
    this.notifications = [];
    this.notificationCount = 0;
    this.newsItems = [];
    this.hasUnreadNews = false;
    this.showNotifications = false;
    this.showNewsPopup = false;
    this.showUserDropdown = false;
    
    // Clear visible menus
    this.visibleMegaMenus = [];
    this.visibleUserMenuItems = [];
    this.visibleMobileMenuItems = [];
  }

  /**
   * Load notifications from API
   */
  private loadNotifications(): void {
    if (!this.isAuthenticated) {
      return;
    }

    this.catalogService.getRecentNotifications(5).subscribe({
      next: (notifications) => {
        // Notifications are automatically updated via the subscription
      },
      error: (error) => {
        console.error('Failed to load notifications:', error);
        // Fallback to empty array on error
        this.notifications = [];
        this.notificationCount = 0;
      }
    });
  }

  /**
   * Load news from API
   */
  private loadNews(): void {
    if (!this.isAuthenticated) {
      return;
    }

    this.catalogService.getRecentNews(6).subscribe({
      next: (news) => {
        // News items are automatically updated via the subscription
      },
      error: (error) => {
        console.error('Failed to load news:', error);
        // Fallback to empty array on error
        this.newsItems = [];
        this.hasUnreadNews = false;
      }
    });
  }

  /**
   * Check if there are unread news items
   */
  private checkUnreadNews(): void {
    if (!this.isAuthenticated) {
      this.hasUnreadNews = false;
      return;
    }

    this.catalogService.hasUnreadNews().subscribe({
      next: (hasUnread) => {
        this.hasUnreadNews = hasUnread;
      },
      error: (error) => {
        console.error('Failed to check unread news:', error);
        this.hasUnreadNews = false;
      }
    });
  }

  getUserDisplayName(): string {
    if (this.currentUser?.first_name && this.currentUser?.last_name) {
      return `${this.currentUser.first_name} ${this.currentUser.last_name}`;
    }
    return this.currentUser?.user_id || 'User';
  }

  getUserEmail(): string {
    return this.currentUser?.email || this.currentUser?.user_id || '';
  }

  showMegaMenu(menu: string): void {
    this.activeMegaMenu = menu;
  }

  hideMegaMenu(menu: string): void {
    // Add a small delay to allow moving to the mega menu
    setTimeout(() => {
      if (this.activeMegaMenu === menu) {
        this.activeMegaMenu = null;
      }
    }, 100);
  }

  closeMegaMenu(): void {
    this.activeMegaMenu = null;
  }

  toggleMobileMenu(): void {
    this.mobileMenuOpen = !this.mobileMenuOpen;
  }

  toggleNotifications(): void {
    this.showNotifications = !this.showNotifications;
  }

  toggleNews(): void {
    this.showNewsPopup = !this.showNewsPopup;
    
    if (this.showNewsPopup) {
      // Show the news bar and mark as read
      this.hasUnreadNews = false;
      this.catalogService.markNewsAsRead().subscribe({
        next: () => {
          console.log('News marked as read');
        },
        error: (error) => {
          console.error('Failed to mark news as read:', error);
        }
      });
      
      // Force show the news bar
      if (this.newsBarComponent) {
        this.newsBarComponent.showBar();
        this.newsBarComponent.refreshNews();
      }
    } else {
      // Hide the news bar
      if (this.newsBarComponent) {
        this.newsBarComponent.hideBar();
      }
    }
  }

  closeNews(): void {
    this.showNewsPopup = false;
  }

  handleNewsClick(newsItem: Catalog): void {
    console.log('News item clicked:', newsItem);
    // Handle news item click (e.g., navigate to article)
    if (newsItem.url) {
      window.open(newsItem.url, '_blank');
    }
  }

  getNotificationIcon(notification: Catalog) {
    // Map notification types to icons based on category or custom fields
    const type = notification.category || notification.custom?.['type'] || 'primary';
    switch (type) {
      case 'system':
      case 'maintenance': return faShieldAlt;
      case 'success':
      case 'deployment': return faRocket;
      case 'warning':
      case 'alert': return faBell;
      case 'assignment':
      case 'project': return faChartLine;
      default: return faBell;
    }
  }

  getNotificationVariant(notification: Catalog): 'primary' | 'secondary' | 'success' | 'warning' | 'danger' | 'muted' | undefined {
    const type = notification.category || notification.custom?.['type'] || 'primary';
    switch (type) {
      case 'system':
      case 'maintenance': return 'warning';
      case 'success':
      case 'deployment': return 'success';
      case 'error':
      case 'critical': return 'danger';
      case 'info':
      case 'assignment': return 'primary';
      default: return 'primary';
    }
  }

  /**
   * Show user menu dropdown
   */
  showUserMenu(): void {
    this.showUserDropdown = true;
  }

  /**
   * Hide user menu dropdown
   */
  hideUserMenu(): void {
    // Add a small delay to allow moving to the dropdown
    setTimeout(() => {
      this.showUserDropdown = false;
    }, 100);
  }

  /**
   * Handle logout
   */
  logout(event: Event): void {
    console.log('Logout button clicked'); // Debug log
    event.preventDefault();
    console.log('Calling auth service logout'); // Debug log

    // Always clear local auth state first
    this.clearLocalAuthState();

    // Try to call logout API, but don't depend on it
    this.authService.logout().subscribe({
      next: () => {
        console.log('Logout API successful'); // Debug log
      },
      error: (error) => {
        console.log('Logout API failed, but continuing with local logout:', error); // Debug log
      }
    });

    // Always navigate to login regardless of API response
    console.log('Navigating to login page'); // Debug log
    this.router.navigate(['/login']);
  }

  /**
   * Clear local authentication state
   */
  private clearLocalAuthState(): void {
    // Clear localStorage tokens and user data
    localStorage.removeItem('access_token');
    localStorage.removeItem('refresh_token');
    localStorage.removeItem('current_user');

    // Reset component state
    this.currentUser = null;
    this.isAuthenticated = false;
    this.showUserDropdown = false;
  }

  navigateTo(path: string): void {
    this.router.navigate([path]);
    this.mobileMenuOpen = false; // Close mobile menu if open
    this.activeMegaMenu = null; // Close any open mega menu
  }
}
import { Injectable } from '@angular/core';
import { HttpInterceptor, HttpRequest, HttpHandler, HttpEvent, HttpErrorResponse } from '@angular/common/http';
import { Observable, throwError, BehaviorSubject } from 'rxjs';
import { catchError, filter, take, switchMap } from 'rxjs/operators';
import { AuthService } from '../services/auth.service';

@Injectable()
export class AuthInterceptor implements HttpInterceptor {
  private isRefreshing = false;
  private refreshTokenSubject: BehaviorSubject<any> = new BehaviorSubject<any>(null);

  constructor(private authService: AuthService) {}

  intercept(req: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
    // Get the auth token from the service
    const authToken = this.authService.getToken();
    
    // Debug logging to track token availability
    console.log('AuthInterceptor - Request URL:', req.url);
    console.log('AuthInterceptor - Token available:', !!authToken);
    console.log('AuthInterceptor - Is public route:', this.isPublicRoute(req.url));
    
    // Clone the request and add the authorization header if token exists
    let authReq = req;
    if (authToken && !this.isPublicRoute(req.url)) {
      authReq = this.addTokenHeader(req, authToken);
      console.log('AuthInterceptor - Added Authorization header');
    } else if (!authToken && !this.isPublicRoute(req.url)) {
      console.warn('AuthInterceptor - No token available for protected route:', req.url);
    }

    return next.handle(authReq).pipe(
      catchError(error => {
        console.error('AuthInterceptor - Request failed:', {
          url: req.url,
          status: error.status,
          message: error.message,
          hasToken: !!authToken
        });
        
        if (error instanceof HttpErrorResponse && error.status === 401) {
          // Don't try to refresh token for auth-related requests (login/register)
          if (this.isAuthRoute(req.url)) {
            return throwError(() => error);
          }
          return this.handle401Error(authReq, next);
        }
        return throwError(() => error);
      })
    );
  }

  private addTokenHeader(request: HttpRequest<any>, token: string): HttpRequest<any> {
    return request.clone({
      headers: request.headers.set('Authorization', `Bearer ${token}`)
    });
  }

  private isPublicRoute(url: string): boolean {
    const publicEndpoints = [
      '/auth/login',
      '/auth/register',
      '/health'
    ];
    
    return publicEndpoints.some(endpoint => url.includes(endpoint));
  }

  private isAuthRoute(url: string): boolean {
    const authEndpoints = [
      '/auth/login',
      '/auth/register',
      '/auth/logout',
      '/auth/refresh'
    ];
    
    return authEndpoints.some(endpoint => url.includes(endpoint));
  }

  private handle401Error(request: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
    if (!this.isRefreshing) {
      this.isRefreshing = true;
      this.refreshTokenSubject.next(null);

      const refreshToken = this.authService.getRefreshToken();
      
      if (refreshToken) {
        return this.authService.refreshToken().pipe(
          switchMap((token: any) => {
            this.isRefreshing = false;
            this.refreshTokenSubject.next(token.access_token);
            
            return next.handle(this.addTokenHeader(request, token.access_token));
          }),
          catchError((err) => {
            this.isRefreshing = false;
            this.authService.logout();
            return throwError(() => err);
          })
        );
      }
    }

    return this.refreshTokenSubject.pipe(
      filter(token => token !== null),
      take(1),
      switchMap((token) => next.handle(this.addTokenHeader(request, token)))
    );
  }
}
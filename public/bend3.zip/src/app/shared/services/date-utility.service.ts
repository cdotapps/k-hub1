import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class DateUtilityService {

  constructor() { }

  /**
   * Format date as time only (HH:MM)
   */
  formatTime(dateString: string | undefined): string {
    if (!dateString) return 'Never';
    return new Date(dateString).toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' });
  }

  /**
   * Format date as date only (MM/DD/YYYY)
   */
  formatDate(dateString: string | undefined): string {
    if (!dateString) return 'Never';
    return new Date(dateString).toLocaleDateString();
  }

  /**
   * Format date as full date and time
   */
  formatDateTime(dateString: string | undefined): string {
    if (!dateString) return 'Never';
    return new Date(dateString).toLocaleString();
  }

  /**
   * Format date as long format (Monday, January 1, 2024)
   */
  formatDateLong(date: Date | string): string {
    if (!date) return 'Never';
    return new Date(date).toLocaleDateString('en-US', {
      weekday: 'long',
      year: 'numeric',
      month: 'long',
      day: 'numeric'
    });
  }

  /**
   * Format date as short format (Jan 1)
   */
  formatShortDate(dateString: string): string {
    if (!dateString) return 'Never';
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', { month: 'short', day: 'numeric' });
  }

  /**
   * Format date with time (Jan 1, 2024, 10:30 AM)
   */
  formatDateWithTime(dateString: string): string {
    if (!dateString) return '--';
    return new Date(dateString).toLocaleString('en-US', {
      month: 'short',
      day: 'numeric',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  }

  /**
   * Format relative time (Today, Yesterday, X days ago, etc.)
   */
  formatRelativeTime(dateString: string): string {
    if (!dateString) return 'Never';
    
    // Handle common date format issues from APIs
    let cleanDateString = dateString.trim();
    
    // Handle potential timezone issues - if the date string doesn't include timezone info,
    // treat it as UTC to avoid local timezone interpretation issues
    if (!/[+-]\d{2}:?\d{2}|Z$/i.test(cleanDateString)) {
      // If it looks like an ISO date without timezone, append Z for UTC
      if (/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(\.\d+)?$/.test(cleanDateString)) {
        cleanDateString += 'Z';
      }
    }
    
    const date = new Date(cleanDateString);
    const now = new Date();
    
    // Check for invalid date
    if (isNaN(date.getTime())) {
      return 'Invalid date';
    }
    
    // Check for future dates (which might indicate timezone issues)
    const diffMs = now.getTime() - date.getTime();
    
    // If the date is in the future by more than 1 hour, there might be a timezone issue
    if (diffMs < -3600000) {
      // Try parsing as local time instead
      const localDate = new Date(dateString.replace('Z', ''));
      const localDiffMs = now.getTime() - localDate.getTime();
      
      if (localDiffMs >= 0) {
        // Use local parsing if it gives a sensible result
        return this.calculateRelativeTime(localDiffMs);
      }
    }
    
    return this.calculateRelativeTime(diffMs);
  }

  /**
   * Calculate relative time from millisecond difference
   */
  private calculateRelativeTime(diffMs: number): string {
    // Handle future dates (return "Just now" for small future dates due to clock differences)
    if (diffMs < 0) {
      if (diffMs > -60000) { // Less than 1 minute in the future
        return 'Just now';
      }
      return 'In the future'; // Clearly a timezone or data issue
    }
    
    // Return 'Just now' for very recent updates (less than a minute ago)
    if (diffMs < 60 * 1000) {
      return 'Just now';
    }
    
    // Minutes ago
    if (diffMs < 60 * 60 * 1000) {
      const minutes = Math.floor(diffMs / (60 * 1000));
      return `${minutes} ${minutes === 1 ? 'min' : 'mins'} ago`;
    }
    
    // Hours ago
    if (diffMs < 24 * 60 * 60 * 1000) {
      const hours = Math.floor(diffMs / (60 * 60 * 1000));
      return `${hours} ${hours === 1 ? 'hr' : 'hrs'} ago`;
    }
    
    // Check if date is today or yesterday
    const now = new Date();
    const today = new Date(now);
    today.setHours(0, 0, 0, 0);
    
    const yesterday = new Date(today);
    yesterday.setDate(yesterday.getDate() - 1);
    
    const date = new Date(now.getTime() - diffMs);
    const dateDay = new Date(date);
    dateDay.setHours(0, 0, 0, 0);
    
    if (dateDay.getTime() === today.getTime()) {
      return 'Today';
    }
    
    if (dateDay.getTime() === yesterday.getTime()) {
      return 'Yesterday';
    }
    
    // Days ago (for the last week)
    if (diffMs < 7 * 24 * 60 * 60 * 1000) {
      const days = Math.floor(diffMs / (24 * 60 * 60 * 1000));
      return `${days} ${days === 1 ? 'day' : 'days'} ago`;
    }
    
    // Weeks ago (for the last month)
    if (diffMs < 30 * 24 * 60 * 60 * 1000) {
      const weeks = Math.floor(diffMs / (7 * 24 * 60 * 60 * 1000));
      return `${weeks} ${weeks === 1 ? 'week' : 'weeks'} ago`;
    }
    
    // Months ago (for the last year)
    if (diffMs < 365 * 24 * 60 * 60 * 1000) {
      const months = Math.floor(diffMs / (30 * 24 * 60 * 60 * 1000));
      return `${months} ${months === 1 ? 'month' : 'months'} ago`;
    }
    
    // Years ago
    const years = Math.floor(diffMs / (365 * 24 * 60 * 60 * 1000));
    return `${years} ${years === 1 ? 'year' : 'years'} ago`;
  }

  /**
   * Format time ago (Today, Yesterday, X days ago)
   */
  formatTimeAgo(dateString: string): string {
    const now = new Date();
    const date = new Date(dateString);
    const diffInMs = now.getTime() - date.getTime();
    const diffInDays = Math.floor(diffInMs / (1000 * 60 * 60 * 24));
    
    if (diffInDays === 0) return 'Today';
    if (diffInDays === 1) return 'Yesterday';
    if (diffInDays < 7) return `${diffInDays} days ago`;
    if (diffInDays < 30) return `${Math.floor(diffInDays / 7)} weeks ago`;
    return `${Math.floor(diffInDays / 30)} months ago`;
  }

  /**
   * Format month and year (January 2024)
   */
  formatMonthYear(dateString: string): string {
    return new Date(dateString).toLocaleDateString('en-US', {
      month: 'long',
      year: 'numeric'
    });
  }

  /**
   * Get current date
   */
  getCurrentDate(): Date {
    return new Date();
  }

  /**
   * Get today's date as string
   */
  getToday(): string {
    return new Date().toLocaleDateString();
  }

  /**
   * Get start of current week as string
   */
  getThisWeek(): string {
    const now = new Date();
    const startOfWeek = new Date(now.setDate(now.getDate() - now.getDay()));
    return startOfWeek.toLocaleDateString();
  }

  /**
   * Get start of current month as string
   */
  getThisMonth(): string {
    const now = new Date();
    return new Date(now.getFullYear(), now.getMonth(), 1).toLocaleDateString();
  }

  /**
   * Check if date is within last X days
   */
  isWithinLastDays(dateString: string, days: number): boolean {
    if (!dateString) return false;
    const date = new Date(dateString);
    const daysAgo = new Date();
    daysAgo.setDate(daysAgo.getDate() - days);
    return date > daysAgo;
  }

  /**
   * Get difference in days between two dates
   */
  getDaysDifference(date1: string | Date, date2: string | Date = new Date()): number {
    const d1 = new Date(date1);
    const d2 = new Date(date2);
    const diffTime = Math.abs(d2.getTime() - d1.getTime());
    return Math.ceil(diffTime / (1000 * 60 * 60 * 24));
  }

  /**
   * Check if date is today
   */
  isToday(dateString: string): boolean {
    const date = new Date(dateString);
    const today = new Date();
    return date.toDateString() === today.toDateString();
  }

  /**
   * Check if date is yesterday
   */
  isYesterday(dateString: string): boolean {
    const date = new Date(dateString);
    const yesterday = new Date();
    yesterday.setDate(yesterday.getDate() - 1);
    return date.toDateString() === yesterday.toDateString();
  }

  /**
   * Get relative time (alias for formatRelativeTime)
   */
  getRelativeTime(dateString: string): string {
    return this.formatRelativeTime(dateString);
  }
}
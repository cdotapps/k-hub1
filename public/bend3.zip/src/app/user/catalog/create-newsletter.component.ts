import { Component, OnInit, OnDestroy } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router, ActivatedRoute } from '@angular/router';
import { Subscription, Subject } from 'rxjs';
import { debounceTime, distinctUntilChanged } from 'rxjs/operators';

// FontAwesome Icons
import { 
  faNewspaper, faFileAlt, faBell, faFileContract, faBook, faGraduationCap,
  faBlog, faFlask, faFileImage, faChartLine, faSave, faTimes, faSpinner,
  faEye, faArrowLeft, faInfoCircle, faExclamationTriangle, faCheckCircle,
  faPlus, faTag, faUser, faCalendar, faGlobe, faLock, faEdit, faClock,
  faSearch
} from '@fortawesome/free-solid-svg-icons';

// Services and Models
import { CatalogService } from '../../shared/services/catalog.service';
import { AuthService } from '../../shared/services/auth.service';
import { CatalogCreate, User, Catalog } from '../../shared/models/user.interface';
import { BreadcrumbItem } from '../../shared/components/breadcrumb/breadcrumb.component';
import { CATALOG_TYPES, CatalogType, filterCatalogTypesByRole } from '../../shared/config/site-config';

@Component({
  selector: 'app-create-newsletter',
  templateUrl: './create-newsletter.component.html',
  styleUrls: ['./create-newsletter.component.css']
})
export class CreateNewsletterComponent implements OnInit, OnDestroy {
  // FontAwesome Icons
  faNewspaper = faNewspaper;
  faFileAlt = faFileAlt;
  faBell = faBell;
  faFileContract = faFileContract;
  faBook = faBook;
  faGraduationCap = faGraduationCap;
  faBlog = faBlog;
  faFlask = faFlask;
  faFileImage = faFileImage;
  faChartLine = faChartLine;
  faSave = faSave;
  faTimes = faTimes;
  faSpinner = faSpinner;
  faEye = faEye;
  faArrowLeft = faArrowLeft;
  faInfoCircle = faInfoCircle;
  faExclamationTriangle = faExclamationTriangle;
  faCheckCircle = faCheckCircle;
  faPlus = faPlus;
  faTag = faTag;
  faUser = faUser;
  faCalendar = faCalendar;
  faGlobe = faGlobe;
  faLock = faLock;
  faEdit = faEdit;
  faClock = faClock;
  faSearch = faSearch;

  // Form and Data
  newsletterForm: FormGroup;
  currentUser: User | null = null;
  selectedCatalogType = '';
  parentId: string = ''; // Added property for parent_id
  
  // UI State
  isLoading = false;
  isSaving = false;
  isPreviewMode = false;
  successMessage = '';
  errorMessage = '';
  
  // Word count tracking
  private currentWordCount: number = 0;
  
  // Available catalog types (will be filtered by user role)
  catalogTypes: CatalogType[] = [];

  // Catalog search popup properties
  showCatalogPopup = false;
  catalogSearchQuery = '';
  isSearchingCatalog = false;
  recentCatalogItems: Catalog[] = [];
  searchCatalogItems: Catalog[] = [];
  private searchSubject = new Subject<string>();

  breadcrumbItems: BreadcrumbItem[] = [
    { label: 'Dashboard', url: '/user/dashboard' },
    { label: 'Catalog', url: '/user/catalog' },
    { label: 'Create Newsletter', active: true }
  ];

  private subscriptions = new Subscription();

  // Quill Editor Configuration
  quillConfig = {
    toolbar: [
      ['bold', 'italic', 'underline', 'strike'],        // toggled buttons
      ['blockquote', 'code-block'],
      [{ 'header': 1 }, { 'header': 2 }],               // custom button values
      [{ 'list': 'ordered'}, { 'list': 'bullet' }],
      [{ 'script': 'sub'}, { 'script': 'super' }],      // superscript/subscript
      [{ 'indent': '-1'}, { 'indent': '+1' }],          // outdent/indent
      [{ 'direction': 'rtl' }],                         // text direction
      [{ 'size': ['small', false, 'large', 'huge'] }],  // custom dropdown
      [{ 'header': [1, 2, 3, 4, 5, 6, false] }],
      [{ 'color': [] }, { 'background': [] }],          // dropdown with defaults from theme
      [{ 'font': [] }],
      [{ 'align': [] }],
      ['clean'],                                         // remove formatting button
      ['link', 'image']                                 // link and image, video
    ]
  };

  constructor(
    private formBuilder: FormBuilder,
    private catalogService: CatalogService,
    private authService: AuthService,
    private router: Router,
    private route: ActivatedRoute
  ) {
    this.newsletterForm = this.createNewsletterForm();
  }

  ngOnInit(): void {
    // Set default catalog type to 'news-letter'
    this.selectedCatalogType = 'news-letter';
    this.newsletterForm.patchValue({ type: 'news-letter' });

    // Subscribe to authentication state
    this.subscriptions.add(
      this.authService.currentUser$.subscribe((user: User | null) => {
        this.currentUser = user;
        this.setAvailableCatalogTypes();
      })
    );

    // Check for parent_id from route query params
    this.subscriptions.add(
      this.route.queryParams.subscribe(params => {
        if (params['parent_id']) {
          this.parentId = params['parent_id'];
          this.newsletterForm.patchValue({ parent_id: this.parentId });
        }
      })
    );

    // Load recent catalog items
    this.loadRecentCatalogItems();

    // Setup search debouncing
    this.subscriptions.add(
      this.searchSubject.pipe(
        debounceTime(300),
        distinctUntilChanged()
      ).subscribe(query => {
        this.performCatalogSearch(query);
      })
    );
  }

  ngOnDestroy(): void {
    this.subscriptions.unsubscribe();
  }

  /**
   * Create newsletter form with validation
   */
  private createNewsletterForm(): FormGroup {
    return this.formBuilder.group({
      title: ['', [Validators.required, Validators.minLength(3), Validators.maxLength(200)]],
      type: ['', [Validators.required]],
      description: ['', [Validators.maxLength(500)]],
      summary: ['', [Validators.maxLength(300)]],
      content: ['', [Validators.required, Validators.minLength(10)]],
      url: [''],
      image: [''],
      tags: [''],
      status: ['draft', [Validators.required]],
      category: [''],
      parent_id: ['']
    });
  }

  /**
   * Set available catalog types based on user role
   */
  private setAvailableCatalogTypes(): void {
    if (!this.currentUser) {
      this.catalogTypes = [];
      return;
    }

    // Get allowed catalog types for the current user role
    const allowedTypes = filterCatalogTypesByRole(this.currentUser.role);

    // Map allowed types to catalog types with descriptions from site-config
    this.catalogTypes = allowedTypes.map(type => ({
      value: type.value,
      label: type.label,
      icon: type.icon,
      color: type.color,
      background: type.background,
      description: type.description // Use description from site-config
    }));
  }

  /**
   * Capitalize the first letter of a string
   */
  private capitalizeFirstLetter(string: string): string {
    return string.charAt(0).toUpperCase() + string.slice(1);
  }

  /**
   * Get catalog type icon by type
   */
  getCatalogTypeIcon(type: string): any {
    switch (type) {
      case 'news': return this.faNewspaper;
      case 'article': return this.faFileAlt;
      case 'notification': return this.faBell;
      case 'document': return this.faFileContract;
      case 'guide': return this.faBook;
      case 'tutorial': return this.faGraduationCap;
      case 'blog': return this.faBlog;
      case 'research': return this.faFlask;
      case 'whitepaper': return this.faFileImage;
      case 'case-study': return this.faChartLine;
      default: return null;
    }
  }

  /**
   * Get catalog type color by type
   */
  private getCatalogTypeColor(type: string): string {
    switch (type) {
      case 'news': return '#007bff';
      case 'article': return '#28a745';
      case 'notification': return '#ffc107';
      case 'document': return '#17a2b8';
      case 'guide': return '#6610f2';
      case 'tutorial': return '#e83e8c';
      case 'blog': return '#fd7e14';
      case 'research': return '#20c997';
      case 'whitepaper': return '#343a40';
      case 'case-study': return '#007bff';
      default: return '#000000';
    }
  }

  /**
   * Get catalog type background by type
   */
  private getCatalogTypeBackground(type: string): string {
    switch (type) {
      case 'news': return '#d1e7ff';
      case 'article': return '#d4edda';
      case 'notification': return '#fff3cd';
      case 'document': return '#d1ecf1';
      case 'guide': return '#f8d7da';
      case 'tutorial': return '#f5c6cb';
      case 'blog': return '#ffeeba';
      case 'research': return '#c3e6cb';
      case 'whitepaper': return '#ced4da';
      case 'case-study': return '#d1e7ff';
      default: return '#ffffff';
    }
  }

  /**
   * Handle catalog type selection
   */
  onCatalogTypeChange(type: string): void {
    // No-op: always 'news-letter'
  }

  /**
   * Get selected catalog type (always 'news-letter')
   */
  getSelectedCatalogType() {
    return this.catalogTypes.find(type => type.value === 'news-letter');
  }

  /**
   * Save newsletter (draft or publish)
   */
  saveNewsletter(publish: boolean = false): void {
    if (this.newsletterForm.invalid) {
      this.newsletterForm.markAllAsTouched();
      return;
    }

    this.isSaving = true;
    this.successMessage = '';
    this.errorMessage = '';

    // Transform form data to match API expectations
    const formData = this.newsletterForm.value;
    
    // Convert tags string to array
    const tagsArray: string[] = [];
    if (formData.tags && typeof formData.tags === 'string') {
      tagsArray.push(...formData.tags.split(',').map((tag: string) => tag.trim()).filter((tag: string) => tag));
    }

    // Prepare article data according to API schema
    const articleData: CatalogCreate = {
      title: formData.title,
      type: formData.type,
      description: formData.description || '',
      summary: formData.summary || '',
      content: formData.content,
      url: formData.url || '',
      image: formData.image || '',
      tags: tagsArray,
      status: formData.status,
      category: formData.category || '',
      parent_id: formData.parent_id || '',
      author: this.getUserDisplayName(),
      created_date: new Date().toISOString(),
      updated_date: new Date().toISOString()
    };

    console.log('Sending article data:', articleData);

    this.subscriptions.add(
      this.catalogService.createArticle(articleData).subscribe({
        next: (response) => {
          console.log('Article created successfully:', response);
          this.isSaving = false;
          this.successMessage = publish ? 'Article published successfully!' : 'Draft saved successfully!';
          this.errorMessage = '';
          this.newsletterForm.markAsPristine();
          if (publish) {
            setTimeout(() => {
              this.router.navigate(['/user/catalog']);
            }, 1000);
          }
        },
        error: (error) => {
          console.error('Error saving article:', error);
          this.isSaving = false;
          
          // Provide more specific error messages
          let errorMessage = 'Failed to save article. Please try again.';
          if (error.message) {
            errorMessage = error.message;
          }
          
          this.errorMessage = errorMessage;
          this.successMessage = '';
        }
      })
    );
  }

  /**
   * Cancel article creation or editing
   */
  cancel(): void {
    this.router.navigate(['/user/catalog']);
  }

  /**
   * Handle word count changes from rich text editor
   */
  onWordCountChange(wordCount: number): void {
    this.currentWordCount = wordCount;
  }

  /**
   * Get word count
   */
  getWordCount(): number {
    return this.currentWordCount;
  }

  /**
   * Get reading time calculation
   */
  getReadingTime(): number {
    const wordsPerMinute = 200;
    return Math.max(1, Math.ceil(this.currentWordCount / wordsPerMinute));
  }

  /**
   * Get preview content method to handle HTML content
   */
  getPreviewContent(): string {
    const content = this.newsletterForm.get('content')?.value || '';
    return content;
  }

  /**
   * Toggle between form and preview mode
   */
  togglePreview(): void {
    this.isPreviewMode = !this.isPreviewMode;
  }

  /**
   * Handle page hero action clicks
   */
  onHeroActionClick(actionIndex: number): void {
    switch (actionIndex) {
      case 0: // Cancel
        this.cancel();
        break;
      case 1: // Preview/Edit toggle
        this.togglePreview();
        break;
    }
  }

  /**
   * Check if a form field has validation errors
   */
  hasFieldError(fieldName: string): boolean {
    const field = this.newsletterForm.get(fieldName);
    return !!(field && field.invalid && (field.dirty || field.touched));
  }

  /**
   * Get validation error message for a field
   */
  getFieldError(fieldName: string): string {
    const field = this.newsletterForm.get(fieldName);
    if (field && field.errors) {
      if (field.errors['required']) {
        return `${fieldName.charAt(0).toUpperCase() + fieldName.slice(1)} is required`;
      }
      if (field.errors['minlength']) {
        return `${fieldName.charAt(0).toUpperCase() + fieldName.slice(1)} must be at least ${field.errors['minlength'].requiredLength} characters`;
      }
      if (field.errors['maxlength']) {
        return `${fieldName.charAt(0).toUpperCase() + fieldName.slice(1)} must not exceed ${field.errors['maxlength'].requiredLength} characters`;
      }
      if (field.errors['email']) {
        return 'Please enter a valid email address';
      }
      if (field.errors['url']) {
        return 'Please enter a valid URL';
      }
    }
    return '';
  }

  /**
   * Get character count for a field
   */
  getCharacterCount(fieldName: string): number {
    const value = this.newsletterForm.get(fieldName)?.value;
    return value ? value.length : 0;
  }

  /**
   * Get maximum length for a field
   */
  getMaxLength(fieldName: string): number {
    const maxLengths: { [key: string]: number } = {
      title: 200,
      description: 500,
      summary: 300
    };
    return maxLengths[fieldName] || 0;
  }

  /**
   * Clear the form
   */
  clearForm(): void {
    this.newsletterForm.reset();
    this.selectedCatalogType = '';
    this.currentWordCount = 0;
    this.successMessage = '';
    this.errorMessage = '';
  }

  /**
   * Save article as draft
   */
  saveDraft(): void {
    this.newsletterForm.patchValue({ status: 'draft' });
    
    if (this.newsletterForm.invalid) {
      this.newsletterForm.markAllAsTouched();
      return;
    }

    this.isSaving = true;
    this.successMessage = '';
    this.errorMessage = '';

    // Transform form data to match API expectations
    const formData = this.newsletterForm.value;
    
    // Convert tags string to array
    const tagsArray: string[] = [];
    if (formData.tags && typeof formData.tags === 'string') {
      tagsArray.push(...formData.tags.split(',').map((tag: string) => tag.trim()).filter((tag: string) => tag));
    }

    // Prepare article data according to API schema
    const articleData: CatalogCreate = {
      title: formData.title,
      type: formData.type,
      description: formData.description || '',
      summary: formData.summary || '',
      content: formData.content,
      url: formData.url || '',
      image: formData.image || '',
      tags: tagsArray,
      status: 'draft',
      category: formData.category || '',
      parent_id: formData.parent_id || '',
      author: this.getUserDisplayName(),
      created_date: new Date().toISOString(),
      updated_date: new Date().toISOString()
    };

    console.log('Sending article data:', articleData);

    this.subscriptions.add(
      this.catalogService.createArticle(articleData).subscribe({
        next: (response) => {
          console.log('Article created successfully:', response);
          this.isSaving = false;
          this.successMessage = 'Draft saved successfully!';
          this.errorMessage = '';
          this.newsletterForm.markAsPristine();
          
          // Redirect to catalog with the same catalog type filter
          setTimeout(() => {
            const catalogType = this.selectedCatalogType || formData.type;
            if (catalogType) {
              // Navigate to catalog with the catalog type as a query parameter to pre-filter
              this.router.navigate(['/user/catalog'], { 
                queryParams: { type: catalogType }
              });
            } else {
              // Fallback to catalog without filter
              this.router.navigate(['/user/catalog']);
            }
          }, 1000);
        },
        error: (error) => {
          console.error('Error saving article:', error);
          this.isSaving = false;
          
          // Provide more specific error messages
          let errorMessage = 'Failed to save article. Please try again.';
          if (error.message) {
            errorMessage = error.message;
          }
          
          this.errorMessage = errorMessage;
          this.successMessage = '';
        }
      })
    );
  }

  /**
   * Get current user display name
   */
  getUserDisplayName(): string {
    if (this.currentUser?.first_name && this.currentUser?.last_name) {
      return `${this.currentUser.first_name} ${this.currentUser.last_name}`;
    }
    return this.currentUser?.email || this.currentUser?.user_id || 'Unknown User';
  }

  /**
   * Get current date formatted
   */
  getCurrentDate(): string {
    return new Date().toLocaleDateString();
  }

  /**
   * Get preview title or placeholder
   */
  getPreviewTitle(): string {
    return this.newsletterForm.get('title')?.value || 'Untitled Newsletter';
  }

  /**
   * Get preview tags as array
   */
  getPreviewTags(): string[] {
    const tags = this.newsletterForm.get('tags')?.value;
    if (!tags) return [];
    return tags.split(',').map((tag: string) => tag.trim()).filter((tag: string) => tag);
  }

  /**
   * Load recent catalog items for the popup
   */
  loadRecentCatalogItems(): void {
    this.catalogService.searchCatalogItems({
      limit: 10,
      sort: 'updated_date',
      order: 'desc'
    }).subscribe({
      next: (response) => {
        this.recentCatalogItems = response.items || [];
      },
      error: (error) => {
        console.error('Error loading recent catalog items:', error);
        this.recentCatalogItems = [];
      }
    });
  }

  /**
   * Show catalog search popup
   */
  showCatalogSearchPopup(): void {
    this.showCatalogPopup = true;
    this.catalogSearchQuery = '';
    this.searchCatalogItems = [];
    this.loadRecentCatalogItems();
  }

  /**
   * Close catalog search popup
   */
  closeCatalogSearchPopup(): void {
    this.showCatalogPopup = false;
    this.catalogSearchQuery = '';
    this.searchCatalogItems = [];
  }

  /**
   * Search catalog items based on query
   */
  onCatalogSearch(): void {
    if (!this.catalogSearchQuery.trim()) {
      this.searchCatalogItems = [];
      return;
    }
    this.searchSubject.next(this.catalogSearchQuery);
  }

  /**
   * Perform the actual catalog search
   */
  private performCatalogSearch(query: string): void {
    if (!query.trim()) {
      this.searchCatalogItems = [];
      return;
    }

    this.isSearchingCatalog = true;
    
    this.catalogService.searchCatalogItems({
      query: query,
      limit: 20,
      sort: 'updated_date',
      order: 'desc'
    }).subscribe({
      next: (response) => {
        this.searchCatalogItems = response.items || [];
        this.isSearchingCatalog = false;
      },
      error: (error) => {
        console.error('Error searching catalog items:', error);
        this.searchCatalogItems = [];
        this.isSearchingCatalog = false;
      }
    });
  }

  /**
   * Insert selected catalog item as a card in the newsletter content
   */
  insertCatalogItem(item: Catalog): void {
    const cardHtml = this.generateCatalogCardHtml(item);
    const currentContent = this.newsletterForm.get('content')?.value || '';
    const newContent = currentContent + '\n\n' + cardHtml;
    
    this.newsletterForm.patchValue({ content: newContent });
    this.closeCatalogSearchPopup();
  }

  /**
   * Generate HTML for catalog item card
   */
  private generateCatalogCardHtml(item: Catalog): string {
    const typeInfo = this.catalogTypes.find(t => t.value === item.type);
    const typeLabel = typeInfo?.label || item.type;
    const authorName = item.author || 'Unknown';
    
    return `
      <div style="border: 1px solid #e0e0e0; border-radius: 8px; padding: 16px; margin: 16px 0; background: #f9f9f9;">
        <div style="display: flex; align-items: center; margin-bottom: 8px;">
          <span style="background: ${typeInfo?.background || '#ccc'}; color: ${typeInfo?.color || '#000'}; padding: 4px 8px; border-radius: 4px; font-size: 12px; margin-right: 8px;">
            ${typeLabel}
          </span>
          <span style="font-size: 12px; color: #666;">
            by ${authorName}
          </span>
        </div>
        <h4 style="margin: 0 0 8px 0; color: #333;">${item.title}</h4>
        <p style="margin: 0 0 12px 0; color: #666; line-height: 1.4;">${item.description || item.summary || ''}</p>
        <div style="font-size: 12px; color: #888;">
          ${this.formatDate(item.created_date || '')}
        </div>
      </div>
    `;
  }

  /**
   * Get catalog type label
   */
  getCatalogTypeLabel(type: string): string {
    const typeInfo = this.catalogTypes.find(t => t.value === type) || 
                     CATALOG_TYPES.find(t => t.value === type);
    return typeInfo?.label || type;
  }

  /**
   * Format date for display
   */
  formatDate(dateString: string): string {
    if (!dateString) return '';
    try {
      const date = new Date(dateString);
      return date.toLocaleDateString('en-US', {
        year: 'numeric',
        month: 'short',
        day: 'numeric'
      });
    } catch {
      return dateString;
    }
  }
}

// Local interface for catalog types with descriptions
interface CreateNewsletterCatalogType {
  value: string;
  label: string;
  icon: any;
  color: string;
  background: string;
  description: string;
}
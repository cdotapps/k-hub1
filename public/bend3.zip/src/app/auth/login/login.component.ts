import { Component, OnInit, OnDestroy } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router, ActivatedRoute } from '@angular/router';
import { AuthService } from '../../shared/services/auth.service';
import { faEye, faEyeSlash, faUser, faLock, faSpinner, faRocket, faUsers, faShieldAlt, faCircle, faExclamationTriangle, faSync } from '@fortawesome/free-solid-svg-icons';
import { Subscription, interval } from 'rxjs';
import { APP_CONFIG } from '../../shared/config/site-config';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit, OnDestroy {
  appName = APP_CONFIG.name;
  loginForm: FormGroup;
  isLoading = false;
  errorMessage = '';
  showPassword = false;
  returnUrl = '';

  // API Health Check properties
  apiStatus: 'checking' | 'online' | 'offline' = 'checking';
  lastHealthCheck: Date | null = null;
  healthCheckSubscription?: Subscription;
  healthCheckInterval = 30000; // 30 seconds

  // Font Awesome icons
  faEye = faEye;
  faEyeSlash = faEyeSlash;
  faUser = faUser;
  faLock = faLock;
  faSpinner = faSpinner;
  faRocket = faRocket;
  faUsers = faUsers;
  faShieldAlt = faShieldAlt;
  faCircle = faCircle;
  faExclamationTriangle = faExclamationTriangle;
  faSync = faSync;

  constructor(
    private formBuilder: FormBuilder,
    private authService: AuthService,
    private router: Router,
    private route: ActivatedRoute
  ) {
    this.loginForm = this.formBuilder.group({
      user_id: ['', [Validators.required, Validators.minLength(3)]],
      password: ['', [Validators.required, Validators.minLength(6)]]
    });
  }

  ngOnInit(): void {
    // Get return url from route parameters or default to '/'
    this.returnUrl = this.route.snapshot.queryParams['returnUrl'] || '/';

    // Redirect if already authenticated
    if (this.authService.isAuthenticated()) {
      this.router.navigate([this.returnUrl]);
    }

    // Start API health check
    this.startHealthCheck();
  }

  ngOnDestroy(): void {
    // Clean up subscription on destroy
    this.healthCheckSubscription?.unsubscribe();
  }

  get f() {
    return this.loginForm.controls;
  }

  togglePasswordVisibility(): void {
    this.showPassword = !this.showPassword;
  }

  onSubmit(): void {
    if (this.loginForm.invalid) {
      this.markFormGroupTouched();
      return;
    }

    this.setLoadingState(true);
    this.errorMessage = '';

    const credentials = {
      user_id: this.f['user_id'].value.trim(),
      password: this.f['password'].value
    };

    console.log('Login component: Submitting login form');

    this.authService.login(credentials).subscribe({
      next: (response) => {
        console.log('Login component: Login successful');
        this.setLoadingState(false);
      },
      error: (error) => {
        console.log('Login component: Login failed with error:', error);
        this.setLoadingState(false);
        this.errorMessage = error.message || 'Login failed. Please try again.';
        
        // Clear the password field for security
        this.loginForm.patchValue({ password: '' });
      }
    });
  }

  private setLoadingState(loading: boolean): void {
    this.isLoading = loading;
    // Use the proper reactive form methods to avoid "changed after checked" errors
    if (loading) {
      this.loginForm.get('user_id')?.disable();
      this.loginForm.get('password')?.disable();
    } else {
      this.loginForm.get('user_id')?.enable();
      this.loginForm.get('password')?.enable();
    }
  }

  private markFormGroupTouched(): void {
    Object.keys(this.loginForm.controls).forEach(field => {
      const control = this.loginForm.get(field);
      control?.markAsTouched({ onlySelf: true });
    });
  }

  navigateToRegister(): void {
    this.router.navigate(['/register']);
  }

  getFieldError(fieldName: string): string {
    const field = this.loginForm.get(fieldName);
    if (field?.errors && field.touched) {
      if (field.errors['required']) {
        return `${this.getFieldDisplayName(fieldName)} is required`;
      }
      if (field.errors['minlength']) {
        const minLength = field.errors['minlength'].requiredLength;
        return `${this.getFieldDisplayName(fieldName)} must be at least ${minLength} characters`;
      }
    }
    return '';
  }

  private getFieldDisplayName(fieldName: string): string {
    const displayNames: { [key: string]: string } = {
      'user_id': 'User ID',
      'password': 'Password'
    };
    return displayNames[fieldName] || fieldName;
  }

  hasFieldError(fieldName: string): boolean {
    const field = this.loginForm.get(fieldName);
    return !!(field?.errors && field.touched);
  }

  private startHealthCheck(): void {
    // Initial health check
    this.checkApiHealth();
    
    // Set up interval for periodic checks
    this.healthCheckSubscription = interval(this.healthCheckInterval).subscribe(() => {
      this.checkApiHealth();
    });
  }

  private checkApiHealth(): void {
    this.authService.checkApiHealth().subscribe({
      next: (response) => {
        this.apiStatus = 'online';
        this.lastHealthCheck = new Date();
      },
      error: (error) => {
        this.apiStatus = 'offline';
        this.lastHealthCheck = new Date();
      }
    });
  }

  /**
   * Manual health check triggered by user
   */
  refreshHealthCheck(): void {
    this.apiStatus = 'checking';
    this.checkApiHealth();
  }

  /**
   * Get status display text
   */
  getStatusText(): string {
    switch (this.apiStatus) {
      case 'online':
        return 'System Online';
      case 'offline':
        return 'System Offline';
      case 'checking':
        return 'Checking...';
      default:
        return 'Unknown';
    }
  }

  /**
   * Get status icon class
   */
  getStatusClass(): string {
    switch (this.apiStatus) {
      case 'online':
        return 'status-online';
      case 'offline':
        return 'status-offline';
      case 'checking':
        return 'status-checking';
      default:
        return 'status-unknown';
    }
  }

  /**
   * Get last check time formatted
   */
  getLastCheckTime(): string {
    if (!this.lastHealthCheck) return 'Never';
    
    const now = new Date();
    const diff = now.getTime() - this.lastHealthCheck.getTime();
    const seconds = Math.floor(diff / 1000);
    
    if (seconds < 60) {
      return `${seconds}s ago`;
    } else if (seconds < 3600) {
      const minutes = Math.floor(seconds / 60);
      return `${minutes}m ago`;
    } else {
      return this.lastHealthCheck.toLocaleTimeString();
    }
  }
}
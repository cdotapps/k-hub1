import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FontawesomeModule } from '../../shared/fontawesome.module';
import { RouterModule } from '@angular/router';

@Component({
  selector: 'app-blogs',
  standalone: true,
  imports: [CommonModule, FontawesomeModule, RouterModule],
  templateUrl: './blogs.component.html',
  styleUrls: ['./blogs.component.css']
})
export class BlogsComponent {
  // Component logic will go here
}

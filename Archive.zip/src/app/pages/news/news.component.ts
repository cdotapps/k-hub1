import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FontawesomeModule } from '../../shared/fontawesome.module';
import { RouterModule } from '@angular/router';

@Component({
  selector: 'app-news',
  standalone: true,
  imports: [CommonModule, FontawesomeModule, RouterModule],
  templateUrl: './news.component.html',
  styleUrls: ['./news.component.css']
})
export class NewsComponent {
  // Component logic will go here
}

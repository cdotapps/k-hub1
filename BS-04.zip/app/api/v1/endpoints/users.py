from typing import Any, List, Optional
from fastapi import APIRouter, Body, Depends, HTTPException, status
from sqlalchemy.ext.asyncio import AsyncSession
import logging

from app import crud, models
from app.schemas import user as schemas
from app.api import deps
from app.db.session import get_db

# Set up logger
logger = logging.getLogger(__name__)

router = APIRouter()

# Current user endpoints
@router.get("/me", response_model=schemas.User)
async def get_current_user(
    db: AsyncSession = Depends(get_db),
    current_user: models.User = Depends(deps.get_current_user),
) -> Any:
    """
    Get current user profile with manager details if available.
    """
    # Debug logging for user profile data
    logger.info(f"🔍 [DEBUG] Current user profile: {current_user.__dict__}")
    logger.info(f"🔍 [DEBUG] Current user ID: {current_user.id}")
    logger.info(f"🔍 [DEBUG] Current user email: {current_user.email}")
    logger.info(f"🔍 [DEBUG] Current user manager_id: {current_user.manager_id}")
    
    # Check if manager object is already embedded
    manager_obj = getattr(current_user, 'manager', None)
    logger.info(f"🔍 [DEBUG] Current user manager object: {manager_obj}")
    
    # If the user has a manager, fetch the manager's details
    if current_user.manager_id:
        logger.info(f"🔍 [DEBUG] Attempting to fetch manager with ID: {current_user.manager_id}")
        try:
            manager = await crud.user.get(db, id=current_user.manager_id)
            if manager:
                logger.info(f"🔍 [DEBUG] Manager found: {manager.email} ({manager.first_name} {manager.last_name})")
                # Attach manager info to the response
                current_user.manager = manager
                logger.info(f"🔍 [DEBUG] Manager attached to user profile successfully")
            else:
                logger.warning(f"🔍 [DEBUG] Manager with ID {current_user.manager_id} not found in database")
        except Exception as e:
            logger.error(f"🔍 [DEBUG] Error fetching manager: {str(e)}")
    else:
        logger.info(f"🔍 [DEBUG] No manager_id assigned to user")
    
    return current_user

@router.put("/me", response_model=schemas.User)
async def update_current_user(
    *,
    db: AsyncSession = Depends(get_db),
    user_in: schemas.UserProfileUpdate,
    current_user: models.User = Depends(deps.get_current_user),
) -> Any:
    """
    Update current user profile.
    """
    user = await crud.user.update(db, db_obj=current_user, obj_in=user_in)
    return user

@router.put("/me/password", response_model=schemas.Msg)
async def update_current_user_password(
    *,
    db: AsyncSession = Depends(get_db),
    current_password: str = Body(...),
    new_password: str = Body(...),
    current_user: models.User = Depends(deps.get_current_user),
) -> Any:
    """
    Update current user password.
    """
    # Verify current password
    if not crud.user.verify_password(current_password, current_user.hashed_password):
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Incorrect current password"
        )
    
    # Update password
    user_update = schemas.UserUpdate(password=new_password)
    await crud.user.update(db, db_obj=current_user, obj_in=user_update)
    
    return {"msg": "Password updated successfully"}

@router.get("/me/peers", response_model=List[schemas.User])
async def get_current_user_peers(
    db: AsyncSession = Depends(get_db),
    current_user: models.User = Depends(deps.get_current_user),
) -> Any:
    """
    Get current user's peers (colleagues who report to the same manager).
    """
    peers = await crud.user.get_user_peers(db, user=current_user)
    return peers

@router.get("/me/team", response_model=List[schemas.User])
async def get_current_user_team(
    db: AsyncSession = Depends(get_db),
    current_user: models.User = Depends(deps.get_current_user),
) -> Any:
    """
    Get current user's team members (direct reports).
    """
    team_members = await crud.user.get_team_members(db, manager=current_user)
    return team_members

# Admin-only user management endpoints
@router.get("/", response_model=List[schemas.User])
async def get_users(
    db: AsyncSession = Depends(get_db),
    skip: int = 0,
    limit: int = 100,
    page: int = None,
    page_size: int = None,
) -> Any:
    """
    Get all users (public access).
    """
    # Handle pagination parameters from frontend
    if page is not None and page_size is not None:
        skip = (page - 1) * page_size if page > 0 else 0
        limit = page_size
    
    users = await crud.user.get_multi(db, skip=skip, limit=limit)
    return users

@router.get("/{user_id}", response_model=schemas.User)
async def get_user_by_id(
    user_id: str,
    db: AsyncSession = Depends(get_db),
    current_user: models.User = Depends(deps.get_current_active_admin),
) -> Any:
    """
    Get a specific user by ID (admin only).
    """
    user = await crud.user.get(db, id=user_id)
    if not user:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="User not found"
        )
    return user

@router.put("/{user_id}", response_model=schemas.User)
async def update_user_by_id(
    *,
    db: AsyncSession = Depends(get_db),
    user_id: str,
    user_in: schemas.UserAdminUpdate,
    current_user: models.User = Depends(deps.get_current_active_admin),
) -> Any:
    """
    Update a user by ID (admin only).
    """
    user = await crud.user.get(db, id=user_id)
    if not user:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="User not found"
        )
    user = await crud.user.update(db, db_obj=user, obj_in=user_in)
    return user

@router.patch("/{user_id}/role", response_model=schemas.User)
async def update_user_role(
    *,
    db: AsyncSession = Depends(get_db),
    user_id: str,
    role: str = Body(..., embed=True),
    current_user: models.User = Depends(deps.get_current_active_admin),
) -> Any:
    """
    Update a user's role (admin only).
    """
    user = await crud.user.get(db, id=user_id)
    if not user:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="User not found"
        )
    if role not in ["user", "admin"]:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Invalid role. Must be 'user' or 'admin'"
        )
    user_in = schemas.UserUpdate(role=role)
    user = await crud.user.update(db, db_obj=user, obj_in=user_in)
    return user

@router.patch("/{user_id}/status", response_model=schemas.User)
async def update_user_status(
    *,
    db: AsyncSession = Depends(get_db),
    user_id: str,
    is_active: bool = Body(..., embed=True),
    current_user: models.User = Depends(deps.get_current_active_admin),
) -> Any:
    """
    Update a user's active status (admin only).
    """
    user = await crud.user.get(db, id=user_id)
    if not user:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="User not found"
        )
    user_in = schemas.UserUpdate(is_active=is_active)
    user = await crud.user.update(db, db_obj=user, obj_in=user_in)
    return user

@router.patch("/{user_id}/toggle-status", response_model=schemas.User)
async def toggle_user_status(
    *,
    db: AsyncSession = Depends(get_db),
    user_id: str,
    current_user: models.User = Depends(deps.get_current_active_admin),
) -> Any:
    """
    Toggle a user's active status (admin only).
    """
    user = await crud.user.get(db, id=user_id)
    if not user:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="User not found"
        )
    
    # Toggle the current active status
    user_in = schemas.UserUpdate(is_active=not user.is_active)
    user = await crud.user.update(db, db_obj=user, obj_in=user_in)
    return user

@router.delete("/{user_id}")
async def delete_user(
    *,
    db: AsyncSession = Depends(get_db),
    user_id: str,
    current_user: models.User = Depends(deps.get_current_active_admin),
) -> Any:
    """
    Delete a user (admin only).
    """
    user = await crud.user.get(db, id=user_id)
    if not user:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="User not found"
        )
    if user.id == current_user.id:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Cannot delete your own account"
        )
    await crud.user.remove(db, id=user_id)
    return {"status": "success", "msg": "User deleted successfully"}
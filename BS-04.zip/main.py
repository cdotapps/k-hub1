from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
import os
import logging
import time
from dotenv import load_dotenv

from app.api.v1.api import api_router
from app.db.session import create_tables

load_dotenv()

# Configure logging for production
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.StreamHandler(),
    ]
)

logger = logging.getLogger(__name__)

app = FastAPI(
    title=os.getenv("APP_NAME", "User Auth API"),
    version="1.0.0",
    description="User Authentication and Profile Management API with role-based access control",
)

# CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=[
        "http://localhost:3000", 
        "http://localhost:8080", 
        "http://localhost:4200",  # Angular default
        "http://localhost:5173",  # Vite default
        "http://localhost:8081",  # Alternative port
        "http://127.0.0.1:3000", 
        "http://127.0.0.1:8080",
        "http://127.0.0.1:4200",
        "http://127.0.0.1:5173",
        "http://127.0.0.1:8081",
        "*"  # Allow all origins for development (remove in production)
    ],
    allow_credentials=True,
    allow_methods=["GET", "POST", "PUT", "DELETE", "PATCH", "OPTIONS"],
    allow_headers=["*"],
    expose_headers=["*"],
)

# Include API router
app.include_router(api_router, prefix="/api/v1")

@app.get("/")
async def root():
    return {"message": "User Auth API", "version": "1.0.0"}

@app.get("/health")
async def health_check():
    return {"status": "healthy"}

@app.on_event("startup")
async def startup_event():
    """Create database tables on startup"""
    await create_tables()
    logger.info("Server started successfully")
    
    # Check SharePoint configuration status
    try:
        from app.core.config import sharepoint_settings
        from app.services.sharepoint_asset_service import sharepoint_asset_service
        
        if sharepoint_settings:
            logger.info("✅ SharePoint configuration loaded successfully")
            logger.info(f"   Site URL: {sharepoint_settings.site_url}")
            logger.info(f"   List Name: {sharepoint_settings.list_name}")
            logger.info(f"   Tenant ID: {sharepoint_settings.tenant_id}")
            
            if sharepoint_asset_service.is_configured():
                logger.info("✅ SharePoint Asset Service is ready")
            else:
                logger.warning("⚠️  SharePoint Asset Service initialization failed")
        else:
            logger.warning("⚠️  SharePoint configuration not found")
            logger.warning("   Set these environment variables for SharePoint integration:")
            logger.warning("   - SHAREPOINT_SITE_URL")
            logger.warning("   - SHAREPOINT_LIST_NAME")
            logger.warning("   - SHAREPOINT_CLIENT_ID")
            logger.warning("   - SHAREPOINT_CLIENT_SECRET")
            logger.warning("   - SHAREPOINT_TENANT_ID")
    except Exception as e:
        logger.error(f"❌ Error checking SharePoint configuration: {e}")

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(
        "main:app",
        host=os.getenv("HOST", "0.0.0.0"),
        port=int(os.getenv("PORT", 8000)),
        reload=True,
    )
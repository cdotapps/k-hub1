import { Component, Input } from '@angular/core';
import { IconDefinition } from '@fortawesome/fontawesome-svg-core';

@Component({
  selector: 'app-tool-icon',
  template: `
    <fa-icon *ngIf="faIcon" [icon]="faIcon" [spin]="spin"></fa-icon>
  `,
  styles: [`
    :host {
      display: inline-flex;
      align-items: center;
      justify-content: center;
      cursor: pointer;
    }
    fa-icon {
      font-size: 0.9rem;
      color: var(--fm-gray-500); /* Set default color to blue */
      transition: color 0.2s;
      margin-right: 0.525rem;
    }

    :host(.edit):hover fa-icon { color: var(--fm-blue-700); }
    :host(.delete):hover fa-icon { color: var(--fm-red-700); }
    :host(.link):hover fa-icon { color: var(--fm-blue-700); }
    :host(:hover) fa-icon { color: var(--fm-blue-700); }
  `]
})
export class ToolIconComponent {
  @Input() faIcon?: IconDefinition;
  @Input() spin: boolean = false;
}
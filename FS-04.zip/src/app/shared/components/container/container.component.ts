import { Component, Input } from '@angular/core';

@Component({
  selector: 'app-container',
  template: `
    <div [class]="containerClasses">
      <ng-content></ng-content>
    </div>
  `,
  styles: [`
    .container {
      width: 100%;
      margin: 0 auto;
      padding: 0 1rem;
    }

    .container-sm {
      max-width: 720px;
    }

    .container-md {
      max-width: 960px;
    }

    .container-lg {
      max-width: 1200px;
    }

    .container-xl {
      max-width: 1440px;
    }

    .container-xxl {
      max-width: 1600px;
    }

    .container-ultra {
      max-width: 1920px;
    }

    .container-fluid {
      max-width: none;
      width: 100%;
    }

    .container-centered {
      text-align: center;
    }

    /* Responsive padding - increased for better spacing */
    @media (min-width: 576px) {
      .container {
        padding: 0 1.5rem;
      }
    }

    @media (min-width: 768px) {
      .container {
        padding: 0 2rem;
      }
    }

    @media (min-width: 1200px) {
      .container {
        padding: 0 2.5rem;
      }
    }

    @media (min-width: 1440px) {
      .container {
        padding: 0 3rem;
      }
    }
  `]
})
export class ContainerComponent {
  @Input() size: 'sm' | 'md' | 'lg' | 'xl' | 'xxl' | 'ultra' | 'fluid' = 'xxl';
  @Input() centered: boolean = false;

  get containerClasses(): string {
    const classes = ['container'];
    
    if (this.size !== 'xxl') {
      classes.push(`container-${this.size}`);
    }
    
    if (this.centered) {
      classes.push('container-centered');
    }
    
    return classes.join(' ');
  }
}
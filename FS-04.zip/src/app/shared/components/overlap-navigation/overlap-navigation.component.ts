import { Component, Input, Output, EventEmitter } from '@angular/core';
import { OverlapButtonConfig } from '../overlap-button/overlap-button.component';

@Component({
  selector: 'app-overlap-navigation',
  template: `
    <div class="overlap-container">
      <app-container>
        <div class="overlap-content">
          <div class="overlap-card">
            <div class="overlap-grid">
              <app-overlap-button
                *ngFor="let button of buttons"
                [icon]="button.icon"
                [label]="button.label"
                [badgeCount]="button.badgeCount"
                [isActive]="button.isActive || false"
                [iconVariant]="button.iconVariant"
                [route]="button.route"
                (buttonClick)="onNavigate($event)"
              ></app-overlap-button>
            </div>
          </div>
        </div>
      </app-container>
    </div>
  `,
  styles: [`
    /* Overlapping Container Styles */
    .overlap-container {
      position: relative;
      z-index: 10;
      max-height: 100px;
      margin-top: -50px;
      margin-bottom: 50px;
    }
    
    .overlap-content {
      display: flex;
      justify-content: center;
      align-items: center;
    }
    
    .overlap-card {
      background: var(--fm-white);
      border-radius: 50px 0px 50px 0px;
      box-shadow: 0 20px 60px rgba(0, 0, 0, 0.1);
      padding: 1rem 2rem;
      width: 100%;
      max-width: 800px;
      border: 1px solid rgba(0, 0, 0, 0.05);
      .icon{
        color: var(--fm-white);
      }
      
    }
    
    .overlap-grid {
      display: flex;
      flex-direction: row;
      justify-content: space-between;
      align-items: center;
      gap: 1rem;
      flex-wrap: nowrap;
      overflow-x: auto;
    }
    
    /* Responsive Design */
    @media (max-width: 768px) {
      .overlap-container {
        margin-top: -80px;
        margin-bottom: 80px;
      }
      
      .overlap-card {
        padding: 1.25rem 0.75rem;
        border-radius: 15px;
        max-width: 500px;
      }
      
      .overlap-grid {
        gap: 0.25rem;
        justify-content: space-around;
        padding: 0 0.25rem;
        overflow-x: auto;
        scrollbar-width: none;
        -ms-overflow-style: none;
      }
      
      .overlap-grid::-webkit-scrollbar {
        display: none;
      }
    }
  `]
})
export class OverlapNavigationComponent {
  @Input() buttons: OverlapButtonConfig[] = [];
  @Output() navigate = new EventEmitter<string>();
  
  onNavigate(route: string): void {
    this.navigate.emit(route);
  }
}
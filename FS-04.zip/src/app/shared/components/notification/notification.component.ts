import { Component, Input, Output, EventEmitter, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FontAwesomeModule } from '@fortawesome/angular-fontawesome';
import { IconDefinition } from '@fortawesome/fontawesome-svg-core';
import { 
  faCheckCircle, 
  faExclamationTriangle, 
  faInfoCircle, 
  faTimes,
  faClipboard,
  faDownload
} from '@fortawesome/free-solid-svg-icons';

export type NotificationType = 'success' | 'warning' | 'info' | 'error';

@Component({
  selector: 'app-notification',
  standalone: true,
  imports: [CommonModule, FontAwesomeModule],
  template: `
    <div class="notification-overlay" *ngIf="show" (click)="onOverlayClick()">
      <div class="notification-modal" (click)="$event.stopPropagation()">
        <div class="notification-header" [ngClass]="'notification-' + type">
          <div class="notification-icon">
            <fa-icon [icon]="getIcon()"></fa-icon>
          </div>
          <h3 class="notification-title">{{ title }}</h3>
          <button class="notification-close" (click)="onClose()">
            <fa-icon [icon]="faTimes"></fa-icon>
          </button>
        </div>
        
        <div class="notification-content">
          <p class="notification-message">{{ message }}</p>
          
          <div class="notification-instructions" *ngIf="instructions && instructions.length > 0">
            <h4>How to use:</h4>
            <ol>
              <li *ngFor="let instruction of instructions">{{ instruction }}</li>
            </ol>
          </div>
        </div>
        
        <div class="notification-actions" *ngIf="actions && actions.length > 0">
          <button 
            *ngFor="let action of actions"
            class="notification-btn"
            [ngClass]="'btn-' + action.type"
            (click)="onActionClick(action)"
          >
            <fa-icon [icon]="action.icon" *ngIf="action.icon"></fa-icon>
            {{ action.label }}
          </button>
        </div>
      </div>
    </div>
  `,
  styles: [`
    .notification-overlay {
      position: fixed;
      top: 0;
      left: 0;
      right: 0;
      bottom: 0;
      background: rgba(0, 0, 0, 0.5);
      display: flex;
      align-items: center;
      justify-content: center;
      z-index: 9999;
      padding: 1rem;
    }

    .notification-modal {
      background: white;
      border-radius: 12px;
      box-shadow: 0 20px 60px rgba(0, 0, 0, 0.3);
      max-width: 500px;
      width: 100%;
      max-height: 80vh;
      overflow-y: auto;
      animation: slideIn 0.3s ease-out;
    }

    @keyframes slideIn {
      from {
        transform: translateY(-20px);
        opacity: 0;
      }
      to {
        transform: translateY(0);
        opacity: 1;
      }
    }

    .notification-header {
      display: flex;
      align-items: center;
      padding: 1.5rem;
      border-bottom: 1px solid #e5e7eb;
      gap: 1rem;
    }

    .notification-header.notification-success {
      background: linear-gradient(135deg, #10b981 0%, #059669 100%);
      color: white;
    }

    .notification-header.notification-info {
      background: linear-gradient(135deg, #3b82f6 0%, #1e40af 100%);
      color: white;
    }

    .notification-header.notification-warning {
      background: linear-gradient(135deg, #f59e0b 0%, #d97706 100%);
      color: white;
    }

    .notification-header.notification-error {
      background: linear-gradient(135deg, #ef4444 0%, #dc2626 100%);
      color: white;
    }

    .notification-icon {
      font-size: 1.5rem;
      flex-shrink: 0;
    }

    .notification-title {
      flex: 1;
      margin: 0;
      font-size: 1.25rem;
      font-weight: 600;
    }

    .notification-close {
      background: none;
      border: none;
      color: inherit;
      font-size: 1.25rem;
      cursor: pointer;
      padding: 0.25rem;
      border-radius: 4px;
      transition: background-color 0.2s;
      flex-shrink: 0;
    }

    .notification-close:hover {
      background: rgba(255, 255, 255, 0.2);
    }

    .notification-content {
      padding: 1.5rem;
    }

    .notification-message {
      margin: 0 0 1rem 0;
      font-size: 1rem;
      line-height: 1.6;
      color: #374151;
    }

    .notification-instructions {
      background: #f8fafc;
      border: 1px solid #e2e8f0;
      border-radius: 8px;
      padding: 1rem;
      margin-top: 1rem;
    }

    .notification-instructions h4 {
      margin: 0 0 0.75rem 0;
      font-size: 0.9rem;
      font-weight: 600;
      color: #1f2937;
    }

    .notification-instructions ol {
      margin: 0;
      padding-left: 1.25rem;
    }

    .notification-instructions li {
      margin-bottom: 0.5rem;
      font-size: 0.9rem;
      color: #4b5563;
    }

    .notification-instructions li:last-child {
      margin-bottom: 0;
    }

    .notification-actions {
      padding: 1rem 1.5rem 1.5rem;
      display: flex;
      gap: 0.75rem;
      justify-content: flex-end;
      border-top: 1px solid #e5e7eb;
    }

    .notification-btn {
      display: flex;
      align-items: center;
      gap: 0.5rem;
      padding: 0.625rem 1.25rem;
      border: none;
      border-radius: 6px;
      font-size: 0.875rem;
      font-weight: 500;
      cursor: pointer;
      transition: all 0.2s ease;
      text-decoration: none;
    }

    .notification-btn.btn-primary {
      background: #3b82f6;
      color: white;
    }

    .notification-btn.btn-primary:hover {
      background: #2563eb;
      transform: translateY(-1px);
      box-shadow: 0 4px 12px rgba(59, 130, 246, 0.4);
    }

    .notification-btn.btn-secondary {
      background: #6b7280;
      color: white;
    }

    .notification-btn.btn-secondary:hover {
      background: #4b5563;
      transform: translateY(-1px);
      box-shadow: 0 4px 12px rgba(107, 114, 128, 0.4);
    }

    .notification-btn.btn-success {
      background: #10b981;
      color: white;
    }

    .notification-btn.btn-success:hover {
      background: #059669;
      transform: translateY(-1px);
      box-shadow: 0 4px 12px rgba(16, 185, 129, 0.4);
    }

    /* Mobile responsiveness */
    @media (max-width: 640px) {
      .notification-modal {
        margin: 1rem;
        max-width: calc(100vw - 2rem);
      }

      .notification-header {
        padding: 1rem;
      }

      .notification-content {
        padding: 1rem;
      }

      .notification-actions {
        padding: 0.75rem 1rem 1rem;
        flex-direction: column;
      }

      .notification-btn {
        width: 100%;
        justify-content: center;
      }
    }
  `]
})
export class NotificationComponent implements OnInit {
  @Input() show = false;
  @Input() type: NotificationType = 'info';
  @Input() title = '';
  @Input() message = '';
  @Input() instructions: string[] = [];
  @Input() actions: NotificationAction[] = [];
  @Input() autoClose = false;
  @Input() autoCloseDelay = 5000;

  @Output() close = new EventEmitter<void>();
  @Output() actionClick = new EventEmitter<NotificationAction>();

  // FontAwesome icons
  faCheckCircle = faCheckCircle;
  faExclamationTriangle = faExclamationTriangle;
  faInfoCircle = faInfoCircle;
  faTimes = faTimes;
  faClipboard = faClipboard;
  faDownload = faDownload;

  ngOnInit() {
    if (this.autoClose && this.show) {
      setTimeout(() => {
        this.onClose();
      }, this.autoCloseDelay);
    }
  }

  getIcon(): IconDefinition {
    switch (this.type) {
      case 'success':
        return this.faCheckCircle;
      case 'warning':
        return this.faExclamationTriangle;
      case 'error':
        return this.faExclamationTriangle;
      case 'info':
      default:
        return this.faInfoCircle;
    }
  }

  onClose(): void {
    this.close.emit();
  }

  onOverlayClick(): void {
    this.onClose();
  }

  onActionClick(action: NotificationAction): void {
    this.actionClick.emit(action);
  }
}

export interface NotificationAction {
  id: string;
  label: string;
  type: 'primary' | 'secondary' | 'success';
  icon?: IconDefinition;
  handler?: () => void;
}

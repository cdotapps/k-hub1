import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';

// Font Awesome
import { FontAwesomeModule } from '@fortawesome/angular-fontawesome';

import { ButtonComponent } from './components/button/button.component';
import { ActionButtonComponent } from './components/button/action-button.component';
import { ToolButtonComponent } from './components/button/tool-button.component';
import { IconButtonComponent } from './components/button/icon-button.component';
import { CardComponent } from './components/card/card.component';
import { IconComponent } from './components/icon/icon.component';
import { ContainerComponent } from './components/container/container.component';
import { HeaderComponent } from './components/header/header.component';
import { FooterComponent } from './components/footer/footer.component';
import { NewsBarComponent } from './components/news-bar/news-bar.component';
import { ProfileCardComponent } from './components/profile-card/profile-card.component';
import { NotificationsPanelComponent } from './components/notifications-panel/notifications-panel.component';
import { BreadcrumbComponent } from './components/breadcrumb/breadcrumb.component';
import { SearchComponent } from './components/search/search.component';
import { UserSearchComponent } from './components/user-search/user-search.component';
import { OverlapButtonComponent } from './components/overlap-button/overlap-button.component';
import { OverlapNavigationComponent } from './components/overlap-navigation/overlap-navigation.component';
import { RichTextEditorComponent } from './components/rich-text-editor/rich-text-editor.component';
import { PageHeroComponent } from './components/page-hero/page-hero.component';
import { PageMinimalHeroComponent } from './components/page-minimal-hero/page-minimal-hero.component';
import { CatalogCardComponent } from './components/card/catalog-card.component';
import { SampleComponent } from './components/sample/sample.component';
import { PopupContainerComponent } from './components/popup-container/popup-container.component';
import { SharePopupComponent } from './components/share-popup/share-popup.component';
import { NotificationComponent } from './components/notification/notification.component';
import { DataTableComponent } from './components/data-table/data-table.component';
import { SmartListComponent } from './components/smart-list/smart-list.component';
import { PopupBottomComponent } from './components/popup-bottom/popup-bottom.component';
import { TabsComponent } from './components/tabs/tabs.component';
import { CardMetricComponent } from './components/card-metric/card-metric.component';
import { CardMetricListComponent } from './components/card-metric-list/card-metric-list.component';
import { ToolIconComponent } from './components/tool-icon/tool-icon.component';

@NgModule({
  declarations: [
    ButtonComponent,
    CardComponent,
    IconComponent,
    ContainerComponent,
    HeaderComponent,
    FooterComponent,
    NewsBarComponent,
    ProfileCardComponent,
    NotificationsPanelComponent,
    BreadcrumbComponent,
    SearchComponent,
    UserSearchComponent,
    OverlapButtonComponent,
    OverlapNavigationComponent,
    RichTextEditorComponent,
    PageHeroComponent,
    PageMinimalHeroComponent,
    CatalogCardComponent,
    SampleComponent,
    PopupContainerComponent,
    SharePopupComponent,
    DataTableComponent,
    SmartListComponent,
    PopupBottomComponent,
    TabsComponent,
    CardMetricComponent,
    CardMetricListComponent,
    ToolIconComponent
  ],
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    FontAwesomeModule,
    RouterModule,
    ActionButtonComponent,
    ToolButtonComponent,
    IconButtonComponent,
    NotificationComponent
  ],
  exports: [
    ButtonComponent,
    ActionButtonComponent,
    ToolButtonComponent,
    IconButtonComponent,
    CardComponent,
    IconComponent,
    ContainerComponent,
    HeaderComponent,
    FooterComponent,
    NewsBarComponent,
    ProfileCardComponent,
    NotificationsPanelComponent,
    BreadcrumbComponent,
    SearchComponent,
    UserSearchComponent,
    OverlapButtonComponent,
    OverlapNavigationComponent,
    RichTextEditorComponent,
    PageHeroComponent,
    PageMinimalHeroComponent,
    CatalogCardComponent,
    PopupContainerComponent,
    SharePopupComponent,
    NotificationComponent,
    DataTableComponent,
    FontAwesomeModule,
    FormsModule,
    ReactiveFormsModule,
    CommonModule,
    SmartListComponent,
    PopupBottomComponent,
    TabsComponent,
    CardMetricComponent,
    CardMetricListComponent,
    ToolIconComponent
  ]
})
export class SharedModule { }
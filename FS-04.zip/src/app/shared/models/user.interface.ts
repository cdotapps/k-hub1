export enum UserDesignation {
  ASSOCIATE = "Associate",
  LEAD_ASSOCIATE = "Lead Associate", 
  MANAGER = "Manager",
  SENIOR_MANAGER = "Senior Manager",
  ADVISOR = "Advisor",
  DIRECTOR = "Director",
  SENIOR_DIRECTOR = "Senior Director",
  PRINCIPAL = "Principal",
  VICE_PRESIDENT = "Vice President",
  SENIOR_VICE_PRESIDENT = "Senior Vice President",
  FELLOW = "Fellow"
}

export interface ConversationMessage {
  id: string;
  user_id: string;
  user_name: string;
  user_profile_image?: string; // Added profile image property
  message: string;
  created_date: string;
  updated_date?: string;
  parent_id?: string; // For reply threading
  likes?: number;
  replies?: ConversationMessage[];
}

export interface CatalogConversation {
  messages: ConversationMessage[];
  total_messages: number;
  last_activity: string;
}

export interface User {
  id: string;
  user_id?: string;
  email?: string;
  first_name?: string;
  last_name?: string;
  profile_image?: string; // Added profile image property
  is_active?: boolean;
  role?: "user" | "admin";
  is_superuser?: boolean;
  email_verified?: boolean;
  manager_id?: string;
  portfolio_id?: string;
  organization_id?: string;
  costcenter_id?: string;
  user_type?: string; // Changed from enum to string to match API
  designation?: "Associate" | "Lead Associate" | "Manager" | "Senior Manager" | "Advisor" | "Director" | "Senior Director" | "Principal" | "Vice President" | "Senior Vice President" | "Fellow"; // Updated to match API spec
  status?: "pending" | "approved" | "rejected";
  created_date: string;     // Changed from created_date to match API
  updated_date?: string;    // Changed from updated_date to match API
  last_login?: string;
  manager?: {
    id: string;
    user_id: string;
    first_name: string;
    last_name: string;
    designation?: "Associate" | "Lead Associate" | "Manager" | "Senior Manager" | "Advisor" | "Director" | "Senior Director" | "Principal" | "Vice President" | "Senior Vice President" | "Fellow"; // Updated to match API spec
  };
}

export interface UserCreate {
  user_id: string;
  email?: string;
  first_name: string;
  last_name: string;
  password: string;
  is_active?: boolean;
  role?: "user" | "admin";
  is_superuser?: boolean;
  email_verified?: boolean;
  manager_id?: string;
  portfolio_id?: string;
  organization_id?: string;
  costcenter_id?: string;
  user_type?: string; // Changed from enum to string to match API
  designation?: "Associate" | "Lead Associate" | "Manager" | "Senior Manager" | "Advisor" | "Director" | "Senior Director" | "Principal" | "Vice President" | "Senior Vice President" | "Fellow"; // Updated to match API spec
}

export interface LoginRequest {
  user_id: string;
  password: string;
}

export interface TokenResponse {
  access_token: string;
  refresh_token: string;
  token_type: string;
  user: {
    id: string;
    user_id: string;
    email?: string;
    first_name: string;
    last_name: string;
    role: "user" | "admin";
  };
}

export interface ApiResponse<T> {
  data?: T;
  message?: string;
  error?: string;
}

export interface CatalogChildItem {
  id: string | number; // The catalog ID of the child item
  index: number; // The child index number for ordering (0-based)
  title?: string;
  description?: string;
  author?: string; // Made optional to match usage patterns
  [key: string]: any; // Allow additional properties
}

export interface Catalog {
  id: string;
  key?: string; // Added key attribute
  title: string;
  type: string;
  description?: string;
  summary?: string;
  content?: string;
  url?: string;
  image?: string;
  imageUrl?: string;
  display?: string;
  tags?: string[];
  author?: string;
  read?: boolean; // NEW: Indicates if the catalog item has been marked as read
  author_id?: string; // Added this property
  created_date?: string;
  updated_date?: string;
  expire_date?: string;
  due_date?: string;
  custom?: Record<string, any>;
  category?: string;
  parent_id?: string; // Added this property
  child_ids?: string[] | CatalogChildItem[]; // Updated to support both formats
  priority?: 'high' | 'medium' | 'low'; // NEW: Priority level of the catalog item
  severity?: 'high' | 'medium' | 'low'; // NEW: Severity level of the catalog item  
  urgent?: boolean; // NEW: Indicates if the catalog item is urgent
  important?: boolean; // NEW: Indicates if the catalog item is important
  likes?: number;
  likes_count?: number; // Added this property
  usages?: number;
  favorites?: number;
  views?: number;
  views_count?: number; // Added this property
  shares?: number;
  approved_by?: string;
  reviewed_by?: string;
  source?: string;
  status?: string;
  published_at?: string; // Added this property
  user_has_liked?: boolean; // Added this property
  conversations?: CatalogConversation; // Added this property
  shared_with?: SharedUser[]; // Client-side rich metadata for shared users
  shared_with_ids?: string[]; // API-compatible field - array of user IDs only
  private?: boolean; // Indicates if the catalog item is private (added for team feed logic)
}

export interface SharedUser {
  id: string;
  name: string;
  shared_date: string;
  access: 'read' | 'write' | 'admin';
}

export interface CatalogCreate {
  title: string;
  type: string;
  description?: string;
  summary?: string;
  content?: string;
  url?: string;
  image?: string;
  imageUrl?: string;
  display?: string;
  tags?: string[];
  author?: string;
  custom?: Record<string, any>;
  category?: string;
  parent_id?: string; // Added this property
  child_ids?: string[] | CatalogChildItem[]; // Updated to support both formats
  priority?: 'high' | 'medium' | 'low'; // NEW: Priority level of the catalog item
  severity?: 'high' | 'medium' | 'low'; // NEW: Severity level of the catalog item  
  urgent?: boolean; // NEW: Indicates if the catalog item is urgent
  important?: boolean; // NEW: Indicates if the catalog item is important
  likes?: number;
  usages?: number;
  favorites?: number;
  views?: number;
  shares?: number;
  source?: string;
  status?: string;
  created_date?: string; // Added this property
  updated_date?: string; // Added this property
}

export interface CatalogUpdate {
  title?: string;
  type?: string;
  description?: string;
  summary?: string;
  content?: string;
  url?: string;
  image?: string;
  imageUrl?: string;
  display?: string;
  tags?: string[];
  author?: string;
  expire_date?: string;
  due_date?: string;
  custom?: Record<string, any>;
  category?: string;
  parent_id?: string; // Added this property
  child_ids?: string[] | CatalogChildItem[]; // Updated to support both formats
  priority?: 'high' | 'medium' | 'low'; // NEW: Priority level of the catalog item
  severity?: 'high' | 'medium' | 'low'; // NEW: Severity level of the catalog item  
  urgent?: boolean; // NEW: Indicates if the catalog item is urgent
  important?: boolean; // NEW: Indicates if the catalog item is important
  likes?: number;
  usages?: number;
  favorites?: number;
  views?: number;
  shares?: number;
  approved_by?: string;
  reviewed_by?: string;
  source?: string;
  status?: string;
}

export interface CatalogResponse {
  items: Catalog[];
  total: number;
  limit: number;
  offset: number;
  page?: number;
  page_size?: number;
  total_pages?: number;
}

export interface CatalogQueryParams {
  type?: string;
  query?: string;
  search?: string;
  q?: string;
  title?: string;
  category?: string;
  status?: string;
  author?: string;
  priority?: 'high' | 'medium' | 'low'; // NEW: Filter by priority level
  severity?: 'high' | 'medium' | 'low'; // NEW: Filter by severity level
  urgent?: boolean; // NEW: Filter by urgent items
  important?: boolean; // NEW: Filter by important items
  page?: number;
  page_size?: number;
  skip?: number;
  limit?: number;
  approved_by?: string;
  reviewed_by?: string;
  source?: string;
  tags?: string;
}

export interface WebhookEvent {
  id: string;
  name: string;
  description: string;
}

export interface Webhook {
  id: string;
  name: string;
  url: string;
  events: string[];
  secret?: string;
  enabled: boolean;
  created_date: string;
  updated_date?: string;
  last_triggered_at?: string;
  last_response_status?: number;
}

export interface WebhookCreate {
  name: string;
  url: string;
  events: string[];
  secret?: string;
  enabled?: boolean;
}

export interface WebhookUpdate {
  name?: string;
  url?: string;
  events?: string[];
  secret?: string;
  enabled?: boolean;
}

export interface WebhookDelivery {
  id: string;
  webhook_id: string;
  event: string;
  request_body: any;
  response_status: number;
  response_headers?: Record<string, string>;
  response_body?: string;
  created_date: string;
  duration_ms: number;
}

export interface WebhookTestResult {
  success: boolean;
  message: string;
  delivery_id?: string;
  request_body?: any;
  response_status?: number;
  response_headers?: Record<string, string>;
  response_body?: string;
  duration_ms?: number;
}

export interface WebhookResponse {
  items: Webhook[];
  total: number;
  limit: number;
  offset: number;
  page?: number;
  page_size?: number;
  total_pages?: number;
}
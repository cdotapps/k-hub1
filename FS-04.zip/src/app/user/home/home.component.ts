import { Component, Input, OnInit, OnDestroy } from '@angular/core';
import { Router } from '@angular/router';
import {
  faChartLine, faFolder, faFileAlt, faLightbulb, faHandshake, faRocket,
  faUser, faCog, faBookmark, faHeart, faCheck, faTimes, faUserCog,
  faExclamationTriangle, faArrowTrendUp, faArrowTrendDown, faPlus, faSearch,
  faBell, faChartPie, faCalendarAlt, faArrowUp, faArrowDown, faEye,
  faThumbsUp, faShare, faDownload, faEdit, faStar, faChevronDown, faUsers,
  faEllipsisV, faNewspaper, faBook, faGraduationCap, faBlog, faFlask,
  faFileContract, faChartLine as faAnalytics, faCheckCircle,
  faExclamationCircle, faClock, faComments
} from '@fortawesome/free-solid-svg-icons';
import { CatalogService } from '../../shared/services/catalog.service';
import { UserService } from '../../shared/services/user.service';
import { AuthService } from '../../shared/services/auth.service';
import { User, Catalog } from '../../shared/models/user.interface';
import { OverlapButtonConfig } from '../../shared/components/overlap-button/overlap-button.component';
import { HOME_NAVIGATION_BUTTONS, CATALOG_TYPES } from '../../shared/config/site-config';
import { Subscription, Observable, of, forkJoin } from 'rxjs';
import { map, catchError } from 'rxjs/operators';
import { SmartListPost } from '../../shared/components/smart-list/smart-list.component';

// Updated interfaces for real data
interface PendingApproval {
  id: string;
  title: string;
  type: string;
  submittedBy: string;
  submittedByUserId: string;
  submittedDate: string;
  priority: 'high' | 'medium' | 'low';
  status: string;
  description?: string;
  content?: string;
}

interface Alert {
  id: string;
  message: string;
  type: 'warning' | 'info' | 'error';
  timestamp: string;
}

interface ActivityItem {
  id: string;
  title: string;
  type: 'created' | 'updated' | 'approved' | 'shared';
  timestamp: string;
  user: string;
}

interface Recommendation {
  id: string;
  title: string;
  type: 'article' | 'tool' | 'resource';
  description: string;
  url: string;
}

interface BookmarkedItem {
  id: string;
  title: string;
  type: 'project' | 'document';
  bookmarkedDate: string;
}

interface TeamFeedItem {
  id: string;
  title: string;
  type: string;
  sharedBy: string;
  sharedByUserId: string;
  sharedDate: string;
  description?: string;
  priority?: 'high' | 'medium' | 'low';
  action: 'shared' | 'updated' | 'commented';
}

@Component({
  selector: 'app-user-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class UserHomeComponent implements OnInit, OnDestroy {
  // Font Awesome icons
  faChartLine = faChartLine;
  faFolder = faFolder;
  faFileAlt = faFileAlt;
  faLightbulb = faLightbulb;
  faHandshake = faHandshake;
  faRocket = faRocket;
  faUser = faUser;
  faCog = faCog;
  faBookmark = faBookmark;
  faHeart = faHeart;
  faCheck = faCheck;
  faTimes = faTimes;
  faUserCog = faUserCog;
  faExclamationTriangle = faExclamationTriangle;
  faArrowTrendUp = faArrowTrendUp;
  faArrowTrendDown = faArrowTrendDown;
  faPlus = faPlus;
  faSearch = faSearch;
  faBell = faBell;
  faChartPie = faChartPie;
  faCalendarAlt = faCalendarAlt;
  faArrowUp = faArrowUp;
  faArrowDown = faArrowDown;
  faEye = faEye;
  faThumbsUp = faThumbsUp;
  faShare = faShare;
  faDownload = faDownload;
  faEdit = faEdit;
  faStar = faStar;
  faChevronDown = faChevronDown;
  faUsers = faUsers;
  faEllipsisV = faEllipsisV;
  faNewspaper = faNewspaper;
  faBook = faBook;
  faGraduationCap = faGraduationCap;
  faBlog = faBlog;
  faFlask = faFlask;
  faFileContract = faFileContract;
  faAnalytics = faAnalytics;
  faCheckCircle = faCheckCircle;
  faExclamationCircle = faExclamationCircle;
  faClock = faClock;
  faComments = faComments;

  showModal: boolean = false;

  // Navigation buttons configuration
  navigationButtons: OverlapButtonConfig[] = [];

  // Badge counts from API
  dashboardCount = 0;
  weeklyWinsCount = 0;
  approvalsCount = 0;
  teamCount = 0;
  catalogCount = 0;
  reportsCount = 0;

  // Legacy counts for activity section
  projectsCount = 0;
  resourcesCount = 0;
  bookmarksCount = 0;
  myProjectsCount = 0;
  favoritesCount = 0;

  private subscription = new Subscription();

  // New properties for dashboard
  showPendingApprovals = false;
  showCreateDropdown = false;
  showCreatePostPopup = false;
  searchQuery = '';

  // Quick Note form fields
  quickNoteTitle: string = '';
  quickNoteContent: string = '';
  quickNoteType: 'notes' | 'quick-wins' | 'documents' = 'notes';
  quickNoteTags: string = '';

  // Statistics
  newItemsCount = 12;
  newItemsTrend = 15;
  unreadPriorityCount = 5;
  completedActionsCount = 28;
  completedActionsProgress = 75;

  // Mock data
  pendingApprovals: PendingApproval[] = [
    {
      id: '1',
      title: 'New FinTech Partnership Proposal',
      type: 'project',
      submittedBy: 'Sarah Johnson',
      submittedByUserId: 'user-1',
      submittedDate: '2 hours ago',
      priority: 'high',
      status: 'pending'
    },
    {
      id: '2',
      title: 'Updated Security Policy Document',
      type: 'document',
      submittedBy: 'Michael Chen',
      submittedByUserId: 'user-2',
      submittedDate: '1 day ago',
      priority: 'medium',
      status: 'pending'
    },
    {
      id: '3',
      title: 'Compliance Framework Update',
      type: 'policy',
      submittedBy: 'Emma Davis',
      submittedByUserId: 'user-3',
      submittedDate: '2 days ago',
      priority: 'low',
      status: 'pending'
    }
  ];

  teamFeed: TeamFeedItem[] = [
    {
      id: '1',
      title: 'Q4 Financial Strategy Document',
      type: 'document',
      sharedBy: 'Sarah Johnson',
      sharedByUserId: 'user-1',
      sharedDate: '2 hours ago',
      description: 'Updated financial strategy for Q4 2025',
      priority: 'high',
      action: 'shared'
    },
    {
      id: '2',
      title: 'API Security Best Practices',
      type: 'guide',
      sharedBy: 'Michael Chen',
      sharedByUserId: 'user-2',
      sharedDate: '4 hours ago',
      description: 'Comprehensive guide for securing financial APIs',
      priority: 'medium',
      action: 'updated'
    },
    {
      id: '3',
      title: 'Digital Transformation Roadmap',
      type: 'project',
      sharedBy: 'Emma Davis',
      sharedByUserId: 'user-3',
      sharedDate: '1 day ago',
      description: 'Strategic roadmap for digital transformation initiatives',
      priority: 'high',
      action: 'shared'
    },
    {
      id: '4',
      title: 'Compliance Framework Update',
      type: 'policy',
      sharedBy: 'Alex Rodriguez',
      sharedByUserId: 'user-4',
      sharedDate: '1 day ago',
      description: 'Updated compliance framework for new regulations',
      priority: 'medium',
      action: 'commented'
    },
    {
      id: '5',
      title: 'Customer Onboarding Process',
      type: 'document',
      sharedBy: 'Lisa Wang',
      sharedByUserId: 'user-5',
      sharedDate: '2 days ago',
      description: 'Streamlined customer onboarding workflow',
      priority: 'low',
      action: 'shared'
    }
  ];

  recommendations: Recommendation[] = [
    {
      id: '1',
      title: 'Best Practices for API Security',
      type: 'article',
      description: 'Essential security measures for financial APIs',
      url: '#'
    },
    {
      id: '2',
      title: 'Digital Transformation Roadmap',
      type: 'resource',
      description: 'Step-by-step guide for fintech innovation',
      url: '#'
    },
    {
      id: '3',
      title: 'Regulatory Compliance Updates',
      type: 'article',
      description: 'Latest changes in financial regulations',
      url: '#'
    }
  ];

  quickWins = [
    { title: 'Review pending documents', icon: faFileAlt },
    { title: 'Update team status', icon: faUsers },
    { title: 'Check system alerts', icon: faBell },
    { title: 'Schedule team meeting', icon: faCalendarAlt }
  ];

  bookmarkedItems: BookmarkedItem[] = [
    {
      id: '1',
      title: 'FinTech Innovation Framework',
      type: 'project',
      bookmarkedDate: '2 days ago'
    },
    {
      id: '2',
      title: 'API Documentation Standards',
      type: 'document',
      bookmarkedDate: '1 week ago'
    },
    {
      id: '3',
      title: 'Risk Management Protocol',
      type: 'document',
      bookmarkedDate: '2 weeks ago'
    }
  ];

  // Current user information
  currentUser: User | null = null;

  constructor(
    private router: Router,
    private catalogService: CatalogService,
    private userService: UserService,
    private authService: AuthService
  ) { }

  ngOnInit(): void {
    this.currentUser = this.authService.getCurrentUserValue();
    this.setupNavigationButtons();
    this.loadUserCounts();
    this.loadTeamFeed(); // Replace loadRecentActivity
    this.initializeChart();
    this.loadTeamUpdates();
    this.loadApprovalQueue(); // Load approval queue on init
  }

  ngOnDestroy(): void {
    this.subscription.unsubscribe();
  }

  /**
   * Navigate to a specific route
   */
  navigateTo(route: string): void {
    console.log('Navigating to:', route);
    switch (route) {
      case 'notifications':
        this.router.navigate(['/user/notifications']);
        break;
      case 'assets':
        this.router.navigate(['/user/catalog-list/assets']);
        break;
      case 'quick-wins':
        this.router.navigate(['/user/catalog-list/quick-wins']);
        break;
      default:
        this.router.navigate(['/user', route]);
        break;
    }
  }

  /**
   * Toggle pending approvals section
   */
  togglePendingApprovals(): void {
    this.showPendingApprovals = !this.showPendingApprovals;
  }

  /**
   * Toggle create dropdown
   */
  toggleCreateDropdown(): void {
    this.showCreateDropdown = !this.showCreateDropdown;
  }

  /**
   * Open create post popup
   */
  openCreatePostPopup(): void {
    this.showCreatePostPopup = true;
  }

  /**
   * Close create post popup
   */
  closeCreatePostPopup(): void {
    this.showCreatePostPopup = false;
    this.resetQuickNoteForm();
  }

  /**
   * Perform search operation
   */
  performSearch(): void {
    if (this.searchQuery.trim()) {
      console.log('Searching for:', this.searchQuery);
      this.router.navigate(['/user/catalog'], {
        queryParams: { search: this.searchQuery }
      });
    }
  }

  /**
   * Create new item of specified type
   */
  createNew(type: string): void {
    console.log('Creating new:', type);
    this.showCreateDropdown = false;
    this.router.navigate(['/user/catalog/create'], {
      queryParams: { type }
    });
  }

  /**
   * Submit create post form
   */
  submitCreatePost(): void {
    this.createQuickNote();
  }

  /**
   * Create a Quick Note item
   */
  createQuickNote(): void {
    if (!this.quickNoteTitle.trim() || !this.quickNoteContent.trim()) {
      alert('Please fill in both title and content fields.');
      return;
    }

    const quickNoteData = {
      title: this.quickNoteTitle,
      description: this.quickNoteContent.trimStart().split(/\s+/).slice(0, 20).join(' ') + '...',
      content: this.quickNoteContent,
      type: this.quickNoteType as 'notes' | 'quick-wins' | 'documents',
      category: '',
      tags: this.quickNoteTags ? this.quickNoteTags.split(',').map(tag => tag.trim()) : [],
      status: 'draft',
      author: this.currentUser ? `${this.currentUser.first_name} ${this.currentUser.last_name}` : 'Unknown Author',
      author_id: this.currentUser?.id || '',
      created_date: new Date().toISOString(),
      updated_date: new Date().toISOString()
    };

    this.catalogService.createCatalogItem(quickNoteData).subscribe({
      next: (newItem) => {
        console.log('Quick Note created successfully:', newItem.title, 'New ID:', newItem.id);
        this.resetQuickNoteForm();
        this.closeCreatePostPopup();
      },
      error: (error) => {
        console.error('Failed to create Quick Note:', error);
        alert('Failed to create Quick Note. Please try again.');
      }
    });
  }

  /**
   * Reset Quick Note form fields
   */
  private resetQuickNoteForm(): void {
    this.quickNoteTitle = '';
    this.quickNoteContent = '';
    this.quickNoteType = 'notes';
    this.quickNoteTags = '';
  }

  /**
   * Setup navigation buttons configuration
   */
  private setupNavigationButtons(): void {
    this.navigationButtons = HOME_NAVIGATION_BUTTONS.map(buttonConfig => ({
      ...buttonConfig,
      badgeCount: this.getBadgeCountForRoute(buttonConfig.route)
    }));
  }

  /**
   * Get badge count for a specific route
   */
  private getBadgeCountForRoute(route: string): number {
    switch (route) {
      case 'dashboard':
        return this.dashboardCount;
      case 'weekly-wins':
        return this.weeklyWinsCount;
      case 'approvals':
        return this.approvalsCount;
      case 'team':
        return this.teamCount;
      case 'catalog':
        return this.catalogCount;
      case 'reports':
        return this.reportsCount;
      default:
        return 0;
    }
  }

  /**
   * Update navigation buttons with latest counts
   */
  private updateNavigationButtons(): void {
    this.navigationButtons.forEach(button => {
      button.badgeCount = this.getBadgeCountForRoute(button.route || '');
    });
  }

  /**
   * Load user dashboard counts from API
   */
  private loadUserCounts(): void {
    this.subscription.add(
      forkJoin({
        projects: this.catalogService.getCatalogItems({ type: 'project', limit: 1 }),
        resources: this.catalogService.getCatalogItems({ type: 'document', limit: 1 }),
        pendingApprovals: this.loadPendingApprovals()
      }).subscribe({
        next: (results) => {
          this.projectsCount = results.projects.total || 0;
          this.resourcesCount = results.resources.total || 0;
          this.catalogCount = this.projectsCount + this.resourcesCount;

          // Update pending approvals with real data
          this.pendingApprovals = results.pendingApprovals;
          this.approvalsCount = this.pendingApprovals.length;

          // Set navigation badge counts
          this.dashboardCount = this.calculateUserDashboardItems();
          this.weeklyWinsCount = this.calculateWeeklyWinsCount();
          this.teamCount = this.calculateTeamCount();
          this.reportsCount = this.calculateReportsCount();

          // Set activity section counts
          this.bookmarksCount = this.calculateBookmarksCount();
          this.myProjectsCount = this.calculateMyProjectsCount();
          this.favoritesCount = this.calculateFavoritesCount();

          // Update navigation buttons with new counts
          this.updateNavigationButtons();
        },
        error: (error) => {
          console.error('Failed to load user counts:', error);
          // Set fallback values and update navigation buttons
          this.updateNavigationButtons();
        }
      })
    );
  }

  /**
   * Load pending approvals where current user is the manager
   */
  private loadPendingApprovals(): Observable<PendingApproval[]> {
    const currentUser = this.authService.getCurrentUserValue();
    if (!currentUser) {
      return of([]);
    }

    return this.catalogService.searchCatalogItems({
      status: 'pending_approval',
      limit: 50
    }).pipe(
      map(response => {
        const filteredItems = response.items?.filter(item => {
          return item.approved_by === currentUser.user_id ||
            item.approved_by === currentUser.id ||
            item.approved_by === currentUser.email;
        }) || [];

        return filteredItems.map(item => this.transformCatalogToPendingApproval(item));
      }),
      catchError(error => {
        console.error('Error loading pending approvals:', error);
        return of([]);
      })
    );
  }

  /**
   * Transform catalog item to PendingApproval interface
   */
  private transformCatalogToPendingApproval(catalog: Catalog): PendingApproval {
    const submittedDate = this.formatRelativeTime(catalog.created_date || catalog.updated_date);
    const priority = this.determinePriority(catalog);
    const submittedBy = catalog.author || 'Unknown';
    const submittedByUserId = catalog.author_id || '';

    return {
      id: catalog.id,
      title: catalog.title || 'Untitled',
      type: catalog.type || 'document',
      submittedBy,
      submittedByUserId,
      submittedDate,
      priority,
      status: catalog.status || 'pending_approval',
      description: catalog.description,
      content: catalog.content
    };
  }

  /**
   * Determine priority based on catalog properties
   */
  private determinePriority(catalog: Catalog): 'high' | 'medium' | 'low' {
    if (catalog.priority) {
      return catalog.priority as 'high' | 'medium' | 'low';
    }

    if (catalog.urgent || catalog.important) {
      return 'high';
    }

    if (catalog.expire_date || catalog.due_date) {
      const targetDate = new Date(catalog.expire_date || catalog.due_date!);
      const now = new Date();
      const daysUntilDue = Math.ceil((targetDate.getTime() - now.getTime()) / (1000 * 60 * 60 * 24));

      if (daysUntilDue <= 1) {
        return 'high';
      } else if (daysUntilDue <= 7) {
        return 'medium';
      }
    }

    const highPriorityTypes = ['policy', 'compliance', 'security', 'legal'];
    if (highPriorityTypes.includes(catalog.type?.toLowerCase() || '')) {
      return 'high';
    }

    return 'low';
  }

  /**
   * Format relative time for display
   */
  private formatRelativeTime(dateString?: string): string {
    if (!dateString) {
      return 'Unknown time';
    }

    const date = new Date(dateString);
    const now = new Date();
    const diffInMs = now.getTime() - date.getTime();
    const diffInMinutes = Math.floor(diffInMs / (1000 * 60));
    const diffInHours = Math.floor(diffInMinutes / 60);
    const diffInDays = Math.floor(diffInHours / 24);

    if (diffInMinutes < 1) {
      return 'Just now';
    } else if (diffInMinutes < 60) {
      return `${diffInMinutes} minute${diffInMinutes !== 1 ? 's' : ''} ago`;
    } else if (diffInHours < 24) {
      return `${diffInHours} hour${diffInHours !== 1 ? 's' : ''} ago`;
    } else if (diffInDays < 7) {
      return `${diffInDays} day${diffInDays !== 1 ? 's' : ''} ago`;
    } else {
      return date.toLocaleDateString();
    }
  }

  /**
   * Load team feed - items shared with the current user
   */
  private loadTeamFeed(): void {
    const currentUser = this.authService.getCurrentUserValue();
    if (!currentUser) {
      return;
    }

    this.subscription.add(
      this.catalogService.getCatalogItems({
        limit: 20,
        sort: 'updated_date',
        order: 'desc'
      }).subscribe({
        next: (response) => {
          const sharedItems = response.items?.filter(item => {
            return item.shared_with_ids &&
              item.shared_with_ids.includes(currentUser.user_id || currentUser.id || currentUser.email || '');
          }) || [];

          this.teamFeed = sharedItems
            .slice(0, 10)
            .map(item => this.transformCatalogToTeamFeedItem(item));
        },
        error: (error) => {
          console.error('Failed to load team feed:', error);
          this.teamFeed = this.getMockTeamFeed();
        }
      })
    );
  }

  /**
   * Transform catalog item to team feed item
   */
  private transformCatalogToTeamFeedItem(catalog: Catalog): TeamFeedItem {
    const sharedDate = this.formatRelativeTime(catalog.updated_date || catalog.created_date);

    return {
      id: catalog.id,
      title: catalog.title || 'Untitled',
      type: catalog.type || 'document',
      sharedBy: catalog.author || 'Unknown',
      sharedByUserId: catalog.author_id || '',
      sharedDate,
      description: catalog.description,
      priority: catalog.priority,
      action: 'shared'
    };
  }

  /**
   * Get mock team feed data as fallback
   */
  private getMockTeamFeed(): TeamFeedItem[] {
    return [
      {
        id: '1',
        title: 'Q4 Financial Strategy Document',
        type: 'document',
        sharedBy: 'Sarah Johnson',
        sharedByUserId: 'user-1',
        sharedDate: '2 hours ago',
        description: 'Updated financial strategy for Q4 2025',
        priority: 'high',
        action: 'shared'
      },
      {
        id: '2',
        title: 'API Security Best Practices',
        type: 'guide',
        sharedBy: 'Michael Chen',
        sharedByUserId: 'user-2',
        sharedDate: '4 hours ago',
        description: 'Comprehensive guide for securing financial APIs',
        priority: 'medium',
        action: 'updated'
      },
      {
        id: '3',
        title: 'Digital Transformation Roadmap',
        type: 'project',
        sharedBy: 'Emma Davis',
        sharedByUserId: 'user-3',
        sharedDate: '1 day ago',
        description: 'Strategic roadmap for digital transformation initiatives',
        priority: 'high',
        action: 'shared'
      },
      {
        id: '4',
        title: 'Compliance Framework Update',
        type: 'policy',
        sharedBy: 'Alex Rodriguez',
        sharedByUserId: 'user-4',
        sharedDate: '1 day ago',
        description: 'Updated compliance framework for new regulations',
        priority: 'medium',
        action: 'commented'
      },
      {
        id: '5',
        title: 'Customer Onboarding Process',
        type: 'document',
        sharedBy: 'Lisa Wang',
        sharedByUserId: 'user-5',
        sharedDate: '2 days ago',
        description: 'Streamlined customer onboarding workflow',
        priority: 'low',
        action: 'shared'
      }
    ];
  }

  /**
   * Initialize chart for content distribution
   */
  private initializeChart(): void {
    console.log('Chart initialization - to be implemented with Chart.js');
  }

  /**
   * Calculate dashboard items count
   */
  private calculateUserDashboardItems(): number {
    return this.projectsCount + this.resourcesCount + this.pendingApprovals.length;
  }

  /**
   * Calculate weekly wins count
   */
  private calculateWeeklyWinsCount(): number {
    return Math.floor(this.completedActionsCount * 0.3);
  }

  /**
   * Calculate team count
   */
  private calculateTeamCount(): number {
    return this.teamFeed.length;
  }

  /**
   * Calculate reports count
   */
  private calculateReportsCount(): number {
    return 3;
  }

  /**
   * Calculate bookmarks count
   */
  private calculateBookmarksCount(): number {
    return this.bookmarkedItems.length;
  }

  /**
   * Calculate my projects count
   */
  private calculateMyProjectsCount(): number {
    return this.projectsCount;
  }

  /**
   * Calculate favorites count
   */
  private calculateFavoritesCount(): number {
    return Math.floor(this.catalogCount * 0.2);
  }

  @Input() smartListPosts: SmartListPost[] = [];
  @Input() approvalQueuePosts: SmartListPost[] = [];

  // Mock data for SmartListPost
  mockSmartListPosts: SmartListPost[] = [
    {
      id: 'mock-1', // Add mock ID
      title: 'How to Secure Your API',
      content: 'Learn the best practices for securing your financial APIs and protecting sensitive data from threats. This guide covers authentication, authorization, and encryption.',
      postedBy: 'Sarah Johnson',
      time: '2 hours ago'
    },
    {
      id: 'mock-2', // Add mock ID
      title: 'Digital Transformation Roadmap',
      content: 'A step-by-step approach to digital transformation in fintech. Discover the key milestones and strategies for successful implementation.',
      postedBy: 'Michael Chen',
      time: '4 hours ago'
    },
    {
      id: 'mock-3', // Add mock ID
      title: 'Regulatory Compliance Updates',
      content: 'Stay up to date with the latest changes in financial regulations and compliance requirements for your organization.',
      postedBy: 'Emma Davis',
      time: '1 day ago'
    },
    {
      id: 'mock-4', // Add mock ID
      title: 'Customer Onboarding Process',
      content: 'Streamline your customer onboarding workflow with these proven techniques and tools for better user experience.',
      postedBy: 'Lisa Wang',
      time: '2 days ago'
    },
    {
      id: 'mock-5', // Add mock ID
      title: 'Risk Management Protocol',
      content: 'Implement effective risk management protocols to safeguard your business from potential threats and losses.',
      postedBy: 'Alex Rodriguez',
      time: '3 days ago'
    }
  ];

  // Other utility methods...
  getActivityIcon(action: string): any {
    switch (action) {
      case 'shared': return this.faShare;
      case 'updated': return this.faEdit;
      case 'commented': return this.faComments;
      case 'created': return this.faPlus;
      case 'approved': return this.faCheck;
      default: return this.faFileAlt;
    }
  }

  getApprovalTypeIcon(type: string): any {
    const typeIconMap: { [key: string]: any } = {
      'assets': this.faFolder,
      'documents': this.faFileAlt,
      'policy': this.faFileContract,
      'article': this.faNewspaper,
      'guide': this.faBook,
      'tutorial': this.faGraduationCap,
      'blog': this.faBlog,
      'research': this.faFlask,
      'reports': this.faAnalytics,
      'notifications': this.faBell,
      'resource': this.faBookmark
    };
    return typeIconMap[type] || this.faFileAlt;
  }

  /**
   * Load team updates for the current user using the new dedicated team shares endpoint
   */
  loadTeamUpdates(): void {
    const currentUser = this.authService.getCurrentUserValue();
    if (!currentUser) {
      console.log('No current user found, using mock data for team updates');
      this.smartListPosts = this.transformMockDataToCatalogTypeItems();
      return;
    }

    console.log('🔍 [DEBUG] Loading team updates for user:', currentUser.user_id || currentUser.id);
    
    this.subscription.add(
      this.catalogService.getTeamShares({
        limit: 10,
        sort: 'created_date',
        order: 'desc'
      }).subscribe({
        next: (response) => {
          console.log('🔍 [DEBUG] Team shares API response:', response);
          console.log('🔍 [DEBUG] Team shares items count:', response.items?.length || 0);
          
          // Transform Catalog items to SmartListPost format for the smart-list component
          this.smartListPosts = response.items?.map((item: Catalog) => this.transformCatalogToSmartListPost(item)) || [];
          
          console.log('🔍 [DEBUG] Transformed smartListPosts:', this.smartListPosts);
          console.log(`✅ Loaded ${this.smartListPosts.length} team shares from dedicated endpoint`);
          
          // Fallback to mock data if no real data
          if (this.smartListPosts.length === 0) {
            console.log('⚠️ No team shares found, using mock data');
            this.smartListPosts = this.transformMockDataToCatalogTypeItems();
          }
          
          // Update team count for navigation badge
          this.teamCount = response.total || this.smartListPosts.length;
          this.updateNavigationButtons();
        },
        error: (error) => {
          console.error('❌ Failed to load team shares from dedicated endpoint:', error);
          // Fallback to mock data if API fails
          this.smartListPosts = this.transformMockDataToCatalogTypeItems();
          console.log('🔍 [DEBUG] Using mock team shares data:', this.smartListPosts);
        }
      })
    );
  }

  /**
   * Load approval queue for the current user using the new dedicated approval queue endpoint
   */
  loadApprovalQueue(): void {
    const currentUser = this.authService.getCurrentUserValue();
    if (!currentUser) {
      console.log('No current user found, using mock data for approval queue');
      this.approvalQueuePosts = this.getMockApprovalQueue();
      return;
    }

    console.log('🔍 [DEBUG] Loading approval queue for user:', currentUser.user_id || currentUser.id);

    this.subscription.add(
      this.catalogService.getApprovalQueue({
        limit: 10,
        sort: 'created_date',
        order: 'desc'
      }).subscribe({
        next: (response) => {
          console.log('🔍 [DEBUG] Approval queue API response:', response);
          console.log('🔍 [DEBUG] Approval queue items count:', response.items?.length || 0);
          
          // Transform Catalog items to SmartListPost format for the smart-list component
          this.approvalQueuePosts = response.items?.map((item: Catalog) => this.transformCatalogToSmartListPost(item)) || [];
          
          console.log('🔍 [DEBUG] Transformed approvalQueuePosts:', this.approvalQueuePosts);
          console.log(`✅ Loaded ${this.approvalQueuePosts.length} approval queue items from dedicated endpoint`);
          
          // Fallback to mock data if no real data
          if (this.approvalQueuePosts.length === 0) {
            console.log('⚠️ No approval queue items found, using mock data');
            this.approvalQueuePosts = this.getMockApprovalQueue();
          }
          
          // Update approvals count for navigation badge
          this.approvalsCount = response.total || this.approvalQueuePosts.length;
          this.updateNavigationButtons();
        },
        error: (error) => {
          console.error('❌ Failed to load approval queue from dedicated endpoint:', error);
          // Fallback to mock data if API fails
          this.approvalQueuePosts = this.getMockApprovalQueue();
          console.log('🔍 [DEBUG] Using mock approval queue data:', this.approvalQueuePosts);
        }
      })
    );
  }

  /**
   * Transform Catalog item to SmartListPost interface
   */
  private transformCatalogToSmartListPost(item: Catalog): SmartListPost {
    // Try to get author name from multiple possible sources
    let authorName = 'Unknown';
    
    if (item.author && item.author.trim()) {
      authorName = item.author;
    } else if (item.author_id) {
      // If we have author_id but no author name, we could potentially look it up
      // For now, just use the ID as fallback
      authorName = `User ${item.author_id}`;
    }

    return {
      id: item.id, // Add ID field for navigation
      title: item.title || 'Untitled',
      content: item.content || item.description || 'No content available',
      postedBy: authorName,
      time: this.formatRelativeTime(item.created_date || item.updated_date),
      category: item.category,
      type: item.type,
      created_date: item.created_date,
      updated_date: item.updated_date,
      status: item.status, // Add status field
      read: item.read || false // Map the read flag from the API response
    };
  }

  /**
   * Transform mock data to CatalogTypeItem format as fallback
   */
  private transformMockDataToCatalogTypeItems(): SmartListPost[] {
    return this.mockSmartListPosts;
  }

  /**
   * Get mock approval queue data as fallback
   */
  private getMockApprovalQueue(): SmartListPost[] {
    return [
      {
        id: 'mock-approval-1', // Add mock ID
        title: 'New FinTech Partnership Proposal',
        content: 'Comprehensive proposal for strategic partnership with emerging fintech companies to expand our digital banking services.',
        postedBy: 'Sarah Johnson',
        time: '2 hours ago'
      },
      {
        id: 'mock-approval-2', // Add mock ID
        title: 'Updated Security Policy Document',
        content: 'Revised security policies incorporating latest industry standards and regulatory requirements for data protection.',
        postedBy: 'Michael Chen',
        time: '1 day ago'
      },
      {
        id: 'mock-approval-3', // Add mock ID
        title: 'Compliance Framework Update',
        content: 'Updated compliance framework to align with new financial regulations and industry best practices.',
        postedBy: 'Emma Davis',
        time: '2 days ago'
      }
    ];
  }

  /**
   * Handle approve item action from smart-list
   */
  onApproveItem(post: SmartListPost): void {
    console.log('Approving item:', post.id, post.title);
    
    // Call the catalog service to approve the item
    this.subscription.add(
      this.catalogService.approveCatalogItem(post.id).subscribe({
        next: (approvedItem) => {
          console.log('✅ Item approved successfully:', approvedItem.title);
          
          // Remove the approved item from the approval queue
          this.approvalQueuePosts = this.approvalQueuePosts.filter(item => item.id !== post.id);
          
          // Update the approvals count
          this.approvalsCount = this.approvalQueuePosts.length;
          this.updateNavigationButtons();
          
          // Show success message
          alert(`Successfully approved: ${post.title}`);
        },
        error: (error) => {
          console.error('❌ Failed to approve item:', error);
          alert('Failed to approve item. Please try again.');
        }
      })
    );
  }
}
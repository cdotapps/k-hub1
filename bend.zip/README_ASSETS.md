# SharePoint Asset Management System

A comprehensive asset management system that integrates directly with SharePoint lists, allowing you to manage your organization's assets through a modern REST API while keeping all data in SharePoint.

## 🎯 Key Features

- **Direct SharePoint Integration**: All asset data lives in SharePoint - no local database required
- **Complete CRUD Operations**: Create, Read, Update, Delete assets via REST API
- **Advanced Search & Filtering**: Search assets by business unit, type, status, owner, and more
- **Asset Statistics**: Real-time statistics and reporting
- **Size Attributes**: Flexible JSON-based size tracking for different asset types
- **Asset Lifecycle Management**: Track status from active to decommissioned
- **Authentication & Authorization**: Secure API with user authentication
- **Modern FastAPI**: Fast, reliable API with automatic OpenAPI documentation

## 📊 Asset Attributes

Each asset can have the following attributes:

### Core Attributes
- **Asset ID**: Unique business identifier
- **Asset Name**: Descriptive name
- **Business**: Business unit or division
- **Block**: Department or sub-division
- **Capability**: Capability area or function
- **Asset Type**: Hardware, Software, Service, Infrastructure, etc.
- **Asset Status**: Active, Inactive, Maintenance, Decommissioned, etc.

### Size & Technical Attributes
- **Size Attributes**: JSON object for flexible size tracking (CPU, RAM, storage, etc.)
- **Description**: Detailed description
- **Location**: Physical or logical location
- **Vendor**: Manufacturer or vendor
- **Model**: Model number or name
- **Version**: Version information

### Ownership & Contact
- **Owner**: Asset owner
- **Contact Person**: Primary contact
- **Contact Email**: Contact email address

### Financial & Risk
- **Cost**: Asset cost/value
- **Currency**: Currency (default: USD)
- **Risk Level**: Low, Medium, High, Critical
- **Criticality**: Business criticality level

### Metadata
- **Tags**: JSON array of tags for categorization
- **Created/Modified**: Automatically tracked by SharePoint
- **Author/Editor**: Automatically tracked by SharePoint

## 🚀 Quick Start

### 1. Set Up SharePoint List

Follow the detailed setup guide in `SHAREPOINT_ASSET_SETUP.md` to:
- Create the SharePoint list with required columns
- Set up Azure AD app registration
- Configure permissions

### 2. Install Dependencies

```bash
pip install -r requirements.txt
```

### 3. Configure SharePoint Connection

**Option A: Use the setup helper**
```bash
python setup_sharepoint.py
```

**Option B: Manual configuration**
```bash
# Copy the template
cp .env.template .env

# Edit .env file with your SharePoint settings
SHAREPOINT_SITE_URL=https://yourcompany.sharepoint.com/sites/yoursite
SHAREPOINT_LIST_NAME=Assets
SHAREPOINT_CLIENT_ID=your-azure-app-client-id
SHAREPOINT_CLIENT_SECRET=your-azure-app-client-secret
SHAREPOINT_TENANT_ID=your-tenant-id
```

### 4. Start the Server

```bash
python main.py
```

The server will start on `http://localhost:8000` and automatically connect to SharePoint using your environment configuration.

### 5. Test Connection

```bash
curl -X POST "http://localhost:8000/api/v1/assets/test-connection" \
  -H "Authorization: Bearer YOUR_TOKEN"
```

## 📚 API Endpoints

### Configuration
- `GET /api/v1/assets/config-info` - Get SharePoint configuration status
- `POST /api/v1/assets/test-connection` - Test SharePoint connection

### Asset Management
- `GET /api/v1/assets/` - Get all assets
- `GET /api/v1/assets/asset-id/{asset_id}` - Get asset by business ID
- `GET /api/v1/assets/sp-id/{sp_id}` - Get asset by SharePoint ID
- `POST /api/v1/assets/` - Create new asset
- `PUT /api/v1/assets/sp-id/{sp_id}` - Update asset
- `DELETE /api/v1/assets/sp-id/{sp_id}` - Delete asset

### Search & Analytics
- `GET /api/v1/assets/search` - Search assets with filters
- `GET /api/v1/assets/statistics` - Get asset statistics

## 🔍 Search & Filtering

The search endpoint supports multiple filters:

```bash
# Search by business unit
GET /api/v1/assets/search?business=IT

# Search by asset type and status
GET /api/v1/assets/search?asset_type=Hardware&asset_status=Active

# Search by owner
GET /api/v1/assets/search?owner=John%20Doe

# General text search
GET /api/v1/assets/search?search_term=server

# Combined filters
GET /api/v1/assets/search?business=IT&asset_type=Hardware&search_term=production
```

## 📊 Asset Statistics

Get comprehensive statistics about your assets:

```json
{
  "total_assets": 245,
  "by_status": {
    "Active": 189,
    "Inactive": 23,
    "Maintenance": 12,
    "Decommissioned": 21
  },
  "by_type": {
    "Hardware": 145,
    "Software": 67,
    "Service": 23,
    "Infrastructure": 10
  },
  "by_business": {
    "IT": 89,
    "Finance": 45,
    "HR": 34,
    "Operations": 77
  }
}
```

## 💾 Example Asset Data

```json
{
  "AssetID": "SRV-001",
  "AssetName": "Production Web Server",
  "Business": "IT",
  "Block": "Infrastructure",
  "Capability": "Web Services",
  "AssetType": "Hardware",
  "AssetStatus": "Active",
  "SizeAttributes": "{\"cpu_cores\": 16, \"ram_gb\": 64, \"storage_tb\": 4}",
  "Description": "Primary web server for company website",
  "Location": "Data Center A",
  "Owner": "IT Operations",
  "ContactPerson": "Jane Smith",
  "ContactEmail": "jane.smith@company.com",
  "Cost": 8500.0,
  "Currency": "USD",
  "Vendor": "HPE",
  "Model": "ProLiant DL380",
  "Version": "Gen10",
  "Tags": "[\"server\", \"web\", \"production\"]",
  "RiskLevel": "Medium",
  "Criticality": "High"
}
```

## 🔐 Authentication

All endpoints require authentication. First, authenticate to get a bearer token:

```bash
curl -X POST "http://localhost:8000/api/v1/auth/login" \
  -H "Content-Type: application/json" \
  -d '{
    "username": "your_username",
    "password": "your_password"
  }'
```

Then include the token in subsequent requests:

```bash
curl -H "Authorization: Bearer YOUR_TOKEN" \
  "http://localhost:8000/api/v1/assets/"
```

## 🌐 API Documentation

- **Interactive Documentation**: `http://localhost:8000/docs`
- **OpenAPI Specification**: `http://localhost:8000/openapi.json`
- **ReDoc Documentation**: `http://localhost:8000/redoc`

## 🧪 Testing

### Test Scripts

- `test_sharepoint_assets.py` - Direct service testing
- `api_usage_example.py` - API endpoint examples

### Run Tests

```bash
# Test SharePoint service directly
python test_sharepoint_assets.py

# View API usage examples
python api_usage_example.py
```

## 📁 Project Structure

```
app/
├── api/v1/endpoints/
│   └── assets.py              # Asset management endpoints
├── services/
│   └── sharepoint_asset_service.py  # SharePoint integration service
├── models/
│   └── user.py               # User authentication models
└── ...

test_sharepoint_assets.py     # Service test script
api_usage_example.py          # API usage examples
SHAREPOINT_ASSET_SETUP.md     # Detailed setup guide
requirements.txt              # Python dependencies
```

## 🔧 Configuration

### Environment Variables

Set these environment variables or include them in a `.env` file:

```bash
# Application settings
SECRET_KEY=your-secret-key
ACCESS_TOKEN_EXPIRE_MINUTES=30

# Database (for user authentication)
DATABASE_URL=sqlite:///./app.db
```

### SharePoint Configuration

SharePoint settings are configured via the API configuration endpoint and include:

- **Site URL**: Your SharePoint site URL
- **List Name**: Name of the SharePoint list (e.g., "Assets")
- **Client ID**: Azure AD app registration client ID
- **Client Secret**: Azure AD app registration client secret
- **Tenant ID**: Your Azure AD tenant ID

## 🆘 Troubleshooting

### Common Issues

1. **Authentication Failed**
   - Check Azure AD app registration settings
   - Verify client ID, client secret, and tenant ID
   - Ensure app has proper SharePoint permissions

2. **List Not Found**
   - Verify SharePoint list name matches configuration
   - Check that the list exists and is accessible
   - Ensure app has permissions to the SharePoint site

3. **Column Missing**
   - Verify all required columns exist in SharePoint list
   - Check column names match exactly (case-sensitive)
   - Refer to `SHAREPOINT_ASSET_SETUP.md` for column setup

4. **Token Expired**
   - The service automatically refreshes tokens
   - Check system clock synchronization
   - Verify token expiration settings

### Debug Mode

Enable debug logging by setting the log level:

```python
import logging
logging.basicConfig(level=logging.DEBUG)
```

## 📞 Support

For setup assistance and troubleshooting:

1. Check the detailed setup guide: `SHAREPOINT_ASSET_SETUP.md`
2. Review the API documentation: `http://localhost:8000/docs`
3. Run the test scripts to verify your setup
4. Check the server logs for detailed error messages

## 🚀 Deployment

For production deployment:

1. Use a production WSGI server (e.g., Gunicorn)
2. Set up proper environment variables
3. Configure HTTPS
4. Set up monitoring and logging
5. Configure SharePoint app permissions for production

## 📝 License

This project is available under the MIT License.

from typing import Optional, List, Dict, Any
from pydantic import BaseModel, Field, HttpUrl
from datetime import datetime

class WebhookBase(BaseModel):
    name: str = Field(..., description="User-friendly name for the webhook")
    url: HttpUrl = Field(..., description="Target URL to call")
    events: List[str] = Field(..., description="List of events to subscribe to")
    secret: Optional[str] = Field(None, description="Secret for webhook signature verification")
    headers: Optional[Dict[str, str]] = Field(None, description="Additional headers to send")
    active: bool = Field(True, description="Whether webhook is active")
    filters: Optional[Dict[str, Any]] = Field(None, description="Conditions for when to trigger webhook")

class WebhookCreate(WebhookBase):
    pass

class WebhookUpdate(BaseModel):
    name: Optional[str] = None
    url: Optional[HttpUrl] = None
    events: Optional[List[str]] = None
    secret: Optional[str] = None
    headers: Optional[Dict[str, str]] = None
    active: Optional[bool] = None
    filters: Optional[Dict[str, Any]] = None

class WebhookInDBBase(WebhookBase):
    id: str
    status: str
    created_by: str
    created_date: datetime
    updated_date: Optional[datetime] = None
    last_triggered: Optional[datetime] = None
    success_count: str
    failure_count: str

    class Config:
        from_attributes = True

class Webhook(WebhookInDBBase):
    pass

class WebhookDeliveryBase(BaseModel):
    webhook_id: str
    event_type: str
    payload: Dict[str, Any]
    response_status: Optional[str] = None
    response_body: Optional[str] = None
    error_message: Optional[str] = None
    attempts: str = "1"
    success: bool = False

class WebhookDeliveryCreate(WebhookDeliveryBase):
    pass

class WebhookDelivery(WebhookDeliveryBase):
    id: str
    delivered_at: datetime

    class Config:
        from_attributes = True

class WebhookEventPayload(BaseModel):
    event: str = Field(..., description="Event type (e.g., catalog.created)")
    timestamp: datetime = Field(..., description="When the event occurred")
    data: Dict[str, Any] = Field(..., description="Event data")
    webhook: Dict[str, str] = Field(..., description="Webhook metadata")

class WebhookTestPayload(BaseModel):
    test: bool = True
    message: str = "This is a test webhook delivery"
    webhook_id: str
    timestamp: datetime

class Msg(BaseModel):
    msg: str
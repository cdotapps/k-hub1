from typing import Optional
from pydantic import BaseModel, EmailStr
from datetime import datetime
from app.models.user import UserRole

class UserBase(BaseModel):
    user_id: Optional[str] = None
    email: Optional[EmailStr] = None
    first_name: Optional[str] = None
    last_name: Optional[str] = None
    is_active: Optional[bool] = True
    role: Optional[UserRole] = UserRole.USER
    is_superuser: Optional[bool] = False
    email_verified: Optional[bool] = False
    manager_id: Optional[str] = None
    portfolio_id: Optional[str] = None
    organization_id: Optional[str] = None
    costcenter_id: Optional[str] = None
    user_type: Optional[str] = None
    designation: Optional[str] = "associate"

class UserCreate(UserBase):
    user_id: str
    password: str
    first_name: str
    last_name: str

class UserUpdate(UserBase):
    password: Optional[str] = None

class UserProfileUpdate(BaseModel):
    """Schema for users to update their own profiles"""
    first_name: Optional[str] = None
    last_name: Optional[str] = None
    email: Optional[EmailStr] = None
    manager_id: Optional[str] = None
    portfolio_id: Optional[str] = None
    organization_id: Optional[str] = None
    costcenter_id: Optional[str] = None
    user_type: Optional[str] = None
    designation: Optional[str] = None

class UserAdminUpdate(UserBase):
    """Schema for admin users to update any user"""
    pass

class ManagerInfo(BaseModel):
    id: str
    user_id: str
    first_name: str
    last_name: str
    designation: Optional[str] = None
    
    class Config:
        from_attributes = True

class UserInDBBase(UserBase):
    id: str
    created_date: datetime
    updated_date: Optional[datetime] = None
    last_login: Optional[datetime] = None
    manager: Optional[ManagerInfo] = None

    class Config:
        from_attributes = True

class User(UserInDBBase):
    pass

class UserInDB(UserInDBBase):
    hashed_password: str

class TokenUser(BaseModel):
    id: str
    user_id: str
    email: Optional[str] = None
    first_name: str
    last_name: str
    role: UserRole
    designation: Optional[str] = None

class Token(BaseModel):
    access_token: str
    refresh_token: str
    token_type: str = "bearer"
    user: TokenUser

class TokenPayload(BaseModel):
    sub: str
    exp: int
    type: str = "access"

class LoginRequest(BaseModel):
    user_id: str
    password: str

class Msg(BaseModel):
    msg: str